#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Category-theory pass over the bit rule.  Question asked: what do the categorical notions (monoidal categories, Morita and Brauer-Wall classes, Frobenius structures,
cube categories, Euler forms of quivers) say about the atlas, starting from the label "0" (the generator whose square is 0) and going up one dimension at a time?
Every statement below is computed with exact arithmetic (integers, fractions, GF(2), Gaussian integers) unless a message says "numerical".  What the four attached papers say is not tested here (it is
quoted in the report with page references); only what the label rule gives is computed.  Standard facts that are recalled but not re-proved are marked "recalled" in the messages.
Python standard library + numpy.   Run: python3 cat_check.py
Shipped in the webapp package as selfcheck/reports/cat_check.py: needs bitcliff.py at <package>/selfcheck/steps15_17 (default: the package two levels up from this script; override with the environment variable ATLAS_PKG). Python dependencies: numpy (and the standard library). Writes nothing into the package: cat_results.json goes to a temporary folder (printed at the end) unless --write is given, which puts it next to the script."""
import os, sys, math, itertools, random, json, tempfile
from fractions import Fraction as Fr
from collections import Counter, defaultdict
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..'))      # the webapp package: two levels up from selfcheck/reports/
sys.path.insert(0, os.path.join(PKG, 'selfcheck', 'steps15_17'))
from bitcliff import Alg, sig, pc, reorder_sign, TYPES, regular_matrix, rand_mv

N_OK = N_BAD = 0
RES = {}                                                       # numbers the report quotes
def chk(cid, cond, msg=''):
    global N_OK, N_BAD
    if cond: N_OK += 1
    else: N_BAD += 1
    print(('ok   ' if cond else 'FAIL ') + cid + (': ' + msg if msg else ''))

# =====================================================================================================================================================
# 0. Small exact tools
# =====================================================================================================================================================
def nullspace_q(rows, ncols):
    M = [[Fr(x) for x in r] for r in rows]; piv = []; r = 0
    for c in range(ncols):
        pr = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if pr is None: continue
        M[r], M[pr] = M[pr], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [a - f * b for a, b in zip(M[i], M[r])]
        piv.append(c); r += 1
        if r == len(M): break
    basis = []
    for f in (c for c in range(ncols) if c not in piv):
        v = [Fr(0)] * ncols; v[f] = Fr(1)
        for i, c in enumerate(piv): v[c] = -M[i][f]
        basis.append(v)
    return basis
def rank_q(rows, ncols): return ncols - len(nullspace_q(rows, ncols))
def f2_nullspace(rows, ncols):                                   # rows are Python ints (bit j = unknown j)
    piv = {}
    for v in rows:
        for c, rv in piv.items():
            if (v >> c) & 1: v ^= rv
        if v == 0: continue
        c = v.bit_length() - 1
        for c2 in list(piv):
            if (piv[c2] >> c) & 1: piv[c2] ^= v
        piv[c] = v
    basis = []
    for f in (c for c in range(ncols) if c not in piv):
        x = 1 << f
        for c, rv in piv.items():
            if (rv >> f) & 1: x |= 1 << c
        basis.append(x)
    return basis
def f2_rank(rows, ncols): return ncols - len(f2_nullspace(rows, ncols))
def rank_modp(rows, P=1000003):                                  # lower bound for the rank over Q (rank mod P <= rank over Q)
    M = [[int(x) % P for x in r] for r in rows]; rk = 0; ncols = len(M[0])
    for c in range(ncols):
        pr = next((i for i in range(rk, len(M)) if M[i][c]), None)
        if pr is None: continue
        M[rk], M[pr] = M[pr], M[rk]; inv = pow(M[rk][c], P - 2, P); M[rk] = [x * inv % P for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c]:
                f = M[i][c]; M[i] = [(a - f * b) % P for a, b in zip(M[i], M[rk])]
        rk += 1
        if rk == len(M): break
    return rk
def signature_q(G):
    """exact (p, q, r) of a symmetric rational matrix by congruence diagonalisation"""
    A = [[Fr(x) for x in row] for row in G]; n = len(A); pos = neg = zer = 0; idx = list(range(n))
    while A:
        m = len(A)
        k = next((i for i in range(m) if A[i][i] != 0), None)
        if k is None:
            pr = next(((i, j) for i in range(m) for j in range(i + 1, m) if A[i][j] != 0), None)
            if pr is None: zer += m; break
            i, j = pr                                                   # e_i -> e_i + e_j makes a non-zero diagonal entry (2 A_ij)
            for t in range(m): A[i][t] += A[j][t]
            for t in range(m): A[t][i] += A[t][j]
            k = i
        piv = A[k][k]
        pos += piv > 0; neg += piv < 0
        for i in range(m):
            if i != k and A[i][k] != 0:
                f = A[i][k] / piv
                for t in range(m): A[i][t] -= f * A[k][t]
                for t in range(m): A[t][i] -= f * A[t][k]
        A = [[A[i][j] for j in range(m) if j != k] for i in range(m) if i != k]
    return pos, neg, zer
def triples(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]
def bits(a): return [i for i in range(a.bit_length()) if (a >> i) & 1]

# =====================================================================================================================================================
# S. The engine: the bit rule is associative for every choice of the trio (exhaustive for up to four generators)
# =====================================================================================================================================================
bad = 0; tot = 0
for eps in itertools.product((1, -1, 0), repeat=4):
    A = Alg(eps); N = A.N
    for a in range(N):
        for b in range(N):
            s1, x = A.blade_mul(a, b)
            for c in range(N):
                s2, _ = A.blade_mul(x, c); t1, u = A.blade_mul(b, c); t2, _ = A.blade_mul(a, u)
                tot += 1; bad += (s1 * s2 != t1 * t2)
chk('S1', bad == 0 and tot == 81 * 4096, f'associativity of the bit rule on all {tot} blade triples for all 81 choices of (eps_1..eps_4) in {{+1,-1,0}} (and, by the shorter list, for fewer generators): the label rule is an associative algebra for every trio choice, label 0 included')

# =====================================================================================================================================================
# L. Bottom-up, rung by rung.  Rung 0 and rung 1.
# =====================================================================================================================================================
A0 = Alg(())
chk('L0', A0.N == 1 and A0.blade_mul(0, 0) == (1, 0) and triples(0) == [(0, 0, 0)],
    'n = 0: one label, the empty bit string; it is the unit (1 times itself is 1), the algebra is R, the monoid of labels (Z2^0, xor) is trivial and the cube is a point. The empty string is the unit object of the monoidal structure, it is not the generator with square 0')
ok = True; units = {}
for eps in (1, -1, 0):
    A = Alg((eps,))
    for a_ in range(-3, 4):
        for b_ in range(-3, 4):
            M = regular_matrix(A, {0: a_, 1: b_}); det = M[0][0] * M[1][1] - M[0][1] * M[1][0]
            ok &= det == a_ * a_ - eps * b_ * b_
    inv_even = [regular_matrix(A, {0: c})[0][0] ** 2 for c in (1, 2, 3)]
    det_odd = [(lambda M: M[0][0] * M[1][1] - M[0][1] * M[1][0])(regular_matrix(A, {1: c})) for c in (1, 2, 3)]
    units[eps] = all(d != 0 for d in det_odd)
chk('L1a', ok and units == {1: True, -1: True, 0: False},
    'n = 1: the norm of a + b e is a^2 - eps b^2 (determinant of the regular representation, 49 integer pairs per sign): eps = +1 indefinite (R + R, split), eps = -1 definite (C, inert), eps = 0 degenerate (R[x]/x^2, ramified). Every non-zero homogeneous element is invertible for eps = +-1 (a graded division algebra, two of the ten of the tenfold way) and not for eps = 0 (the odd generator is nilpotent)')
def legendre(a, p): a %= p; return 0 if a == 0 else (1 if pow(a, (p - 1) // 2, p) == 1 else -1)
ok = True
for p in (3, 5, 7, 11, 13):
    nonres = next(d for d in range(2, p) if legendre(d, p) == -1)
    for d, chi in ((0, 0), (1, 1), (nonres, -1)):
        nu = 0
        for a_ in range(p):
            for b_ in range(p):
                if any((a_ * c + b_ * e * d) % p == 1 and (a_ * e + b_ * c) % p == 0 for c in range(p) for e in range(p)): nu += 1
        ok &= nu == (p - 1) * (p - chi)
chk('L1b', ok, 'the same one-generator algebra over the finite fields F_3, F_5, F_7, F_11, F_13 with e^2 = d for d = 0, 1 and a non-residue: the number of invertible elements is (p-1)(p - chi(d)) with chi the Legendre symbol (0, +1, -1). The trio (-1, 0, +1) is the trichotomy inert / ramified / split of x^2 = eps (the quadratic character takes the same three values; over R the character is the sign). Analogy for the atlas, exact for n = 1 (recalled idea, counted here)')

# =====================================================================================================================================================
# R. Radical, super-centre, Loewy layers, trace form, for every (p, q, r) up to five generators
# =====================================================================================================================================================
TAB = {}
def analyse(p, q, r):
    n = p + q + r; A = Alg(sig(p, q, r)); N = A.N
    L = {a: np.array(regular_matrix(A, {a: 1}), dtype=np.int64) for a in range(N)}
    T = [[int(np.trace(L[a] @ L[b])) for b in range(N)] for a in range(N)]            # trace form of the regular representation (Dickson: its kernel is the radical in characteristic 0)
    ker = nullspace_q(T, N)
    nullset = [i for i in range(n) if A.eps[i] == 0]; nm = sum(1 << i for i in nullset)
    radb = [a for a in range(N) if a & nm]
    rad_ok = len(ker) == len(radb) and all(all(sum(T[a][b] * (1 if b == c else 0) for b in range(N)) == 0 for a in range(N)) for c in radb[:8]) and all(T[c][b] == 0 for c in radb for b in range(N))
    ideal = all((a ^ c) & nm and True for c in radb for a in range(N) if A.blade_mul(a, c)[0] != 0) and all(((c ^ a) & nm) for c in radb for a in range(N) if A.blade_mul(c, a)[0] != 0)
    layers = []; cur = set(radb)
    while cur:
        layers.append(len(cur)); cur = {A.blade_mul(a, b)[1] for a in cur for b in radb if A.blade_mul(a, b)[0] != 0}
    # super-centre and centre by generic linear algebra on the 2^n coefficients
    def centre_dim(sign_of_parity):
        tot = 0; basis = []
        for par in (0, 1):
            idx = [a for a in range(N) if pc(a) % 2 == par]; sg = sign_of_parity(par); rows = []
            for i in range(n):
                for c in range(N):
                    row = [0] * len(idx)
                    for k, a in enumerate(idx):
                        if a ^ (1 << i) == c:
                            s1 = A.blade_mul(a, 1 << i)[0]; s2 = A.blade_mul(1 << i, a)[0]
                            row[k] = s1 - sg * s2
                    rows.append(row)
            if not idx: continue
            ns = nullspace_q(rows, len(idx)) if rows else [[Fr(int(j == k)) for j in range(len(idx))] for k in range(len(idx))]
            tot += len(ns)
            for v in ns: basis.append({idx[k]: x for k, x in enumerate(v) if x != 0})
        return tot, basis
    sc, scb = centre_dim(lambda par: -1 if par == 1 else 1)         # z e_i = (-1)^{|z|} e_i z
    ce, _ = centre_dim(lambda par: 1)
    sc_ok = sc == 2 ** r and all(set(v) <= {a for a in range(N) if (a & ~nm) == 0} for v in scb)
    return dict(n=n, dim=N, rad=len(radb), rad_ok=bool(rad_ok and ideal), layers=layers, sc=sc, sc_ok=bool(sc_ok), centre=ce, ss=2 ** (p + q))
for n in range(0, 6):
    for (p, q, r) in triples(n): TAB[(p, q, r)] = analyse(p, q, r)
RES['R'] = {f'{p},{q},{r}': v for (p, q, r), v in TAB.items()}
chk('R1', all(v['rad'] == v['dim'] - v['ss'] and v['rad_ok'] for v in TAB.values()),
    f'radical (kernel of the trace form of the regular representation, recalled criterion for characteristic 0) is exactly the span of the labels that contain a null bit: dimension 2^n - 2^(p+q), it is a two-sided ideal; {len(TAB)} signatures (p,q,r) with up to five generators; the quotient is the non-degenerate Clifford algebra Cl(p,q)')
chk('R2', all(v['layers'] == ([] if v['rad'] == 0 else [sum(math.comb(r, k) * 2 ** (p + q) for k in range(j, r + 1)) for j in range(1, r + 1)]) for (p, q, r), v in TAB.items()),
    'the radical is nilpotent with Loewy length r + 1: the powers rad^k are spanned by the labels with at least k null bits, dimension sum_{j>=k} C(r,j) 2^(p+q); each layer rad^k / rad^(k+1) has dimension C(r,k) 2^(p+q) (all signatures up to five generators; the product of k null labels is computed by the bit rule, not assumed)')
chk('R3', all(v['sc'] == 2 ** k[2] and v['sc_ok'] for k, v in TAB.items()),
    'the super-centre (elements with z x = (-1)^{|z||x|} x z) of Cl(p,q,r) is exactly the exterior algebra on the r null generators: dimension 2^r (all 56 signatures with up to five generators, solved as a linear system, not read from a formula). Cl(p,q) is graded-central simple for every n (even and odd: the pseudoscalar of an odd algebra is central but not super-central), so it is "Azumaya" in the graded sense iff r = 0')
chk('R4', all(TAB[(p, q, 0)]['centre'] == (1 if (p + q) % 2 == 0 else 2) for (p, q, r) in TAB if r == 0 and p + q > 0),
    'ordinary centre of the non-degenerate algebra: dimension 1 for an even number of generators, 2 (span of 1 and the pseudoscalar) for an odd number; in the super sense it is always 1. The difference between the two counts is the whole ungraded / graded story of the Morita classes')

# =====================================================================================================================================================
# G. Label 0 and the lifting of the Z2 grading to Z
# =====================================================================================================================================================
def grading_rank(eps):
    A = Alg(eps); N = A.N; rows = []
    for a in range(N):
        for b in range(N):
            if A.blade_mul(a, b)[0] != 0:
                row = [0] * N; row[a] += 1; row[b] += 1; row[a ^ b] -= 1; rows.append(row)
    return N - rank_q(rows, N)
GR = {}
for n in range(1, 5):
    for (p, q, r) in triples(n): GR[(p, q, r)] = grading_rank(sig(p, q, r))
chk('G1', all(v == k[2] for k, v in GR.items()),
    'among the gradings in which every label is homogeneous (one symbol per label with g_a + g_b = g_(a xor b) whenever e_a e_b is non-zero), the largest free abelian grading group has rank r, the number of null generators, for all 34 signatures with 1 to 4 generators (the universal label-homogeneous grading group is Z2^(p+q) x Z^r, T2). A generator with square +-1 forces 2 g = 0; a null generator is exactly one whose label grading lifts from Z2 to Z (an additive Z-degree, not a conserved charge: there is no Hamiltonian here; the exterior algebra is N^r-graded). The qualifier "label-homogeneous" is needed: see G2')
# G2: among label-homogeneous gradings the universal grading group is Z2^(p+q) x Z^r; for arbitrary gradings the rank can be larger (M2(R) has a Z-grading by matrix units).
# Cl(2,0) = M2(R) (r = 0) carries a Z-grading by matrix-unit degree: E11 = (1 + e1)/2, E22 = (1 - e1)/2, E12 = E11 e2, E21 = e2 E11, deg E12 = 1, deg E21 = -1, deg E11 = deg E22 = 0.
A20 = Alg(sig(2, 0)); h = Fr(1, 2)
MU = {'11': {0: h, 1: h}, '22': {0: h, 1: -h}}
MU['12'] = A20.mul(MU['11'], {2: 1}); MU['21'] = A20.mul({2: 1}, MU['11'])
mu_ok = all(A20.mul(MU[x], MU[y]) == (MU[x[0] + y[1]] if x[1] == y[0] else {}) for x in MU for y in MU)              # matrix units: E_ij E_kl = delta_jk E_il
def grading_rank_basis(basis, mul):                                        # the same linear algebra as G1 on an arbitrary basis whose products are 0 or +-1 times a basis element
    keys = list(basis); idx = {k: i for i, k in enumerate(keys)}; rows = []
    for x in keys:
        for y in keys:
            z = mul(basis[x], basis[y])
            if not z: continue
            hit = [k for k in keys if z == basis[k] or z == {a: -c for a, c in basis[k].items()}]; assert len(hit) == 1
            row = [0] * len(keys); row[idx[x]] += 1; row[idx[y]] += 1; row[idx[hit[0]]] -= 1; rows.append(row)
    return len(keys) - rank_q(rows, len(keys))
rank_mu = grading_rank_basis(MU, A20.mul)
mu_deg = {'11': 0, '22': 0, '12': 1, '21': -1}
deg_ok = all((A20.mul(MU[x], MU[y]) == {} or mu_deg[x] + mu_deg[y] == mu_deg[x[0] + y[1]]) for x in MU for y in MU)
nonhom = any(len(MU[x]) > 1 for x in MU)
chk('G2', mu_ok and deg_ok and nonhom and rank_mu == 1 and GR[(2, 0, 0)] == 0,
    'the qualifier of G1 is necessary: Cl(2,0) = M2(R) has r = 0 and label-homogeneous grading rank 0 (G1), but its matrix units E11 = (1 + e1)/2, E22 = (1 - e1)/2, E12 = E11 e2, E21 = e2 E11 (verified to multiply as matrix units) carry the Z-grading deg E12 = 1, deg E21 = -1, deg E11 = deg E22 = 0 (additive on every non-zero product), and the same linear algebra as in G1 on that basis gives free rank 1 > r = 0. The matrix units are not label-homogeneous (E11 mixes the labels 1 and e1). So "the largest free grading group has rank r" holds for label-homogeneous gradings only (T2); for arbitrary gradings the rank can be larger')

# =====================================================================================================================================================
# F. Frobenius duality, Nakayama automorphism, symmetric or not; scalar-part trace versus top-blade form
# =====================================================================================================================================================
FR = {}
def frob(p, q, r):
    n = p + q + r; A = Alg(sig(p, q, r)); N = A.N; F = N - 1
    G = [[0] * N for _ in range(N)]
    for a in range(N):
        for b in range(N):
            s, c = A.blade_mul(a, b)
            if s and c == F: G[a][b] = s
    supp = all((G[a][b] != 0) == (b == a ^ F) for a in range(N) for b in range(N))
    full = rank_q(G, N) == N
    nak = []; ratio_ok = True
    for a in range(N):
        b = a ^ F; s_ab = A.blade_mul(a, b)[0]; s_ba = A.blade_mul(b, a)[0]
        chi = s_ab * s_ba                                              # +-1: lambda(e_a e_b) = chi lambda(e_b e_a)
        ratio_ok &= chi == (-1) ** (pc(b) * (n - pc(b)))
        nak.append(chi)
    sym_form = all(x == 1 for x in nak)
    # does ANY symmetric form give a non-degenerate pairing?  (symmetric algebra)
    rows = []
    for a in range(N):
        for b in range(a + 1, N):
            s1, c = A.blade_mul(a, b); s2, _ = A.blade_mul(b, a)
            if s1 != s2:
                row = [0] * N; row[c] = s1 - s2; rows.append(row)
            elif s1 == 0 and False: pass
    mus = nullspace_q(rows, N) if rows else [[Fr(int(i == j)) for j in range(N)] for i in range(N)]
    rng = random.Random(5 + n); symmetric = False
    for _ in range(8):
        mu = [sum(rng.randint(-4, 4) * v[c] for v in mus) for c in range(N)]
        Gm = [[(A.blade_mul(a, b)[0] * mu[a ^ b]) for b in range(N)] for a in range(N)]
        if rank_q(Gm, N) == N: symmetric = True; break
    # scalar-part form
    G0 = [[(A.blade_mul(a, b)[0] if a == b else 0) for b in range(N)] for a in range(N)]
    return dict(supp=supp, full=full, ratio_ok=bool(ratio_ok), sym_form=bool(sym_form), symmetric=bool(symmetric), rank0=rank_q(G0, N), n=n)
for n in range(1, 6):
    for (p, q, r) in triples(n): FR[(p, q, r)] = frob(p, q, r)
RES['F'] = {f'{p},{q},{r}': v for (p, q, r), v in FR.items()}
chk('F1', all(v['supp'] and v['full'] for v in FR.values()),
    'Frobenius form: lambda = the coefficient of the full label 11...1. The pairing (a, b) -> lambda(e_a e_b) is non-zero exactly when b = a xor 11...1 (the complement mask, the atlas F7) with value +-1, so it is non-degenerate for every signature, label 0 included (all 55 signatures with 1 to 5 generators). The complement mask is a Frobenius (Poincare-type) duality of the algebra, not only a metric Hodge star')
chk('F2', all(v['ratio_ok'] for v in FR.values()) and all(v['sym_form'] == (v['n'] % 2 == 1) for v in FR.values()),
    'Nakayama automorphism of that form: lambda(e_a e_b) = (-1)^{|b| (n - |b|)} lambda(e_b e_a) for b the complement of a: it is the identity on every label when n is odd and the grade involution (-1)^{|b|} when n is even. So the top-blade form is symmetric exactly for odd n (all signatures, 1 to 5 generators)')
bad_sym = [k for k, v in FR.items() if v['symmetric'] != (v['n'] % 2 == 1 or k[2] == 0)]
chk('F3', not bad_sym,
    'does ANY symmetrising form exist (random member of the space of symmetric functionals, non-degenerate pairing, 8 tries, exact rank)? Yes exactly when n is odd or r = 0; the signatures with 1 to 5 generators for which no symmetrising form was found are exactly those with n even and r >= 1: ' + ', '.join(f'({p},{q},{r})' for (p, q, r), v in FR.items() if not v['symmetric']) + '. Among them the projective algebra Cl(3,0,1). There the Nakayama automorphism is the grade involution and no unit of the algebra implements it: every element that conjugates the grade involution lies in the radical, so it is nilpotent and not a unit (F5; proved for all n in T3). Frobenius, not symmetric. Observed by rank test')
chk('F4', all(v['rank0'] == 2 ** (k[0] + k[1]) for k, v in FR.items()),
    'the "scalar part" functional (the probability / trace rule x -> <x>_0) has a pairing of rank 2^(p+q) only: it is blind to every label with a null bit (55 signatures, 1 to 5 generators). This does NOT mean that a state must use the top-blade form instead: every state vanishes on the labels with a null bit and the top-blade form is never a state (C3; T15), so the scalar part is blind to the radical exactly as every state is. Matters for Schuller Ch. 17 and for the projective algebras')
# F5: the torsor statement (T3): lambda(u .) is a Frobenius form iff u is a UNIT (any unit, not only a central one);
# it is symmetric iff u is central (when lambda itself is symmetric, n odd); and for n even with r >= 1 every conjugator of the grade involution lies in the radical.
def frob_u(A, u):
    """pairing (a, b) -> lambda(u e_a e_b) with lambda the top-label coefficient: (non-degenerate?, symmetric?)"""
    N = A.N; F = N - 1
    G = [[A.mul(A.mul(u, {a: 1}), {b: 1}).get(F, 0) for b in range(N)] for a in range(N)]
    return rank_q(G, N) == N, all(G[a][b] == G[b][a] for a in range(N) for b in range(N))
def is_unit(A, u): return rank_q(regular_matrix(A, u), A.N) == A.N
def is_central(A, u): return all(A.mul(u, {1 << i: 1}) == A.mul({1 << i: 1}, u) for i in range(A.n))
tor_ok = True; rng5 = random.Random(35); ntor = 0
for (p, q, r) in ((3, 0, 0), (2, 1, 0), (1, 1, 1), (2, 0, 1), (0, 3, 0), (1, 2, 0)):
    A = Alg(sig(p, q, r))
    cands = [rand_mv(A, rng=rng5, lo=-2, hi=2) for _ in range(14)] + [{0: 1, 1: 1}, {1: 1, 2: 1}, {0: 2, 1: 1}, {0: 1, A.N - 1: 2}, {A.N - 1: 1}]
    for u in cands:
        if not u: continue
        nd, symm = frob_u(A, u); unit = is_unit(A, u); central = is_central(A, u); ntor += 1
        tor_ok &= (nd == unit)                                                            # non-degenerate iff u is a unit
        if (p + q + r) % 2 == 1 and unit: tor_ok &= (symm == central)                      # n odd: lambda symmetric, lambda(u .) symmetric iff u central
A30 = Alg(sig(3, 0)); u_nc = {0: 2, 1: 1}; u_c = {0: 1, 7: 2}; u_nu = {0: 1, 1: 1}            # 2 + e1 (unit, not central), 1 + 2 e123 (central unit), 1 + e1 (zero divisor)
ex_ok = (is_unit(A30, u_nc) and not is_central(A30, u_nc) and frob_u(A30, u_nc) == (True, False)
         and is_unit(A30, u_c) and is_central(A30, u_c) and frob_u(A30, u_c) == (True, True)
         and not is_unit(A30, u_nu) and frob_u(A30, u_nu)[0] is False)
# conjugators of the grade involution: w with alpha(e_a) w = w e_a for every label a, i.e. w e_i + e_i w = 0 for every generator; for even n and r >= 1 they all lie in the radical
conj_ok = True; CJ = {}
for n in (2, 4, 6):
    for (p, q, r) in triples(n):
        A = Alg(sig(p, q, r)); N = A.N; rows = []
        for i in range(n):
            for c in range(N):
                row = [0] * N
                for a in range(N):
                    if a ^ (1 << i) == c:
                        row[a] += A.blade_mul(a, 1 << i)[0] + A.blade_mul(1 << i, a)[0]
                rows.append(row)
        W = nullspace_q(rows, N); nm = sum(1 << i for i in range(n) if A.eps[i] == 0)
        in_rad = all(all((a & nm) for a, x in enumerate(v) if x != 0) for v in W)
        CJ[(p, q, r)] = (len(W), in_rad)
        conj_ok &= (in_rad if r >= 1 else (len(W) == 1 and W[0][N - 1] != 0 and not in_rad))          # r = 0: W = span(e_F), a unit
chk('F5', tor_ok and ex_ok and conj_ok,
    f'the torsor statement (T3): with lambda the top-label form, lambda(u .) is non-degenerate (a Frobenius form) iff u is a unit, for ANY unit ({ntor} elements, random and chosen, in Cl(3,0), Cl(2,1), Cl(0,3), Cl(1,2), Cl(1,1,1), Cl(2,0,1): exact rank), and for odd n (lambda symmetric) lambda(u .) is symmetric iff u is central. Explicitly in Cl(3,0): u = 2 + e1 is a non-central unit and lambda(u .) is a non-degenerate, non-symmetric Frobenius form; u = 1 + 2 e123 is a central unit and lambda(u .) is symmetric; u = 1 + e1 is a zero divisor and lambda(u .) is degenerate. So all Frobenius forms are a torsor under the unit group and only the symmetric ones under the central units. The non-symmetry at even n with r >= 1: the space of w with w e_i + e_i w = 0 for every generator (the conjugators of the grade involution) is computed exactly for every signature with n = 2, 4, 6; for r >= 1 every solution is supported on labels with a null bit (in the radical, nilpotent, not a unit: dimensions ' + ', '.join(f'({p},{q},{r}): {d}' for (p, q, r), (d, _) in CJ.items() if r >= 1 and p + q + r == 4) + ' at n = 4), for r = 0 it is the line of the pseudoscalar, a unit')

# =====================================================================================================================================================
# K1. The cube category and the signs: the bit rule is the (unique up to gauge) sign assignment that makes every square anticommute
# =====================================================================================================================================================
def jw(a, i): return -1 if pc(a & ((1 << i) - 1)) & 1 else 1           # (-1)^{number of set bits below i}
def cube_edges(n): return [(a, i) for a in range(1 << n) for i in range(n) if not (a >> i) & 1]
ok = True; cnt = {}
for n in range(0, 8):
    for a in range(1 << n):
        for i in range(n):
            for j in range(i + 1, n):
                if not (a >> i) & 1 and not (a >> j) & 1:
                    ok &= jw(a, i) * jw(a | (1 << i), j) * jw(a, j) * jw(a | (1 << j), i) == -1
    cnt[n] = (3 ** n, math.comb(n, 2) * 2 ** max(n - 2, 0) if n >= 2 else 0)
okpairs = all(3 ** n == sum(1 for a in range(1 << n) for b in range(1 << n) if a & b == a) for n in range(0, 7))
chk('K1a', ok and okpairs, 'cube category = the poset of labels under inclusion (one arrow a -> b when a is a subset of b; 3^n arrows, n <= 6 counted). With the sign (-1)^{#set bits below i} on the edge a -> a + {i} the product of the four signs around every square is -1 for n <= 7: every square anticommutes')
ok = True
for n in range(1, 7):
    A = Alg(sig(n, 0))
    for a in range(1 << n):
        for i in range(n):
            if not (a >> i) & 1: ok &= A.blade_mul(1 << i, a)[0] == jw(a, i)
chk('K1b', ok, 'the edge sign is the bit-rule sign: e_i e_a = (-1)^{#{j in a : j < i}} e_(a + i) for i not in a (Cl(n,0), n <= 6): the Clifford sign structure is the Jordan-Wigner string')
rows = []                                                              # 1-cochains on edges over GF(2): unknown z_edge; square condition: z(e1)+z(e4) = z(e2)+z(e3)  (commuting squares)
H1 = {}
for n in range(1, 7):
    E = cube_edges(n); eid = {e: k for k, e in enumerate(E)}; sq_rows = []
    for a in range(1 << n):
        for i in range(n):
            for j in range(i + 1, n):
                if not (a >> i) & 1 and not (a >> j) & 1:
                    sq_rows.append((1 << eid[(a, i)]) | (1 << eid[(a | (1 << i), j)]) | (1 << eid[(a, j)]) | (1 << eid[(a | (1 << j), i)]))
    nul = f2_nullspace(sq_rows, len(E)); V = 1 << n
    H1[n] = (len(nul), V - 1)
chk('K1c', all(a == b for a, b in H1.values()),
    'H^1 of the cube with GF(2) coefficients is zero: the space of 1-cochains whose squares all commute has dimension 2^n - 1 = the dimension of the coboundaries (vertex sign changes mod a global one), n = 1..6. Hence two sign assignments with anticommuting squares differ by a rescaling of the basis labels by +-1: the bit-rule sign is unique up to gauge (recalled: standard in the cube-of-resolutions constructions)')
ok = True; brute = 0
n = 3; E = cube_edges(3); sols = 0
sq3 = []
for a in range(8):
    for i in range(3):
        for j in range(i + 1, 3):
            if not (a >> i) & 1 and not (a >> j) & 1: sq3.append(((a, i), (a | (1 << i), j), (a, j), (a | (1 << j), i)))
for assign in itertools.product((1, -1), repeat=len(E)):
    s = dict(zip(E, assign))
    if all(s[x] * s[y] * s[u] * s[v] == -1 for x, y, u, v in sq3): sols += 1
chk('K1d', sols == 2 ** 7 == 128, f'brute force on the 3-cube (2^12 sign assignments): {sols} have all six squares anticommuting = 2^(2^3 - 1) = one gauge orbit')
def dmat(n):
    N = 1 << n; D = [[0] * N for _ in range(N)]
    for a in range(N):
        for i in range(n):
            if (a >> i) & 1: D[a ^ (1 << i)][a] = jw(a ^ (1 << i), i)      # contraction with the same sign as the creation
    return np.array(D, dtype=np.int64)
ok = True; acyc = True
for n in range(1, 7):
    D = dmat(n); ok &= not (D @ D).any()
    N = 1 << n; rk = np.linalg.matrix_rank(D.astype(float)); acyc &= rk == N // 2        # ker = im  <=>  rank D = 2^(n-1) (exact: D is a 0,+-1 matrix of a known acyclic complex)
chk('K1e', ok and acyc, 'the Koszul / simplex boundary d e_a = sum_i (-1)^{#{j in a: j < i}} e_(a - i) on the 2^n labels squares to zero (n <= 6) and the complex is exact (rank 2^(n-1)); the same sign gives the antiderivation of the Lundholm-Svensson boundary d_V = s_V _| (their Sect. 4.1) and the creation operators of the Fock space')

# =====================================================================================================================================================
# K2. Group cohomology: H^2(Z2^n, Z2) is the space of quadratic forms; the bit rule picks the Clifford family inside it
# =====================================================================================================================================================
H2 = {}
for n in range(1, 5):
    G = (1 << n) - 1; nz = list(range(1, 1 << n)); uid = {(a, b): k for k, (a, b) in enumerate((a, b) for a in nz for b in nz)}; U = len(uid)
    def var(a, b): return (1 << uid[(a, b)]) if a and b else 0
    eqs = []
    for a in nz:
        for b in nz:
            for c in nz:
                eqs.append(var(a, b) ^ var(a ^ b, c) ^ var(a, b ^ c) ^ var(b, c))
    Z2 = f2_nullspace(eqs, U); dZ = len(Z2)
    dB = (1 << n) - 1 - n
    # invariants of a cocycle: beta(e_i,e_i) and beta(e_i,e_j)+beta(e_j,e_i); and the quadratic function q(a) = beta(a,a)
    ev = lambda z, a, b: (z >> uid[(a, b)]) & 1 if a and b else 0
    inv_rows = []
    quad_ok = True
    for z in Z2:
        row = [ev(z, 1 << i, 1 << i) for i in range(n)] + [ev(z, 1 << i, 1 << j) ^ ev(z, 1 << j, 1 << i) for i in range(n) for j in range(i + 1, n)]
        inv_rows.append(sum(b << k for k, b in enumerate(row)))
        qf = lambda a: ev(z, a, a)
        quad_ok &= all(qf(a ^ b) ^ qf(a) ^ qf(b) == (ev(z, a, b) ^ ev(z, b, a)) for a in nz for b in nz)
    rk = f2_rank(inv_rows, n * (n + 1) // 2)
    # coboundaries have vanishing invariants
    H2[n] = dict(dimZ=dZ, dimB=dB, dimH=dZ - dB, rank_inv=rk, quad=quad_ok, expected=n * (n + 1) // 2)
cb_ok = True
for n in range(1, 5):
    for _ in range(40):
        f = {a: random.Random(a * 7 + n).randint(0, 1) for a in range(1 << n)}; f[0] = 0
        d = lambda a, b: f[a] ^ f[b] ^ f[a ^ b]
        inv = [d(1 << i, 1 << i) for i in range(n)] + [d(1 << i, 1 << j) ^ d(1 << j, 1 << i) for i in range(n) for j in range(i + 1, n)]
        cb_ok &= not any(inv)
chk('K2a', all(v['dimH'] == v['expected'] == v['rank_inv'] and v['quad'] for v in H2.values()) and cb_ok,
    'normalised 2-cocycles of Z2^n with values in GF(2) (n = 1..4, solved as linear systems): dim H^2 = n(n+1)/2 = ' + ', '.join(f'{v["dimH"]} (n={n})' for n, v in H2.items()) + '. A class is determined by the squares beta(e_i,e_i) and the commutators beta(e_i,e_j) + beta(e_j,e_i) (the invariant map has full rank and kills coboundaries), and beta(a,a) is a quadratic function with polar form the commutator: H^2(Z2^n, Z2) is the space of quadratic forms (recalled)')
ok = True
for n in range(1, 5):
    for eps in itertools.product((1, -1), repeat=n):
        A = Alg(eps)
        for a in range(1 << n):
            for b in range(1 << n):
                for c in range(1 << n):
                    s1, x = A.blade_mul(a, b); s2, _ = A.blade_mul(x, c); t1, u = A.blade_mul(b, c); t2, _ = A.blade_mul(a, u)
                    ok &= s1 * s2 == t1 * t2
cls = set()
for eps in itertools.product((1, -1), repeat=3):
    A = Alg(eps); cls.add(tuple([(A.blade_mul(1 << i, 1 << i)[0] == -1) for i in range(3)] + [(A.blade_mul(1 << i, 1 << j)[0] != A.blade_mul(1 << j, 1 << i)[0]) for i in range(3) for j in range(i + 1, 3)]))
chk('K2b', ok and len(cls) == 8 and all(c[3:] == (True, True, True) for c in cls),
    'the bit rule with eps in {+1,-1}^n is a 2-cocycle (associativity, n <= 4), and its class has all commutator invariants equal to 1 (every pair of generators anticommutes) and the square invariants equal to the signature: 2^n of the 2^(n(n+1)/2) classes. The Clifford algebras are the sub-family of H^2 with c_ij = 1 for all i != j; the other classes (some pairs commuting) are twisted group algebras that are not Clifford algebras')

# =====================================================================================================================================================
# K3. The octonions: the same labels with a sign that is not a cocycle; its associator is a coboundary 3-cocycle
# =====================================================================================================================================================
def cd_conj(z):
    if len(z) == 1: return list(z)
    h = len(z) // 2
    return cd_conj(z[:h]) + [-t for t in z[h:]]
def cd_mul(x, y):
    n = len(x)
    if n == 1: return [x[0] * y[0]]
    h = n // 2; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    p1 = cd_mul(a, c); p2 = cd_mul(cd_conj(d), b); p3 = cd_mul(d, a); p4 = cd_mul(b, cd_conj(c))
    return [u - v for u, v in zip(p1, p2)] + [u + v for u, v in zip(p3, p4)]
unit = lambda n, i: [1 if t == i else 0 for t in range(n)]
OCT = {}
for a in range(8):
    for b in range(8):
        r = cd_mul(unit(8, a), unit(8, b)); k = [t for t in range(8) if r[t]]; OCT[(a, b)] = (r[k[0]], k[0])
def phi(a, b, c):                                                        # associator sign computed from the products themselves
    x = cd_mul(cd_mul(unit(8, a), unit(8, b)), unit(8, c)); y = cd_mul(unit(8, a), cd_mul(unit(8, b), unit(8, c)))
    k = [t for t in range(8) if x[t]][0]; return x[k] * y[k]
def det2(a, b, c):                                                       # determinant over GF(2) of the three bit vectors
    return int(a != 0 and b != 0 and c != 0 and a != b and a != c and b != c and (a ^ b) != c)
PHI = {(a, b, c): phi(a, b, c) for a in range(8) for b in range(8) for c in range(8)}
chk('K3a', all(PHI[t] == (-1) ** det2(*t) for t in PHI) and sum(1 for v in PHI.values() if v == -1) == 168,
    'octonions on the eight labels (Cayley-Dickson): the associator sign is (-1)^det over GF(2) (-1 on the 168 independent triples, +1 elsewhere), computed from the 512 products of three units')
pent = all(PHI[(b, c, d)] * PHI[(a, b ^ c, d)] * PHI[(a, b, c)] == PHI[(a ^ b, c, d)] * PHI[(a, b, c ^ d)] for a in range(8) for b in range(8) for c in range(8) for d in range(8))
dF = all(OCT[(b, c)][0] * OCT[(a ^ b, c)][0] * OCT[(a, b ^ c)][0] * OCT[(a, b)][0] == PHI[(a, b, c)] for a in range(8) for b in range(8) for c in range(8))
A03 = Alg(sig(0, 3)); dS = all(A03.blade_mul(b, c)[0] * A03.blade_mul(a ^ b, c)[0] * A03.blade_mul(a, b ^ c)[0] * A03.blade_mul(a, b)[0] == 1 for a in range(8) for b in range(8) for c in range(8))
chk('K3b', pent and dF and dS,
    'the associator is a 3-cocycle on Z2^3 (pentagon identity, all 4096 quadruples); it equals the coboundary of the octonion sign function F (dF(a,b,c) = F(b,c) F(a+b,c) F(a,b+c) F(a,b)), while the Clifford sign s of Cl(0,3) on the same labels has ds = 1: the octonions are the same label set with a 2-cochain that is not a cocycle, and because dF is a coboundary the associator is a twist (recalled from Albuquerque-Majid: the octonions are a cochain twist of the group algebra of Z2^3)')

# =====================================================================================================================================================
# K4. The clock: Gauss sum = Brown invariant = p - q mod 8 = Frobenius-Schur indicator
# =====================================================================================================================================================
def gauss(p, q, r=0):
    eps = sig(p, q, r); re_ = im_ = 0
    for a in range(1 << len(eps)):
        if any(eps[i] == 0 for i in bits(a)): continue                  # a label with a null bit has weight 0 (its square is 0)
        k = sum(1 if eps[i] == 1 else -1 for i in bits(a)) % 4
        re_, im_ = (re_ + (1, 0, -1, 0)[k], im_ + (0, 1, 0, -1)[k])
    return re_, im_
def cpow(base, e):
    r_ = (1, 0)
    for _ in range(e): r_ = (r_[0] * base[0] - r_[1] * base[1], r_[0] * base[1] + r_[1] * base[0])
    return r_
def cmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
ok = True; ok2 = True; maxn = 10
for p in range(maxn + 1):
    for q in range(maxn + 1 - p):
        g = gauss(p, q); ref = cmul(cpow((1, 1), p), cpow((1, -1), q))
        ok &= g == ref and gauss(p, q, 2) == g
        ang = math.atan2(g[1], g[0]) / (math.pi / 4); ok2 &= round(ang) % 8 == (p - q) % 8 and abs(ang - round(ang)) < 1e-9
chk('K4a', ok and ok2,
    'Gauss sum over the labels: sum_a i^(|a & P| - |a & Q|) (a runs over all 2^n labels, P the positive and Q the negative generators) equals (1+i)^p (1-i)^q exactly (Gaussian integers, all p + q <= 10); its phase is (p - q) pi/4: the clock c = p - q mod 8 is the Brown phase of the Z4-valued quadratic form of the labels; a label with a null bit has weight 0, so each null generator contributes the factor 1 + 0 (checked with two extra null labels): the clock is blind to r. The trio -1, 0, +1 are the three steps of the clock: back, stay, forward')
def fs(p, q):
    A = Alg(sig(p, q)); n = p + q; S = sum(A.sq(a) for a in range(A.N)); return Fr(2 ** (n // 2) * S, 2 ** n), S
def derived_type(p, q):
    nu, S = fs(p, q); n = p + q; A = Alg(sig(p, q))
    K = {1: 'R', 0: 'C', -1: 'H'}[int(nu)]
    f = 2 if (n % 2 == 1 and A.sq((1 << n) - 1) == 1) else 1
    return K + ('2' if f == 2 else '') if K != 'C' else 'C'
bad = []
for p in range(9):
    for q in range(9 - p):
        nu, S = fs(p, q)
        if nu not in (1, 0, -1) or derived_type(p, q) != TYPES[(p - q) % 8]: bad.append((p, q))
chk('K4b', not bad,
    'the Frobenius-Schur count sum_a e_a^2 over the labels (the indicator of the finite group {+-e_a}, order 2^(n+1), acting on the algebra by left multiplication, T4 (iv)): the rescaled number nu = (2^(floor(n/2)) / 2^n) sum_a e_a^2, computed from the squares of the labels, is +1, 0, -1 for the real, complex, quaternionic type, and the type (with the number of simple factors read from the square of the full label) equals the textbook mod-8 list for all p + q <= 8 (45 signatures; the list is used only to compare). In the usual normalisation sum_a e_a^2 = k N ind(D) (k simple summands M_N(D)) the indicator per summand is +1 (R), 0 (C), -2 (H) (T4). Schur lemma (Baez, tenfold way) and Gauss sum are the same count')
sums = [(c, [fs(p, q)[1] / (2 ** ((p + q + 1) / 2)) for (p, q) in ((8 + c, 0), (0, 8 - c) if c else (0, 8))][:1]) for c in range(8)]
okc = all(abs(fs(p, q)[1] - 2 ** ((p + q + 1) / 2) * math.cos((p - q - 1) * math.pi / 4)) < 1e-6 for p in range(9) for q in range(9 - p))
okc_sum = all(fs(p, q)[1] == gauss(p, q)[0] + gauss(p, q)[1] for p in range(9) for q in range(9 - p))                       # sum_a e_a^2 = Re S + Im S = Re((1 - i) S), exactly
okc_c2 = all(gauss(p, q)[0] == 0 and fs(p, q)[1] > 0 for p in range(9) for q in range(9 - p) if (p - q) % 8 == 2)           # at c = 2 the real part alone is 0 while the type is R
chk('K4c', okc and okc_sum and okc_c2, 'what the type is the sign of: the sum of the squares of the labels, sum_a e_a^2 = Re S + Im S = Re((1 - i) S) with S = (1+i)^p (1-i)^q the Gauss sum of K4a (exact Gaussian integers, all p + q <= 8), with the closed form 2^((n+1)/2) cos((p - q - 1) pi / 4) (numerical, tolerance 1e-6): the sign of the cosine is the type (positive: R, zero: C, negative: H). It is not the real part of S alone: at c = p - q = 2 mod 8 the real part of S is 0 for every signature while the type is R (checked: Re S = 0, sum e_a^2 > 0 there)')

# =====================================================================================================================================================
# K5. Ladders: graded tensor product = concatenation of labels (Koszul rule); the even subalgebra needs an invertible generator
# =====================================================================================================================================================
def koszul_ok(e1, e2):
    A1, A2, A = Alg(e1), Alg(e2), Alg(tuple(e1) + tuple(e2)); n1 = len(e1); ok = True
    for a1 in range(A1.N):
        for b1 in range(A2.N):
            for a2 in range(A1.N):
                for b2 in range(A2.N):
                    s_1, x1 = A1.blade_mul(a1, a2); s_2, x2 = A2.blade_mul(b1, b2)
                    exp = (-1) ** (pc(b1) * pc(a2)) * s_1 * s_2
                    s, c = A.blade_mul(a1 | (b1 << n1), a2 | (b2 << n1)); ok &= s == exp and (c == (x1 | (x2 << n1)) or exp == 0)
    return ok
chk('K5a', all(koszul_ok(e1, e2) for e1, e2 in (((1, -1), (-1, 1)), ((1, 0), (-1, 0)), ((0, 1), (1,)), ((0, 0), (1, -1)), ((1,), (0, 0)), ((-1, -1, 1), (0,)))),
    'concatenating two lists of generators gives exactly the graded tensor product with the Koszul sign: (a1 (x) b1)(a2 (x) b2) = (-1)^{|b1||a2|} a1 a2 (x) b1 b2 on all label pairs, for six pairs of signatures including null generators. The bit rule is the Koszul sign rule of super vector spaces; Cl(p1+p2, q1+q2) = Cl(p1,q1) (x)^ Cl(p2,q2) (Lundholm-Svensson Prop. 5.8)')
def even_iso(p, q, r):
    A = Alg(sig(p, q, r)); n = p + q + r
    t = next((i for i in range(n) if A.eps[i] != 0), None)
    if t is None: return None
    others = [i for i in range(n) if i != t]; s = A.eps[t]
    new = tuple(-s * A.eps[i] for i in others) if True else None            # f_i = e_i e_t has square -eps_i eps_t
    B = Alg(tuple(-s * A.eps[i] if A.eps[i] != 0 else 0 for i in others))
    def img(a):                                                              # f_{i1} f_{i2} ... (increasing), as a multivector of A
        x = {0: 1}
        for k, i in enumerate(others):
            if (a >> k) & 1: x = A.mul(x, A.mul({1 << i: 1}, {1 << t: 1}))
        return x
    ok = True
    for a in range(B.N):
        for b in range(B.N):
            s1, c = B.blade_mul(a, b); lhs = A.mul(img(a), img(b)); rhs = A.scal(img(c), s1)
            ok &= lhs == rhs
    ok &= all(len(img(a)) == 1 for a in range(B.N))
    return ok
ev_ok = all(even_iso(p, q, r) for n in range(1, 5) for (p, q, r) in triples(n) if p + q >= 1)
noneven = None
Alam3 = Alg(sig(0, 0, 3)); even3 = [a for a in range(8) if pc(a) % 2 == 0]
prod_even = {Alam3.blade_mul(a, b)[1] for a in even3 for b in even3 if a and b and Alam3.blade_mul(a, b)[0] != 0}
Alam2 = Alg(sig(0, 0, 2)); layers2 = []; cur = {1, 2, 3}
while cur: layers2.append(len(cur)); cur = {Alam2.blade_mul(a, b)[1] for a in cur for b in (1, 2, 3) if Alam2.blade_mul(a, b)[0] != 0}
layers3e = []; cur = {a for a in even3 if a}
while cur: layers3e.append(len(cur)); cur = {Alam3.blade_mul(a, b)[1] for a in cur for b in even3 if b and Alam3.blade_mul(a, b)[0] != 0}
chk('K5b', ev_ok and not prod_even and layers2 == [3, 1] and layers3e == [3],
    'going down one rung: the even subalgebra of Cl(p,q,r) is Cl(p,q-1,r) (or Cl(q,p-1,r)) when one generator with non-zero square t is available: f_i = e_i e_t satisfies the Clifford relations with square -eps_i eps_t, and the map is an isomorphism on all label pairs (every signature with 1 to 4 generators and p + q >= 1). With only null generators it fails from 3 generators on (p = q = 0, r >= 3; T5(d): for r <= 2 the even part is still a Clifford algebra): the even part of the exterior algebra on 3 generators has dimension 4 and zero products (Loewy length 2), the exterior algebra on 2 generators has Loewy length 3. The step n -> n-1 needs an invertible vector, except for r <= 2 all-null generators; in that sense label 0 cannot be peeled off from the top')

def sort_swaps(a, b):                                                        # bubble-sort the concatenated list of generators, count the adjacent swaps
    L = [i for i in range(8) if (a >> i) & 1] + [i for i in range(8) if (b >> i) & 1]; sw = 0; done = False
    while not done:
        done = True
        for k in range(len(L) - 1):
            if L[k] > L[k + 1]: L[k], L[k + 1] = L[k + 1], L[k]; sw += 1; done = False
    return sw
chk('K5c', all(reorder_sign(a, b) == (-1) ** sort_swaps(a, b) for a in range(256) for b in range(256)),
    'the sign of the bit rule is the parity of the number of inversions of the concatenated list of generators, counted by an independent bubble sort (all 65536 label pairs of 8 generators). This is the sorting sign of Tian (Lemma 4.20): moving a generator past a smaller one costs one sign, and each such move is one crossing of two strands')

# =====================================================================================================================================================
# T. Tian's algebra Cl_Z and its finite truncations: where label 0 hides
# =====================================================================================================================================================
def tian_mats(n):
    N = 1 << n
    def create(j):
        M = np.zeros((N, N), dtype=np.int64)
        for S in range(N):
            if not (S >> (j - 1)) & 1: M[S | (1 << (j - 1)), S] = -1 if pc(S & ((1 << (j - 1)) - 1)) & 1 else 1
        return M
    def annih(j):
        if j == 0: return np.zeros((N, N), dtype=np.int64)
        M = np.zeros((N, N), dtype=np.int64)
        for S in range(N):
            if (S >> (j - 1)) & 1: M[S ^ (1 << (j - 1)), S] = -1 if pc(S & ((1 << (j - 1)) - 1)) & 1 else 1
        return M
    a = {}
    for j in range(1, n + 1):
        a[2 * j] = create(j); a[2 * j - 1] = annih(j) + annih(j - 1)
    return a
ok = True; faithful = True; odd_ok = True; orad = True
for n in range(1, 4):
    a = tian_mats(n); I = np.eye(1 << n, dtype=np.int64); m = 2 * n
    for i in range(1, m + 1):
        ok &= not (a[i] @ a[i]).any()
        for j in range(i + 1, m + 1):
            ac = a[i] @ a[j] + a[j] @ a[i]
            ok &= (ac == I).all() if j == i + 1 else not ac.any()
    mons = []
    for S in range(1 << m):
        M = I.copy()
        for i in range(1, m + 1):
            if (S >> (i - 1)) & 1: M = M @ a[i]
        mons.append(list(M.ravel()))
    faithful &= rank_modp(mons) == 4 ** n
    # odd truncation a_1..a_{2n-1}: the radical vector r = a_1 - a_3 + a_5 ...
    mo = []
    for S in range(1 << (m - 1)):
        M = I.copy()
        for i in range(1, m):
            if (S >> (i - 1)) & 1: M = M @ a[i]
        mo.append(list(M.ravel()))
    odd_ok &= rank_modp(mo) == 2 ** (m - 1)
    rr = sum(((-1) ** k) * a[2 * k + 1] for k in range(n))
    orad &= rr.any() and not (rr @ rr).any() and all(not (rr @ a[i] + a[i] @ rr).any() for i in range(1, m))
chk('T1', ok and faithful, 'Tian (arXiv:1309.6049, Sect. 3, Lemma 3.3) relations a_i^2 = 0, a_i a_j = -a_j a_i for |i-j| > 1, a_i a_(i+1) + a_(i+1) a_i = 1 realised on the exterior algebra of n sites (a_2j creates, a_(2j-1) annihilates sites j and j-1, with the sign of the occupied sites below): hold for n = 1, 2, 3 and the 4^n monomials are linearly independent (rank 4^n, computed mod a large prime, which can only under-estimate): End(V_n) = M_(2^n)(Z) is faithful. Our own check; the paper proves it in general')
chk('T2', odd_ok and orad, 'cut the generator list at an odd length 2n-1: the monomials still have the full rank 2^(2n-1) (the module of 2^n labels is faithful) and r = a_1 - a_3 + a_5 - ... is non-zero, squares to 0 and anticommutes with every generator: the odd truncation has a radical vector, a label 0 that Tian\'s relations do not display (n = 1, 2, 3)')
def tian_sig(k):
    G = [[0] * k for _ in range(k)]
    for i in range(k - 1): G[i][i + 1] = G[i + 1][i] = 1
    return signature_q(G)
TS = {k: tian_sig(k) for k in range(1, 11)}
def gram_det(k):
    G = [[0] * k for _ in range(k)]
    for i in range(k - 1): G[i][i + 1] = G[i + 1][i] = 1
    from fractions import Fraction
    M = [[Fraction(x) for x in r] for r in G]; d = Fraction(1)
    for c in range(k):
        pr = next((i for i in range(c, k) if M[i][c] != 0), None)
        if pr is None: return 0
        if pr != c: M[c], M[pr] = M[pr], M[c]; d = -d
        d *= M[c][c]
        for i in range(c + 1, k):
            f = M[i][c] / M[c][c]; M[i] = [x - f * y for x, y in zip(M[i], M[c])]
    return d
chk('T3', all(TS[k] == (k // 2, k // 2, k % 2) for k in TS) and all(gram_det(k) == (0 if k % 2 else (-1) ** (k // 2)) for k in range(1, 11)),
    'the quadratic form behind Tian\'s relations (v^2 = sum c_i c_(i+1), polar form = adjacency matrix of the path with k nodes) has real signature (floor(k/2), floor(k/2), k mod 2) for k = 1..10: even length: hyperbolic, Cl(m,m) = M_(2^m)(R), the clock-0 matrix algebra (and unimodular over Z: determinant +-1); odd length: one label 0 hides in the form (determinant 0)')
def cl_from_gram(k):
    n = (k + 1) // 2; a = tian_mats((k + 1) // 2 if k % 2 == 0 else (k + 1) // 2)
    return a
ok = True
for k, nsites in ((2, 1), (3, 2), (4, 2)):
    a = tian_mats(nsites); N = 1 << nsites
    G = np.zeros((k, k))
    for i in range(k - 1): G[i, i + 1] = G[i + 1, i] = 1
    # orthogonalise: Gram-Schmidt on the form v^2 = c^T G c / 2
    w, V = np.linalg.eigh(G / 2.0)
    gens = []; eps = []
    for t in range(k):
        v = V[:, t]; mat = sum(v[i] * a[i + 1] for i in range(k)); lam = w[t]
        if abs(lam) < 1e-9: gens.append(mat); eps.append(0)
        else: gens.append(mat / math.sqrt(abs(lam))); eps.append(1 if lam > 0 else -1)
    order = sorted(range(k), key=lambda t: {1: 0, -1: 1, 0: 2}[eps[t]]); gens = [gens[t] for t in order]; eps = [eps[t] for t in order]
    Ab = Alg(tuple(eps)); I = np.eye(N)
    def M_of(a_):
        M = I.copy()
        for i in range(k):
            if (a_ >> i) & 1: M = M @ gens[i]
        return M
    good = True
    for a_ in range(Ab.N):
        for b_ in range(Ab.N):
            s, c = Ab.blade_mul(a_, b_)
            good &= np.allclose(M_of(a_) @ M_of(b_), s * M_of(c))
    ok &= good and tuple(eps) == tuple(sig(k // 2, k // 2, k % 2))
chk('T4', ok, 'Tian\'s generators a_1..a_k (k = 2, 3, 4) re-expressed in an orthonormal basis of the form (numerical, eigenvectors, tolerance 1e-8) multiply by the bit rule of Cl(1,1), Cl(1,1,1), Cl(2,2) on all label pairs: Tian\'s algebra over R is a Clifford algebra of the atlas, in a non-orthogonal basis; the nilpotent a_i are NOT label 0 (they come in hyperbolic pairs: u = a_1 + a_2 has square +1, v = a_1 - a_2 square -1), only the radical vector of an odd truncation is')

# =====================================================================================================================================================
# M. Mother algebra: label 0 as the difference of a +1 and a -1 generator
# =====================================================================================================================================================
def mother_ok(p, q, r):
    n = p + q + r; B = Alg(sig(p, q, r)); M = Alg(sig(p + r, q + r))
    gen = [{i: 1} for i in range(p)]                                    # indices in the big algebra: positives 0..p+r-1, negatives p+r..p+q+2r-1
    gen = [{1 << i: 1} for i in range(p)] + [{1 << (p + r + j): 1} for j in range(q)] + [{1 << (p + k): 1, 1 << (p + r + q + k): -1} for k in range(r)]
    def img(a):
        x = {0: 1}
        for i in range(n):
            if (a >> i) & 1: x = M.mul(x, gen[i])
        return x
    imgs = [img(a) for a in range(B.N)]; ok = True
    for a in range(B.N):
        for b in range(B.N):
            s, c = B.blade_mul(a, b); ok &= M.mul(imgs[a], imgs[b]) == M.scal(imgs[c], s)
    keys = sorted({k for x in imgs for k in x}); rows = [[x.get(k, 0) for k in keys] for x in imgs]
    return ok and rank_q(rows, len(keys)) == B.N
ok = all(mother_ok(p, q, r) for (p, q, r) in [(1, 0, 1), (0, 1, 1), (1, 1, 1), (2, 0, 1), (3, 0, 1), (0, 0, 2), (1, 0, 2), (2, 1, 1), (0, 0, 3)])
chk('M1', ok, 'mother algebra (Lundholm-Svensson Sect. 5.3): Cl(p,q,r) embeds in the non-degenerate Cl(p+r, q+r) with each null generator sent to f+ - f-, the difference of a +1 and a -1 generator (square 1 - 1 = 0, anticommuting with everything else). Checked for nine signatures up to six generators: the images multiply by the bit rule on all label pairs and the 2^n images are linearly independent (exact rank). Label 0 = the null vector of a hyperbolic pair; the pair itself, (+1, -1) together, is the zero of the Witt group')
u = {1: 1, 2: 1}; v = {1: 1, 2: -1}; A11 = Alg(sig(1, 1))
ok = A11.mul(u, u) == {} and A11.mul(v, v) == {} and A11.add(A11.mul(u, v), A11.mul(v, u)) == {0: 4}
tr = [A11.N, A11.N]
pair_rad = TAB[(1, 1, 0)]['rad'] == 0 and TAB[(0, 0, 2)]['rad'] == 3
chk('M2', ok and pair_rad, 'in Cl(1,1) the two null vectors u = e1 + e2, v = e1 - e2 square to 0 and u v + v u = 4: a paired null (creation / annihilation) generates a matrix algebra with radical 0, while two unpaired null generators (Cl(0,0,2)) have a radical of dimension 3. Paired null = Fock pair (Lundholm-Svensson Sect. 8.2, Tian); unpaired null = label 0')

# =====================================================================================================================================================
# W. Spectral frames: totally singular subspaces of the F2 quadric = commuting sets of blades with square +1; the Witt index is the split rank
# =====================================================================================================================================================
def quad_data(p, q):
    A = Alg(sig(p, q)); n = p + q; N = 1 << n
    qf = [1 if A.sq(a) == -1 else 0 for a in range(N)]
    Bf = [[0 if A.comm_sign(a, b) == 1 else 1 for b in range(N)] for a in range(N)]
    return A, qf, Bf
def singular_subspaces(p, q):
    A, qf, Bf = quad_data(p, q); N = 1 << (p + q)
    by_dim = {0: {frozenset([0])}}; d = 0
    while by_dim[d]:
        nxt = set()
        for S in by_dim[d]:
            for v in range(1, N):
                if v in S or qf[v]: continue
                if all(Bf[v][s] == 0 for s in S):
                    nxt.add(frozenset(S | {s ^ v for s in S}))
        d += 1; by_dim[d] = nxt
    return by_dim
def split_rank_from_type(p, q):
    t = TYPES[(p - q) % 8]; n = p + q; f = 2 if t.endswith('2') else 1; K = t[0]; dk = {'R': 1, 'C': 2, 'H': 4}[K]
    Nn2 = Fr(2 ** n, f * dk); Nn = int(round(math.sqrt(Nn2))); assert Nn * Nn == Nn2
    return f * Nn
WI = {}
ok = True
for n in range(1, 9):
    for p in range(n + 1):
        q = n - p
        if n >= 7 and (p, q) not in ((8, 0), (0, 8), (4, 4), (7, 0), (0, 7), (6, 2), (7, 1), (3, 4)) and n == 8: continue
        if n == 7 and (p, q) not in ((7, 0), (0, 7), (4, 3), (3, 4)): continue
        sub = singular_subspaces(p, q); w = max(d for d in sub if sub[d]); WI[(p, q)] = (w, len(sub[w]), {d: len(s) for d, s in sub.items() if s})
        ok &= 2 ** w == split_rank_from_type(p, q)
chk('W1', ok and len(WI) >= 30,
    f'Witt index = split rank: the largest set of mutually commuting labels whose blades all square to +1 spans a split commutative algebra R^(2^w) (its 2^w orthogonal projectors are the finite shadow of the spectral theorem); the largest w found by exhaustive search over totally singular subspaces of the F2 quadric q(a) = [e_a^2 = -1] satisfies 2^w = (number of simple factors) x N where Cl(p,q) = M_N(K) (+ M_N(K)): all {len(WI)} signatures tried (every one up to 6 generators, selected ones with 7 and 8)')
chk('W2', WI[(8, 0)][1] == 270 and WI[(8, 0)][2][1] == 135 and WI[(6, 0)][2] == {0: 1, 1: 27, 2: 45} and WI[(4, 0)][2] == {0: 1, 1: 5},
    'Cl(8,0) (hyperbolic, M_16(R)): 135 non-trivial blades with square +1 and 270 maximal commuting sets (solids); Cl(6,0) (elliptic, M_4(H)): 27 blades with square +1 and 45 maximal sets (lines): the points and lines of the quadrics Q+(7,2) and Q-(5,2) on which W(E8) and W(E6) act (recalled: the 27 lines and 45 tritangent planes). Cl(4,0): 5 points, no lines. Counted by enumeration')
# the two families of 135 (triality) in Cl(8,0)
sub8 = singular_subspaces(8, 0); sol = list(sub8[4])
parity = lambda S, T: (4 - int(math.log2(len(S & T)))) % 2
fam1 = [S for S in sol if parity(S, sol[0]) == 0]; fam2 = [S for S in sol if parity(S, sol[0]) == 1]
chk('W3', len(fam1) == 135 and len(fam2) == 135, 'the 270 maximal commuting sets of Cl(8,0) split into two families of 135 (two solids are in the same family iff their intersection has codimension even): the two half-spin classes; with the 135 points they are the three 135s of triality (counted)')

# =====================================================================================================================================================
# L. Lattices and quivers: the trio -1, 0, +1 in the Tits form; E8 -> E9 -> E10
# =====================================================================================================================================================
def tree_T(p, q, r):                                                     # star with arms of p-1, q-1, r-1 nodes around a centre
    nodes = 1 + (p - 1) + (q - 1) + (r - 1); edges = []; nxt = 1
    for L in (p - 1, q - 1, r - 1):
        prev = 0
        for _ in range(L): edges.append((prev, nxt)); prev = nxt; nxt += 1
    return nodes, edges
def cartan(nodes, edges):
    C = [[2 if i == j else 0 for j in range(nodes)] for i in range(nodes)]
    for i, j in edges: C[i][j] = C[j][i] = -1
    return C
def path(n): return n, [(i, i + 1) for i in range(n - 1)]
def Dn(n): return n, [(i, i + 1) for i in range(n - 2)] + [(n - 3, n - 1)]
def cycle(n): return n, [(i, (i + 1) % n) for i in range(n)]
def Dn_aff(n): return n + 1, [(0, 2), (1, 2)] + [(i, i + 1) for i in range(2, n - 1)] + [(n - 2, n), (n - 2, n - 1)]
fin = {'A3': path(3), 'A8': path(8), 'D4': Dn(4), 'D8': Dn(8), 'E6': tree_T(2, 3, 3), 'E7': tree_T(2, 3, 4), 'E8': tree_T(2, 3, 5)}
aff = {'A~3': cycle(4), 'D~4': Dn_aff(4), 'D~7': Dn_aff(7), 'E~6': tree_T(3, 3, 3), 'E~7': tree_T(2, 4, 4), 'E~8': tree_T(2, 3, 6)}
SIGS = {}
for k, (nd, ed) in {**fin, **aff}.items(): SIGS[k] = signature_q(cartan(nd, ed))
ok_f = all(SIGS[k] == (fin[k][0], 0, 0) for k in fin)
ok_a = all(SIGS[k] == (aff[k][0] - 1, 0, 1) for k in aff)
marks = [3, 4, 2, 5, 4, 3, 2, 1]                                          # not used; the null vector of E~8 is computed below
nd, ed = tree_T(2, 3, 6); C = cartan(nd, ed); ns = nullspace_q(C, nd)
dv = ns[0]; scale = max(abs(x.denominator) for x in dv); dv = [x * scale for x in dv]
g_ = math.gcd(*[int(x) for x in dv]); dv = [int(x) // g_ for x in dv]
if dv[0] < 0: dv = [-x for x in dv]
chk('Q1', ok_f and ok_a and len(ns) == 1 and sorted(dv) == [1, 2, 2, 3, 3, 4, 4, 5, 6] and sum(dv) == 30 + 0 * 1 and (np.array(C) @ np.array(dv) == 0).all(),
    'Cartan (Tits) form of the Dynkin diagrams A3, A8, D4, D8, E6, E7, E8: positive definite, signature (n,0,0) = Cl(n,0); of the extended diagrams A3~, D4~, D7~, E6~, E7~, E8~: positive semi-definite with a one-dimensional radical, signature (n,0,1) = Cl(n,0,1). The radical of E8~ is the null root with marks 1,2,2,3,3,4,4,5,6 (sum 30 = the Coxeter number h = 30 of E8, node of mark 6 in the centre). The first step beyond a finite root system is exactly one null direction (reading it as a label 0 is ours) (exact rational diagonalisation)')
def En(n):
    if n == 3: return 3, [(0, 1)]                                         # E3 = A2 x A1 (no arm structure in T(2,3,0))
    if n == 4: return path(4)
    if n == 5: return Dn(5)
    return tree_T(2, 3, n - 3)
det_ok = True; sig_E = {}
for n in range(3, 12):
    nd, ed = En(n)
    C = cartan(nd, ed); sig_E[n] = signature_q(C)
    from fractions import Fraction
    M = [[Fraction(x) for x in r] for r in C]; d = Fraction(1)
    for c in range(nd):
        pr = next((i for i in range(c, nd) if M[i][c] != 0), None)
        if pr is None: d = 0; break
        if pr != c: M[c], M[pr] = M[pr], M[c]; d = -d
        d *= M[c][c]
        for i in range(c + 1, nd):
            f = M[i][c] / M[c][c]; M[i] = [x - f * y for x, y in zip(M[i], M[c])]
    det_ok &= (d == 9 - n) if n >= 4 else (d == 6 if n == 3 else True)
chk('Q2', det_ok and sig_E[6] == (6, 0, 0) and sig_E[7] == (7, 0, 0) and sig_E[8] == (8, 0, 0) and sig_E[9] == (8, 0, 1) and sig_E[10] == (9, 1, 0) and sig_E[11] == (10, 1, 0),
    'the E_n series: det Cartan(E_n) = 9 - n for n = 3..11 (3 is A2 x A1: 6); signatures E6: (6,0,0), E7: (7,0,0), E8: (8,0,0), E9 = E8~: (8,0,1), E10: (9,1,0), E11: (10,1,0). The step E8 -> E9 introduces one null direction (the null root; reading it as a label 0 is ours), the step E9 -> E10 trades it for a -1 (Lorentzian: a signature of the Cartan form on the root lattice, not of a spacetime); det = 9 - n is 0 only at n = 9. Recalled: E9, E10, E11 are the affine, hyperbolic and Lorentzian Kac-Moody diagrams; the signatures are computed')
def positive_roots(nd, ed):
    C = cartan(nd, ed); simple = [tuple(int(i == j) for j in range(nd)) for i in range(nd)]
    seen = set(simple); fr = list(simple)
    while fr:
        new = []
        for x in fr:
            for i in range(nd):
                c = sum(C[i][j] * x[j] for j in range(nd)); y = list(x); y[i] -= c; y = tuple(y)
                if y not in seen and len(seen) < 5000: seen.add(y); new.append(y)
        fr = new
    return sorted(x for x in seen if all(t >= 0 for t in x))
PR = {k: len(positive_roots(*fin[k])) for k in fin}
chk('Q3', PR == {'A3': 6, 'A8': 36, 'D4': 12, 'D8': 56, 'E6': 36, 'E7': 63, 'E8': 120},
    'number of positive roots (reflection orbit of the simple roots) A3: 6, A8: 36, D4: 12, D8: 56, E6: 36, E7: 63, E8: 120; by Gabriel\'s theorem (recalled) these are the numbers of indecomposable representations of the quivers with these underlying graphs (any orientation); E8: 120, i.e. 240 roots')
def disc_group(C):
    nd = len(C); Ci = np.linalg.inv(np.array(C, dtype=float)); gens = []
    for i in range(nd):
        w = tuple(Fr(round(Ci[i][j] * 1000), 1000) for j in range(nd)); gens.append(w)
    return gens
def gauss_milgram(nd, ed):
    C = cartan(nd, ed); Cf = [[Fr(x) for x in r] for r in C]
    det = round(np.linalg.det(np.array(C, dtype=float)))
    # inverse by exact elimination
    M = [row[:] + [Fr(int(i == j)) for j in range(nd)] for i, row in enumerate(Cf)]
    for c in range(nd):
        pr = next(i for i in range(c, nd) if M[i][c] != 0); M[c], M[pr] = M[pr], M[c]; iv = 1 / M[c][c]; M[c] = [x * iv for x in M[c]]
        for i in range(nd):
            if i != c and M[i][c] != 0:
                f = M[i][c]; M[i] = [a - f * b for a, b in zip(M[i], M[c])]
    Ci = [row[nd:] for row in M]
    gens = [tuple(Ci[i][j] for j in range(nd)) for i in range(nd)]
    red = lambda w: tuple(x - math.floor(x) for x in w)
    zero = tuple(Fr(0) for _ in range(nd)); grp = {zero}; fr = [zero]
    while fr:
        nw = []
        for x in fr:
            for g in gens:
                y = red(tuple(a + b for a, b in zip(x, g)))
                if y not in grp: grp.add(y); nw.append(y)
        fr = nw
    tot = 0
    for w in grp:
        nm = sum(w[i] * Cf[i][j] * w[j] for i in range(nd) for j in range(nd))
        tot += complex(math.cos(math.pi * float(nm)), math.sin(math.pi * float(nm)))
    return len(grp), tot
GM = {}; ok = True
for k in ('A3', 'A8', 'D4', 'D8', 'E6', 'E7', 'E8'):
    nd, ed = fin[k]; size, tot = gauss_milgram(nd, ed); GM[k] = (size, tot)
    ok &= abs(tot - math.sqrt(size) * complex(math.cos(2 * math.pi * nd / 8), math.sin(2 * math.pi * nd / 8))) < 1e-9
chk('Q4', ok, 'Gauss-Milgram (van der Blij) for the root lattices: sum over the discriminant group D = L*/L of exp(pi i x.x) = sqrt|D| exp(2 pi i n / 8) for A3 (|D| 4), A8 (9), D4 (4), D8 (4), E6 (3), E7 (2), E8 (1) (numerical, tolerance 1e-9, exact rational norms): the Brown phase of the discriminant form is the clock c = n mod 8 of Cl(n,0) of K4a. recalled theorem, checked on seven lattices')
def mod2_counts(nd, ed):
    C = cartan(nd, ed); N = 1 << nd; q1 = 0; q0 = 0; Bf = [[C[i][j] % 2 for j in range(nd)] for i in range(nd)]
    for x in range(1, N):
        v = [(x >> i) & 1 for i in range(nd)]; val = sum(v[i] * C[i][j] * v[j] for i in range(nd) for j in range(nd)) // 2
        if val % 2: q1 += 1
        else: q0 += 1
    rk = f2_rank([sum(((C[i][j] % 2) << j) for j in range(nd)) for i in range(nd)], nd)
    return q1, q0, nd - rk
LAD = {}
for n in range(3, 9):
    nd, ed = En(n); q1, q0, rad = mod2_counts(nd, ed); A_ = Alg(sig(n, 0)); cb = len(A_.center_blades())
    LAD[n] = dict(pos=len(positive_roots(nd, ed)), q1=q1, q0=q0, rad=rad, cl_q1=sum(1 for a in range(1 << n) if A_.sq(a) == -1), cl_q0=sum(1 for a in range(1, 1 << n) if A_.sq(a) == 1), cl_rad=int(math.log2(cb)))
M2 = {f'E{n}': (v['q1'], v['q0'], v['rad']) for n, v in LAD.items()}
RES['LAD'] = {str(n): v for n, v in LAD.items()}
chk('Q5', all(v['q1'] == v['cl_q1'] and v['q0'] == v['cl_q0'] and v['rad'] == v['cl_rad'] == n % 2 for n, v in LAD.items()) and all(v['q1'] == v['pos'] + (1 if n == 7 else 0) for n, v in LAD.items()),
    'root lattice E_n mod 2 against the blades of Cl(n,0), n = 3..8 (E3 = A2 x A1, E4 = A4, E5 = D5): the number of classes of E_n/2E_n with q = (x.x)/2 mod 2 equal to 1, the number of non-zero classes with q = 0 and the dimension of the radical of the pairing mod 2 equal the number of blades of Cl(n,0) with square -1, of non-trivial blades with square +1, and the dimension of the radical of the commutation form: ' + '; '.join(f'n={n}: ({v["q1"]}, {v["q0"]}, {v["rad"]})' for n, v in LAD.items()) + '. These data fix the isometry class of the quadratic space over GF(2) (recalled classification), so E_n/2E_n and the blades of Cl(n,0) are the same quadratic space for n = 3..8. The number with q = 1 is the number of positive roots (3: 4, 4: 10, 5: 20, 6: 36, 8: 120), and for n = 7 it is 63 + 1, the extra class being the central pseudoscalar. This is the atlas statement "W(E_n) mod 2 = O(Q of Cl(n,0))" at the level of counts; the group statement is not recalled: the atlas checks it (groups_check.py part B, n = 3..8) and T9 proves it, with E_n/2E_n carrying the label form of Cl(n,0) for all n >= 3 and A_n/2A_n that of Cl(0,n), the two coinciding iff 4 | n')

# =====================================================================================================================================================
# E. The Euler form of the cube category (incidence algebra of the Boolean lattice)
# =====================================================================================================================================================
Uu = [[1, -1], [0, 1]]
def kron(A, B): return [[a * b for a in ra for b in rb] for ra in A for rb in B]
M_ = [[1]]; ES = {}; rad3 = None
for n in range(0, 6):
    S = [[M_[i][j] + M_[j][i] for j in range(len(M_))] for i in range(len(M_))]
    ES[n] = signature_q(S)
    if n == 3: rad3 = nullspace_q(S, 8)
    M_ = kron(M_, Uu) if True else M_
# kron above uses (row-major of A) x (B) = standard Kronecker product: check on n=1,2 by hand-free consistency (signature agrees with A2 and D4)
M_chk = kron(Uu, Uu)
chk('E1', ES[0] == (1, 0, 0) and ES[1] == (2, 0, 0) and ES[2] == (4, 0, 0) and ES[3] == (6, 0, 2) and ES[4] == (14, 2, 0) and ES[5] == (20, 2, 10),
    'Euler form of the cube category (incidence algebra of the Boolean lattice: <e_a, e_b> = (-1)^|b - a| for a subset of b, i.e. the Moebius function = the tensor power of [[1,-1],[0,1]]), symmetrised: signature n=0: (1,0,0), n=1: (2,0,0) (the arrow A2), n=2: (4,0,0) (the commutative square, same signature as D4), n=3: (6,0,2) (two null directions), n=4: (14,2,0), n=5: (20,2,10). A null direction of the symmetrised Euler form first appears at n = 3 (reading it as a label 0 is ours; the Tits form differs from n = 3 on, T8). Computed; meaning open (see the questions)')
RES['E'] = {str(n): v for n, v in ES.items()}
RES['E3_rad'] = [[str(x) for x in v] for v in rad3]

# =====================================================================================================================================================
# J. Majkic, "Categorial geometry and algebraic topology" (arXiv 2403.19689): the stated construction tested on the cube category
# =====================================================================================================================================================
def majkic(n):
    objs = list(range(1 << n)); arrows = [(a, b) for a in objs for b in objs if a & b == a and a != b]       # non-identity arrows of the cube poset
    atoms = [(a, b) for (a, b) in arrows if pc(b ^ a) == 1]
    norm = {f: pc(f[0] ^ f[1]) for f in arrows}                                                                  # minimal number of atoms composing f
    comp = lambda f, g: f[1] == g[0]                                                                              # g o f exists
    dot = lambda f, g: norm[f] * norm[g] if (f == g or comp(f, g) or comp(g, f)) else 0
    return objs, arrows, atoms, norm, comp, dot
res = {}
for n in (2, 3):
    objs, arrows, atoms, norm, comp, dot = majkic(n)
    pairs = [(f, g) for f in arrows for g in arrows if f != g]
    orth = sum(1 for f, g in pairs if not comp(f, g) and not comp(g, f)); one = sum(1 for f, g in pairs if comp(f, g) != comp(g, f)); both = sum(1 for f, g in pairs if comp(f, g) and comp(g, f))
    # additivity test: each arrow is the sum (composition) of atoms along any maximal chain; a bilinear form must satisfy dot(f, g) = sum of atom-level values along ANY decomposition
    def decomp(f):
        a, b = f; out = []; cur = a
        for i in range(n):
            if (b ^ a) >> i & 1: nxt = cur | (1 << i); out.append((cur, nxt)); cur = nxt
        return out
    bad = 0; tested = 0
    for f in arrows:
        for g in arrows:
            if f == g: continue
            tested += 1
            if sum(dot(x, y) for x in decomp(f) for y in decomp(g)) != dot(f, g): bad += 1
    res[n] = dict(arrows=len(arrows), atoms=len(atoms), orth=orth // 2, one=one // 2, both=both // 2, nonbilinear=bad, tested=tested)
RES['J'] = res
chk('J1', res[2] == dict(arrows=5, atoms=4, orth=8, one=2, both=0, nonbilinear=res[2]['nonbilinear'], tested=20) and res[2]['both'] == res[3]['both'] == 0 and res[2]['one'] > 0 and res[3]['one'] > 0,
    f'Majkic Cat-arrows space on the cube category: n = 2: {res[2]["arrows"]} non-identity arrows, {res[2]["atoms"]} atoms, among the unordered pairs of distinct arrows {res[2]["orth"]} are orthogonal (non-composable), {res[2]["one"]} composable in one order and none in both (a poset has no cycles); n = 3: {res[3]["arrows"]} arrows, {res[3]["orth"]} orthogonal, {res[3]["one"]} composable. In (18) every composable pair has f g + g f = scalar + bivector, not a scalar, so the Clifford relation f g + g f = 2 <f,g> is not satisfied there')
chk('J2', res[2]['nonbilinear'] > 0 and res[3]['nonbilinear'] > 0,
    f'the paper\'s inner product is not additive along composition: on the 2-cube f = (0 -> 12) is the composite of two atoms, but dot(f, atom) = 0 while the atom-by-atom sum is 2 ({res[2]["nonbilinear"]} of {res[2]["tested"]} ordered pairs fail on n = 2, {res[3]["nonbilinear"]} of {res[3]["tested"]} on n = 3); with no vector-space structure on the arrows there is no quadratic form v -> v^2 and the construction is not a Clifford algebra of a vector space. The two properties the paper proves (e_i^2 = 1 and f g = - g f for orthogonal f, g) hold by definition (norm 1 for atoms; opposite orientation of the two bivectors)')
# the constructive reading: the Gram matrix of atoms with e^2 = 1 and {e_f, e_g} = 1 for composable pairs is a legitimate Clifford algebra of a quadratic form; its signature
sigJ = {}
for n in (2, 3, 4):
    objs, arrows, atoms, norm, comp, dot = majkic(n)
    G = [[2 if f == g else (1 if (comp(f, g) or comp(g, f)) else 0) for g in atoms] for f in atoms]
    sigJ[n] = signature_q(G)
RES['Jsig'] = {str(k): v for k, v in sigJ.items()}
chk('J3', sigJ == {2: (4, 0, 0), 3: (11, 0, 1), 4: (26, 4, 2)}, 'constructive reading (ours, not in the paper): put Gram matrix 2 on the diagonal and 1 for atoms that compose on the cube category (atoms: 4, 12, 32); the signature (p,q,r) of this form is ' + ', '.join(f'n={k}: {v}' for k, v in sigJ.items()) + ': definite, then one null direction at n = 3, then indefinite at n = 4 - the same sequence as the Euler form of the cube category (E1). A Clifford algebra of a quiver is the Clifford algebra of a form like this; the null direction at n = 3 is a label 0')

# =====================================================================================================================================================
# B. Fermionic ladder = bosonic ladder in super vector spaces
# =====================================================================================================================================================
def fock(n):
    N = 1 << n; A = []
    for i in range(n):
        M = np.zeros((N, N), dtype=np.int64)
        for S in range(N):
            if (S >> i) & 1: M[S ^ (1 << i), S] = jw(S ^ (1 << i), i)
        A.append(M)
    return A
ok = True; sd = True
for n in range(1, 5):
    a = fock(n); I = np.eye(1 << n, dtype=np.int64); Nn = [x.T @ x for x in a]
    par = np.diag([(-1) ** pc(S) for S in range(1 << n)])
    for i in range(n):
        for j in range(n):
            sc = a[i] @ a[j].T + a[j].T @ a[i]; ok &= (sc == (I if i == j else 0 * I)).all()                  # super-commutator [a, a^+] = a a^+ + a^+ a  (odd, odd)
            ok &= not (a[i] @ a[j] + a[j] @ a[i]).any()
            ok &= (Nn[i] @ a[j] - a[j] @ Nn[i] == (-a[j] if i == j else 0 * a[j])).all()                      # [N, a] = -a, same as the bosonic ladder
    sd &= int(np.trace(par)) == 0 and int(np.trace(I)) == 2 ** n
chk('B1', ok and sd, 'fermionic oscillators on the 2^n labels (n <= 4): [a_i, a_j^+]_super = a_i a_j^+ + a_j^+ a_i = delta_ij and [N_i, a_j] = - delta_ij a_j are the Heisenberg-ladder relations of the boson with the commutator replaced by the super-commutator (Koszul sign for two odd elements); the dimension is 2^n but the super-dimension (trace of the parity) is 0, which is what a relation [a, a+] = 1 needs (an ordinary commutator has trace 0 and cannot equal 1 in finite dimension). Same equations, other braiding; the Pauli rule a^2 = 0 is the super-commutator of an odd element with itself')

# =====================================================================================================================================================
# C. Eight graded classes from five ungraded types; the Born rule as the Frobenius form of Cl(3,0)
# =====================================================================================================================================================
pairs_ = {}
for c in range(8):
    p, q = c + 1, 1                                                         # p - q = c, one negative generator so that the even subalgebra Cl(p, q-1) exists
    pairs_[c] = (derived_type(p, q), derived_type(p, q - 1))
chk('C1', len(set(pairs_.values())) == 8 and len({v[0] for v in pairs_.values()}) == 5 and all(pairs_[c][1] == TYPES[(c + 1) % 8] for c in range(8)),
    'ungraded the real Clifford algebras have only 5 types (R, R+R, C, H, H+H); the pair (type of Cl, type of its even subalgebra Cl(p,q-1)) takes 8 different values as p - q runs through Z8: ' + '; '.join(f'c={c}: {pairs_[c][0]}/{pairs_[c][1]}' for c in range(8)) + '. The grading is what separates c = 0 from c = 2, 1 from 7 ... (the eight Brauer-Wall classes of the tenfold way, 8 real + 2 complex; the group law is the sum of the clocks of K4a and K5a; recalled: Wall 1964, Baez 2020). The types are computed from the Gauss sum, the textbook list is used only to compare')
A3_ = Alg(sig(3, 0)); okb = True
for v in ((Fr(3, 5), Fr(4, 5), Fr(0)), (Fr(1, 3), Fr(-2, 3), Fr(1, 3)), (Fr(1, 2), Fr(1, 2), Fr(1, 2)), (Fr(0), Fr(0), Fr(1))):
    for u in ((Fr(1), Fr(0), Fr(0)), (Fr(2, 3), Fr(2, 3), Fr(1, 3)), (Fr(0), Fr(3, 5), Fr(4, 5))):
        rho = {k: x for k, x in {0: Fr(1, 2), 1: v[0] / 2, 2: v[1] / 2, 4: v[2] / 2}.items() if x != 0}; P = {k: x for k, x in {0: Fr(1, 2), 1: u[0] / 2, 2: u[1] / 2, 4: u[2] / 2}.items() if x != 0}
        prob = 2 * A3_.mul(rho, P).get(0, 0)
        okb &= prob == (1 + sum(a * b for a, b in zip(u, v))) / 2
        two = {k: 2 * x for k, x in rho.items()}; two[0] = two.get(0, 0) - 1; two = {k: x for k, x in two.items() if x != 0}
        okb &= A3_.mul(two, two) == {0: sum(a * a for a in v)} or (sum(a * a for a in v) == 0 and A3_.mul(two, two) == {})
        okb &= A3_.mul(P, P) == P if sum(a * a for a in u) == 1 else True
w = 7; okb &= all((A3_.blade_mul(w, a)[0] * -1 if A3_.blade_mul(w, a)[1] == 0 else 0) == (1 if a == 7 else 0) for a in range(8))
chk('C2', okb, 'Cl(3,0) = M_2(C): the mixed state rho = (1 + v)/2 (v a vector) and the projector P = (1 + u)/2 give the probability 2 <rho P>_0 = (1 + v.u)/2 exactly (12 rational pairs); (2 rho - 1)^2 = v^2, so rho is positive iff |v| <= 1 and pure iff |v| = 1 (the Bloch ball); and the top-blade Frobenius form of F1 is lambda(x) = - <w x>_0 with w the pseudoscalar (w^2 = -1, central): the trace of quantum mechanics is a symmetric Frobenius form, lambda(w .) up to sign, and the symmetric Frobenius forms of Cl(3,0) are exactly lambda(z .) with z a central unit (F5; T3), so among them the trace is canonical up to a central unit. All Frobenius forms are lambda(u .) with u any unit (F5). Only the trace is a state: lambda(1) = 0 (C3). For r > 0 the scalar part is blind to the radical (F4), as every state is (C3)')
# C3: states with null generators (T15). dagger involution: e_i^dag = eps_i e_i for eps_i != 0, e_i^dag = e_i for a null generator, extended as an anti-automorphism.
def dag_sign(A, a):
    s = (-1) ** ((pc(a) * (pc(a) - 1) // 2) % 2)
    for i in bits(a):
        if A.eps[i] != 0: s *= A.eps[i]
    return s
def gram(A, f):
    """Gram matrix G_ab = f(e_a^dag e_b) of a functional f (dict label -> value) for the dagger involution"""
    N = A.N; G = np.zeros((N, N))
    for a in range(N):
        for b in range(N):
            s, c = A.blade_mul(a, b)
            if s: G[a, b] = dag_sign(A, a) * s * f.get(c, 0)
    return G
st_ok = True; nsig3 = 0; npert = 0; rng3 = random.Random(15); NH = {}
for n in range(1, 5):
    for (p, q, r) in triples(n):
        A = Alg(sig(p, q, r)); N = A.N; nm = sum(1 << i for i in range(n) if A.eps[i] == 0); nsig3 += 1
        st_ok &= all(A.blade_mul(a, b)[0] * dag_sign(A, a ^ b) == dag_sign(A, a) * dag_sign(A, b) * A.blade_mul(b, a)[0] for a in range(N) for b in range(N))   # (e_a e_b)^dag = e_b^dag e_a^dag (both sides 0 when the labels share a null bit)
        tau = {0: 1.0}; G0 = gram(A, tau)
        st_ok &= np.array_equal(G0, np.diag([0.0 if (a & nm) else 1.0 for a in range(N)]))                      # <e_a^dag e_b>_0 = delta_ab on the labels without a null bit, 0 on the radical: positive, blind to J
        if r:
            herm = [c for c in range(N) if (c & nm) and dag_sign(A, c) == 1]                                        # hermitian directions supported on the radical
            for _ in range(12):
                phi = {c: rng3.uniform(-1, 1) for c in herm}
                for t in (0.1, -0.1):
                    f = dict(tau); f.update({c: t * x for c, x in phi.items()}); Gt = gram(A, f); npert += 1
                    st_ok &= np.allclose(Gt, Gt.T) and all(Gt[c, c] == 0 for c in range(N) if c & nm) and np.linalg.eigvalsh(Gt).min() < -1e-9   # hermitian, zero on the diagonal of J, not positive
        lam = {N - 1: 1.0}; GL = gram(A, lam); herm = np.array_equal(GL, GL.T)
        st_ok &= GL[0, 0] == 0 and (not herm or np.linalg.eigvalsh(GL).min() < -1e-9)                              # the top-blade form: lambda(1) = 0, and either not hermitian or some x has lambda(x^dag x) < 0: never a positive hermitian functional
        NH[r > 0] = NH.get(r > 0, 0) + (not herm)
chk('C3', st_ok and nsig3 == 34,
    f'states and null generators (T15, verified): with the dagger involution (e_i^dag = eps_i e_i, null generators fixed; checked to be an anti-automorphism on the labels) the scalar part <x>_0 has the Gram matrix <e_a^dag e_b>_0 = delta_ab on the labels without a null bit and 0 on the labels with one, for all {nsig3} signatures with 1 to 4 generators: it is a positive functional (a state after normalisation) that vanishes on the radical. Adding to it any hermitian functional supported on the radical ({npert} perturbations, t = +-0.1, 20 null signatures) keeps the diagonal of the radical labels at 0 and produces a negative eigenvalue of the Gram matrix: no state sees a label with a null bit, so the states of Cl(p,q,r) are those of Cl(p,q). The top-blade form has lambda(1) = 0 and is never a positive hermitian functional: for every signature its Gram matrix is either not symmetric (lambda(x^dag) != lambda(x)) or has a negative eigenvalue: a Frobenius duality, never a state. The scalar part stays the state functional, for the dagger involution')

# =====================================================================================================================================================
print('\nchecks: %d ok, %d failed' % (N_OK, N_BAD))
RESULTS_PATH = os.path.join(HERE, 'cat_results.json') if '--write' in sys.argv else os.path.join(tempfile.mkdtemp(prefix='cat_check_'), 'cat_results.json')
json.dump(dict(res=RES, nok=N_OK, nbad=N_BAD,
               WI={f'{p},{q}': dict(w=v[0], count=v[1], dims={str(k): c for k, c in v[2].items()}) for (p, q), v in WI.items()},
               SIGS={k: list(v) for k, v in SIGS.items()}, sig_E={str(k): list(v) for k, v in sig_E.items()}, PR=PR, TS={str(k): list(v) for k, v in TS.items()},
               H2={str(k): v for k, v in H2.items()}, GM={k: [v[0], round(v[1].real, 9), round(v[1].imag, 9)] for k, v in GM.items()}, M2={k: list(v) for k, v in M2.items()},
               GR={f'{p},{q},{r}': v for (p, q, r), v in GR.items()}, marks=dv),
          open(RESULTS_PATH, 'w'), indent=1, default=str)
print('results written to', RESULTS_PATH)
sys.exit(1 if N_BAD else 0)
