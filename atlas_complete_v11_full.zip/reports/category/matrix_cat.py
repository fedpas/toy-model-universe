# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The translation matrix between the category-theory pass and the atlas.
Rows: what the four papers talk about (by paper) and the categorical notions I brought myself.  Columns: where the atlas draws or checks it (the same 22 pages and steps as the Schuller and Baez matrices).
Grade of a cell:
  E  exact        the same object or identity; a check in cat_check.py computes it (check ids in the note)
  S  structural   the same structure in another generality, or a standard fact the atlas uses (recalled facts are said to be recalled)
  A  analogy      a reading we propose (tagged ours); nothing computes that it is the same
  .  (absent)     no counterpart
A row with no cell at all is a GAP: the atlas has nothing there."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
# the 22 atlas columns (key, short name, long name, where in the atlas): rule, cells, Maxwell, Furey, shapes, steps 2..17; the same as in the Baez matrix
COLS = [
    ('rule', 'Rule', 'The rule: bit labels, XOR, signs', 'page 1'),
    ('cells', 'Cells', 'The atlas of cells Cl(p,q), the clock', 'page 2'),
    ('clock', '1 Clock', 'Step 1: clock and trinity', 'step 1'),
    ('maxwell', 'Maxwell', 'Calibration 1: Maxwell ∇F=J', 'page 4'),
    ('shapes', 'Shapes', 'Orthoplex, demicube, Gosset series', 'page 5'),
    ('comm', '2 Comm', 'Step 2: bivector commutators', 'step 2'),
    ('mirrors', '3 Mirr', 'Step 3: mirrors and versors', 'step 3'),
    ('dirac', '4 Dirac', 'Step 4: Dirac equation', 'step 4'),
    ('spin', '5 Spin', 'Step 5: spinors', 'step 5'),
    ('coupling', '6 Coupl', 'Step 6: coupling', 'step 6'),
    ('ym', '7 YM', 'Step 7: Yang–Mills', 'step 7'),
    ('matter', '8 Matter', 'Step 8: charged matter', 'step 8'),
    ('grav1', '9 Grav', 'Step 9: gravity, tetrad and curvature', 'step 9'),
    ('grav2', '10 Grav', 'Step 10: gravity, Einstein form', 'step 10'),
    ('projective', '11 Proj', 'Step 11: projective and conformal', 'step 11'),
    ('gauge', '12 Gauge', 'Step 12: gauge gravity', 'step 12'),
    ('null', '13 Null', 'Step 13: null surfaces', 'step 13'),
    ('forque', '14 Forq', 'Step 14: forque dynamics', 'step 14'),
    ('spring', '15 Sprg', 'Step 15: springs', 'step 15'),
    ('rigid', '16 Rigd', 'Step 16: rigid bodies', 'step 16'),
    ('furey', 'Furey', 'Calibration 2: Furey, one generation in Cl(0,8)', 'page 7'),
    ('groups', '17 Grps', 'Step 17: finite groups', 'step 17'),
]

SRC_NAME = {'K': 'Lundholm–Svensson · Clifford algebra, geometric algebra and applications (KTH notes)', 'W': 'Baez · The tenfold way (with Wall, Trimble, Freed–Moore behind it)',
            'T': 'Tian · A diagrammatic categorification of a Clifford algebra', 'M': 'Majkić · Categorial geometry and algebraic topology',
            'C': 'Category notions brought in by me (standard language, our reading)'}
SRC_SHORT = {'K': 'KTH notes', 'W': 'Tenfold way', 'T': 'Tian', 'M': 'Majkić', 'C': 'Category lens'}
ORDER = 'KWTMC'

ROWS = [
 ('K1', 'K', 'Combinatorial Clifford algebra Cl(X,R,r): basis P(X), product tau(A,B) A△B (Def. 2.4-2.5, Lemma 2.6)', {
   'rule': ('E', 'The recursion of the proof unwinds to the bit-rule sign (the notes give no closed form); associativity holds for every choice of the trio, null included (S1); property (iv) of the lemma is the 2-cocycle condition (K2b).'),
   'cells': ('S', 'The boxes of their Table 5.1 are the atlas cells (p,q); the notes put the number of +1 first, as the atlas does.')}),
 ('K2', 'K', 'Signature value 0 is allowed; degenerate algebras, Grassmann algebra for q = 0 (Sect. 2.1, 6.6.3, 7.1)', {
   'rule': ('E', 'Radical = labels with a null bit, nilpotent of length r + 1, super-centre = exterior algebra on the null generators (R1-R3); among label-homogeneous gradings the grading lifts to Z exactly for null generators (G1, G2).'),
   'projective': ('E', 'Cl(n,0,1) is the projective algebra of Sect. 7.1; its radical is one null label, the top-blade form is a Frobenius form, symmetric only for odd n: Cl(3,0,1) is Frobenius but not symmetric (F3).'),
   'null': ('S', 'Step 13 has both kinds of null: the horizon vector in the ambient (t,r) plane is a paired null of the non-degenerate Cl(1,1) (M2), not a label 0, while the tangent algebra Cl(0,n-2,1) of the null hypersurface has an unpaired null, its radical (T18).')}),
 ('K3', 'K', 'Real classification: Table 5.1 and the (s - t) mod 8 rule (Thm 5.5, Prop. 5.4)', {
   'cells': ('E', 'The type R, C, H (with one or two simple factors) is recovered from the squares of the labels alone, as a Frobenius-Schur indicator, for all p + q <= 8 (K4b).'),
   'clock': ('E', 'The mod-8 rule is the phase of a Gauss sum over the labels: (1+i)^p (1-i)^q (K4a, K4c).')}),
 ('K4', 'K', 'Graded tensor product: Cl(s+p, t+q) = Cl(s,t) (x)^ Cl(p,q), sign (-1)^{delta(y) delta(x\')} (Sect. 5.3, Prop. 5.8)', {
   'rule': ('E', 'Concatenating the lists of generators is exactly this product with the Koszul sign, on all label pairs, null generators included (K5a).'),
   'clock': ('S', 'The clock is additive under it (K4a): this is the group law of the Brauer-Wall group (recalled).')}),
 ('K5', 'K', 'Even subalgebra: Cl_+(s,t) = Cl(s,t-1) (Prop. 5.1)', {
   'cells': ('E', 'Explicit isomorphism f_i = e_i e_t checked on all label pairs for every signature up to four generators, null ones included, provided one generator has non-zero square (K5b).'),
   'spin': ('S', 'Step 5 builds spinors from even parts; the same map, and the same limitation: a null generator cannot serve as the invertible vector.')}),
 ('K6', 'K', 'Mother algebra: Cl(s,t,u) inside Cl(n,n), null generator = f+ - f- (Sect. 5.3, p. 62)', {
   'null': ('E', 'Checked for nine signatures: the images multiply by the bit rule and are independent; the null generator is the difference of a +1 and a -1 generator (M1); a paired null is a matrix algebra (M2).'),
   'projective': ('E', 'The projective generator of step 11 is exactly this difference inside the conformal algebra Cl(n+1,1) (M1, recalled for the conformal reading).'),
   'cells': ('S', 'The degenerate cell (p,q,r) sits inside the cell (p+r,q+r) on the same clock c = p - q.')}),
 ('K7', 'K', 'Fock space as exterior algebra; creation = wedge, annihilation = contraction; Cl(m,m) acts irreducibly (Sect. 4.3, 8.2)', {
   'rule': ('E', 'The anticommutation relations and the number operator on the 2^n labels (B1); the sign is the Jordan-Wigner string (K1b).'),
   'spin': ('S', 'The 32 = Lambda C^5 of the generation pages is this Fock space.'),
   'spring': ('A', 'The oscillator ladder [N,a] = -a is the same relation as for the boson; only the commutator becomes a super-commutator (B1). Our reading of step 15.')}),
 ('K8', 'K', 'Simplicial boundary d_V = s_V contraction, d^2 = 0 (Sect. 4.1)', {
   'rule': ('E', 'The same signs make the cube of labels a complex: d^2 = 0 and exact for n <= 6 (K1e); the signs are the unique ones up to gauge (K1c, K1d).')}),
 ('K9', 'K', 'Irreducible representations: number and dimension (Thm 8.2-8.4, Table 8.1)', {
   'cells': ('S', 'The split rank (number of simple factors times N) equals 2^w, w the Witt index of the quadric of squares (W1).'),
   'clock': ('S', 'Real, complex or quaternionic is the sign of the same Gauss sum (K4b).')}),
 ('K10', 'K', 'Octonions through Clifford algebras; Hurwitz theorem (Sect. 8.3.1)', {
   'rule': ('E', 'The octonions are the same eight labels with a sign that is a 2-cochain, not a cocycle; the associator is (-1)^det over GF(2) (K3a, K3b).'),
   'furey': ('S', 'Furey\'s page builds on the octonions; the notes\' formula with the 3-vector C was not tested.')}),
 ('W1', 'W', 'Schur\'s lemma: End of an irreducible representation is R, C or H (Dyson threefold way)', {
   'cells': ('S', 'The type of the cell is the Frobenius-Schur indicator of the group generated by the labels (K4b).'),
   'clock': ('S', 'The three types are the three signs of Re S + Im S = Re((1 - i) S), the sum of the squares of the labels, S the Gauss sum (K4c; the real part of S alone is 0 at c = 2).')}),
 ('W2', 'W', 'The ten real super division algebras: R, C, H even; 2 + 3 + 2 with an odd generator', {
   'clock': ('E', 'Ungraded the Clifford algebras have 5 types, graded 8: the pair (type, type of the even part) separates the eight values of the clock (C1); n = 1 gives the two graded division algebras with e^2 = +-1 (L1a).'),
   'cells': ('S', 'The two complex ones are Cl_n(C), n even or odd; recalled.')}),
 ('W3', 'W', 'Brauer-Wall group of R is Z8 (Wall 1964)', {
   'clock': ('E', 'Clock = p - q mod 8 is a homomorphism for the graded product (K4a, K5a); the group law is additive; null generators contribute 0 (K4a).'),
   'rule': ('S', 'The graded tensor product is the label concatenation (K5a).')}),
 ('W4', 'W', 'Real and complex Bott periodicity unified', {
   'clock': ('S', 'The Gauss sum has period 8 in p - q, period 2 for complex generators; Cl(p+8,q) = Cl(p,q) (x) M_16(R) (recalled).'),
   'groups': ('S', 'Gauss-Milgram: the signature mod 8 of an even lattice is the Brown phase of its discriminant form (Q4).')}),
 ('W5', 'W', 'Ten symmetry classes of free-fermion matter (Altland-Zirnbauer; Ryu et al.)', {
   'clock': ('S', 'Standard, quoted: Baez’s paper states that the ten super division algebras (the eight clock values plus the two complex ones) correspond to the ten symmetry classes; the atlas computes only the eight graded pairs (C1), not the physical classification, and which class sits at which clock value is open here (QC3).')}),
 ('W6', 'W', 'Freed-Moore twisted equivariant matter; Deligne-Morgan; Trimble (the references)', {}),
 ('T1', 'T', 'Z-algebra Cl_Z: aᵢ² = 0, aᵢaⱼ = −aⱼaᵢ for |i−j| > 1, aᵢaᵢ₊₁ + aᵢ₊₁aᵢ = 1', {
   'cells': ('E', 'Over R it is Cl(m,m) for 2m generators (clock 0, matrix algebra, unimodular over Z) and Cl(m,m,1) for 2m + 1 generators (T3, T4).'),
   'null': ('E', 'The nilpotent aᵢ are paired nulls, not label 0; the radical vector of an odd truncation, a_1 - a_3 + a_5 - ..., is (T2).'),
   'rule': ('S', 'In a non-orthogonal basis (hyperbolic pairs); the bit-rule signature is read off the path graph (T3).')}),
 ('T2', 'T', 'Fock space V: even-label sets, a_2j wedges, a_(2j-1) contracts at two sites, sign (-1)^{occupied below}; Cl_Z(n) = End_Z(V_n)', {
   'rule': ('E', 'Relations and faithfulness checked for n = 1, 2, 3 on the 2^n labels (T1); the sign is the Jordan-Wigner string (K1b).'),
   'spin': ('S', 'The faithful module of the finite truncation is the Fock space of the labels.')}),
 ('T3', 'T', 'Signs from odd cohomological shifts of crossings; [X[1]] = -[X] in K0; sorting sign = number of inversions (Lemma 4.20, 6.11)', {
   'rule': ('S', 'The bit-rule sign is the parity of the number of inversions when the labels are sorted (K5c): the paper\'s eta. That each inversion is an odd shift is the paper\'s statement, not tested.')}),
 ('T4', 'T', 'DG category CL, monoidal functor, K0(CL) = Cl_Z; contact category of a strip; morphisms over F2', {}),
 ('T5', 'T', 'Open: Hom(empty, empty) in CL (Remark 2.6), Conjecture 2.11', {}),
 ('M1', 'M', 'Cat-arrows space V: arrows are vectors, composition is the partial sum', {}),
 ('M2', 'M', 'Inner product from composability; orthogonal = not composable in either order', {
   'rule': ('A', 'Sound reading, ours: a quiver gives a symmetric form (2 on the diagonal, 1 on composable pairs) and hence a Clifford algebra; on the cube category its signature goes (4,0,0), (11,0,1), (26,4,2) (J3).'),
   'groups': ('A', 'The quiver forms that matter are the Tits and Euler forms: ADE, extended = null root (Q1-Q3).')}),
 ('M3', 'M', 'Wedge product, "geometric Cat-algebra" and the two Clifford properties (e^2 = 1, f g = -g f)', {}),
 ('C1', 'C', 'Cube category (poset of labels); sign assignment on the squares; Koszul complex', {
   'rule': ('E', 'Every square anticommutes with the Jordan-Wigner sign (K1a); it is the unique assignment up to gauge, H^1(cube; F2) = 0 (K1c, K1d); the boundary squares to zero and is exact (K1e).')}),
 ('C2', 'C', 'Group cohomology: H^2(Z2^n; Z2) = quadratic forms; twisted group algebras; Clifford = the family with all c_ij = 1', {
   'rule': ('E', 'dim H^2 = n(n+1)/2 computed for n <= 4; invariants (squares, commutators) separate the classes; the bit rule has all commutators 1 (K2a, K2b).'),
   'cells': ('S', 'The other classes (some pairs commuting) are twisted group algebras that are not Clifford algebras; recalled.')}),
 ('C3', 'C', 'Associator as a 3-cocycle; octonions as a cochain twist of the group algebra of Z2^3', {
   'rule': ('E', 'Pentagon identity for (-1)^det on Z2^3, and the associator is the coboundary of the octonion sign (K3b).'),
   'furey': ('S', 'The octonionic blocks of the Furey page carry this associator.'),
   'shapes': ('S', 'The 168 independent triples are the complement of the 7 lines of the Fano plane (K3a).')}),
 ('C4', 'C', 'Super vector spaces, Koszul sign rule, supertrace', {
   'rule': ('E', 'The bit rule is the Koszul rule (K5a) and the sorting sign (K5c); parity-supertrace of the Fock space is 0 (B1).'),
   'matter': ('S', 'Fermion statistics of step 8 as the symmetric braiding of super vector spaces; recalled.'),
   'spin': ('S', 'Spinors are odd objects of that category; recalled.')}),
 ('C5', 'C', 'Brown invariant of the Z4-valued quadratic form of the labels; Gauss sum; Frobenius-Schur indicator', {
   'clock': ('E', 'Sum over labels of i^(|a∩P| - |a∩Q|) = (1+i)^p (1-i)^q, phase (p-q) pi/4; the sum of the squares of the labels, Re S + Im S = Re((1 - i) S), gives the type by its sign (K4a-c; the real part of S alone is 0 at c = 2; the Frobenius-Schur count per simple summand is +1, 0, -2, T4).'),
   'cells': ('E', 'Type and number of simple factors for 45 signatures (K4b).')}),
 ('C6', 'C', 'Frobenius algebra, Nakayama automorphism: the complement mask is a Frobenius duality, not a metric Hodge star', {
   'rule': ('E', 'The pairing (a, a xor 11..1) is non-degenerate for every signature, label 0 included; the Nakayama automorphism is the grade involution to the power n + 1 (F1, F2).'),
   'null': ('E', 'The scalar-part (trace) form is blind to null labels, the top-blade form is not (F4); every state is blind to them too and the top-blade form is never a state (C3); a symmetrising form exists iff n is odd or r = 0 (F3), because every conjugator of the grade involution lies in the radical (F5).'),
   'projective': ('E', 'Cl(3,0,1) is Frobenius but not symmetric (F3).'),
   'spin': ('S', 'Born rule in Cl(3,0): probability 2<rho P>_0 = (1 + v.u)/2 and the Bloch ball (C2); the trace is a symmetric Frobenius form, unique up to a central unit among the symmetric ones, while all Frobenius forms are lambda(u .) with u any unit (F5; T3). This is item 1 of "Next, in order".')}),
 ('C7', 'C', 'Radical, Loewy series, super-centre, graded Azumaya; representation type of the exterior algebra (finite r <= 1, tame r = 2, wild r >= 3: recalled)', {
   'null': ('E', 'Radical dimension 2^n - 2^(p+q), Loewy length r + 1, super-centre of dimension 2^r (R1-R3, 56 signatures). The representation types are recalled, not computed.'),
   'projective': ('E', 'Same for r = 1: the dual-number direction (R1-R3).')}),
 ('C8', 'C', 'Grading lift: among label-homogeneous gradings the Z2 grading lifts to Z exactly on null generators (an additive Z-degree; N-graded exterior algebra)', {
   'null': ('E', 'Free rank of the universal label-homogeneous grading group equals r for all 34 signatures with 1 to 4 generators (G1; universal group Z2^(p+q) x Z^r, T2); for arbitrary gradings the rank can exceed r: M2(R) = Cl(2,0) has a Z-grading by matrix units (G2).'),
   'projective': ('S', 'The translation (null) generator of the projective algebra is the one whose Z2-degree lifts to an additive Z-degree.')}),
 ('C9', 'C', 'Paired null (Witt pair, hyperbolic plane) versus unpaired null (radical)', {
   'null': ('E', 'u = e1 + e2, v = e1 - e2 in Cl(1,1) pair up (u v + v u = 4, matrix algebra, radical 0); two unpaired nulls span a radical of dimension 3 (M2).'),
   'cells': ('S', 'In the Witt group (+1) + (-1) = 0; the clock does not move across a pair (K4a).')}),
 ('C10', 'C', 'Witt index = split rank; maximal commuting sets of blades; the finite shadow of the spectral theorem', {
   'groups': ('E', 'Exhaustive over totally singular subspaces: 2^w = number of simple factors times N for 30+ signatures; Cl(4,0): 5; Cl(6,0): 27 and 45; Cl(8,0): 135 and 270 = 135 + 135 (W1-W3).'),
   'shapes': ('S', '135 and 270 are the points and solids of Q+(7,2); 27 and 45 the points and lines of the elliptic quadric Q-(5,2), not the Klein quadric (recalled geometry, counted; T11).'),
   'furey': ('A', 'The two families of 135 solids and the 135 points are the three 135s of triality; a reading ours, not tied to her blocks.')}),
 ('C11', 'C', 'Quiver forms: Dynkin = definite, extended = one null root, hyperbolic = one negative direction; E8 -> E9 -> E10', {
   'groups': ('E', 'Signatures (n,0,0), (n,0,1), E10 (9,1,0), E11 (10,1,0); det Cartan(E_n) = 9 - n; positive roots 36, 63, 120; null root of E8~ with marks summing to 30 (Q1-Q3).'),
   'null': ('E', 'The first step beyond a finite root system adds exactly one null direction (Q1, Q2); reading it as a label 0 is ours.'),
   'shapes': ('S', 'The Gosset series E6, E7, E8 of page 5 is the finite part of this ladder.')}),
 ('C12', 'C', 'Gauss-Milgram: Brown phase of the discriminant form = signature mod 8', {
   'groups': ('E', 'A3, A8, D4, D8, E6, E7, E8, numerically with exact rational norms (Q4).'),
   'clock': ('E', 'The same phase as the Gauss sum of the labels of Cl(n,0) (K4a, Q4).')}),
 ('C13', 'C', 'E_n / 2E_n as a quadratic space equals the blades of Cl(n,0): W(E_n) mod 2 = O(Q)', {
   'groups': ('E', 'Counts and radical equal for n = 3..8: 4, 10, 20, 36, 64, 120 blades with square -1 (Q5); the group statement is checked by the atlas (groups_check.py part B, n = 3..8) and proved in T9: E_n/2E_n carries the label form of Cl(n,0) for all n >= 3, A_n/2A_n that of Cl(0,n), they coincide iff 4 | n.'),
   'shapes': ('S', 'The Gosset polytopes 2_21, 3_21, 4_21 have these root systems.')}),
 ('C14', 'C', 'Euler form of the cube category (incidence algebra of the Boolean lattice); Gram form of Majkic\'s atoms', {
   'null': ('A', 'Signature (2,0,0), (4,0,0), (6,0,2), (14,2,0) for n = 1..4: definite, then null directions at n = 3, then indefinite; the Gram form of the atoms does the same. Observed, meaning open (E1, J3).')}),
 ('C15', 'C', 'Fermionic and bosonic ladder: the same relations in super vector spaces', {
   'spring': ('S', 'Step 15: [N,a] = -a and [a,a+] = 1 hold with the super-commutator; Pauli a^2 = 0 is the super-commutator of an odd element with itself (B1). This answers item 3 of "Next, in order" at the level of relations.'),
   'spin': ('S', 'sdim of the Fock space is 0 while dim = 2^n (B1).')}),
 ('C16', 'C', 'Ladder steps: double by the graded product; halve by the even part, which needs an invertible vector (except for at most two generators, all null); restrict to a face of the cube', {
   'cells': ('E', 'Doubling is exact (K5a); halving works for every signature with a non-null generator and fails exactly for the exterior algebra on three or more generators (K5b at r = 3; T5(d)).'),
   'mirrors': ('S', 'Step 3 reflects in invertible vectors; a null vector has no reflection.'),
   'null': ('E', 'Label 0 cannot be peeled off from the top in the sense of T5(d): the even part of the exterior algebra on r >= 3 generators is not a Clifford algebra (K5b).')}),
]
ROWS = [(r[0],) + tuple(r[1:]) for r in ROWS]

def stats():
    from collections import Counter
    n = len(ROWS); col = {k: Counter() for k, *_ in COLS}; per = []
    order = {'E': 3, 'S': 2, 'A': 1}
    for rid, src, title, cells in ROWS:
        best = 'gap'
        for k, (g, note) in cells.items():
            col[k][g] += 1
            if best == 'gap' or order[g] > order[best]: best = g
        per.append((rid, best))
    cnt = Counter(b for _, b in per)
    bysrc = {s: Counter(b for (rid, b), r in zip(per, ROWS) if r[1] == s) for s in ORDER}
    total_cells = sum(len(r[3]) for r in ROWS)
    cellg = Counter(g for r in ROWS for g, _ in r[3].values())
    return dict(n=n, best=cnt, bysrc=bysrc, col=col, total_cells=total_cells, cellg=cellg, per=per)

if __name__ == '__main__':
    s = stats()
    print('rows', s['n'], 'best grade per row', dict(s['best']), 'cells', s['total_cells'], dict(s['cellg']))
    for k, v in s['bysrc'].items(): print(k, dict(v))
    keys = [k for k, *_ in COLS]
    assert all(kk in keys for r in ROWS for kk in r[3]), 'unknown column'
    print('columns', {k: sum(s['col'][k].values()) for k in keys})
