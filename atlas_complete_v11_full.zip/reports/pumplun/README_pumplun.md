# Bit rule, crossed products and Petit algebras: a dictionary report (7 October 2026)

Shipped in the web-app package as `reports/pumplun/` (this folder) with the built page in `../html/pumplun_dictionary_report.html`; `../zips/pumplun_report.zip` holds the page and this folder (members `html/pumplun_dictionary_report.html` and `pumplun/…`).

The page is a dictionary between the atlas (one sign cochain on Z2^n, the bit rule, that gives the Clifford algebras and the octonions) and the skew polynomial constructions of S. Pumplün, arXiv:2606.18371: Petit algebras S_f = K[t;σ]/K[t;σ]f, the algebras S_f(K,i0,ν,ρ), MRD codes, isotopy and idealisers. It is written about the paper; it is one self-contained file that opens offline, in light and dark, and runs every computation in the browser.

## Files
- `../html/pumplun_dictionary_report.html`: the report, built by `build/build.py`. §0 the atlas in one page; §1 the dictionary (atlas word, word of the paper, where it is checked); §2 twelve steps from the fields to the constructions of the paper, each with a live widget W0–W12; §3 nineteen noise and null tests N1–N19 that run in the browser; §4 what was reproduced and six points P1–P6 where the computation differs from the statement as read (each may come from a misreading on our side); §5 the build down to the atlas and to physics; §6 the atlas's views and lenses in the language of the paper; §7 open questions Q1–Q7; §8 glossary and references.
- `build/`: the sources. `template.html` (the text), `style.css`, `engine.js` (finite fields, K[t;σ], Petit algebras and S_f(K,i0,ν,ρ), nuclei and idealisers, bit-rule algebras), `analysis.js` (the statements of the paper as functions: Theorem 3.2, Proposition 3.5, Lemmas 7.1–7.3, Theorems 4.1, 5.4, 5.7, 6.1), `lib.js`, `widgets.js`, `noise.js`, `main.js`, `status_chips.py` (the five status icons as a hidden sprite, the chip, the legend line and their style rules; the same file in the six report folders); `build.py` joins them into the page (`python3 build/build.py`). `package.json` there marks the scripts as classic (CommonJS) scripts for node.
- `pumplun_checks.py`: the independent re-run in plain Python (standard library only): the same statements over F9, F27 and with `--full` the 4,704 MRD cases over F8, and the hand-checkable cases of P1 and P3 and the sign cochains of Q2. It prints one line `ok   C<n>:` per claim (C1–C9; C10–C11 with `--full`) and exits 1 if one fails. `--out FILE.json` writes the numbers.
- `golden.json`: the numbers of `python3 pumplun_checks.py --full --out golden.json` (about 5 minutes; without `--full` about 15 seconds). The JavaScript engine and the page are compared with it.
- `build/test_engine.js` (the engine against `golden.json` on F9 exhaustive, 23,040 algebras, and F27; about 4 seconds), `build/test_f8.js` (the F8 enumeration of 4,704 cases in the engine; about 5 minutes).
- `test_report_pumplun.py`: 35 tests that the page agrees with its sources: it is what `build/build.py` makes of `build/`; its numbers are those of `golden.json` and of the log; sections, widgets, noise tests, points and questions are all there and cite things that exist; the page is written about a paper (no second person but the reader's own browser, none of the sentences addressed to an author, the author named only as an author); no history wording (`../no_history.py`); no external request, no address; every script has the licence header; a fresh run of `pumplun_checks.py` and of the engine test gives the recorded numbers. `--full` adds the F8 enumeration.
- `test_page_pumplun.mjs`: the browser test (needs playwright with Chromium): thirteen widgets render, the 19 noise tests run (13 passed, 6 differ from the statement as read, 0 failed), no console error, no sideways scroll at 400 and 375 px, the theme button toggles, no request outside the file. About one minute.
- `logs/`: `pumplun_checks.log` (quick run), `pumplun_checks_full.log` (with `--full`).

## Rerun
Needs Python 3 and node; playwright with Chromium for the browser test.

    python3 pumplun_checks.py > logs/pumplun_checks.log
    python3 build/build.py && python3 test_report_pumplun.py
    (cd build && node test_engine.js)
    node test_page_pumplun.mjs

## Honest status
- "Checked here" means a widget or the independent script recomputed it: Theorem 3.2 of the paper against brute force in all 23,040 algebras S_f(F9,i0,ν,ρ) (3,200 division algebras, 0 disagreements); Lemmas 7.1–7.3 over F9 (class A exact as printed); Example 7.4 (2,304 of 2,304 over F9, 3,840 of 3,840 sampled over F25); Theorem 6.1 on 56 Petit division algebras; Kaplansky's trick; Theorem 4.1 in the reading of the proof, in all 4,704 cases over F8; the bit-rule side (cocycle condition, mod-8 type of every Cl(p,q) with p+q ≤ 6 computed twice, the 168 triples of the octonions).
- Six points differ from the statements as read (P1–P6) and are stated as points to check, not as findings against the paper: Proposition 3.5 as printed against Theorem 3.2 (6,400 of the 23,040 algebras), the literal reading of Theorem 4.1 (4,676 of 4,704), the product of Theorem 5.4, Theorem 5.7(ii), the class size in Example 4.4 (273 = 3 × 91), the labelling of the class lists of §7.1. Not tested individually: Theorems 3.8, 3.10, 4.2, 6.2, 6.7, a list of corollaries and examples, and the nuclei formulas for ν ≠ 0.
- Physics: the page makes no claim about it; the atlas's physical readings enter only as inputs (a chart with ∇, a time direction, a complex structure) that the rule does not supply.
- The report changes no statement of the web app. No address of any person is in any file.
