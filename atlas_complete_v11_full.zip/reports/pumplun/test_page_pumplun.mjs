// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Browser smoke test of ../html/pumplun_dictionary_report.html: the page opens as a file and loads nothing from the network; its thirteen widgets W0-W12 all render without an
// error; the 19 noise tests run in the browser (about 1 to 2 minutes) with the result the report states: 13 passed, 6 differ from the statement as read (N3, N6, N7, N17, N18,
// N19), 0 failed; no console error; no sideways scroll at 400 and 375 px; every status chip is an icon chip, those of the noise table too; the theme button toggles. Needs playwright with Chromium (exit 77 without it).   Run: node test_page_pumplun.mjs
import path from 'node:path'; import { fileURLToPath, pathToFileURL } from 'node:url';
let chromium; try { ({ chromium } = await import('playwright')); } catch (e) { console.log('SKIP: playwright is not installed'); process.exit(77); }
const PAGE = pathToFileURL(path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'html', 'pumplun_dictionary_report.html')).href;
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const b = await chromium.launch(); const errs = []; const external = [];
const watch = (pg, tag) => { pg.on('pageerror', e => errs.push(tag + ' pageerror: ' + e.message)); pg.on('console', m => { if (m.type() === 'error') errs.push(tag + ' console: ' + m.text()); });
  pg.on('request', r => { const u = r.url(); if (!/^(file|data|blob|about):/.test(u)) external.push(u); }); };
const pg = await b.newPage({ viewport: { width: 1280, height: 900 } }); watch(pg, 'desktop');
await pg.goto(PAGE); await pg.waitForTimeout(500);
const secs = await pg.$$eval('main section', s => s.map(x => x.id));
ok(JSON.stringify(secs) === JSON.stringify(['s0', 's1', 's2', 's3', 's4', 's5', 's6', 's7', 's8']), 'nine sections s0..s8 in order: ' + secs.join(','));
ok((await pg.title()).startsWith('Bit rule, crossed products and Petit algebras'), 'the page title is the dictionary report title');
await pg.evaluate(() => window.PUM_ALL()); await pg.waitForTimeout(3000);
for (const id of ['W0', 'W1', 'W2', 'W3', 'W4', 'W5', 'W6', 'W7', 'W8', 'W9', 'W10', 'W11', 'W12']) {
  const r = await pg.$eval(`[data-w="${id}"]`, el => ({ kids: el.children.length, err: el.querySelectorAll('.err').length, bad: el.querySelectorAll('.st.bad').length, busy: el.querySelectorAll('.busy').length }));
  ok(r.kids >= 2 && r.err === 0 && r.bad === 0 && r.busy === 0, `widget ${id} renders (${JSON.stringify(r)})`);
}
await pg.click('[data-w="NOISE"] button.b:not(.ghost)');
await pg.waitForFunction(() => /19 of 19 run/.test(document.querySelector('[data-w="NOISE"]').innerText), null, { timeout: 300000 });
const note = await pg.innerText('[data-w="NOISE"] p.note');
ok(/19 of 19 run: 13 passed, 6 differ from the statement as we read it, 0 failed/.test(note), 'noise summary: ' + note);
const rows = await pg.$$eval('[data-w="NOISE"] tbody tr', trs => trs.map(tr => [tr.querySelector('.nid').innerText.split('\n')[0].trim(), tr.querySelector('.ns').innerText]));
const differ = rows.filter(r => /differs/.test(r[1])).map(r => r[0]).join(','), passed = rows.filter(r => /passed/.test(r[1])).length;
ok(rows.length === 19 && differ === 'N3,N6,N7,N17,N18,N19' && passed === 13, `the six rows that differ are N3, N6, N7, N17, N18, N19 and 13 pass (differ: ${differ}; passed: ${passed})`);
// status chips: every chip, those of the page and those the page makes (the noise table), is an icon (role img, a name and a hover text that start with the word, one use of a symbol of the sprite, no text) and is visible
const chips = await pg.$$eval('.chip', cs => cs.map(c => ({ flag: [...c.classList].find(k => k !== 'chip'), role: c.getAttribute('role'), name: c.getAttribute('aria-label') || '', tip: c.getAttribute('title') || '', text: c.textContent.trim(), uses: c.querySelectorAll('svg.ic use').length, w: c.getBoundingClientRect().width })));
ok(chips.length >= 40 && chips.every(c => ['standard', 'checked', 'ours', 'open'].includes(c.flag) && c.role === 'img' && c.name.startsWith(c.flag) && c.tip.startsWith(c.flag) && c.text === '' && c.uses === 1), `all ${chips.length} chips are icon chips: ` + JSON.stringify(chips.filter(c => !(c.role === 'img' && c.name.startsWith(c.flag) && c.text === '' && c.uses === 1)).slice(0, 2)));
const nchips = await pg.$$eval('[data-w="NOISE"] tbody tr', trs => trs.map(tr => { const c = tr.querySelector('.nid .chip'); return [tr.querySelector('.nid').innerText.split('\n')[0].trim(), c ? c.className : '', c ? c.getAttribute('aria-label') : '', c ? c.getBoundingClientRect().width : 0]; }));
const askRows = nchips.filter(r => r[2] === 'open: to check').map(r => r[0]).join(','), paperRows = nchips.filter(r => r[2] === 'standard: a statement of the paper').map(r => r[0]).join(',');
ok(nchips.length === 19 && nchips.every(r => r[3] > 10) && askRows === 'N3,N6,N7,N17,N18,N19' && paperRows === 'N2,N4,N5,N16', `each of the 19 noise rows has one visible icon chip: the six that differ from the statement as read are open (to check), the four that restate the paper are standard (a statement of the paper) (open: ${askRows}; paper: ${paperRows})`);
// light and dark
const t0 = await pg.evaluate(() => document.documentElement.getAttribute('data-theme')); await pg.click('#themebtn'); const t1 = await pg.evaluate(() => document.documentElement.getAttribute('data-theme'));
await pg.click('#themebtn'); const t2 = await pg.evaluate(() => document.documentElement.getAttribute('data-theme'));
ok(t1 && t1 !== t2 && t1 !== t0, `the theme button toggles (${t0} -> ${t1} -> ${t2})`);
// phones
for (const w of [400, 375]) {
  const ph = await b.newPage({ viewport: { width: w, height: 860 } }); watch(ph, 'phone' + w);
  await ph.goto(PAGE); await ph.waitForTimeout(500); await ph.evaluate(() => window.PUM_ALL()); await ph.waitForTimeout(3000);
  const ov = await ph.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  ok(ov.sw <= ov.cw, `no sideways scroll at ${w} px (${ov.sw}/${ov.cw})`); await ph.close();
}
ok(errs.length === 0, 'no page error and no console error: ' + errs.join(' | '));
ok(external.length === 0, 'no request outside the file: ' + external.join(' '));
await b.close();
console.log(`test_page_pumplun: ${checks - bad} of ${checks} checks pass`); process.exit(bad ? 1 : 0);
