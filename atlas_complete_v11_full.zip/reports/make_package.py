#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Rebuilds the six zips from the shipped report folders and writes html/index.json (the list of the six reports) and MANIFEST.json (sha256 and size of every
file in reports/).
Python standard library only.  Deterministic: fixed member order (sorted paths), fixed timestamps (7 October 2026, 12:00), fixed permissions.

    python3 make_package.py            writes zips/category_report.zip, baez_report.zip, schuller_report.zip, hestenes_report.zip, furey_report.zip,
                                       pumplun_report.zip, html/index.json and MANIFEST.json
    python3 make_package.py --check    writes nothing; exit 1 if a zip does not unpack to exactly its folder and its page, if html/ does not hold exactly
                                       the six pages and index.json, or if index.json or MANIFEST.json is not current

html/index.json lists the six reports for the web app (id, file, title, one line, the check scripts, the number of ok lines of their logs, the test suite,
the size of the page); the title is the page's own heading, the counts are those of the logs.

A zip holds the report's page under html/ and its folder under the folder's name (html/category_atlas_report.html and category/..., and so on for the
others), so unpacking it in reports/ gives the same tree as the package.  Left out of zips and manifest: __pycache__, the papers' texts (txt/, never
shipped) and editor or system files.  Refused: any e-mail address or mail link in a text file, and any absolute path of a working machine."""
import hashlib, html, io, json, os, re, sys, zipfile
HERE = os.path.dirname(os.path.abspath(__file__))
REPORTS = [
    dict(id='category', folder='category', page='category_atlas_report.html', scripts=['category/cat_check.py'], logs=['category/logs/cat_check.log'], suite='category/test_report_cat.py',
         line='What label 0 is, seen through categories: findings, dead ends, perspectives, the checks'),
    dict(id='baez', folder='baez', page='baez_atlas_report.html', scripts=['baez/baez_check.py'], logs=['baez/logs/baez_check.log'], suite='baez/test_report_baez.py',
         line='Seven Baez papers and the atlas: findings, the translation matrix, the checks'),
    dict(id='schuller', folder='schuller', page='schuller_bridge_report.html', scripts=['schuller/bridge_check.py', 'schuller/bridge_check_qm.py', 'schuller/fibre_check.py'],
         logs=['schuller/logs/bridge_check_final.log', 'schuller/logs/bridge_check_qm_final.log', 'schuller/logs/fibre_check_final.log'], suite='schuller/test_report.py',
         line="Schuller's lectures read as fibre and base: findings, the matrix, the checks"),
    dict(id='hestenes', folder='hestenes', page='hestenes_ldg_report.html', scripts=['hestenes/hest_check.py'], logs=['hestenes/logs/hest_check.log'], suite='hestenes/test_report_hestenes.py',
         line="Hestenes' space-time algebra and gauge-theory gravity seen through the bit rule: the Dirac and Maxwell identities, the checks"),
    dict(id='furey', folder='furey', page='furey_report.html', scripts=['furey/furey_papers_check.py', 'furey/furey_construction_check.py'],
         logs=['furey/logs/furey_papers_check.log', 'furey/logs/furey_construction_check.log'], suite='furey/test_report_furey.py',
         line="Furey's six papers and the atlas: the algebra rebuilt from the octonion table, the spectra, the checks"),
    dict(id='pumplun', folder='pumplun', page='pumplun_dictionary_report.html', scripts=['pumplun/pumplun_checks.py'], logs=['pumplun/logs/pumplun_checks.log'], suite='pumplun/test_report_pumplun.py',
         line='A dictionary between the atlas and the skew polynomial constructions of arXiv:2606.18371, recomputed over finite fields in the browser'),
]
ZIPS = {r['id'] + '_report.zip': (r['folder'], r['page']) for r in REPORTS}
PAGES = sorted(r['page'] for r in REPORTS)
HTML_DIR = sorted(PAGES + ['index.json'])
SKIP_DIRS = {'__pycache__', 'txt', '.git'}
SKIP_FILES = re.compile(r'(\.pyc|~|\.swp|\.DS_Store)$')
TEXT = re.compile(r'\.(py|sh|js|mjs|md|json|html|css|log|txt)$')
MAIL = re.compile(r'[\w.+-]+@[\w-]+(\.[\w-]+)*\.[A-Za-z]{2,}')
MACHINE = re.compile('|'.join(['/tm' + 'p/claude', '/ho' + 'me/claude', 'scratch' + 'pad', '/Us' + 'ers/']))   # written in pieces so that this file does not match itself
DATE = (2026, 10, 7, 12, 0, 0)

def files(root):
    out = []
    for d, dirs, fs in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(fs):
            if not SKIP_FILES.search(f): out.append(os.path.relpath(os.path.join(d, f), HERE).replace(os.sep, '/'))
    return sorted(out)

def clean(rel, data):
    if TEXT.search(rel):
        t = data.decode('utf-8')
        if rel.endswith('.html'): t = re.sub(r'<!--.*?-->', '', t, flags=re.S)
        if MAIL.search(t) or ('mail' + 'to:') in t: sys.exit(f'refused: an e-mail address or a mail link in {rel}')
        if MACHINE.search(t): sys.exit(f'refused: a path of a working machine in {rel}')

def members(folder, page):
    """The files a zip holds: the report's page and every file of its folder (paths relative to reports/)."""
    return sorted(['html/' + page] + files(os.path.join(HERE, folder)))

def zip_bytes(folder, page):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        for rel in members(folder, page):
            data = open(os.path.join(HERE, rel), 'rb').read(); clean(rel, data)
            info = zipfile.ZipInfo(rel, date_time=DATE); info.create_system = 3; info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return buf.getvalue()

def unpacks_to(zpath, folder, page):
    """True when the zip holds exactly the page and the files of the folder, byte for byte (and nothing else)."""
    with zipfile.ZipFile(zpath) as z:
        have = sorted(i.filename for i in z.infolist() if not i.is_dir())
        return have == members(folder, page) and all(z.read(m) == open(os.path.join(HERE, m), 'rb').read() for m in have)

def html_is_the_six():
    return sorted(os.listdir(os.path.join(HERE, 'html'))) == HTML_DIR

def index_json():
    out = []
    for r in REPORTS:
        page = open(os.path.join(HERE, 'html', r['page']), encoding='utf-8').read()
        h1 = re.search(r'<h1[^>]*>(.*?)</h1>', page, re.S)
        title = html.unescape(re.sub(r'<[^>]+>', '', h1.group(1))).strip()
        n = sum(len(re.findall(r'^ok  ', open(os.path.join(HERE, l), encoding='utf-8').read(), re.M)) for l in r['logs'])
        out.append({'id': r['id'], 'file': 'reports/html/' + r['page'], 'title': title, 'line': r['line'], 'scripts': ['reports/' + x for x in r['scripts']], 'checks': n, 'logs': ['reports/' + x for x in r['logs']],
                    'suite': 'reports/' + r['suite'], 'zip': 'reports/zips/' + r['id'] + '_report.zip', 'bytes': os.path.getsize(os.path.join(HERE, 'html', r['page']))})
    return json.dumps({'about': 'The six reports of reports/html/, in the order of the Lenses page and the research pages; written by make_package.py. every path is relative to the package (the folder that holds reports/); checks: the ok lines of the logs; bytes: the size of the page.',
                       'reports': out}, ensure_ascii=False, indent=1) + '\n'

def manifest():
    entries = {}
    for rel in files(HERE):
        if rel == 'MANIFEST.json': continue
        data = open(os.path.join(HERE, rel), 'rb').read(); clean(rel, data)
        entries[rel] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    return json.dumps({'about': 'reports/ of the Cascade Atlas web-app package: sha256 and size of every shipped file (this file excepted); written by make_package.py',
                       'zips': {z: {'page': 'html/' + page, 'folder': f + '/'} for z, (f, page) in ZIPS.items()}, 'files': entries,
                       'total_bytes': sum(e['bytes'] for e in entries.values())}, ensure_ascii=False, indent=1) + '\n'

if '--check' in sys.argv:
    bad = [z for z, (f, page) in ZIPS.items() if not os.path.exists(os.path.join(HERE, 'zips', z)) or not unpacks_to(os.path.join(HERE, 'zips', z), f, page)]
    extra = sorted(set(os.listdir(os.path.join(HERE, 'zips'))) - set(ZIPS)) if os.path.isdir(os.path.join(HERE, 'zips')) else []
    pages = html_is_the_six()
    ix = os.path.join(HERE, 'html', 'index.json'); ix_ok = pages and os.path.exists(ix) and open(ix, encoding='utf-8').read() == index_json()
    m = os.path.join(HERE, 'MANIFEST.json'); man_ok = os.path.exists(m) and open(m, encoding='utf-8').read() == manifest()
    good = not bad and not extra and pages and ix_ok and man_ok
    print(('up to date' if good else 'OUT OF DATE') + f': zips {"ok" if not bad and not extra else "differ: " + ", ".join(bad + extra)}, html/ {"holds the six pages and index.json" if pages else "does not hold exactly the six pages and index.json"}, index.json {"current" if ix_ok else "out of date"}, MANIFEST.json {"current" if man_ok else "out of date"}')
    sys.exit(0 if good else 1)
open(os.path.join(HERE, 'html', 'index.json'), 'w', encoding='utf-8').write(index_json()) if all(os.path.exists(os.path.join(HERE, 'html', pg)) for pg in PAGES) else sys.exit('html/ must hold the six pages: ' + ', '.join(PAGES))
if not html_is_the_six(): sys.exit('html/ must hold exactly the six pages and index.json: ' + ', '.join(HTML_DIR))
os.makedirs(os.path.join(HERE, 'zips'), exist_ok=True)
for old in sorted(set(os.listdir(os.path.join(HERE, 'zips'))) - set(ZIPS)): os.remove(os.path.join(HERE, 'zips', old))
for z, (f, page) in ZIPS.items():
    data = zip_bytes(f, page); open(os.path.join(HERE, 'zips', z), 'wb').write(data)
    assert unpacks_to(os.path.join(HERE, 'zips', z), f, page)
    print(f'wrote zips/{z}: {len(members(f, page))} files, {len(data)} bytes')
open(os.path.join(HERE, 'MANIFEST.json'), 'w', encoding='utf-8').write(manifest())
print(f'wrote MANIFEST.json: {len(files(HERE)) - 1} files')
