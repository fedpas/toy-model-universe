#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Bridge checks: the atlas's bit rule against the objects of Schuller's lectures (Geometric Anatomy of Theoretical Physics, 2013/14),
of "Gravitational closure of matter field equations" (Dull, Schuller, Stritzelberger, Wolz, arXiv:1611.08878) and of the review
"Constructive gravity: foundations and applications" (Schuller, arXiv:2003.09726).
Each block states the claim, the place in Schuller's text it is compared with, and what is computed.  Exact arithmetic (fractions) wherever possible;
numpy only where a block says so.  Run: python3 bridge_check.py   (needs the atlas package for bitcliff.py, see below)
Shipped in the webapp package as selfcheck/reports/bridge_check.py: needs bitcliff.py at <package>/selfcheck/steps15_17 (default: the package two levels up from this script; override with the environment variable ATLAS_PKG). Python dependencies: numpy (and the standard library). Writes nothing."""
import os, sys, random, itertools, math
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..'))      # the webapp package: two levels up from selfcheck/reports/
sys.path.insert(0, os.path.join(PKG, 'selfcheck', 'steps15_17'))
from bitcliff import Alg, sig, pc, reorder_sign, TYPES
import numpy as np

N_OK = N_BAD = 0
LOG = {}
def chk(cid, cond, msg=''):
    global N_OK, N_BAD
    if cond: N_OK += 1
    else:
        N_BAD += 1
    LOG.setdefault(cid, []).append((bool(cond), msg))
    print(('ok   ' if cond else 'FAIL ') + cid + (': ' + msg if msg else ''))

def clock_type(p, q):
    return TYPES[(p - q) % 8]

# ======================================================================================================================
# A. Lectures ch. 12 (Grassmann algebra) <-> the bit rule.  The Grassmann algebra is the bit rule with every generator null: Cl(0,0,n).
# ======================================================================================================================
def wedge_sign(a, b):
    return 0 if a & b else reorder_sign(a, b)
for n in range(1, 7):
    alg = Alg(sig(0, 0, n))
    ok = all(alg.blade_mul(a, b)[0] == wedge_sign(a, b) and alg.blade_mul(a, b)[1] == a ^ b for a in range(alg.N) for b in range(alg.N))
    chk('A1', ok, f'n={n}: all-null bit rule = wedge product on bit labels (e_a e_b = ±e_(a|b) if disjoint, 0 if they share a bit); {alg.N * alg.N} products')
# Theorem 12.8: omega ^ sigma = (-1)^{nm} sigma ^ omega  (pure degree)
bad = 0
for n in range(1, 7):
    alg = Alg(sig(0, 0, n))
    for a in range(alg.N):
        for b in range(alg.N):
            sa, ca = alg.blade_mul(a, b); sb, cb = alg.blade_mul(b, a)
            if sa != ((-1) ** (pc(a) * pc(b))) * sb or ca != cb: bad += 1
chk('A2', bad == 0, 'Thm 12.8 (graded commutativity, sign (-1)^{nm}) holds for every pair of blades, n<=6')
# the Clifford product is the wedge product deformed by the quadratic form: s(a,b) = wedge_sign(a,b) * prod_{i in a&b} eps_i
bad = 0; cnt = 0
for p in range(0, 5):
    for q in range(0, 5):
        if p + q == 0 or p + q > 6: continue
        alg = Alg(sig(p, q))
        for a in range(alg.N):
            for b in range(alg.N):
                s, c = alg.blade_mul(a, b); cnt += 1
                m = a & b; pr = 1
                for i in range(alg.n):
                    if m >> i & 1: pr *= alg.eps[i]
                # overlap bits contract to eps_i; disjoint part keeps the Grassmann sign of the reordering
                if s != reorder_sign(a, b) * pr or c != a ^ b: bad += 1
chk('A3', bad == 0, f'Cl(p,q) product = Grassmann reordering sign times the product of the squares of the shared generators ({cnt} products, p, q <= 4 and n <= 6): the quadratic form only decides what a shared bit contributes; with all squares 0 it is the wedge')
# top-grade part of e_a e_b is the wedge (the associated graded algebra of Cl(p,q) is the Grassmann algebra)
bad = 0
for (p, q) in [(1, 3), (3, 1), (2, 2), (4, 0), (0, 4), (2, 3)]:
    alg = Alg(sig(p, q))
    for a in range(alg.N):
        for b in range(alg.N):
            s, c = alg.blade_mul(a, b)
            if (a & b) == 0 and (s != wedge_sign(a, b) or pc(c) != pc(a) + pc(b)): bad += 1
chk('A4', bad == 0, 'disjoint blades multiply exactly as in the Grassmann algebra in every signature tested (Cl(1,3), Cl(3,1), Cl(2,2), Cl(4,0), Cl(0,4), Cl(2,3))')
# in the non-degenerate cells (no null generator) the metric Hodge star is multiplication by the pseudoscalar, which on labels is the complement XOR 1...1 with a sign;
# with a null generator it is not a Hodge star (A6 below): never write "Hodge star = XOR with 1...1" without that condition
bad = 0
for (p, q) in [(1, 3), (4, 0), (2, 2), (3, 1)]:
    alg = Alg(sig(p, q)); full = alg.N - 1
    for a in range(alg.N):
        s, c = alg.blade_mul(full, a)
        if c != a ^ full or pc(c) != alg.n - pc(a): bad += 1
    I2 = alg.sq(full)
    chk('A5', bad == 0, f'Cl({p},{q}): multiplying by the pseudoscalar sends a k-blade to the (4-k)-blade with the complement label (XOR 1111); I^2 = {I2:+d} (a non-degenerate cell: the pseudoscalar is invertible, this is his metric Hodge star; see A6 for a null generator)')
# A6: with a null generator the top blade is nilpotent, so multiplication by it is NOT a Hodge star; the complement map XOR 1...1 is still a Frobenius duality (category N3, T3)
a6_ok = True; a6_rows = []
for (p, q, r) in [(3, 0, 1), (1, 3, 1), (0, 0, 4), (2, 2, 1)]:
    alg = Alg(sig(p, q, r)); N = alg.N; full = N - 1; I2 = alg.sq(full)
    nm = sum(1 << i for i in range(alg.n) if alg.eps[i] == 0)
    img = {alg.blade_mul(full, a)[1] for a in range(N) if alg.blade_mul(full, a)[0] != 0}            # labels reached by multiplication with the top blade
    killed = all(alg.blade_mul(full, a)[0] == 0 for a in range(N) if a & nm)                           # every label with a null bit is sent to 0
    pairing = all(sum(1 for b in range(N) if alg.blade_mul(a, b)[0] != 0 and alg.blade_mul(a, b)[1] == full) == 1 for a in range(N))   # exactly one partner b = a xor 1...1 with e_a e_b = +-e_full
    a6_ok &= I2 == 0 and killed and len(img) == 2 ** (p + q) and pairing and sorted(a ^ full for a in range(N)) == list(range(N))
    a6_rows.append(f'Cl({p},{q},{r}): {len(img)} of {N}')
chk('A6', a6_ok, 'with a null generator the top blade squares to 0 and multiplication by it reaches only 2^(p+q) of the 2^n labels, every label with a null bit being killed (' + ', '.join(a6_rows) + '): "multiplication by the pseudoscalar" is then nilpotent, not invertible, not a metric Hodge star. The complement map a -> a xor 1...1 is still a bijection of the labels and the pairing (a, b) -> coefficient of the top blade in e_a e_b is non-zero exactly for b = a xor 1...1: a Frobenius duality for every signature (category report N3; proved in T3). This is what "XOR with 1...1" means once a generator is null')

# ======================================================================================================================
# B. Closure paper II.C, matter condition (a): hyperbolicity of the principal polynomial.
#    For a quadratic principal polynomial P(k)=sum eps_i k_i^2 (the Clifford form of the Dirac field, paper p.35: gamma^(a gamma^b) = G^ab), P hyperbolic
#    <=> exactly one generator has the odd sign.  Compared with the atlas's wave-type table (min(k,d)=0 elliptic, 1 hyperbolic, >=2 ultrahyperbolic).
# ======================================================================================================================
rng = np.random.default_rng(7)
def hyperbolic_direction_exists(eps, trials=6000):
    eps = np.array(eps, float); n = len(eps); S = np.diag(eps)
    cands = [np.eye(n)[i] for i in range(n)] + [rng.normal(size=n) * rng.choice([0.3, 1, 3], size=n) for _ in range(trials)]
    for h in cands:
        Ph = float(h @ S @ h)
        if abs(Ph) < 1e-9: continue
        # P(q + lam h) = P(h) lam^2 + 2 B(q,h) lam + P(q): real roots for ALL q  <=>  B(q,h)^2 - P(h) P(q) >= 0 for all q
        sh = S @ h
        M = np.outer(sh, sh) - Ph * S
        if np.linalg.eigvalsh(M).min() >= -1e-9: return True
    return False
table = {}
for n in range(2, 8):
    for k in range(0, n + 1):
        d = n - k
        eps = [1] * k + [-1] * d
        has = hyperbolic_direction_exists(eps)
        want = (min(k, d) == 1)
        table[(k, d)] = has
        chk('B1', has == want, f'signature (k={k} plus, d={d} minus), n={n}: hyperbolic direction found = {has}; atlas wave type {"elliptic" if min(k,d)==0 else "hyperbolic" if min(k,d)==1 else "ultrahyperbolic"}')
# the argument behind it (Sylvester on the B-orthogonal complement of h), recorded as a checked identity: the form q -> B(q,h)^2 - P(h)P(q) vanishes on h and equals -P(h)P on h-perp
bad = 0
for _ in range(300):
    n = int(rng.integers(2, 7)); eps = rng.choice([-1., 1.], size=n); S = np.diag(eps); h = rng.normal(size=n)
    Ph = h @ S @ h
    if abs(Ph) < 1e-3: continue
    Q = lambda q: (q @ S @ h) ** 2 - Ph * (q @ S @ q)
    if abs(Q(h)) > 1e-8: bad += 1
    q = rng.normal(size=n); q = q - ((q @ S @ h) / Ph) * h        # B-orthogonal to h
    if abs(Q(q) + Ph * (q @ S @ q)) > 1e-8: bad += 1
chk('B2', bad == 0, 'the criterion q -> B(q,h)^2 - P(h)P(q) is zero on h and equals -P(h)P on the B-orthogonal complement: so P is hyperbolic iff P restricted to that complement is definite of sign opposite to P(h), i.e. signature (1,n-1) or (n-1,1)')
# cells: the admissible ones sit on the two ladders k=1 or d=1
adm = sorted([kd for kd, v in table.items() if v])
chk('B3', all(min(kd) == 1 for kd in adm) and (1, 3) in adm and (3, 1) in adm and (2, 2) not in adm, 'admissible cells are exactly the two families Cl(1,d) and Cl(k,1) (one Lorentzian class in two sign conventions); at n=4: Cl(1,3) [clock 6, ' + clock_type(1, 3) + '] and Cl(3,1) [clock 2, ' + clock_type(3, 1) + '] yes; Cl(2,2) [clock 0, ' + clock_type(2, 2) + '] no (first ultrahyperbolic cell)')
chk('B3b', clock_type(1, 3) == 'H' and clock_type(3, 1) == 'R' and clock_type(2, 2) == 'R' and clock_type(4, 0) == 'H', 'types read from the clock (standard table, only compared): Cl(1,3)=M2(H), Cl(3,1)=M4(R), Cl(2,2)=M4(R), Cl(4,0)=M2(H)')

# Dirac: the principal symbol of the atlas's Dirac equation (step 4: psi even in Cl(1,3), 8 real components, grad psi J = m psi gamma_0) has determinant (p^2)^4;
# the closure paper (22)-(24) takes the reduced principal tensor by dropping repeated factors: P = p^2, the Klein-Gordon one (paper p.35: 'Dirac fields ... recover again the same principal tensor')
def det_fr(M):
    M = [row[:] for row in M]; n = len(M); d = Fr(1)
    for i in range(n):
        piv = next((r for r in range(i, n) if M[r][i] != 0), None)
        if piv is None: return Fr(0)
        if piv != i: M[i], M[piv] = M[piv], M[i]; d = -d
        d *= M[i][i]
        for r in range(i + 1, n):
            f = M[r][i] / M[i][i]
            if f:
                for c in range(i, n): M[r][c] -= f * M[i][c]
    return d
A = Alg(sig(1, 3)); n = 4
even = [a for a in range(16) if pc(a) % 2 == 0]; odd = [a for a in range(16) if pc(a) % 2 == 1]
J = {0b0110: 1}  # gamma_2 gamma_1 up to sign: bits 1,2 ; the determinant only needs J invertible
def dirac_symbol(p):
    P = {1 << i: Fr(p[i]) for i in range(4) if p[i]}
    M = [[Fr(0)] * 8 for _ in range(8)]
    for j, b in enumerate(even):
        out = A.mul(A.mul(P, {b: 1}), J)
        for a, c in out.items(): M[odd.index(a)][j] += c
    return M
okd = True
for _ in range(12):
    p = [Fr(random.randint(-5, 5), random.randint(1, 3)) for _ in range(4)]
    p2 = p[0] ** 2 - p[1] ** 2 - p[2] ** 2 - p[3] ** 2
    if abs(det_fr(dirac_symbol(p))) != p2 ** 4: okd = False
chk('B4', okd, '8x8 symbol of the atlas Dirac operator on even psi in Cl(1,3): |det| = (p0^2-p1^2-p2^2-p3^2)^4 at 12 random rational momenta; reduced (square-free) principal polynomial = p.p, the Klein-Gordon / Maxwell one')
# bi-metric (closure paper V.B): two Dirac (or two Klein-Gordon) fields on G and H: block-diagonal symbol, determinant (G.k)^4 (H.k)^4, reduced polynomial P = (G.k)(H.k) = G^(ij) H^(kl) k_i k_j k_k k_l  (paper eq. (108))
okb = True
for _ in range(20):
    k = rng.normal(size=4)
    g = rng.normal(size=(4, 4)); g = g + g.T; h = rng.normal(size=(4, 4)); h = h + h.T
    Gk = k @ g @ k; Hk = k @ h @ k
    Psym = sum(g[i, j] * h[a, b] * k[i] * k[j] * k[a] * k[b] for i in range(4) for j in range(4) for a in range(4) for b in range(4))
    if abs(Psym - Gk * Hk) > 1e-8 * (1 + abs(Gk * Hk)): okb = False
chk('B5', okb, 'two metrics: the symmetrised product G^(ij)H^(kl) k_i k_j k_k k_l equals (G.k)(H.k): the quartic principal polynomial is the product of the two quadratic ones (closure paper (108))')

# ======================================================================================================================
# C. Closure paper III.B, eqs (48)-(50): the hypersurface deformation algebra.  In one space dimension with the structure function frozen to a constant
#    c = (deg P - 1) p^{11} and the lapse given the weight of a vector field, the brackets are  [D,D]=D, [D,H]=H, [H,H]=c D  =  Witt (x) A_c,
#    A_c = R[h]/(h^2 = c): the one-generator Clifford algebra of square c.  Real Fourier basis, [l_j,l_k] = (j-k) l_{j+k}.
# ======================================================================================================================
def A_mul(c):
    """multiplication table of A_c = span{1,h}, h^2=c, taken from the bit rule (generator of square eps)"""
    a = Alg((c,)); T = {}
    for x in (0, 1):
        for y in (0, 1):
            s, m = a.blade_mul(x, y); T[(x, y)] = (s, m)
    return T
def bracket(c, X, Y, weight_minus_one=True):
    """X, Y: dicts {(j, a): coeff}, a=0 -> D_j = l_j (x) 1, a=1 -> H_j = l_j (x) h.  Returns [X,Y]."""
    T = A_mul(c); out = {}
    for (j, a), u in X.items():
        for (k, b), v in Y.items():
            s, m = T[(a, b)]
            if s == 0: continue
            if weight_minus_one:
                coef = (j - k) * s * u * v
            else:
                # scalar lapse (weight 0): D acts on H by the derivative only: [D_j,H_k] = -k H_{j+k}  (no -j part); [H,H] and [D,D] as before
                if a == 0 and b == 1: coef = (-k) * s * u * v
                elif a == 1 and b == 0: coef = (j) * s * u * v
                else: coef = (j - k) * s * u * v
            if coef: out[(j + k, m)] = out.get((j + k, m), 0) + coef
    return {k: v for k, v in out.items() if v != 0}
def addd(X, Y, cy=1):
    o = dict(X)
    for k, v in Y.items(): o[k] = o.get(k, 0) + cy * v
    return {k: v for k, v in o.items() if v != 0}
def jacobi_resid(c, wm1, R=3):
    basis = [(j, a) for j in range(-R, R + 1) for a in (0, 1)]
    worst = 0
    for x in basis:
        for y in basis:
            for z in basis:
                X, Y, Z = {x: Fr(1)}, {y: Fr(1)}, {z: Fr(1)}
                t = addd(addd(bracket(c, X, bracket(c, Y, Z, wm1), wm1), bracket(c, Y, bracket(c, Z, X, wm1), wm1)), bracket(c, Z, bracket(c, X, Y, wm1), wm1))
                worst = max(worst, sum(abs(v) for v in t.values()))
    return worst
for c in (1, 0, -1):
    chk('C1', jacobi_resid(c, True) == 0, f'eps={c:+d}: Jacobi identity exact for all triples of modes |j|<=3 (Witt (x) A_eps, the lapse carries weight -1)')
chk('C2', jacobi_resid(1, False) != 0, f'honest side result: with a constant structure function and a SCALAR lapse (weight 0) the Jacobi identity fails (residual {jacobi_resid(1, False)}): this is why (48) carries a structure FUNCTION p^(ab)[X], not a constant')
# A_eps is the one-generator Clifford algebra: split-complex Cl(1,0), complex Cl(0,1), dual numbers Cl(0,0,1)
for c, name in ((1, 'Cl(1,0) = R+R (split-complex)'), (-1, 'Cl(0,1) = C'), (0, 'Cl(0,0,1) = dual numbers')):
    chk('C3', A_mul(c)[(1, 1)] == (c, 0) if c else A_mul(c)[(1, 1)][0] == 0, f'eps={c:+d}: h*h = {c:+d}; A_eps = {name}; Cl type from the clock: ' + ('(degenerate: no clock)' if c == 0 else clock_type(1, 0) if c == 1 else clock_type(0, 1)))
# eps = +1 (hyperbolic matter): two commuting copies of the Witt algebra, E+- = (D +- H)/2
def E(sg, j): return {(j, 0): Fr(1, 2), (j, 1): Fr(sg, 2)}
okc = True; okw = True
for j in range(-3, 4):
    for k in range(-3, 4):
        if bracket(1, E(+1, j), E(-1, k)): okc = False
        for sg in (+1, -1):
            lhs = bracket(1, E(sg, j), E(sg, k)); rhs = {kk: v * (j - k) for kk, v in E(sg, j + k).items() if v * (j - k) != 0}
            if lhs != rhs: okw = False
chk('C4', okc and okw, 'eps=+1: [E+,E-]=0 and each of E+, E- closes as the Witt algebra: Witt + Witt (left and right movers), exact for |j|,|k|<=3')
# eps = 0 (Carroll): span{H_j} is an abelian ideal on which D acts as the adjoint: Witt semidirect Witt_ad (BMS3 without central terms)
oka = all(not bracket(0, {(j, 1): 1}, {(k, 1): 1}) for j in range(-3, 4) for k in range(-3, 4))
oki = all(all(m == 1 for (_, m) in bracket(0, {(j, 0): 1}, {(k, 1): 1})) for j in range(-3, 4) for k in range(-3, 4))
chk('C5', oka and oki, 'eps=0: [H,H]=0 and [D,H] stays in span H: an abelian ideal; quotient = Witt; this is the BMS3 pattern [l,l]=l, [l,m]=m, [m,m]=0 (Carroll limit)')
# eps = -1 (Euclidean): the same algebra is Witt (x) C: h acts as a complex structure commuting with everything ([h x, h y] = - [x,y])
okj = all(bracket(-1, {(j, 1): 1}, {(k, 1): 1}) == ({(j + k, 0): -(j - k)} if j != k else {}) for j in range(-3, 4) for k in range(-3, 4))
chk('C6', okj, 'eps=-1: [H_j,H_k] = -(j-k) D_{j+k}: Witt (x) C read as a real algebra (the Euclidean deformation algebra)')

# ======================================================================================================================
# D. Review (3)-(4), closure paper V.C: the area metric G^{abcd} (21 components) and the atlas's bivector plane pairs, B^2 = S + W e_1234 (step 1).
# ======================================================================================================================
n = 4
biv = [a for a in range(16) if pc(a) == 2]
share = {0: 0, 1: 0, 2: 0}
for i, a in enumerate(biv):
    for b in biv[i:]:
        share[pc(a & b)] += 1
chk('D1', share == {0: 3, 1: 12, 2: 6} and sum(share.values()) == 21, f'unordered pairs of bivector labels (S^2 of the 6 planes) at n=4: same plane {share[2]}, one shared axis {share[1]}, none {share[0]}: total {sum(share.values())} = the 21 components of the area metric (review p.3)')
A41 = Alg(sig(4, 0))
anti = [(a, b) for a in biv for b in biv if a < b and pc(a & b) == 0]
chk('D2', len(anti) == 3 and all(A41.comm_sign(a, b) == 1 for a, b in anti), f'the 3 "none" pairs are the antipodal planes {[(bin(a)[2:].zfill(4), bin(b)[2:].zfill(4)) for a,b in anti]} (they commute); their cross terms are exactly the three terms of F^F = e^{{abcd}} F_ab F_cd')
chk('D3', 21 - math.comb(4, 4) == 4 ** 2 * (4 ** 2 - 1) // 12 == 20, 'Riemann-type subspace: 21 minus one cyclic (first Bianchi) relation per 4-subset = n^2(n^2-1)/12 = 20 (atlas step 9/10); the one removed combination is the e^{abcd} part')
# S and W: the two Lorentz invariants of a bivector, B^2 = S + W e_1234 and nothing else
okS = True
for (p, q) in [(1, 3), (3, 1), (2, 2), (4, 0), (0, 4)]:
    al = Alg(sig(p, q))
    for _ in range(30):
        B = {a: random.randint(-4, 4) for a in biv}
        B2 = al.mul(B, B)
        if any(pc(m) not in (0, 4) for m in B2): okS = False
chk('D4', okS, 'B^2 has only grade 0 and grade 4 in every signature tested: S = scalar part, W = coefficient of e_1234 (the two invariants F.F and F^F)')
# SO(4) content of S^2(Lambda^2) (numpy): su(2)+su(2); Weyl 10 = (2,0)+(0,2); traceless Ricci 9 = (1,1); two singlets (scalar curvature R and the epsilon part)
def so4_gens():
    G = []
    for i in range(4):
        for j in range(i + 1, 4):
            M = np.zeros((4, 4)); M[i, j] = 1; M[j, i] = -1; G.append(M)
    return G
gens = so4_gens()
# bivector (6-dim) rep: action on antisymmetric 2-tensors, basis E_ij
pairs = [(i, j) for i in range(4) for j in range(i + 1, 4)]
def on_biv(M):
    R = np.zeros((6, 6))
    for c, (i, j) in enumerate(pairs):
        # (M.omega + omega.M^T) with omega = E_ij - E_ji
        om = np.zeros((4, 4)); om[i, j] = 1; om[j, i] = -1
        new = M @ om + om @ M.T
        for r, (k, l) in enumerate(pairs): R[r, c] = new[k, l]
    return R
Rb = [on_biv(M) for M in gens]
# symmetric square (21-dim): basis e_r e_s, r<=s ; action x.(e_r e_s) = (x e_r) e_s + e_r (x e_s)
sp = [(r, s) for r in range(6) for s in range(r, 6)]; idx = {p: i for i, p in enumerate(sp)}
def on_sym(Rm):
    S = np.zeros((21, 21))
    for c, (r, s) in enumerate(sp):
        for t in range(6):
            for (a, b, co) in ((t, s, Rm[t, r]), (r, t, Rm[t, s])):
                if co == 0: continue
                key = (a, b) if a <= b else (b, a)
                S[idx[key], c] += co
    return S
Rs = [on_sym(Rm) for Rm in Rb]
# self-dual / anti-self-dual generators: J1 = (L23+L14)/2 etc.  index of pair (i,j) in so4_gens order: 01,02,03,12,13,23
g = {p: Rs[i] for i, p in enumerate(pairs)}
Jp = [(g[(1, 2)] + g[(0, 3)]) / 2, (g[(0, 2)] - g[(1, 3)]) / 2, (g[(0, 1)] + g[(2, 3)]) / 2]
Jm = [(g[(1, 2)] - g[(0, 3)]) / 2, (g[(0, 2)] + g[(1, 3)]) / 2, (g[(0, 1)] - g[(2, 3)]) / 2]
Cp = -sum(J @ J for J in Jp); Cm = -sum(J @ J for J in Jm)
comm_ok = max(np.abs(Jp[0] @ Jm[1] - Jm[1] @ Jp[0]).max(), np.abs(Jp[2] @ Jm[2] - Jm[2] @ Jp[2]).max()) < 1e-9
# joint eigenvalues of the two Casimirs
evals = np.linalg.eigvals(Cp + 7.0 * Cm)           # weights distinguish (j1(j1+1), j2(j2+1)) pairs
from collections import Counter
cnt = Counter()
for v in evals:
    v = round(float(np.real(v)), 4)
    cnt[v] += 1
# j(j+1) in {0, 3/4, 2, 15/4, 6}: pair (a,b) -> a + 7 b
want = Counter({round(6 + 0, 4): 5, round(0 + 7 * 6, 4): 5, round(2 + 7 * 2, 4): 9, 0.0: 2})
chk('D5', comm_ok and cnt == want, f'so(4)=su(2)+su(2) acting on the 21-dim S^2(Lambda^2) splits as 5+5+9+1+1 (spins (2,0),(0,2),(1,1),(0,0) twice): Weyl 10 + traceless Ricci 9 + scalar R + e^abcd; found {dict(cnt)}')

# Review p.3: the density of the area-metric action is omega_G = (eps^{ijkl} G_ijkl)^{-1}.  eps.G is the signed sum of the three ANTIPODAL plane-pair components (the "none" class of D1).
def area_metric(M):
    G = np.zeros((4, 4, 4, 4))
    for r, (a, b) in enumerate(pairs):
        for t, (c, d) in enumerate(pairs):
            v = M[r, t]
            G[a, b, c, d] = v; G[b, a, c, d] = -v; G[a, b, d, c] = -v; G[b, a, d, c] = v
    return G
def levi4():
    E = np.zeros((4, 4, 4, 4))
    for perm in itertools.permutations(range(4)):
        sgn = np.linalg.det(np.eye(4)[list(perm)])
        E[perm] = round(sgn)
    return E
EPS = levi4()
okG = True
for _ in range(20):
    M = rng.normal(size=(6, 6)); M = M + M.T
    G = area_metric(M)
    full_ = float(np.einsum('ijkl,ijkl', EPS, G))
    anti3 = 8 * (G[0, 1, 2, 3] - G[0, 2, 1, 3] + G[0, 3, 1, 2])
    if abs(full_ - anti3) > 1e-9: okG = False
    if abs(G[0, 1, 2, 3] - G[2, 3, 0, 1]) > 1e-12: okG = False
chk('D6', okG, 'eps^{ijkl} G_ijkl = 8 (G_01,23 - G_02,13 + G_03,12) for random G with the area-metric symmetries: the denominator of the density omega_G is the signed sum of the three antipodal components')
eta = np.diag([1., -1, -1, -1])
G0 = np.zeros((4, 4, 4, 4))
for a, b, c, d in itertools.product(range(4), repeat=4):
    G0[a, b, c, d] = eta[a, c] * eta[b, d] - eta[a, d] * eta[b, c]          # 2 eta^{a[c} eta^{d]b}
chk('D7', abs(float(np.einsum('ijkl,ijkl', EPS, G0))) < 1e-12, 'the pure metric part 2 eta^{a[c} eta^{d]b} (Maxwell) has all three antipodal components zero, so eps.G = 0 and omega_G would be infinite')
EPSU = np.einsum('abcd->abcd', EPS)
G1 = G0 - EPSU
chk('D8', abs(abs(float(np.einsum('ijkl,ijkl', EPS, G1))) - 24) < 1e-9 and np.allclose(G1, area_metric(np.array([[G1[a, b, c, d] for (c, d) in pairs] for (a, b) in pairs]))), 'with the epsilon term of the review (G = 2 eta^{a[c} eta^{d]b} - eps^{abcd}) |eps.G| = 24: the epsilon (W) part is what makes the density finite; G1 has the 21-component symmetries')

# ======================================================================================================================
# E. Lectures ch. 15: the relativistic spin group SL(2,C), ch. 14: Dynkin/Weyl.  Cell addresses [R,C]=[p+q,p-q] of the atlas.
# ======================================================================================================================
A13 = Alg(sig(1, 3)); full = 15
# even subalgebra Cl0(1,3): centre {1, I}, I^2=-1: a complex structure; 8 real dims = M2(C)
ev = [a for a in range(16) if pc(a) % 2 == 0]
cen = [a for a in ev if all(A13.comm_sign(a, b) == 1 for b in ev if b)]
chk('E1', cen == [0, 15] and A13.sq(15) == -1 and len(ev) == 8, 'even part of Cl(1,3): 8 real dimensions, centre {1, e1234}, e1234^2=-1: M2(C) (8 = 2*2*2); with the quadratic (bivector) Lie algebra of dimension 6 this is sl(2,C) (lectures ch.15, "relativistic spin group")')
chk('E2', clock_type(1, 2) == 'C' and clock_type(0, 2) == 'H' and clock_type(1, 3) == 'H', 'cells: Spin(1,3)=SL(2,C) lives in Cl0(1,3)=Cl(1,2) at [3,-1] (clock 7, C); SU(2)=Spin(3) in Cl(0,2)=H at [2,-2]; the whole Cl(1,3) at [4,-2] (clock 6, H)')
# SL(2,C) dimension: unit even versors R with R R~ = 1 form a 6-dim group: tangent space = bivectors  (R = 1 + eps B)
tang = [a for a in ev if pc(a) == 2]
okR = True
for _ in range(10):
    B = {a: Fr(random.randint(-3, 3)) for a in tang}
    one = {0: Fr(1)}
    R = A13.add(one, B, Fr(1, 1000))        # first-order: 1 + e B
    Rrev = {}
    for a, cf in R.items():
        sgn = (-1) ** (pc(a) * (pc(a) - 1) // 2); Rrev[a] = cf * sgn
    P_ = A13.mul(R, Rrev)
    # R R~ = 1 + e^2 (-B^2) ; first order must be exactly 1
    first = A13.add(P_, A13.mul(B, B), Fr(1, 10 ** 6))
    if set(first) - {0}: okR = False
chk('E3', okR, 'unit even versors: R R~ = 1 to first order for R = 1 + eB with B any bivector: the group is generated by the 6 bivectors (dim 6 = dim SL(2,C))')

# Lectures 17.2, Example 17.13: the Casimir of rho_spin of so(3) is (3/4) id on C^2 = R^4.  In the bit rule J_i = (1/2) e_jk (Cl0(3,0) = H = {1,e12,e13,e23}, e123 central with square -1 plays the i of the Pauli matrices).
# General: sum over bivectors of (e_ab/2)^2 with indices raised by the metric = -C(n,2)/4 in EVERY signature, so Omega = dim g / dim V (trace-form dual basis), here 3/4.
bad = 0
for (p, q) in [(3, 0), (0, 3), (1, 2), (2, 1), (4, 0), (1, 3), (3, 1), (2, 2), (0, 5), (3, 3)]:
    al = Alg(sig(p, q)); tot = Fr(0); n_ = p + q
    for a in range(al.N):
        if pc(a) == 2:
            i1, i2 = [i for i in range(n_) if a >> i & 1]
            sq = al.mul({a: Fr(1, 2)}, {a: Fr(1, 2)})
            if set(sq) - {0}: bad += 1; continue
            tot += sq.get(0, 0) * al.eps[i1] * al.eps[i2]          # raise both indices with the metric
    if tot != -Fr(math.comb(n_, 2), 4): bad += 1
chk('E4', bad == 0, 'Casimir of the spin representation: sum_{a<b} (e_ab/2)^2 (indices raised) = -C(n,2)/4, every bivector squares to a scalar; n=3: Omega = 3/4 = dim so(3)/dim C^2, the number of the lecture\'s Example 17.13')
H = Alg(sig(3, 0)); Hb = [3, 5, 6]
ok = all(set(H.mul({a: 1}, {a: 1})) == {0} and H.mul({a: 1}, {a: 1})[0] == -1 for a in Hb) and H.sq(7) == -1 and all(H.comm_sign(7, 1 << i) == 1 for i in range(3))
chk('E5', ok, 'Cl(3,0): e12, e13, e23 square to -1 (quaternion units; J_i = e_jk/2 reproduces the lecture\'s rho_spin(J_i) = -(i/2) sigma_i with i = e123, central, e123^2 = -1)')

# ======================================================================================================================
# F. Counts that the notes of the report quote
# ======================================================================================================================
chk('F1', math.comb(6, 2) + math.comb(6, 1) == 21 and math.comb(4, 2) == 6, 'area metric: dim S^2(R^6) = 21; Maxwell-type 6 = C(4,2)')
chk('F2', 20 + 1 == 21 and 10 + 9 + 1 + 1 == 21, 'bookkeeping: 21 = 20 + 1 = (10 Weyl + 10 Ricci) + 1')

print()
print(f'bridge_check: {N_OK} ok, {N_BAD} failed')
sys.exit(1 if N_BAD else 0)
