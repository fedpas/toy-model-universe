#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Tests of ../html/schuller_bridge_report.html against its own sources: every headline number equals the logs and the matrix data; no external request; no e-mail address;
every check id the page cites exists in a log; every Schuller statement the page quotes as a number is pinned to the text files. Run: python3 test_report.py"""
import os, re, sys, html
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..'))
import no_history as NH
import status_check as SK
import matrix_data as MD
page = open(os.path.join(HERE, '..', 'html', 'schuller_bridge_report.html'), encoding='utf-8').read()   # the page is built into reports/html/
txt = re.sub(r'<style.*?</style>|<script.*?</script>', '', page, flags=re.S)
plain = html.unescape(re.sub(r'<[^>]+>', ' ', txt)); plain = re.sub(r'\s+', ' ', plain)
ok = bad = 0
def chk(name, cond, msg=''):
    global ok, bad
    if cond: ok += 1
    else: bad += 1
    print(('ok   ' if cond else 'FAIL ') + name + (': ' + msg if (msg and not cond) else ''))
def log(name):
    ids = []; o = b = 0
    for l in open(os.path.join(HERE, 'logs', name), encoding='utf-8'):
        m = re.match(r'(ok  |FAIL) (\S+?):', l)
        if m:
            ids.append(m.group(2))
            if m.group(1).startswith('ok'): o += 1
            else: b += 1
    return o, b, ids
oA, bA, idsA = log('bridge_check_final.log'); oQ, bQ, idsQ = log('bridge_check_qm_final.log'); oG, bG, idsG = log('fibre_check_final.log')
chk('T1 headline checks = logs', f'<b>{oA + oQ + oG}</b>' in page and f'{oA} geometry, {oQ} quantum, {oG} fibre and base' in plain, f'{oA + oQ + oG}')
chk('T2 no check fails in the logs', bA + bQ + bG == 0)
st = MD.stats()
chk('T3 rows and cells = matrix data', f'{st["n"]} × 22' in plain and f'{st["total_cells"]} filled cells' in plain)
be = st['best']
chk('T4 best-grade counts = matrix data', f'{be["E"]} have an exact counterpart' in plain and f'{be["S"]} a structural one' in plain and f'{be["A"]} an analogy' in plain and f'{be["gap"]} none' in plain)
chk('T5 gap rows named', all(r[0] in plain for r in MD.ROWS if not r[3]))
chk('T6 every matrix cell is in the page (table view)', all(html.escape(note) in page for r in MD.ROWS for g, note in r[3].values()))
chk('T7 no external request', not re.search(r'(src|href)="https?://(?!arxiv\.org)', page) and 'url(http' not in page and '@import' not in page and not re.search(r'<script[^>]+src=', page) and not re.search(r'<link[^>]+href', page))
chk('T8 no e-mail address', not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', page, flags=re.S)))
cited = set()
for m in re.finditer(r'checks? ([A-Z]\d?[\w–,\- ]*)', plain):
    for part in re.split(r'[,\s]+', m.group(1)):
        m2 = re.match(r'([A-Z])(\d+)(?:–([A-Z]?)(\d+))?([a-z]?)$', part)
        if m2:
            cited.add(m2.group(1) + m2.group(2))
            if m2.group(4): cited.add((m2.group(3) or m2.group(1)) + m2.group(4))
allids = set(re.match(r'[A-Z]\d+', i).group(0) for i in idsA + idsQ + idsG)
chk('T9 every cited check id exists in a log', cited <= allids, str(sorted(cited - allids)))
chk('T10 themes and guards present', 'prefers-color-scheme: dark' in page and ':root[data-theme="dark"]' in page and ':root:not([data-theme="light"])' in page)
chk('T11 title is a name of 2-4 words', re.search(r'<title>([^<]+)</title>', page).group(1).count(' ') in (1, 2, 3, 4))
flog = open(os.path.join(HERE, 'logs', 'fibre_check_final.log'), encoding='utf-8').read()
mut = open(os.path.join(HERE, 'logs', 'mutation_fibre.log'), encoding='utf-8').read()
mm = re.search(r'mutants caught: (\d+) of (\d+)', mut)
chk('T18 sabotage counts: automated run log = page, all caught', mm and mm.group(1) == mm.group(2) and f'{mm.group(1)} of {mm.group(2)}' in plain and f'{mm.group(1)} automated sabotages caught' in plain)
pins = ['k=0: 256, k=1: 128, k=2: 64, k=3: 32, k=4: 16, k=5: 8, k=6: 4, k=7: 2, k=8: 1', '135 = 135 = 135', '759 octads', 'exponents [1, 5, 7, 11]', '240 -> 56 -> 27 -> 16 -> 10 -> 6 -> 3', '240 (rank 8), 126 (rank 7), 72 (rank 6), 40 (rank 5), 20 (rank 4), 8 (rank 3)', '60 random integer samples', 'k=0: Cl(0,8)=R', 'k=3: Cl(0,4) (x) R2=H2', 'order 24', 'weights {0: 1, 8: 759, 12: 2576, 16: 759, 24: 1}', 'P + m w)^2 = |p|^2 - E^2 - m^2']
chk('T19 numbers typed in the fibre-and-base text appear in the fibre log', all(p in flog for p in pins), str([p for p in pins if p not in flog]))
m5 = re.search(r'G5e: one fixed two-step potential: (\d+) band edges', flog)
chk('T20 band-edge count on the page = log', m5 and f'{m5.group(1)} band edges were found' in plain, m5.group(1) if m5 else '')
for fid in ('F10', 'F11', 'F12', 'F13', 'F14', 'F15'):
    chk(f'T21 {fid} present with tags', f'id="{fid.lower()}"' in page and re.search(rf'id="{fid.lower()}".*?class="chips">(.*?)</div>', page, re.S) is not None)
# the unqualified "Hodge star = XOR with 1...1" (quoted here as a test string only) is nowhere on the page; A6 is in the geometry log and cited; the matrix rows L9 and M5 say that with a null generator the top blade is nilpotent
_bad_hodge = re.compile(r'Hodge star = XOR with 1…1(?! reads| …)|Hodge star = XOR with 11…1\.|Hodge = XOR 1…1 and I²')   # no occurrence is allowed
chk('T23 the unqualified Hodge sentence is nowhere on the page, the matrix rows and the lens cards; A6 is in the log and cited', 'A6' in idsA and 'A6' in plain and 'nilpotent' in MD.ROWS[[r[0] for r in MD.ROWS].index('L9')][3]['rule'][1]
    and 'nilpotent' in MD.ROWS[[r[0] for r in MD.ROWS].index('M5')][3]['groups'][1] and not _bad_hodge.search(html.unescape(re.sub(r'<[^>]+>', ' ', page))))
# Schuller numbers pinned to the texts: T12-T17 and T22 read the lecture texts (txt/, made with pdftotext; not shipped with the package).
# With the texts beside this script they run and count; without them they are reported as skipped and not counted (never as passed).
TXTS = ('Lectures_on_Geometric_Anatomy_of_Theoretical_Physics.txt', 'Lectures_on_Quantum_Theory_complete.txt', 'Gravitational_closure_of_matter_field_equations.txt')
HAVE_TXT = all(os.path.exists(os.path.join(HERE, 'txt', n)) for n in TXTS); skipped = []
if HAVE_TXT:
    T = lambda n: open(os.path.join(HERE, 'txt', n), encoding='utf-8').read()
    geo = T('Lectures_on_Geometric_Anatomy_of_Theoretical_Physics.txt'); qm = T('Lectures_on_Quantum_Theory_complete.txt'); clo = T('Gravitational_closure_of_matter_field_equations.txt')
    chk('T12 quantum notes: Remark 14.17 psi^psi = 0 and footnote 54 signature', 'Pauli exclusion' in qm and 'diag(−1, 1, 1, 1)' in qm and 'γ µ γ ν + γ µ γ ν = 2η µν' in qm)
    chk('T13 quantum notes: Fock space of fermions is the antisymmetric one', 'which describes fermionic systems' in qm and 'F := C ⊕ H ⊕ (H ⊗ H)' in qm)
    chk('T14 closure paper: Dirac algebra gives the same principal tensor', 'Dirac' in clo and 'recovers again the same principal tensor' in clo)
    chk('T15 geometry lectures: no Clifford algebra', 'lifford' not in geo and 'lifford' not in clo)
    chk('T16 geometry lectures: Example 17.13 is the Casimir 3/4', re.search(r'Example 17\.13', geo) is not None)
    qmn = re.sub(r'\s+', ' ', qm)
    chk('T17 notes: the trace slip and the open intervals are in the text', 'ψ1E (a) + ψ2E (a) = Tr M E (a)' in qmn and 'countable union of open intervals' in qmn and 'Lemma 20.8' in qmn)
    chk('T22 notes: Floquet chapter and Pauli/Fock facts used in F13 are in the text', 'Floquet' in qm and 'fundamental matrix' in qm)
else:
    skipped = ['T12', 'T13', 'T14', 'T15', 'T16', 'T17', 'T22']
    print('skip ' + ', '.join(skipped) + ": these pin the report to the lecture texts, which are not shipped (put them in txt/ to run them)")
# the forbidden wording (quoted below as test strings only) is nowhere on the page (text, tooltips, matrix notes),
# the right wording is on the page, the grade order of F6 is the figure's, and the matrix rows L13, C3, M4, M11 carry their notes
_page_nc = page
outside = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'<style.*?</style>|<script.*?</script>', '', _page_nc, flags=re.S))) + ' ' + ' '.join(html.unescape(t) for t in re.findall(r'data-tip="([^"]*)"', _page_nc)))
FORBIDDEN = ['quadric of entangled', 'Mass is a fibre momentum', 'mass as a fibre momentum', 'hyperbolicity says the fibre is space-like', 'fibre momenta behave like space', 'E, S, E, S, S, S, A', 'steps 1–3 of his pipeline: exact',
           'exactly two ladders', 'the first excluded', 'first excluded', 'first to fail', 'is first to fail', 'fifth home', 'is Furey’s End(V)', 'is Furey’s M₁₆(ℝ)', 'has the type M₂(ℍ) of Cl(1,3)', 'the missing step',
           'never name a Clifford algebra', '(the BMS₃ pattern, Carroll)', 'would be Euclid, Carroll and Lorentz', 'identified by count and rank)', 'edge: X² = 0, parabolic', 'equals −C(n,2)/4 in every signature.',
           'Casimir of the spin representation = C(n,2)/4', 'The bands of chapter 20 are the trio', 'not a theorem I have proved in general']
chk('T24 the forbidden wording is nowhere on the page (text, tooltips, matrix notes)', not any(w in outside for w in FORBIDDEN), str([w for w in FORBIDDEN if w in outside]))
RIGHT = ['product states are the null cone of det on M₂(ℝ)', 'over ℂ the condition is det = 0 on M₂(ℂ)', 'A momentum along an extra space-like direction enters as a mass', 'a null direction never enters the determinant',
         'S, E, E, S, S, S, A', 'one Lorentzian class in two conventions, P ↔ −P', 'Cl(2,2) is the first ultrahyperbolic cell', 'the textbook elliptic/parabolic/hyperbolic split of SL(2,ℝ)', 'M = ±I has X = 0 and bounded powers',
         'isomorphic as an algebra to the End(V)', 'reversion x ↦ x̃ exchanges left and right', 'without naming a Clifford algebra', 'calling it Carroll is ours', 'This is a Euclidean so(4) count',
         'depends on the chosen frame', 'from count and rank only', 'with the indices raised', 'untested against his equations', 'the same algebraic identity, pointwise, in one chart', 'is a theorem: a doubly-even self-dual code of length n', 'a band edge is X² = 0 with X ≠ 0']
chk('T25 the right wording is on the page', all(t in plain or t in outside for t in RIGHT), str([t for t in RIGHT if t not in plain and t not in outside]))
_rows = {r[0]: r for r in MD.ROWS}
chk('T26 matrix notes: L13 sign and raised indices, C3 one Lorentzian class, M4 real amplitudes, M11 no trio as a fact, C8 Λ untested', '−C(n,2)/4 with the indices raised' in _rows['L13'][3]['spin'][1]
    and 'one class in two conventions' in _rows['C3'][3]['cells'][1] and 'For real amplitudes' in _rows['M4'][3]['maxwell'][1] and 'M = ±I has X = 0' in _rows['M11'][3]['clock'][1] and 'untested' in _rows['C8'][3]['projective'][1])
chk('T27 no corrections section, no struck sentence, no erratum id', 'id="corr"' not in page and 'href="#corr"' not in page and '<s>' not in page and not re.search(r'\bE-\d{3}\b', plain))
chk('T28 no history in the visible text of the page (shared pattern list, reports/no_history.py); every "<" in a text node is written &lt;, so the reader sees all the text', not NH.scan_page(page) and not NH.bare_lt(page), NH.scan_page(page)[:3])
chk('T29 the history scan catches its planted phrases', not NH.selftest(), NH.selftest())
# the sabotage card says exactly what was done: hand-recorded runs (6 on the geometry side, 10 on Q5-Q12), automated runs (those of the log), and that the other checks have no sabotage run
_named = set(re.findall(r",\s*'([A-Z]\d+[a-z]?)'\)\s*,?\s*(?:#.*)?$", open(os.path.join(HERE, 'mutate_fibre.py'), encoding='utf-8').read(), re.M))
mh = re.search(r'(\d+) changes, all caught: (\d+) on the geometry side and (\d+) on Q5–Q12 are recorded by hand, without a script; (\d+) are automated \(\s*mutate_fibre\.py\s*\), on (\d+) of the (\d+) fibre-and-base checks and on A6\. '
               r'The other checks have no sabotage run: at most (\d+) of the (\d+) checks have one', plain)
chk('T30 the sabotage card: changes = hand-recorded (geometry side, Q5-Q12) + automated (the log); the automated ones name 20 of the 35 fibre-and-base checks and A6; the other checks have no sabotage run',
    bool(mh) and int(mh.group(1)) == int(mh.group(2)) + int(mh.group(3)) + int(mh.group(4)) and (int(mh.group(2)), int(mh.group(3))) == (6, 10) and int(mh.group(4)) == int(mm.group(1)) == int(mm.group(2))
    and int(mh.group(5)) == len(_named & set(idsG)) == 20 and int(mh.group(6)) == oG == 35 and int(mh.group(7)) == int(mh.group(1)) and int(mh.group(8)) == oA + oQ + oG and 'A6' in open(os.path.join(HERE, 'mutate_fibre.py'), encoding='utf-8').read(),
    str(mh.groups() if mh else None))
chk('T31 the headings of the perspectives are neutral: "Perspectives" (section and card), a reader of the lectures, nothing addressed to a person',
    '<h2>Perspectives <small>all ours or open; offered, not claimed</small></h2>' in page and '<h3>3 · Perspectives</h3>' in page and 'might raise for a reader of the lectures' in plain and 'The lectures go from forms (ch. 12)' in plain
    and not re.search(r'Perspectives for|for his group', plain))
F4 = ('checked', 'standard', 'ours', 'open')
chk('T32 every status is an icon chip (role img, name and hover text start with the word, the drawing of the atlas badge, no word chip, one legend entry per flag); all four flags are used',
    not SK.problems(page, F4) and set(SK.kinds(page)) == set(F4), str(SK.problems(page, F4)[:3]))
_f4 = re.search(r'id="f4".*?class="chips">(.*?)</div>', page, re.S).group(1)
chk('T33 F4: the count 21 − 1 = 20 is tagged standard (counting; D3 evaluates the arithmetic and builds no space of curvature tensors), next to checked (D1, D2) and open; the matrix note of C10 says so',
    SK.kinds(_f4) == ['checked', 'standard', 'open'] and '(standard counting: D3 evaluates this arithmetic and builds no space of curvature tensors)' in plain
    and 'the 20 after the Bianchi relation is standard counting (D3 evaluates the arithmetic)' in _rows['C10'][3]['grav2'][1] and 'D3' in idsA)
print(f'\ntest_report: {ok} ok, {bad} failed' + (f', {len(skipped)} skipped (no txt/)' if skipped else '')); sys.exit(1 if bad else 0)
