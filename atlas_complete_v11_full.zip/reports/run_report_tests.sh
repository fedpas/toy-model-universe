#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# Runs everything that ships with the six reports, one line each (PASS, FAIL or SKIP), and exits 1 if anything failed:
#   the check scripts (their ok lines must equal the recorded logs; for Hestenes the numbers that carry a residual or a timing are compared after normalisation),
#   the six report test suites (the browser parts when python's playwright, and for the Pumplun page node's playwright, are installed and REPORT_NO_BROWSER is not set;
#   else without them, and the line says so), the Pumplun engine test, the matrix json, the check-id table of selfcheck/reports/README.md, the zips and MANIFEST.json.
#   sh reports/run_report_tests.sh              about 5 minutes
#   sh reports/run_report_tests.sh --long       also the exhaustive MRD enumeration over F_8 of the Pumplun report (about 10 minutes more)
#   sh reports/run_report_tests.sh --mutation   also the five sabotage scripts (about 1.5 hours on two cores): every mutant must be caught
# Needs python3 with numpy, scipy and networkx (exit 77 without them); node for the Pumplun engine. The papers' texts are not shipped: Baez check R1 and the text-pinned report tests are skipped and say so.
cd "$(dirname "$0")" || exit 2
MUT=0; LONG=0
for a in "$@"; do case "$a" in --mutation) MUT=1;; --long) LONG=1;; *) echo "run_report_tests.sh: unknown option $a" >&2; exit 2;; esac; done
python3 -c 'import numpy, scipy, networkx' 2>/dev/null || { echo "run_report_tests.sh: python3 with numpy, scipy and networkx is needed (pip install numpy scipy networkx)"; exit 77; }
ATLAS_PKG=${ATLAS_PKG:-$(cd .. && pwd)}; export ATLAS_PKG
TMP=$(mktemp -d "${TMPDIR:-/tmp}/report_tests.XXXXXX") || exit 2
trap 'rm -rf "$TMP"' EXIT
FAILS=0; PASSES=0; SKIPS=0
say() { echo "$1 $2: $3"; case $1 in PASS) PASSES=$((PASSES+1));; FAIL) FAILS=$((FAILS+1));; SKIP) SKIPS=$((SKIPS+1));; esac; }
oklines() { grep -E '^(ok  |FAIL) ' "$1" | grep -v '^ok   R1:'; }
normal() { sed -E 's/[0-9.]+e[-+][0-9]+/<n>/g; s/[0-9]+\.[0-9]+/<n>/g'; }   # a number that carries a residual or a timing is compared as <n>
# 1. the check scripts against their logs (R1 of baez_check.py needs the papers' texts; it is left out of the comparison when skipped).  A pair is script:log, or script:log:n
#    when the numbers that carry a residual are compared after normalisation.
for pair in category/cat_check.py:category/logs/cat_check.log baez/baez_check.py:baez/logs/baez_check.log schuller/fibre_check.py:schuller/logs/fibre_check_final.log \
            schuller/bridge_check.py:schuller/logs/bridge_check_final.log schuller/bridge_check_qm.py:schuller/logs/bridge_check_qm_final.log \
            hestenes/hest_check.py:hestenes/logs/hest_check.log:n furey/furey_papers_check.py:furey/logs/furey_papers_check.log \
            furey/furey_construction_check.py:furey/logs/furey_construction_check.log pumplun/pumplun_checks.py:pumplun/logs/pumplun_checks.log; do
  s=${pair%%:*}; rest=${pair#*:}; l=${rest%%:*}; n=; case $rest in *:*) n=${rest#*:};; esac
  out="$TMP/$(basename "$s").out"
  (cd "$(dirname "$s")" && python3 "$(basename "$s")") > "$out" 2>&1; rc=$?
  if [ -n "$n" ]; then oklines "$out" | normal > "$TMP/a"; oklines "$l" | normal > "$TMP/b"; else oklines "$out" > "$TMP/a"; oklines "$l" > "$TMP/b"; fi
  if [ $rc -eq 0 ] && [ -s "$TMP/a" ] && cmp -s "$TMP/a" "$TMP/b"; then say PASS "$s" "$(grep -c '^ok  ' "$out") ok, the same lines as $l$([ -n "$n" ] && echo ' (residuals normalised)')$(grep -q '^skip R1' "$out" && echo ' (R1 skipped: no texts)')"
  else say FAIL "$s" "exit $rc or lines differ from $l"; fi
done
(cd hestenes && python3 gtg_check.py S G) > "$TMP/gtg.out" 2>&1 && grep -q '^ALL GTG/RDK CHECKS PASS' "$TMP/gtg.out" && say PASS "hestenes/gtg_check.py S G" "ALL GTG/RDK CHECKS PASS" || say FAIL "hestenes/gtg_check.py S G" "$(tail -1 "$TMP/gtg.out")"
# 2. the report suites
if [ -n "${REPORT_NO_BROWSER:-}" ]; then NB=1; elif python3 -c 'import playwright' 2>/dev/null; then NB=; else NB=1; fi   # REPORT_NO_BROWSER=1: leave the browser part out on purpose
for pair in category:test_report_cat.py baez:test_report_baez.py schuller:test_report.py hestenes:test_report_hestenes.py furey:test_report_furey.py; do
  d=${pair%%:*}; t=${pair#*:}
  (cd "$d" && REPORT_NO_BROWSER=$NB python3 "$t") > "$TMP/$d.out" 2>&1 && say PASS "$d/$t" "$(tail -1 "$TMP/$d.out")" || say FAIL "$d/$t" "$(grep -m3 '^FAIL' "$TMP/$d.out" | tr '\n' ' ') $(tail -1 "$TMP/$d.out")"
done
if [ $LONG = 1 ]; then PL=--full; else PL=; fi
(cd pumplun && python3 test_report_pumplun.py $PL) > "$TMP/pum.out" 2>&1 && say PASS "pumplun/test_report_pumplun.py" "$(tail -1 "$TMP/pum.out")" || say FAIL "pumplun/test_report_pumplun.py" "$(grep -m3 '^FAIL' "$TMP/pum.out" | tr '\n' ' ') $(tail -1 "$TMP/pum.out")"
if command -v node >/dev/null 2>&1; then
  (cd pumplun/build && node test_engine.js) > "$TMP/eng.out" 2>&1 && grep -q '^ALL OK' "$TMP/eng.out" && say PASS "pumplun/build/test_engine.js" "ALL OK" || say FAIL "pumplun/build/test_engine.js" "$(tail -2 "$TMP/eng.out" | tr '\n' ' ')"
  if [ $LONG = 1 ]; then
    (cd pumplun/build && node test_f8.js) > "$TMP/f8.out" 2>&1 && say PASS "pumplun/build/test_f8.js" "$(tail -1 "$TMP/f8.out")" || say FAIL "pumplun/build/test_f8.js" "$(tail -2 "$TMP/f8.out" | tr '\n' ' ')"
  else say SKIP "pumplun/build/test_f8.js" "run with --long (the F_8 enumeration, about 10 minutes more)"; fi
  if [ -n "$NB" ]; then say SKIP "pumplun/test_page_pumplun.mjs" "the browser part is left out (REPORT_NO_BROWSER is set or python playwright is missing)"
  else
    (cd pumplun && node test_page_pumplun.mjs) > "$TMP/pg.out" 2>&1; rc=$?
    if [ $rc -eq 0 ]; then say PASS "pumplun/test_page_pumplun.mjs" "$(tail -1 "$TMP/pg.out")"
    elif [ $rc -eq 77 ]; then say SKIP "pumplun/test_page_pumplun.mjs" "$(tail -1 "$TMP/pg.out")"
    else say FAIL "pumplun/test_page_pumplun.mjs" "$(grep -m3 '^FAIL' "$TMP/pg.out" | tr '\n' ' ') $(tail -1 "$TMP/pg.out")"; fi
  fi
else say SKIP "pumplun node tests" "node is not installed"; fi
# 3. generated files are current
python3 make_matrix_json.py --check > "$TMP/m.out" 2>&1 && say PASS make_matrix_json.py "$(tail -1 "$TMP/m.out")" || say FAIL make_matrix_json.py "$(tail -1 "$TMP/m.out")"
python3 make_check_table.py --check > "$TMP/t.out" 2>&1 && say PASS make_check_table.py "$(tail -1 "$TMP/t.out")" || say FAIL make_check_table.py "$(tail -1 "$TMP/t.out")"
python3 make_package.py --check > "$TMP/p.out" 2>&1 && say PASS make_package.py "$(tail -1 "$TMP/p.out")" || say FAIL make_package.py "$(tail -1 "$TMP/p.out")"
# 4. sabotage (optional, long): in a copy, so the shipped logs stay as they are
if [ $MUT = 1 ]; then
  cp -R category baez schuller hestenes furey "$TMP/"
  for pair in schuller:mutate_fibre.py category:mutate_cat.py baez:mutate_baez.py hestenes:mutate_hestenes.py furey:mutate_furey.py; do
    d=${pair%%:*}; s=${pair#*:}
    ONLY=; NOTE=
    if [ "$s" = mutate_baez.py ] && [ ! -d baez/txt ]; then ONLY=$(seq -f 'M%02g' 2 56); NOTE=' (M01, the sabotage of R1, needs the papers'"'"' texts: not run)'; fi
    (cd "$TMP/$d" && python3 "$s" $ONLY) > "$TMP/$s.log" 2>&1; caught=$(grep -o 'mutants caught: [0-9]* of [0-9]*' "$TMP/$s.log")
    n1=$(echo "$caught" | awk '{print $3}'); n2=$(echo "$caught" | awk '{print $5}')
    if [ -n "$n1" ] && [ "$n1" = "$n2" ]; then say PASS "$d/$s" "$caught$NOTE"; else say FAIL "$d/$s" "${caught:-no verdict}$NOTE"; fi
  done
else say SKIP "sabotage scripts" "run with --mutation (about 1.5 hours)"; fi
echo "run_report_tests.sh: $PASSES passed, $FAILS failed, $SKIPS skipped"
[ $FAILS = 0 ]
