# Hestenes and gauge-theory gravity in the bit rule (7 October 2026)

Shipped in the web-app package as `reports/hestenes/` (this folder) with the built page in `../html/hestenes_ldg_report.html`; `../zips/hestenes_report.zip` holds the page and this folder (members `html/hestenes_ldg_report.html` and `hestenes/…`). `gtg_check.py` and `bitcliff.py` here are byte-identical to `selfcheck/steps15_17/gtg_check.py` and `bitcliff.py` of the package.

The report takes the objects of Hestenes' space-time algebra Cl(1,3) (γ0² = +1) and of the gauge-theory gravity of Lasenby, Doran and Gull (LDG) that the atlas uses in steps 4, 5, 12 and 13 and in Calibration 1 (Maxwell), writes them as labels of the bit rule, and recomputes them twice: in the atlas's own engine (`gtg_check.py`) and in a second implementation of the algebra written for the report.

## Files
- `../html/hestenes_ldg_report.html`: the report (one self-contained file; opens offline; light and dark; wide drawings scroll sideways on a phone). Head, the one-paragraph summary, findings F1–F13 (the cell and its labels; the "i" of the Dirac equation as the real bivector J; the Dirac equation on plane waves; the chirality as XOR with 9; pointors; Maxwell; the three classes in the Lorentz group; the Dirac action; the point mass as one unipotent shear; free fall and the curvature operator; the horizon; time reversal; curvature counts by dimension), a dictionary of 23 rows, the seven inputs, dead ends and limits, the checks table, sources. Four figures: the sixteen labels with the kernels and the XOR 9 pairs, the curvature operator, the square of the radial gradient, the two time shifts.
- `hest_check.py`: runs the four scripts below and prints one log of `ok   <id>: <text>` lines (ids H1–H30, L1–L10, A1–A2, S1a–S12a, G1a–G8e; 95 checks, about 20 s). The ids of `gtg_check.py` are renumbered S1a, S1b, ... and G1a, ... in the order of its lines.
- `hest_indep.py` (H1–H30): the second implementation, Hestenes' algebra: cell facts, the symbol of the Dirac map and its determinant, the kernels at p = (m, 0, 0, 0) and (−m, 0, 0, 0), the 4 × 4 matrix form, the chirality ψ ↦ IψJ, pointors and the Yvon–Takabayasi angle, Maxwell, the Lorentz force. Uses `stalg.py` (its own bit-rule product for Cl(1,3), numpy only).
- `ldg_indep.py` (L1–L10): gauge-theory gravity: the Painlevé–Gullstrand and Kerr–Schild shears give vacuum metrics with Kretschmann scalar 48M²/r⁶, controls, the curvature operator against B + 3σ_r B σ_r, free fall, the time shifts (numpy and scipy).
- `ldg_action.py` (A1–A2): the Euler–Lagrange equations of the free Dirac action against Hestenes' equation.
- `gtg_check.py S G`: parts S (the space-time algebra: names, the "i", plane waves, Maxwell, the Lorentz group, the Weyl map, the action) and G (gauge fields as shears: Newtonian gauge, Kerr–Schild, the horizon classes, time reversal, curvature counts) of the atlas's script; its parts R and F belong to steps 1, 12 and 17 and are not used here. Raw log: `logs/gtg_check_SG.log`.
- `mutate_hestenes.py`: automated sabotage of the four independent scripts, 26 mutants (one wrong sign, exponent, signature, label or constant each, in a temporary copy; the named check must fail; a crash does not count). Result: 26 of 26 caught (`logs/mutate_hestenes.log`, about 2 minutes). `gtg_check.py` is sabotaged by the atlas's `selfcheck/steps15_17/run_mutations.py`.
- `figs_hestenes.py`, `content_hestenes.py`, `build_report_hestenes.py`, `report_style.css`, `report_script.js`, `status_chips.py` (the five status icons as a hidden sprite, the chip, the legend line and their style rules; the same file in the six report folders): build the report from the logs, the algebra engine, the figure code and the text.
- `test_report_hestenes.py`: 39 data tests and 10 browser tests that the page agrees with its sources: every number equals the log, every check id named exists and every id of the log is named, each finding tagged checked names a check, the numbers in the text equal the lines they cite, a fresh run of the checks gives the log, the copied scripts are byte-identical to the atlas's, the cross-references to other scripts exist, no external request, no address, no history wording (`../no_history.py`), the forbidden sentences are nowhere on the page; and in a browser: figure counts, tooltips, theme button, no sideways overflow at 1100 and 375 px. With REPORT_NO_BROWSER=1 the 10 browser tests are skipped and say so.
- `logs/`: `hest_check.log`, `gtg_check_SG.log`, `mutate_hestenes.log`.

## Rerun
Needs Python 3, numpy and scipy, the atlas package this folder ships in (two folders up; or set `ATLAS_PKG`; its `selfcheck/` is needed, and its `researchers_checks/` is looked at by test T19 only when the folder is there: without it that one cross-reference, to `check_T16.py`, is skipped and the run says so), and playwright with Chromium for the browser tests (the package runs them through `reports/run_report_tests.sh`).

    python3 hest_check.py > logs/hest_check.log
    python3 gtg_check.py S G > logs/gtg_check_SG.log
    python3 mutate_hestenes.py > logs/mutate_hestenes.log     # about 2 minutes
    python3 build_report_hestenes.py && python3 test_report_hestenes.py

## Honest status
- The statements tagged checked are computed in flat space for the Dirac equation and Maxwell, and for one metric (the point mass) in gravity. The independent scripts use floating point with the tolerances their lines state; `gtg_check.py` is exact where its lines say so. Nothing is claimed beyond that.
- The field equations of gauge-theory gravity, cosmology, the rotating solution and the Hawking-radiation sections of LDG are not decoded; the Dirac equation is not built in a gravitational field; the chiral coupling is not drawn; the coupling constant is not derived.
- Inputs, named in the report: the time direction and the signature, the chart and the derivative, the grade a field lives in, the complex structure J, the equations themselves, the form of the shear (the Schwarzschild solution as LDG write it), the coupling.
- The horizon vector e_t − e_r is a paired null vector of Cl(1,1); the atlas's label 0 (an unpaired null generator) is not the horizon, and the report says so.
- The report changes no statement of the web app. No address of any person is in any file.
