#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Independent check of the statements of Hestenes' spacetime algebra that the atlas reads (the Dirac equation, the chirality, pointors, Maxwell, the Lorentz force).
Own bit-rule algebra for Cl(1,3) (stalg.py: gamma_0^2 = +1, gamma_k^2 = -1), own Dirac matrices; nothing imported from the atlas.  numpy only.
Conventions of Hestenes and of Lasenby-Doran-Gull (LDG, appendix A): frame gamma_mu, reciprocal frame gamma^mu, grad = gamma^mu d_mu, i sigma_3 = gamma_2 gamma_1,
I = gamma_0 gamma_1 gamma_2 gamma_3, sigma_k = gamma_k gamma_0.  One line `ok   H<n>: ...` per check, exit 1 if one fails.   Run: python3 hest_indep.py"""
import os, sys
import numpy as np
from math import comb
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stalg import *
rng = np.random.default_rng(20261006)
NOK = NBAD = 0
def check(text, cond):
    global NOK, NBAD
    if cond: NOK += 1
    else: NBAD += 1
    print(('ok   ' if cond else 'FAIL ') + 'H%d: %s' % (NOK + NBAD, text))
EV = lambda: np.where(np.isin(np.arange(N), EVEN), rng.normal(size=N), 0)      # a random even multivector

check('J = gamma2 gamma1 = I sigma3 and J^2 = -1', np.allclose(J, gp(I, sig[3])) and np.allclose(gp(J, J), -bl(0)))
check('I^2 = -1 and I = sigma1 sigma2 sigma3', np.allclose(gp(I, I), -bl(0)) and np.allclose(I, gp(gp(sig[1], sig[2]), sig[3])))

# ---------------- (i) Dirac: the symbol of the equation on plane waves, its kernel, and the 4 x 4 form
def vec(c, up=False): return sum(c[i] * (gup if up else g)[i] for i in range(4))
def symbol(p_low, m, sgn=-1):
    """plane wave psi = psi0 exp(sgn J p.x) (Hestenes: sgn = -1): the exact derivative at x = 0 is d_mu psi = psi (sgn J) p_mu; the symbol is psi -> grad psi J - m psi gamma_0."""
    cols = []
    for e in EVEN:
        psi = bl(e)
        grad = sum(gp(gup[mu], gp(psi, sgn * p_low[mu] * J)) for mu in range(4))
        T = gp(grad, J) - m * gp(psi, g[0])
        cols.append([T[o] for o in ODD])
        assert np.allclose([T[e2] for e2 in EVEN], 0)          # the image lies in the odd part
    return np.array(cols).T
worst = 0
for _ in range(40):
    p = rng.normal(size=4) * 2; m = abs(rng.normal()) + 0.1
    p2 = p[0] ** 2 - p[1] ** 2 - p[2] ** 2 - p[3] ** 2
    d = np.linalg.det(symbol(p, m)); worst = max(worst, abs(abs(d) - abs((p2 - m * m) ** 4)) / max(1, abs((p2 - m * m) ** 4)))
check('|det| of the symbol of grad(psi) i sigma3 - m psi gamma0 on plane waves equals |p^2 - m^2|^4 (40 random p and m, relative error below 1e-9)', worst < 1e-9)
m = 1.3; prest = np.array([m, 0, 0, 0])
K = symbol(prest, m); ns = 8 - np.linalg.matrix_rank(K)
_, _, Vt = np.linalg.svd(K); ker = Vt[-ns:]
kerblades = sorted({EVEN[j] for v in ker for j in np.nonzero(np.abs(v) > 1e-9)[0]})
check('at p = (m,0,0,0) the kernel is span{1, I sigma_k} (the Pauli-even blades 1, g1g2, g1g3, g2g3), real dimension 4', ns == 4 and set(kerblades) == {0, 6, 10, 12})
K2 = symbol(-prest, m); ns2 = 8 - np.linalg.matrix_rank(K2); _, _, Vt2 = np.linalg.svd(K2)
kb2 = sorted({EVEN[j] for v in Vt2[-ns2:] for j in np.nonzero(np.abs(v) > 1e-9)[0]})
check('at p = (-m,0,0,0) the kernel is span{sigma_k, I} (the blades g0g1, g0g2, g0g3, I), a different 4-dimensional space: the sign of the energy belongs to the point p', ns2 == 4 and set(kb2) == {3, 5, 9, 15})
Jmat = np.array([[gp(bl(e), J)[e2] for e in EVEN] for e2 in EVEN])
P = ker.T @ np.linalg.pinv(ker.T)
check('the on-shell kernel at fixed p is closed under right multiplication by J: complex dimension 2, two spin states and one sign of the energy', np.allclose(P @ Jmat @ ker.T, Jmat @ ker.T))
# 4 x 4 Dirac matrices, Dirac-Pauli representation, upper index (Bjorken-Drell)
s0 = np.eye(2); s = [np.array([[0, 1], [1, 0]], complex), np.array([[0, -1j], [1j, 0]]), np.array([[1, 0], [0, -1]], complex)]
Gup = [np.block([[s0, 0 * s0], [0 * s0, -s0]]).astype(complex)] + [np.block([[0 * s0, sk], [-sk, 0 * s0]]) for sk in s]
Glow = [Gup[0]] + [-x for x in Gup[1:]]                 # LDG (A.1): gamma-hat_mu, lower index
def M(A):                                               # multivector -> 4 x 4 matrix, frame gamma_mu -> gamma-hat_mu (LDG A.3)
    out = np.zeros((4, 4), complex)
    for mm in np.nonzero(A)[0]:
        X = np.eye(4, dtype=complex)
        for i in bits(mm): X = X @ Glow[i]
        out += A[mm] * X
    return out
u = np.array([1, 0, 0, 0], complex)
check('gamma0 u = u and (gamma2 gamma1) u = +i u for the column u = (1,0,0,0): right multiplication by i sigma3 is the imaginary unit', np.allclose(M(g[0]) @ u, u) and np.allclose(M(J) @ u, 1j * u))
Amap = np.array([np.concatenate([(M(bl(e)) @ u).real, (M(bl(e)) @ u).imag]) for e in EVEN])
check('psi -> psi u is a real-linear bijection of the 8-dimensional even subalgebra onto C^4', np.linalg.matrix_rank(Amap) == 8)
err = 0
for _ in range(200):
    psi = EV(); dpsi = [EV() for _ in range(4)]
    mm_ = rng.normal()
    lhs = sum(gp(gup[mu], dpsi[mu]) for mu in range(4)); lhs = gp(lhs, J) - mm_ * gp(psi, g[0])
    std = 1j * sum(Gup[mu] @ (M(dpsi[mu]) @ u) for mu in range(4)) - mm_ * (M(psi) @ u)
    err = max(err, np.abs(M(lhs) @ u - std).max())
check('Hestenes grad(psi) i sigma3 - m psi gamma0, with grad = gamma^mu d_mu, goes to i gamma^mu d_mu Psi - m Psi under psi -> Psi = psi u (200 random psi, derivatives and m; error below 1e-12)', err < 1e-12)
R = gp(g[3], g[2])
def plane_residual(psi0, p_low, mq, Junit, sgn):
    """the residual of grad psi Junit - mq psi gamma0 for the plane wave psi = psi0 exp(sgn J p.x): J commutes with gamma0, so the factor exp(sgn J p.x) passes through and the residual at x = 0 is the whole story (d_mu psi = psi0 sgn p_mu J)"""
    grad = sum(gp(gup[mu], gp(psi0, sgn * p_low[mu] * J)) for mu in range(4))
    return gp(grad, Junit) - mq * gp(psi0, g[0])
solved = mapped = control = True; nker = 0
for E_sign in (1, -1):
    for _ in range(5):
        mq = abs(rng.normal()) + 0.3; kvec = rng.normal(size=3); p_low = np.array([E_sign * np.sqrt(mq * mq + kvec @ kvec), *kvec])
        Kq = symbol(p_low, mq); nsq = 8 - np.linalg.matrix_rank(Kq); _, _, Vtq = np.linalg.svd(Kq)
        for v in Vtq[8 - nsq:]:                                   # a basis of the solutions at p (psi0 on the 8 even blades)
            psi0 = np.zeros(N)
            for j, e in enumerate(EVEN): psi0[e] = v[j]
            nker += 1
            solved &= np.abs(plane_residual(psi0, p_low, mq, J, -1)).max() < 1e-9                      # psi0 exp(-J p.x) solves grad psi J = m psi gamma0
            mapped &= np.abs(plane_residual(gp(psi0, R), p_low, mq, -J, 1)).max() < 1e-9               # psi R = psi0 R exp(+J p.x) solves grad psi (-J) = m psi gamma0
            control &= np.abs(plane_residual(psi0, p_low, mq, -J, -1)).max() > 1e-3                    # the same wave without the map does not
check('psi -> psi gamma3 gamma2 maps solutions of grad psi gamma2 gamma1 = m psi gamma0 to solutions of grad psi gamma1 gamma2 = m psi gamma0: the plane wave psi0 exp(-J p.x) goes to psi0 R exp(+J p.x) for every kernel vector at 10 random on-shell p (5 of each sign of the energy, %d vectors, residual below 1e-9), and the same wave without the map fails the second equation; R commutes with gamma0 and anticommutes with J: the opposite sign of the unit is the same equation' % nker,
      solved and mapped and control and nker == 40 and np.allclose(gp(R, g[0]), gp(g[0], R)) and np.allclose(gp(R, J), -gp(J, R)))

# ---------------- (ii) Maxwell: grad F = J, grades 1 and 3, in the gamma0 frame
def maxwell_check():
    dE = rng.normal(size=(4, 4)); dB = rng.normal(size=(4, 4))        # dE[mu][k] = d_mu E^k (k = 1..3; index 0 unused)
    dF = [sum(dE[mu][k] * sig[k] + dB[mu][k] * gp(I, sig[k]) for k in (1, 2, 3)) for mu in range(4)]
    gF = sum(gp(gup[mu], dF[mu]) for mu in range(4))
    only13 = all(abs(gF[mm]) < 1e-12 for mm in range(N) if grade(mm) not in (1, 3))
    divE = dE[1][1] + dE[2][2] + dE[3][3]; divB = dB[1][1] + dB[2][2] + dB[3][3]
    curl = lambda d: np.array([0, d[2][3] - d[3][2], d[3][1] - d[1][3], d[1][2] - d[2][1]])
    cE, cB = curl(dE), curl(dB)
    X = gp(g[0], gF)                                   # gamma0 grad F = (d_t + nabla)(E + I B)
    vecpart = np.array([0] + [gp(X, sig[k])[0] for k in (1, 2, 3)])
    ampere = np.allclose(vecpart[1:], (dE[0][1:] - cB[1:])); gauss = np.isclose(X[0], divE)
    biv = np.array([0] + [-gp(X, gp(I, sig[k]))[0] for k in (1, 2, 3)])
    faraday = np.allclose(biv[1:], dB[0][1:] + cE[1:]); nomono = np.isclose(-gp(X, I)[0], divB)
    X1 = gp(g[0], part(gF, 1)); X3 = gp(g[0], part(gF, 3))
    split = np.isclose(X1[0], divE) and np.allclose([gp(X1, sig[k])[0] for k in (1, 2, 3)], dE[0][1:] - cB[1:]) \
        and np.allclose([-gp(X3, gp(I, sig[k]))[0] for k in (1, 2, 3)], dB[0][1:] + cE[1:]) and np.isclose(-gp(X3, I)[0], divB)
    return only13 and ampere and gauss and faraday and nomono and split
check('grad F has grades 1 and 3 only; grade 1 = Gauss + Ampere (4 equations), grade 3 = Faraday + div B = 0 (4 equations); 20 random samples', all(maxwell_check() for _ in range(20)))
H = rng.normal(size=(4, 4)); H = H + H.T; F0 = sum(rng.normal() * bl(mm) for mm in range(N) if grade(mm) == 2)
gg = sum(H[a, b] * gp(gup[a], gp(gup[b], F0)) for a in range(4) for b in range(4))
check('grad grad F = box F with box = d_t^2 - d_x^2 - d_y^2 - d_z^2', np.allclose(gg, (H[0, 0] - H[1, 1] - H[2, 2] - H[3, 3]) * F0))
check('equation counts of grad F = J: grade 1 has n components and grade 3 has C(n,3) (n = 4: 4 + 4; n = 5: 5 + 10)', comb(4, 3) == 4 and comb(5, 3) == 10)
def symbol_ranks():
    biv = [a for a in range(16) if grade(a) == 2]; g1 = [k for k in range(16) if grade(k) == 1]; g3 = [k for k in range(16) if grade(k) == 3]
    out = {}
    for name, pv in [('timelike', [1.0, 0.3, -0.2, 0.1]), ('null', [1.0, 1.0, 0, 0]), ('spacelike', [0.2, 1.0, 0.4, 0.0])]:
        Pm = sum(pv[i] * SQ[i] * g[i] for i in range(4))
        Mx = np.zeros((16, 6))
        for j, a in enumerate(biv): Mx[:, j] = gp(Pm, bl(a))
        assert np.allclose(Mx[[k for k in range(16) if k not in g1 + g3], :], 0)
        out[name] = (np.linalg.matrix_rank(Mx[g1, :]), np.linalg.matrix_rank(Mx[g3, :]), np.linalg.matrix_rank(Mx))
    return out
SR = symbol_ranks()
check('the symbol F -> p F of grad F = 0 on bivectors has rank 6 of 6 unknowns for a timelike and for a spacelike p and rank 4 of 6 for a null p (grade 1 and grade 3 each of rank 3)',
      SR['timelike'] == (3, 3, 6) and SR['spacelike'] == (3, 3, 6) and SR['null'] == (3, 3, 4))
def lorentz():
    E = rng.normal(size=3); B = rng.normal(size=3); v = rng.normal(size=3); v = 0.9 * v / np.linalg.norm(v); gam = 1 / np.sqrt(1 - v @ v)
    F = sum(E[k - 1] * sig[k] + B[k - 1] * gp(I, sig[k]) for k in (1, 2, 3))
    uu = gam * (g[0] + sum(v[k - 1] * g[k] for k in (1, 2, 3)))
    Fu = 0.5 * (gp(F, uu) - gp(uu, F))
    want = gam * ((E @ v) * g[0] + sum((E + np.cross(v, B))[k - 1] * g[k] for k in (1, 2, 3)))
    return np.allclose(Fu, want) and np.allclose(Fu, part(gp(F, uu), 1))
check('F.u = (Fu - uF)/2 = <F u>_1 = gamma[(E.v) gamma0 + (E + v x B)^k gamma_k] for F = E + I B and u = gamma(gamma0 + v^k gamma_k) (20 samples): the Lorentz force', all(lorentz() for _ in range(20)))

# ---------------- (iii) chirality psi -> I psi J and the bit labels
flip = {}
for mm in range(N):
    x = gp(gp(I, bl(mm)), J); nz = np.nonzero(x)[0]; assert len(nz) == 1; flip[mm] = (nz[0], x[nz[0]])
check('psi -> I psi J sends every blade e_m to +-e_(m XOR 9) (9 = 15 XOR 6 = the bits of gamma0 gamma3)', all(flip[mm][0] == mm ^ 9 for mm in range(N)))
check('psi -> I psi J is an involution', all(np.allclose(gp(gp(I, gp(gp(I, bl(mm)), J)), J), bl(mm)) for mm in range(N)))
psi = EV(); sig3 = sig[3]
check('on an even psi, I psi J = -psi sigma3 = psi gamma0 gamma3: a right multiplication', np.allclose(gp(gp(I, psi), J), -gp(psi, sig3)) and np.allclose(gp(gp(I, psi), J), gp(psi, gp(g[0], g[3]))))
C8 = np.array([[gp(gp(I, bl(e)), J)[e2] for e in EVEN] for e2 in EVEN]); ev = np.round(np.linalg.eigvals(C8).real, 9)
check('on the 8 even blades the eigenspaces of psi -> I psi J are 4 + 4', sorted(ev).count(1.0) == 4 and sorted(ev).count(-1.0) == 4)
g5 = 1j * Gup[0] @ Gup[1] @ Gup[2] @ Gup[3]
check('with the LDG map Psi = psi u: I psi J goes to -gamma5 Psi (gamma5 = i g^0 g^1 g^2 g^3), that is psi sigma3 goes to gamma5, as in LDG (A.3)',
      np.allclose(M(gp(gp(I, psi), J)) @ u, -g5 @ (M(psi) @ u)) and np.allclose(M(gp(psi, sig3)) @ u, g5 @ (M(psi) @ u)))
def Cinv(x): return gp(gp(I, x), J)                                       # the same formula on odd elements
def chir_split():
    ok1 = ok2 = True
    for _ in range(20):
        psi = EV(); dpsi = [EV() for _ in range(4)]
        Kc = sum(gp(gup[mu], gp(Cinv(dpsi[mu]), J)) for mu in range(4))   # K(C psi): grad (I psi J) J
        CK = Cinv(sum(gp(gup[mu], gp(dpsi[mu], J)) for mu in range(4)))   # C(K psi)
        ok1 &= np.allclose(Kc, -CK)
        ok2 &= np.allclose(gp(Cinv(psi), g[0]), Cinv(gp(psi, g[0])))
    return ok1, ok2
c1, c2 = chir_split()
check('the derivative term grad psi J anticommutes with psi -> I psi J and the mass term psi gamma0 commutes with it (20 samples): for m = 0 the Dirac equation splits into two Weyl halves, and the mass term couples them', c1 and c2)

def kernel_at(p_low, m):
    K_ = symbol(p_low, m); ns_ = 8 - np.linalg.matrix_rank(K_); _, _, Vt_ = np.linalg.svd(K_); return Vt_[len(Vt_) - ns_:] if ns_ else np.zeros((0, 8)), ns_
def as_mv(v):
    x = np.zeros(N)
    for j, e in enumerate(EVEN): x[e] = v[j]
    return x
okmap = oksign = True
for E_sign in (1, -1):
    for _ in range(5):
        k = rng.normal(size=3); E = E_sign * np.sqrt(m * m + k @ k); p_low = np.array([E, *k])
        kp, dp = kernel_at(p_low, m); km, dm = kernel_at(-p_low, m)
        okmap &= (dp == 4 and dm == 4)
        for v in km:                                      # the chirality maps the kernel at -p into the kernel at p
            w = gp(gp(I, as_mv(v)), J); okmap &= np.allclose(symbol(p_low, m) @ np.array([w[e] for e in EVEN]), 0, atol=1e-9)
        for v in kp:                                      # every kernel element has psi psi~ = a, b = 0, sign a = sign E
            q = gp(as_mv(v), rev(as_mv(v))); oksign &= abs(q[15]) < 1e-9 and q[0] * E_sign > 0
check('psi -> I psi J maps the solutions at -p onto the solutions at p (10 random on-shell p, 5 of each sign of the energy, kernel dimension 4 at p and at -p): the chirality exchanges the two signs of the energy at a given p', okmap)
check('at the same on-shell points every solution has psi psi~ = a with b = 0 and the sign of a equal to the sign of the energy p0: a pointor with beta = 0 for p0 > 0 and beta = pi for p0 < 0', oksign)

# ---------------- pointors and the Yvon-Takabayasi angle
def ypt(psi):
    n2 = gp(psi, rev(psi)); a, b = n2[0], n2[15]
    return a, b, np.allclose([n2[mm] for mm in range(N) if mm not in (0, 15)], 0)
check('for even psi, psi psi~ = a + b I = rho e^{I beta}: scalar and pseudoscalar parts only (20 samples)', all(ypt(EV())[2] for _ in range(20)))
def is_pointor(psi):
    x = gp(gp(psi, I), rev(psi)); return np.allclose([x[mm] for mm in range(15)], 0)
def expb(Bv):                                                             # exp of a bivector, by the series
    out = bl(0); term = bl(0)
    for k_ in range(1, 40):
        term = gp(term, Bv) / k_; out = out + term
    return out
cnt = npoint = nnon = 0
for t_ in range(200):
    if t_ % 3 == 2: psi = EV()                                            # generic: b != 0, not a pointor
    else:                                                                 # a pointor: rho^(1/2) e^{I beta/2} R with beta = 0 or pi
        Bv = sum(rng.normal() * 0.4 * bl(a) for a in (3, 5, 6, 9, 10, 12)); beta_ = (0.0, np.pi)[t_ % 3]
        psi = rng.uniform(0.5, 2) * gp(np.cos(beta_ / 2) * bl(0) + np.sin(beta_ / 2) * I, expb(Bv))
    a, b, _ = ypt(psi); pt = is_pointor(psi)
    cnt += (pt == np.isclose(b, 0)); npoint += pt; nnon += (not pt)
check('psi I psi~ is a multiple of I if and only if b = 0, that is sin(beta) = 0 (200 samples: 134 with beta = 0 or pi, 66 generic)', cnt == 200 and npoint == 134 and nnon == 66)
check('psi = I (beta = pi): psi psi~ = -1, b = 0 and psi I psi~ = -I, a pointor with beta = pi: the slice b = 0 is beta in {0, pi}, not beta = 0',
      np.allclose(gp(I, rev(I)), -bl(0)) and is_pointor(I) and np.allclose(gp(gp(I, I), rev(I)), -I))
q = np.cos(np.pi / 4) * bl(0) + np.sin(np.pi / 4) * I
check('psi = e^{I pi/4} (beta = pi/2) is not a pointor', not is_pointor(q))
psi = EV(); a, b, _ = ypt(psi); rho = np.hypot(a, b); beta = np.arctan2(b, a)
Rr = gp(rho ** -0.5 * (np.cos(-beta / 2) * bl(0) + np.sin(-beta / 2) * I), psi)
check('psi = rho^(1/2) e^(I beta/2) R with R R~ = 1 (canonical form of an even multivector with rho > 0)', np.allclose(gp(Rr, rev(Rr)), bl(0)))
okv = okp = True
for _ in range(20):
    psi = EV(); a, b, _ = ypt(psi); rho = np.hypot(a, b); beta = np.arctan2(b, a)
    x = sum(rng.normal() * g[i] for i in range(4)); y = gp(gp(psi, x), rev(psi))
    okv &= all(abs(y[mm]) < 1e-9 for mm in range(N) if grade(mm) != 1) and np.isclose(gp(y, y)[0], rho ** 2 * gp(x, x)[0])
    w = gp(gp(psi, I), rev(psi)); okp &= np.allclose(w, rho * gp(np.cos(beta) * bl(0) + np.sin(beta) * I, I))
check('psi x psi~ = rho R x R~ is a vector for every even psi (beta cancels), while psi I psi~ = rho e^{I beta} I (beta survives), 20 samples', okv and okp)
okX = True
for _ in range(100):
    psi = EV(); a, b, _ = ypt(psi); X = gp(gp(psi, g[0]), rev(psi)); X2 = gp(X, X)
    okX &= all(abs(X[k]) < 1e-9 for k in range(N) if grade(k) != 1) and np.isclose(X2[0], a * a + b * b) and all(abs(X2[k]) < 1e-9 for k in range(1, N))
check('the current X = psi gamma0 psi~ is a vector and X^2 = a^2 + b^2 = rho^2 (not (a + bI)^2), 100 samples', okX)
print('\nchecks: %d ok, %d failed' % (NOK, NBAD)); sys.exit(1 if NBAD else 0)
