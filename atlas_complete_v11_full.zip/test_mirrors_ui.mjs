// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML } from './paths.mjs';
import { eqNavIds, stepCount } from './steps.js';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
const b=await chromium.launch();const errs=[];
const C=(n,k)=>{if(k<0||k>n)return 0;let r=1;for(let i=0;i<k;i++)r=r*(n-i)/(i+1);return Math.round(r);};
const AX=['t','x','y','z','u'];const pc=x=>{let c=0;while(x){c+=x&1;x>>=1;}return c;};
const names=S=>AX.filter((_,i)=>S>>i&1).join('');
for(const lang of ['en','it']) for(const w of [1100,375]){
 const pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push(`${lang}${w}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${lang}${w} console: ${m.text()}`));
 await pg.goto(APP_HTML + '#equations/mirrors');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.locator('[data-profile="Mathematician"]').click();await pg.waitForTimeout(200);
 const nav=await pg.locator('.tabbar [role=tab]').count(); if(nav!==eqNavIds().length)errs.push(`${lang}${w}: nav ${nav}`);
 const rows=await pg.locator('#eq-mirrors .mr-table tbody tr').count(); if(rows!==7)errs.push(`${lang}${w}: ladder rows ${rows}`);
 const idr=await pg.locator('#eq-mirrors .mr-id tbody tr').count(); if(idr!==4)errs.push(`${lang}${w}: identity rows ${idr}`);
 const ticks=await pg.locator('#eq-mirrors .mr-id td').filter({hasText:'✓'}).count(); if(ticks!==12)errs.push(`${lang}${w}: ticks ${ticks}`);
 const chips=pg.locator('#eq-mirrors .mr-chip'); if(await chips.count()!==7)errs.push('chips '+await chips.count());
 // the cube picture works from the keyboard (T2-1): the svg is a group, each of the 16 corners (n = 4) is a button with a name in the page's language and aria-pressed;
 // Tab from the last chip reaches the first corner, Tab moves on corner by corner, Enter and Space pick the focused corner, and the focus ring is drawn
 { const a11y=await pg.evaluate(()=>{const svg=document.querySelector('#eq-mirrors svg.mr-pic'),bs=[...svg.querySelectorAll('[role=button]')];return{svgRole:svg.getAttribute('role'),svgName:svg.getAttribute('aria-label')||'',n:bs.length,tab:bs.filter(x=>x.getAttribute('tabindex')==='0').length,pressed:bs.filter(x=>x.getAttribute('aria-pressed')==='true').map(x=>x.querySelector('.mr-corner').dataset.mask),names:bs.map(x=>x.getAttribute('aria-label')||''),corners:svg.querySelectorAll('.mr-corner').length};});
  if(a11y.svgRole!=='group'||a11y.n!==16||a11y.corners!==16||a11y.tab!==16)errs.push(`${lang}${w}: corners are not keyboard buttons: ${JSON.stringify({...a11y,names:a11y.names.length})}`);
  if(a11y.pressed.join()!=='15')errs.push(`${lang}${w}: aria-pressed should mark corner 15 only: ${a11y.pressed}`);
  const nameRe=lang==='it'?/^(Vertice [txyz]+, \d specch[io]|Il vertice di partenza)/:/^(Corner [txyz]+, \d mirrors?|The starting corner)/;
  if(!a11y.names.every(x=>nameRe.test(x))||new Set(a11y.names).size!==16)errs.push(`${lang}${w}: corner names not localised or not distinct: ${a11y.names.slice(0,4)}`);
  if(!(lang==='it'?/vertic/:/corners/).test(a11y.svgName))errs.push(`${lang}${w}: picture name "${a11y.svgName}"`);
  const focused=()=>pg.evaluate(()=>{const a=document.activeElement;return a&&a.matches('#eq-mirrors .mr-corner-btn')?{mask:+a.querySelector('.mr-corner').dataset.mask,ring:getComputedStyle(a.querySelector('.mr-corner')).stroke}:null;});
  await chips.last().focus(); await pg.keyboard.press('Tab'); let f=await focused();
  if(!f||f.mask!==0)errs.push(`${lang}${w}: Tab from the last chip does not reach the first corner (${JSON.stringify(f)})`);
  else if(!/74, 168, 255/.test(f.ring))errs.push(`${lang}${w}: no focus ring on the focused corner (${f.ring})`);
  await pg.keyboard.press('Tab'); await pg.keyboard.press('Tab'); f=await focused();     // weight 0: [0]; weight 1: [1, 2, 4, 8] -> the third corner in the Tab order is 2 (x)
  if(!f||f.mask!==2)errs.push(`${lang}${w}: Tab does not move corner by corner (${JSON.stringify(f)})`);
  await pg.keyboard.press('Enter'); await pg.waitForTimeout(50);
  let head=await pg.locator('#eq-mirrors .mr-head').textContent(), pr=await pg.locator('#eq-mirrors .mr-corner-btn[aria-pressed="true"] .mr-corner').evaluateAll(es=>es.map(e=>e.dataset.mask));
  if(!/\bx:/.test(head)||pr.join()!=='2')errs.push(`${lang}${w}: Enter does not pick the focused corner x (head "${head}", pressed ${pr})`);
  await pg.keyboard.press('Tab'); const y0=await pg.evaluate(()=>scrollY); await pg.keyboard.press(' '); await pg.waitForTimeout(50);
  head=await pg.locator('#eq-mirrors .mr-head').textContent(); pr=await pg.locator('#eq-mirrors .mr-corner-btn[aria-pressed="true"] .mr-corner').evaluateAll(es=>es.map(e=>e.dataset.mask)); f=await focused();
  if(!/\by:/.test(head)||pr.join()!=='4'||!f||f.mask!==4)errs.push(`${lang}${w}: Space does not pick the focused corner y (head "${head}", pressed ${pr}, focus ${JSON.stringify(f)})`);
  if(await pg.evaluate(()=>scrollY)!==y0)errs.push(`${lang}${w}: Space on a corner scrolls the page`); }
 for(let n=2;n<=8;n++){
  await chips.nth(n-2).click();
  const v=await pg.locator('#eq-mirrors .mr-view').count(); if(v!==7)errs.push(`${lang}${w} n=${n}: ${v} views`);
  const on=await pg.locator('#eq-mirrors .mr-table tbody tr.on td').first().textContent(); if(+on!==n)errs.push(`${lang}${w} n=${n}: row ${on}`);
  const txt=await pg.locator('#eq-mirrors').textContent(); if(/undefined|NaN|\[object/.test(txt))errs.push(`${lang}${w} n=${n}: placeholder`);
  if(n<=5){
   const all=await pg.locator('#eq-mirrors .mr-corner').count(); if(all!==1<<n)errs.push(`${lang}${w} n=${n}: ${all} corners`);
   const ev=await pg.locator('#eq-mirrors .mr-corner.even').count(); if(ev!==1<<(n-1))errs.push(`${lang}${w} n=${n}: ${ev} even corners`);
   for(let k=0;k<=n;k++){const c=await pg.locator(`#eq-mirrors .mr-corner[data-w="${k}"]`).count(); if(c!==C(n,k))errs.push(`${lang}${w} n=${n}: weight ${k} has ${c}`);}
   // click every corner: the text names its axes and its number of mirrors and its parity
   for(let S=0;S<1<<n;S++){
    await pg.locator(`#eq-mirrors .mr-corner[data-mask="${S}"]`).dispatchEvent('click');
    const head=await pg.locator('#eq-mirrors .mr-head').textContent(), l1=await pg.locator('#eq-mirrors .mr-line').nth(1).textContent(), l2=await pg.locator('#eq-mirrors .mr-line').nth(2).textContent();
    if(S&&!head.includes(names(S)))errs.push(`${lang}${w} n=${n} S=${S}: head ${head}`);
    if(!l1.includes(String(pc(S))))errs.push(`${lang}${w} n=${n} S=${S}: mirrors line ${l1}`);
    const even=pc(S)%2===0; if(even!==/Even|Pari/.test(l2))errs.push(`${lang}${w} n=${n} S=${S}: parity line ${l2}`);
    const sel=await pg.locator('#eq-mirrors .mr-corner.on').count(); if(sel!==1)errs.push(`${lang}${w} n=${n} S=${S}: ${sel} selected`);
   }
   // the demicube toggle dims the odd corners
   await pg.locator('#eq-mirrors .mr-toggle').click(); const dimmed=await pg.evaluate(()=>[...document.querySelectorAll('#eq-mirrors .mr-corner.odd')].every(e=>+e.getAttribute('opacity')<.5)&&[...document.querySelectorAll('#eq-mirrors .mr-corner.even')].every(e=>+e.getAttribute('opacity')===1)); if(!dimmed)errs.push(`${lang}${w} n=${n}: toggle`);
   await pg.locator('#eq-mirrors .mr-toggle').click();
  } else {
   const bars=await pg.locator('#eq-mirrors .mr-bar').count(); if(bars!==n+1)errs.push(`${lang}${w} n=${n}: ${bars} bars`);
   for(let k=0;k<=n;k++){const c=await pg.locator(`#eq-mirrors .mr-bar[data-w="${k}"]`).getAttribute('data-count'); if(+c!==C(n,k))errs.push(`${lang}${w} n=${n}: bar ${k} = ${c}`);}
  }
 }
 const end=await pg.locator('#eq-mirrors .mr-two-pic').getAttribute('data-end'); if(end!=='0.600000,0.800000')errs.push(`${lang}${w}: two mirrors end ${end}`);
 const rowsT=await pg.locator('#eq-mirrors .mr-two tbody tr').count(); if(rowsT!==2)errs.push('two-mirror rows '+rowsT);
 const opens=await pg.locator('#eq-mirrors .eq-pt').count(); if(opens!==2)errs.push(`${lang}${w}: open items ${opens}`);
 const dl=await pg.locator('#eq-mirrors .eq-btn').count(); if(dl!==3)errs.push(`${lang}${w}: download buttons ${dl}`);
 await pg.close();}
await b.close();
// exit status: a failure must fail run_tests.sh (before v9-fix this test printed its errors and still exited 0)
console.log(errs.length?errs:'MIRRORS UI OK'); process.exit(errs.length?1:0);
