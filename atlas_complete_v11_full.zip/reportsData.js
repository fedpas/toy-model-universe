// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The six reports of the package, listed by the Reports block of the For researchers page (ResearchersSection.jsx). English only, like the rest of that page's data.
//   id      key of the report and name of its folder under reports/ (reports/<id>/ holds its builder, check scripts, logs, test suite and README)
//   file    the report itself: one self-contained page that works offline (reports/html/<file>.html in the package; the link on the page is this path)
//   line    one plain sentence on what it holds
//   title   the h1 of the report's own page
//   script  [script, number of checks it prints] pairs: the check scripts the report quotes (hest_check.py is one wrapper that runs the independent scripts of its report). The counts are the ok lines
//           of the logs in reports/<id>/logs, the numbers of reports/html/index.json (test_researchers.mjs compares them when that file is in the package)
//   suite   the test suite of the report (in reports/<id>/)
//   on      where the atlas condenses it: tab ids or page ids (StoryShell finds the page that holds each one; an id that names nothing is not linked)
export const REPORTS = [
  { id: 'category', file: 'reports/html/category_atlas_report.html', title: 'What is label 0, seen through categories?',
    line: 'What label 0 is, seen through categories: findings, dead ends, perspectives, the checks.',
    script: [['cat_check.py', 52]], suite: 'test_report_cat.py', on: ['category'] },
  { id: 'baez', file: 'reports/html/baez_atlas_report.html', title: 'Seven Baez papers and the atlas',
    line: 'Seven Baez papers and the atlas: findings, the translation matrix, the checks.',
    script: [['baez_check.py', 56]], suite: 'test_report_baez.py', on: ['baez'] },
  { id: 'schuller', file: 'reports/html/schuller_bridge_report.html', title: 'Schuller and the atlas: a translation matrix',
    line: 'Schuller’s lectures read as fibre and base: findings, the matrix, the checks.',
    script: [['bridge_check.py', 77], ['bridge_check_qm.py', 51], ['fibre_check.py', 35]], suite: 'test_report.py', on: ['schuller'] },
  { id: 'hestenes', file: 'reports/html/hestenes_ldg_report.html', title: 'Space-time algebra and gauge-theory gravity in the bit rule',
    line: 'Hestenes’ space-time algebra and gauge-theory gravity seen through the bit rule: the Dirac and Maxwell identities, the checks.',
    script: [['hest_check.py', 95]], suite: 'test_report_hestenes.py', on: ['dirac', 'spin', 'gauge'] },
  { id: 'furey', file: 'reports/html/furey_report.html', title: 'The division algebras and the Standard Model in the bit rule',
    line: 'Furey’s six papers and the atlas: the algebra rebuilt from the octonion table, the spectra, the checks.',
    script: [['furey_papers_check.py', 30], ['furey_construction_check.py', 12]], suite: 'test_report_furey.py', on: ['furey'] },
  { id: 'pumplun', file: 'reports/html/pumplun_dictionary_report.html', title: 'The bit rule in the language of crossed products and Petit algebras',
    line: 'A dictionary between the atlas and the skew polynomial constructions of arXiv:2606.18371, recomputed over finite fields in the browser.',
    script: [['pumplun_checks.py', 9]], suite: 'test_report_pumplun.py', on: [] },
];
