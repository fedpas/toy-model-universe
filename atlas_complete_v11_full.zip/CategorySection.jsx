// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';
import { KIT_STYLE, Tags, ScriptBox, HonestyBar, ReportLink } from './LensKit.jsx';
import LensMatrix from './LensMatrix.jsx';
import { Fold, level } from './Fold.jsx';
import { FOLD } from './audienceCopy.js';
import { scrollToAnchor } from './StoryShell.jsx';
import { COPY, THM, THM_WORDS } from './categoryCopy.js';
import { RS } from './researchersCopy.js';
import { VerdictMark } from './StatusBadge.jsx';
import { CAT_CHECK_PY } from './categorySelfcheckSource.js';
import { CW1, CW2, CW3, CW4, CW5, CategoryWidgetsScript } from './CategoryWidgets.jsx';
import * as CWALL from './CategoryWidgets.jsx';
const CW6 = CWALL.CW6;   // the optional widget of DECISIONS (Sign the cube): its section is drawn only when the widgets file exports it

// Step 18 of the lenses page: "What is label 0?", the category lens (DECISIONS.md §1). The whole chapter in the decided order: the first screen in three voices,
// "zero means three things", the widgets of CategoryWidgets.jsx (label-0 card, two kinds of zero, the complement mask as a Frobenius duality, four moves,
// the top of the ladder, and Sign the cube when the widgets file has it), bottom up (Mathematician), the folded findings and papers, dead ends, refinements, perspectives, questions, the honest list, the
// honesty bar and the translation matrix and the check scripts. Every statement is an item of categoryCopy.js drawn as a
// point (class eq-pt: a column of tags, then the text), so the reader filter sees its tags; every section has its anchor cat-<name> and the in-page menu
// scrolls to it (no hash change: the address keeps #lenses/category). The Young Learner reads the plain voice and sees the five widgets; the formal content
// is in one closed fold "For older readers". The Physicist reads a short introduction and opens the long text; the Mathematician has every fold open.
const STYLE = `
.ln .cat-sec{margin-top:1.4em}.ln .cat-w{margin:10px 0}.ln .cat-fh{font-size:.85em;opacity:.85;margin:.2em 0 .5em}.ln .cat-fh code{margin-right:6px}
.ln .cat-q{border:1px solid rgba(128,128,128,.3);border-radius:10px;padding:8px 12px;margin:10px 0}.ln .cat-q .ln-cap{margin:.25em 0}
.ln .cat-persp{border-left:3px solid rgba(128,128,128,.35);padding:2px 0 2px 10px;margin:10px 0}.ln .cat-persp h4{margin:.2em 0 .3em}
.ln .cat-defs dt{font-weight:600;margin-top:.4em}.ln .cat-defs dd{margin:0 0 0 1em}
.ln .cat-ldef{font-size:.95em}
`;
const kindsOf = k => String(k || '').split(/\s+/).filter(Boolean);
// one tagged statement: tags, then the text and (formal voice) the ids of the checks that carry it
function Pt({ it, lang, plain = false, cls }) {
  return <div className={'eq-pt' + (cls ? ' ' + cls : '')}><div style={{ minWidth: 92 }}><Tags kinds={kindsOf(it.k)} lang={lang} /></div>
    <p><Tx>{it.t}</Tx>{!plain && it.c && it.c.length ? <span className="ln-chk"> {it.c.map(c => <code key={c} className="ln-id">{c}</code>)}</span> : null}</p></div>;
}
const Pts = ({ items, lang, plain, M }) => <div>{items.filter(x => M || !x.m).map((x, i) => <Pt key={i} it={x} lang={lang} plain={plain} />)}</div>;
// a text that names checks: every id (cat·R1, bridge·A6, catw·P3, a range cat·F1–F5, Thm T3) is drawn as code, the words around it as text
const ID_RE = /((?:cat|bridge|catw)·[A-Z]\d+[a-z]?(?:–[A-Z]?\d+[a-z]?)?|Thm T\d+)/;
const IdText = ({ s }) => <>{String(s).split(ID_RE).map((x, i) => (i % 2 ? <code key={i} className="ln-id">{x}</code> : x ? <Tx key={i}>{x}</Tx> : null))}</>;
const Sec = ({ id, h, children }) => <div className="cat-sec" id={id}><h3><Tx>{h}</Tx></h3>{children}</div>;
const Widget = ({ id, W, lang, profile }) => <div className="cat-w" id={id}><W lang={lang} profile={profile} /></div>;
const FindHead = ({ id, title, t }) => <p className="cat-fh"><span className="ln-k">{t.lbl.finding}</span><code className="ln-id">{id}</code><Tx>{title}</Tx></p>;
const Table = ({ cols, rows, cls }) => <div className="ln-wrap"><table className={'ln-tab' + (cls ? ' ' + cls : '')}><thead><tr>{cols.map(x => <th key={x} scope="col"><Tx>{x}</Tx></th>)}</tr></thead>
  <tbody>{rows.map((r, i) => <tr key={i}>{r.map((x, j) => <td key={j}>{typeof x === 'string' ? <IdText s={x} /> : x}</td>)}</tr>)}</tbody></table></div>;

// the statements A.1–A.9 (the Mathematician's first screen; the Physicist's full introduction; the Young Learner's fold)
const Statements = ({ t, lang, M }) => <div className="cat-stm">{t.first.stm.filter(x => M || !x.m).map(x => <div key={x.id} className="eq-pt" data-stm={x.id}><div style={{ minWidth: 92 }}><Tags kinds={kindsOf(x.k)} lang={lang} /></div>
  <p><code className="ln-id">{x.id}</code> <Tx>{x.t}</Tx> <span className="ln-chk">{x.c.map(c => <code key={c} className="ln-id">{c}</code>)}</span></p></div>)}</div>;
const Defs = ({ t, L }) => <><dl className="cat-defs">{t.defs.items.map(([a, b]) => <React.Fragment key={a}><dt><Tx>{a}</Tx></dt><dd><Tx>{b}</Tx></dd></React.Fragment>)}</dl>
  <h4><Tx>{t.defs.thmH}</Tx></h4><Table cols={t.defs.thmCols} rows={THM.map(x => [`Thm ${x.id} · ${x[L][0]}`, x[L][1], <><Tx>{THM_WORDS[L][x.st]}</Tx>; <VerdictMark v={x.v} word={RS[L].theorems.verifier[x.v]} /> <Tx>{THM_WORDS[L][x.v]}</Tx></>])} cls="cat-thm" /></>;
const MoreFindings = ({ t, lang, open }) => <div>{t.more.items.map(f => <Fold key={f.id} title={`${f.id} · ${f.title}`} open={open}>
  <div className="eq-pt ln-find" data-finding={f.id}><div style={{ minWidth: 92 }}><Tags kinds={kindsOf(f.k)} lang={lang} /></div>
    <div><p><Tx>{f.text}</Tx></p><p className="ln-chk"><span className="ln-k">{t.lbl.checks}</span> {f.c.map(c => <code key={c} className="ln-id">{c}</code>)}</p></div></div></Fold>)}</div>;
const Papers = ({ t, lang }) => <div>{t.papers.items.map((p, i) => <div key={i} className="cat-paper"><h4><Tx>{p.h}</Tx></h4><Pt it={p} lang={lang} /></div>)}</div>;
const Question = ({ q, t, lang }) => <div className="cat-q" data-q={q.id}><p className="cat-fh"><code className="ln-id">{q.id}</code><span className="ln-k">{t.questions.whom}</span><Tx>{q.whom}</Tx></p>
  <Pt it={{ k: q.k, t: q.t }} lang={lang} /><p className="ln-cap"><b><Tx>{t.questions.chk}</Tx>:</b> <IdText s={q.chk} /></p><p className="ln-cap"><b><Tx>{t.questions.not}</Tx>:</b> <IdText s={q.not} /></p></div>;
const Scripts = ({ t, L, profile }) => <><ScriptBox lang={L} file="selfcheck/reports/cat_check.py" text={CAT_CHECK_PY} note={t.script.note} />
  <p className="ln-cap"><Tx>{t.script.widgets}</Tx></p><div className="cat-w" id="cat-w-script"><CategoryWidgetsScript lang={L} profile={profile} /></div><ReportLink r={t.script.report} /></>;
const Refine = ({ t, lang }) => <><Pts items={t.refine.pts} lang={lang} /><p className="ln-cap"><Tx>{t.refine.note}</Tx></p></>;
function Persp({ t, lang, M }) {
  return <>{t.persp.items.map(p => { const body = <div className="cat-persp" id={'cat-' + p.id.toLowerCase()} data-persp={p.id}><h4><code className="ln-id">{p.id}</code><Tx>{p.h}</Tx></h4>
    <Pts items={p.pts} lang={lang} /><button type="button" className="ln-btn" data-goto={p.go} onClick={() => scrollToAnchor(p.go)}><Tx>{t.persp.go}</Tx></button></div>;
    return p.fold ? <Fold key={p.id} title={`${p.id} · ${p.h}`} open={M}>{body}</Fold> : <React.Fragment key={p.id}>{body}</React.Fragment>; })}</>;
}
const Menu = ({ label, items }) => <nav className="ln-menu" aria-label={label} data-menu="category">{items.map(([id, txt]) => <button key={id} type="button" data-goto={id} onClick={() => scrollToAnchor(id)}><Tx>{txt}</Tx></button>)}</nav>;

export default function CategorySection({ lang = 'en', profile = 'Young Learner', go }) {
  const L = lang === 'it' ? 'it' : 'en', lv = level(profile), yl = lv === 0, M = lv === 2, t = COPY[L], y = COPY.yl[L], W = { lang: L, profile };
  const open = M;   // the Physicist opens the folds himself; the Mathematician reads everything open
  const head = <><style>{KIT_STYLE + STYLE}</style><p className="eyebrow"><Tx>{stepEyebrow(L, 'lens', 'category')}</Tx></p></>;
  if (yl) {
    const mi = [['cat-zero', y.menu.zero], ['cat-label0', y.menu.label0], ['cat-twozeros', y.menu.twozeros], ['cat-frobenius', y.menu.frobenius], ['cat-moves', y.menu.moves], ['cat-top', y.menu.top], ...(CW6 ? [['cat-cube', y.menu.cube]] : []), ['cat-deadends', y.menu.deadends], ['cat-honest', y.menu.honest], ['cat-bar', y.menu.bar], ['cat-older', y.menu.older]];
    return <section className="ln" id="ln-category" data-voice="yl">{head}
      <h2 className="cat-title"><Tx>{y.title}</Tx></h2>
      <div id="cat-first"><p className="lede"><Tx>{y.sentence}</Tx></p><p className="cat-ldef"><Tx>{y.define}</Tx></p></div>
      <div><Tags kinds={['checked', 'standard', 'ours', 'open']} lang={L} /></div>
      <Menu label={t.menuLbl} items={mi} />
      <Sec id="cat-zero" h={y.zero.h}><Pts items={y.zero.pts} lang={L} plain /></Sec>
      <Sec id="cat-label0" h={y.label0.h}><Widget id="cat-w-label0" W={CW1} {...W} /><Pts items={y.label0.pts} lang={L} plain /></Sec>
      <Sec id="cat-twozeros" h={y.twozeros.h}><Widget id="cat-w-twozeros" W={CW5} {...W} /><Pts items={y.twozeros.pts} lang={L} plain /></Sec>
      <Sec id="cat-frobenius" h={y.frobenius.h}><Widget id="cat-w-frobenius" W={CW2} {...W} /><Pts items={y.frobenius.pts} lang={L} plain /></Sec>
      <Sec id="cat-moves" h={y.moves.h}><Widget id="cat-w-moves" W={CW3} {...W} /><Pts items={y.moves.pts} lang={L} plain /></Sec>
      <Sec id="cat-top" h={y.top.h}><Widget id="cat-w-top" W={CW4} {...W} /><Pts items={y.top.pts} lang={L} plain /></Sec>
      {CW6 && <Sec id="cat-cube" h={y.cube.h}><Widget id="cat-w-cube" W={CW6} {...W} /><Pts items={y.cube.pts} lang={L} plain /></Sec>}
      <Sec id="cat-deadends" h={y.deadends.h}><Pts items={y.deadends.pts} lang={L} plain /></Sec>
      <Sec id="cat-honest" h={y.honest.h}><Pts items={y.honest.pts} lang={L} plain /></Sec>
      <Sec id="cat-bar" h={y.menu.bar}><p className="ln-cap"><Tx>{y.bar}</Tx></p><HonestyBar lang={L} source="category" voice="yl" /></Sec>
      <div className="cat-sec" id="cat-older"><p><Tx>{y.older}</Tx></p>
        <Fold title={(FOLD[L] || FOLD.en).older} open={false}>
          <h3><Tx>{t.first.stmH}</Tx></h3><p><Tx>{t.first.ledeM}</Tx></p><Statements t={t} lang={L} M />
          <h3><Tx>{t.more.h}</Tx></h3><MoreFindings t={t} lang={L} open={false} />
          <h3><Tx>{t.papers.h}</Tx></h3><Papers t={t} lang={L} />
          <h3><Tx>{t.refine.h}</Tx></h3><Refine t={t} lang={L} />
          <h3><Tx>{t.questions.h}</Tx></h3>{t.questions.items.filter(q => !q.m).map(q => <Question key={q.id} q={q} t={t} lang={L} />)}
          <h3><Tx>{t.script.h}</Tx></h3><Scripts t={t} L={L} profile={profile} />
        </Fold></div>
    </section>;
  }
  const mi = [['cat-zero', t.menu.zero], ['cat-defs', t.menu.defs], ['cat-label0', t.menu.label0], ['cat-twozeros', t.menu.twozeros], ['cat-frobenius', t.menu.frobenius], ['cat-moves', t.menu.moves], ['cat-top', t.menu.top], ...(CW6 ? [['cat-cube', t.menu.cube]] : []),
    ...(M ? [['cat-bottom', t.menu.bottom]] : []), ['cat-more', t.menu.more], ['cat-papers', t.menu.papers], ['cat-deadends', t.menu.deadends], ['cat-refine', t.menu.refine], ['cat-persp', t.menu.persp], ['cat-questions', t.menu.questions],
    ['cat-honest', t.menu.honest], ['cat-bar', t.menu.bar], ['cat-script', t.menu.script]];
  return <section className="ln" id="ln-category" data-voice={M ? 'm' : 'p'}>{head}
    <h2 className="cat-title"><Tx>{t.title}</Tx></h2>
    <div id="cat-first">
      {M ? <p className="lede"><Tx>{t.first.ledeM}</Tx></p> : <p className="lede eq-short"><Tx>{t.first.ledeP}</Tx></p>}
      <Pts items={t.first.scope} lang={L} />
      {M ? <><h3><Tx>{t.first.stmH}</Tx></h3><Statements t={t} lang={L} M /></>
        : <Fold title={(FOLD[L] || FOLD.en).full} open={false}><p><Tx>{t.first.ledeM}</Tx></p><Statements t={t} lang={L} M={false} /></Fold>}
    </div>
    <div><Tags kinds={['checked', 'standard', 'ours', 'open']} lang={L} /></div>
    <Menu label={t.menuLbl} items={mi} />
    <Sec id="cat-zero" h={t.zero.h}><p className="ln-cap"><Tx>{t.zero.intro}</Tx></p><Pts items={t.zero.pts} lang={L} /></Sec>
    <Sec id="cat-defs" h={t.defs.h}>{M ? <Defs t={t} L={L} /> : <Fold title={t.defs.h} open={false}><Defs t={t} L={L} /></Fold>}</Sec>
    <Sec id="cat-label0" h={t.label0.h}><FindHead id={t.label0.fid} title={t.label0.ftitle} t={t} /><Widget id="cat-w-label0" W={CW1} {...W} /><Pts items={t.label0.pts} lang={L} M={M} /></Sec>
    <Sec id="cat-twozeros" h={t.twozeros.h}><Widget id="cat-w-twozeros" W={CW5} {...W} /><Pts items={t.twozeros.pts} lang={L} M={M} /></Sec>
    <Sec id="cat-frobenius" h={t.frobenius.h}><FindHead id={t.frobenius.fid} title={t.frobenius.ftitle} t={t} /><Widget id="cat-w-frobenius" W={CW2} {...W} /><Pts items={t.frobenius.pts} lang={L} M={M} /><p className="ln-cap"><Tx>{t.frobenius.links}</Tx></p></Sec>
    <Sec id="cat-moves" h={t.moves.h}><FindHead id={t.moves.fid} title={t.moves.ftitle} t={t} /><Widget id="cat-w-moves" W={CW3} {...W} /><Pts items={t.moves.pts} lang={L} M={M} />
      <Fold title={t.moves.tabH} open={open}><Table cols={t.moves.tabCols} rows={t.moves.tab} cls="cat-movetab" /></Fold></Sec>
    <Sec id="cat-top" h={t.top.h}><FindHead id={t.top.fid} title={t.top.ftitle} t={t} /><Widget id="cat-w-top" W={CW4} {...W} /><Pts items={t.top.pts} lang={L} M={M} />
      <p className="ln-cap"><Tx>{t.top.gosset}</Tx> {go ? <button type="button" className="ln-btn" data-go="sh-gosset" onClick={() => go('shapes', 'sh-gosset')}><Tx>{t.top.gossetGo}</Tx></button> : null}</p></Sec>
    {CW6 && <Sec id="cat-cube" h={t.cube.h}><Widget id="cat-w-cube" W={CW6} {...W} /><Pts items={t.cube.pts} lang={L} M={M} /></Sec>}
    {M && <Sec id="cat-bottom" h={t.bottom.h}><Pt it={t.bottom.intro} lang={L} /><Table cols={t.bottom.cols} rows={t.bottom.rows} cls="cat-bottomtab" /><Pts items={t.bottom.pts} lang={L} M /></Sec>}
    <Sec id="cat-more" h={t.more.h}><p className="ln-cap"><Tx>{t.more.intro}</Tx></p><MoreFindings t={t} lang={L} open={open} /></Sec>
    <Sec id="cat-papers" h={t.papers.h}><Fold title={t.papers.h} open={open}><Papers t={t} lang={L} /></Fold></Sec>
    <Sec id="cat-deadends" h={t.deadends.h}><Pts items={t.deadends.pts} lang={L} M={M} /></Sec>
    <Sec id="cat-refine" h={t.refine.h}><Refine t={t} lang={L} /></Sec>
    <Sec id="cat-persp" h={t.persp.h}><Persp t={t} lang={L} M={M} /></Sec>
    <Sec id="cat-questions" h={t.questions.h}><p className="ln-cap"><Tx>{t.questions.intro}</Tx></p>{t.questions.items.filter(q => M || !q.m).map(q => <Question key={q.id} q={q} t={t} lang={L} />)}</Sec>
    <Sec id="cat-honest" h={t.honest.h}><Pts items={t.honest.pts} lang={L} M={M} /></Sec>
    <Sec id="cat-bar" h={t.bar.h}><p className="ln-cap"><Tx>{t.bar.note}</Tx></p><HonestyBar lang={L} source="category" voice="formal" />
      {M ? <LensMatrix lang={L} source="category" /> : <Fold title={t.bar.matrixH} open={false}><LensMatrix lang={L} source="category" /></Fold>}</Sec>
    <Sec id="cat-script" h={t.script.h}><Scripts t={t} L={L} profile={profile} /></Sec>
  </section>;
}
