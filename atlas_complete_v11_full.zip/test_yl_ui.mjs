// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
import fs from 'fs';
// The Young Learner pages carry no formulas and no technical vocabulary, except very easy arithmetic (small sums such as 5 XOR 3 = 6, counts such as
// "four pairs", a power of two such as 2 x 2 x 2 = 8). What a closed fold hides does not count (a young reader who opens it chose to), but nothing
// may be visible outside a fold. Every page and every tab is opened by its deep link, in English and Italian, at 1100 and 375 px, with the audience
// set to Young Learner exactly as a visitor would have it (atlas.audience). Visible = rendered: display/visibility, closed <details> and
// zero-size boxes are skipped; SVG text and the typeset runs (.mt), math blocks (<pre>) and code (<code>) are checked as well.
// A page that is emptied does not pass: each view must keep at least MIN_WORDS visible words, and every page keeps its picture (an <svg> or <canvas>).
// Exit 1 on any violation.  Run: node test_yl_ui.mjs    (ATLAS_DIST=<dist folder>, REPORT=<file.json> writes every violation, ONLY=<page,page/tab> limits the run)
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html', MIN_WORDS = 40;
const PAGES = ['rule', 'atlas', 'conventions', 'maxwell', 'shapes', 'equations', 'furey', 'lenses', 'map', 'ask'];
// formula symbols and notations that a young reader should not meet outside a fold (v9 fix round: also squares and cubes, ⁿ, ±, the fraction glyphs, ℏ
// an equation between a single letter and a letter or a number, such as e² = +1, T = 0 or n = 8, and sums with a letter such as n − 3 or 1/(n − 3) (a consonant: "+1 o −1", "a −1" are Italian words);
// easy arithmetic with digits on both sides, such as 62 + 194 = 256, 1/2 + 1/3 + 1/5 = 31/30 or 5 XOR 3 = 6, stays allowed)
const SYMBOLS = /[∇∂∫∑∏⊗⊕⊙≅≈≠≤≥∈∉∀∃⟨⟩†ℝℂℍ𝕆𝔹𝕊𝕍ℤℕ→↔⇒⇔√∞∧∨⊂⊃∪∩⊥ωψφθΩλμνρσκτΣΔΓΛΠΦΨΘαβγδεζηιξπχ]|[₀-₉⁰¹⁴-⁹]|\^|[A-Za-z0-9)\]}]_[A-Za-z0-9{(]|\bCl\(|\bM\d*\(|\bso\(|\bsu\(|\bSU\(|\bSO\(|\bU\(\d|\\[a-zA-Z]+|\bdet\b|\bTr\b|\bP[₀-₉]|\be[₀-₉]|\be\d{2,}\b|\[\s*\d+\s*,\s*[+−-]?\d+\s*\]|\bB\+F\b|\bB[−-]F\b|\[\s*[A-Za-z]{1,4}\d*\s*,\s*[A-Za-z]{1,4}\d*\s*\]\s*=|[²³ⁿ±½⅓¼¾ℏ]|\b[a-zA-Z]\s*=\s*[−+-]?[a-zA-Z0-9]|\b[b-df-hj-np-tv-zB-DF-HJ-NP-TV-Z]\s?[−±]\s?\d|\d\s?\/\s?\(/;
// technical words (v9 fix round: also axiom / assioma and quaternion / quaternioni)
const JARGON = /isomorph|idempotent|pseudoscalar|bivector|trivector|multivector|\bPeirce\b|\bWitt\b|involution|semisimple|eigen(value|vector)|Lagrangian|Hamiltonian|manifold|holonomy|cohomolog|automorphism|Casimir|Lie algebra|radical ideal|zero divisor|tensor|commutator|anticommut|orthoplex|demicube|polytope|\bincidence|Clifford algebra|matrix ring|\bPGA\b|metric signature|quadratic form|Killing|geodesic|Schwarzschild|Kerr\b|covariant|gauge|Hodge|spinor|pointor|rotor|versor|motor\b|forque|axiom|assiom|quaternion/i;
// ---- v9 fix round (lane D): four more things are checked.
//  T4-11  what a screen reader or a hover shows counts as visible: [aria-label], [title] and svg <title> are scanned with the same lists. Every picture
//         must pass (EXEMPT stays empty).
//  T4-5   "nothing was deleted; a curious reader opens the fold": every page with formal content keeps at least one closed fold "For older readers"
//         (audienceCopy.js FOLD.older) holding at least FOLD_MIN_WORDS words. FOLD_MIN_WORDS = 10 is read from the data: the smallest formal block of
//         the package is the one-line reproduction note of the findings tab (11 words in English and in Italian). Pages without formal content: NO_FORMAL.
//  T4-9   text shown only after a click: in English and Italian (1100 px) every in-page chooser of every link is clicked in turn (stage choosers, the
//         sectors, the views, Space + / Time +, chips, map branches; navigation, downloads, the chat, the contact form and the folds "For older readers"
//         are skipped; at most MAX_CLICKS per link, the choosers first) and the page is scanned again after each click.
//  T4-2   the status tags: on every step of the equations page the glance strip shows exactly the tags that the step's own statements carry (all folds
//         open), and the tally shows for each row the same tags (both read from mapData.js TREE through equationsCopy.js TT); `input` is one of the five kinds.
import { FOLD } from './audienceCopy.js';
import { TT } from './equationsCopy.js';
import { STEP_GROUPS } from './steps.js';
const FOLD_MIN_WORDS = 10, NO_FORMAL = ['rule', 'ask'], MAX_CLICKS = 90;
const EXEMPT = [];   // no picture is exempt any more (the Yang–Mills graph now has a plain label for the Young Learner, audienceCopy.js PIC_YL.ym)
const OLDER = [FOLD.en.older, FOLD.it.older];
const b = await chromium.launch(), viol = [], errs = [], clickLog = {}; let views = 0, clicks = 0;
const links = [];
{ const pg = await b.newPage({ viewport: { width: 1100, height: 900 } });
  for (const p of PAGES) { await pg.goto(APP + '#' + p); await pg.waitForTimeout(200); const ids = await pg.locator('.tabbar [data-tab]').evaluateAll(es => es.map(e => e.dataset.tab)); if (ids.length) ids.forEach(id => links.push(p + '/' + id)); else links.push(p); }
  await pg.close(); }
// ONLY=maxwell,equations/forque  limits the run to those pages / links while you work (the full run has no filter)
const ONLY = (process.env.ONLY || '').split(',').filter(Boolean);
if (ONLY.length) for (let i = links.length - 1; i >= 0; i--) if (!ONLY.some(o => links[i] === o || links[i].startsWith(o + '/'))) links.splice(i, 1);
// the scan of one rendered view (runs in the page): visible text, attributes read aloud or on hover, math blocks, and the folds "For older readers"
const SCAN = ([symSrc, jarSrc, older, exempt]) => {
  const SYM = new RegExp(symSrc, 'u'), JAR = new RegExp(jarSrc, 'i'), EX = exempt.map(r => new RegExp(r, 'u'));
  const out = { words: 0, hits: [], blocks: [], pictures: document.querySelectorAll('main svg, main canvas').length, folds: [] };
  const seen = new Set();
  const vis = el => { try { return el.checkVisibility({ checkVisibilityCSS: true }); } catch { return !!(el.getClientRects().length); } };
  const shut = el => !!el.closest('details:not([open])') && !el.closest('summary');
  const clean = t => t.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json|md|html|txt|sh)\b/g, ' ').replace(/\barXiv:[\d.]+(v\d+)?/gi, ' ').replace(/https?:\/\/\S+/g, ' ');   // file names, paper ids and addresses are not formulas
  const test = (t, el, kind) => { const tt = clean(t), m1 = SYM.exec(tt), m2 = JAR.exec(tt); if (!m1 && !m2) return; const k = kind + (m1 ? 'S' : 'J') + ':' + t; if (seen.has(k)) return; seen.add(k); out.hits.push({ kind: (m1 ? 'formula' : 'jargon') + (kind ? ' in ' + kind : ''), match: (m1 || m2)[0], text: t.slice(0, 140), where: el.closest('[class]')?.className?.baseVal ?? el.closest('[class]')?.className ?? '' }); };
  const main = document.querySelector('main');
  const w = document.createTreeWalker(main, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const t = n.nodeValue.replace(/\s+/g, ' ').trim(); if (!t) continue;
    const el = n.parentElement; if (!el || el.closest('script,style,title') || !vis(el)) continue;
    if (shut(el)) continue;
    out.words += t.split(' ').length;
    test(t, el, '');
  }
  for (const e of main.querySelectorAll('[aria-label], [title], svg title')) {
    if (shut(e)) continue;
    const isT = e.tagName.toLowerCase() === 'title', host = isT ? e.parentElement : e; if (!host || !vis(host)) continue;
    const texts = isT ? [['svg title', e.textContent]] : [['aria-label', e.getAttribute('aria-label')], ['title', e.getAttribute('title')]];
    for (const [kind, t] of texts) if (t && !EX.some(r => r.test(t))) test(t.replace(/\s+/g, ' ').trim(), host, kind);
  }
  for (const e of main.querySelectorAll('pre, code, .katex, .katex-display')) if (vis(e) && !shut(e)) out.blocks.push(e.tagName.toLowerCase() + ': ' + e.textContent.replace(/\s+/g, ' ').trim().slice(0, 100));
  for (const d of main.querySelectorAll('details.eq-fold')) { const s = d.querySelector(':scope > summary'); if (!s || !older.some(o => s.textContent.trim().startsWith(o))) continue;
    out.folds.push({ open: d.open, words: d.textContent.slice(s.textContent.length).replace(/\s+/g, ' ').trim().split(' ').filter(Boolean).length }); }
  return out;
};
const ARGS = [SYMBOLS.source, JARGON.source, OLDER, EXEMPT.map(x => x.re.source)];
const record = (link, tag, r, after = '') => {
  for (const h of r.hits) viol.push({ link, tag, ...h, ...(after ? { after } : {}) });
  for (const x of r.blocks) viol.push({ link, tag, kind: 'math block', text: x, ...(after ? { after } : {}) });
};
async function run(lang, w) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 } });
  await ctx.addInitScript(([l, a]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, [lang, 'Young Learner']);
  const pg = await ctx.newPage(), tag = `${lang} ${w}`;
  pg.on('pageerror', e => errs.push(`${tag}: ${e.message}`));
  for (const link of links) {
    await pg.goto(APP + '#' + link); await pg.waitForTimeout(180);
    const set = await pg.evaluate(() => [document.documentElement.lang, document.querySelector('.audience-group .active')?.dataset.profile]);
    if (set[0] !== lang || set[1] !== 'Young Learner') errs.push(`${tag} #${link}: settings not applied (${set})`);
    // the interactive pictures need a moment to draw; no fold is opened
    await pg.waitForTimeout(120);
    const r = await pg.evaluate(SCAN, ARGS);
    views++;
    if (r.words < MIN_WORDS) viol.push({ link, tag, kind: 'emptied', text: `only ${r.words} visible words` });
    if (!r.pictures && !/^(map|ask)/.test(link)) viol.push({ link, tag, kind: 'no picture', text: 'no svg or canvas on the page' });
    record(link, tag, r);
    // the picture of the atlas page is named in the Young Learner's words, not with the formal name of the view
    for (const a of await pg.evaluate(() => [...document.querySelectorAll('main .canvas[aria-label]')].map(e => e.getAttribute('aria-label')))) if (/Clifford|Simplex|Prime|visuali[sz]/i.test(a)) viol.push({ link, tag, kind: 'picture name', text: a });
    // the at-a-glance strip of a tab names no file for the Young Learner: the check row says in words that a script recomputes what carries a tick
    for (const g of await pg.evaluate(() => [...document.querySelectorAll('main aside.glance')].map(e => e.textContent))) if (/\.(py|mjs|js)\b|selfcheck|README|Python/i.test(g) || !/recomputes everything that carries a tick/.test(g)) viol.push({ link, tag, kind: 'glance', text: g.slice(0, 120) });
    // T4-5: the formal content is folded away, not deleted
    if (!NO_FORMAL.includes(link.split('/')[0])) {
      const closed = r.folds.filter(f => !f.open);
      if (!closed.length) viol.push({ link, tag, kind: 'fold missing', text: 'no closed fold "For older readers": the formal content of this page is gone' });
      else if (Math.max(...closed.map(f => f.words)) < FOLD_MIN_WORDS) viol.push({ link, tag, kind: 'fold emptied', text: `the folds "For older readers" hold only ${closed.map(f => f.words)} words` });
    }
    if (r.folds.some(f => f.open)) viol.push({ link, tag, kind: 'fold open', text: 'a fold "For older readers" is open on arrival' });
  }
  await ctx.close();
}
// T4-9: click through every chooser of every link and scan again after each click
const SKIP = '.story-nav, .stepnav, .story-pager, .tabbar, .audience-group, .contact-link, .eq-btn, .cg-btn, [data-contact-open], .gl-map, .sn-prev, .sn-next, .pg-prev, .pg-next, .ask-button, .match-button, .agent-selector, footer, .settings, form, a';
const FIRST = '[data-stage], [data-metric], [data-view], [data-sector], .d-chip, .sh-chips button, .eq-chips button, .gs-chips button';
async function clickPass(lang) {
  const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(([l, a]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, [lang, 'Young Learner']);
  const pg = await ctx.newPage(), tag = `${lang} 1100 clicks`;
  pg.on('pageerror', e => errs.push(`${tag}: ${e.message}`));
  for (const link of links) {
    await pg.goto(APP + '#' + link); await pg.waitForTimeout(200);
    const n = await pg.evaluate(([skip, first, older]) => { const all = [...document.querySelectorAll('main button, main [role="button"], main summary')].filter(e => !e.closest(skip) && !(e.tagName === 'SUMMARY' && (older.some(o => e.textContent.trim().startsWith(o)) || e.closest('details.eq-fold'))));
      const a = all.filter(e => e.matches(first)), z = all.filter(e => !e.matches(first)); [...a, ...z].forEach((e, i) => e.setAttribute('data-ylclick', i)); return a.length + z.length; }, [SKIP, FIRST, OLDER]);
    for (let i = 0; i < Math.min(n, MAX_CLICKS); i++) {
      const lab = await pg.evaluate(i => { const e = document.querySelector(`[data-ylclick="${i}"]`); if (!e) return null; const r = e.getBoundingClientRect(); if (!r.width || !r.height || (e.closest('details:not([open])') && e.tagName !== 'SUMMARY')) return null; if (typeof e.click === 'function') e.click(); else e.dispatchEvent(new MouseEvent('click', { bubbles: true })); return (e.textContent || e.getAttribute('aria-label') || '').trim().slice(0, 40); }, i);
      if (lab === null) continue; clicks++; (clickLog[`${lang} ${link}`] ||= []).push(lab);
      await pg.waitForTimeout(100);
      if (!(await pg.evaluate(() => location.hash)).startsWith('#' + link.split('/')[0])) { await pg.goto(APP + '#' + link); await pg.waitForTimeout(150); continue; }
      record(link, tag, await pg.evaluate(SCAN, ARGS), `click ${i} "${lab}"`);
    }
  }
  await ctx.close();
}
// T4-2: the glance of every equations step = the tags of the step's own statements = the tally row (one source: mapData.js TREE via equationsCopy.js TT)
async function tagPass() {
  const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('atlas.lang', 'en'); localStorage.setItem('atlas.audience', 'Young Learner'); } catch { /* ignore */ } });
  const pg = await ctx.newPage(), KINDS = ['checked', 'standard', 'ours', 'open', 'input'], same = (a, x) => [...new Set(a)].sort().join() === [...new Set(x)].sort().join();
  for (const id of STEP_GROUPS.eq) {
    if (ONLY.length && !links.includes('equations/' + id)) continue;
    await pg.goto(APP + '#equations/' + id); await pg.waitForTimeout(200);
    const r = await pg.evaluate(K => { const p = document.querySelector('[role=tabpanel]'); p.querySelectorAll('details').forEach(d => { d.open = true; });
      const kinds = e => [...e.classList].filter(c => K.includes(c));
      return { glance: [...p.querySelectorAll('aside.glance .tag')].flatMap(kinds), own: [...p.querySelectorAll('.tag')].filter(e => !e.closest('aside.glance')).flatMap(kinds), hasGlance: !!p.querySelector('aside.glance') }; }, KINDS);
    // the gauge-gravity tab draws its own frame (LabelsTabs.jsx): the Young Learner reads it with no status strip (test_labels_ui.mjs pins that), so its only tag is the `input` badge of its needs strip (when the strip lists an input); its other flags are on its Map node and its tally row
    if (id === 'gauge' ? !same(r.own, TT(id).filter(k => k === 'input')) : !same(r.own, TT(id))) viol.push({ link: 'equations/' + id, tag: 'tags', kind: 'tags', text: `the statements of the step carry ${[...new Set(r.own)]} but its Map node (glance, tally) says ${TT(id)}` });
    if (r.hasGlance && !same(r.glance, TT(id))) viol.push({ link: 'equations/' + id, tag: 'tags', kind: 'tags', text: `glance ${r.glance} differs from the Map node ${TT(id)}` });
  }
  if (!ONLY.length || links.includes('equations/tally')) {
    await pg.goto(APP + '#equations/tally'); await pg.waitForTimeout(200);
    const rows = await pg.evaluate(K => [...document.querySelectorAll('.yl-tally-list li[data-row]')].map(li => [li.dataset.row, [...li.querySelectorAll('.tag')].flatMap(e => [...e.classList].filter(c => K.includes(c)))]), KINDS);
    if (rows.length !== STEP_GROUPS.eq.length + 1) viol.push({ link: 'equations/tally', tag: 'tags', kind: 'tags', text: `${rows.length} tally rows` });
    for (const [id, ks] of rows) if (!same(ks, TT(id))) viol.push({ link: 'equations/tally', tag: 'tags', kind: 'tags', text: `tally row ${id}: ${ks} against the Map node ${TT(id)}` });
  }
  await ctx.close();
}
const jobs = []; for (const lang of ['en', 'it']) for (const w of [1100, 375]) jobs.push([lang, w]);
await Promise.all(jobs.map(j => run(...j)));
await Promise.all([clickPass('en'), clickPass('it')]);
await tagPass();
await b.close();
if (views !== links.length * jobs.length) errs.push(`only ${views} of ${links.length * jobs.length} views measured`);
if (clicks < links.length) errs.push(`only ${clicks} clicks made on ${links.length} links: the click-through did not run`);
if (process.env.REPORT) fs.writeFileSync(process.env.REPORT, JSON.stringify({ links, viol, errs, clicks, clickLog }, null, 1));
const byLink = {}; for (const v of viol) { const k = v.link; (byLink[k] ||= []).push(v); }
const lines = Object.entries(byLink).map(([k, a]) => `${k}: ${a.length} (${a.slice(0, 2).map(v => `${v.kind} "${v.text.slice(0, 60)}"${v.after ? ' after ' + v.after : ''}`).join('; ')})`);
console.log(viol.length ? `FAIL ${viol.length} violations on ${Object.keys(byLink).length} of ${links.length} links\n` + lines.join('\n') : `ALL YOUNG LEARNER PAGES PASS: ${links.length} deep links × EN/IT × 1100/375 px (${views} views), no formula and no jargon outside a fold, in the text, the labels and the hover titles; ${clicks} clicks through the choosers; every page with formal content keeps its fold "For older readers"; the status tags of every step, its glance and the tally agree`);
if (errs.length) console.log(errs.slice(0, 20).join('\n'));
process.exit(viol.length || errs.length ? 1 : 0);
