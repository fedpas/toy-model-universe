// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import E from './equationsData.js';
import { EQ_PY, DIRAC_PY } from './equationsSelfcheckSource.js';
import { STORY } from './storyCopy.js';
import COPY from './equationsCopy.js';
import { Intro } from './Fold.jsx';
import { Formal, isLearner } from './Formal.jsx';
import { STEP_GROUPS, stepNo } from './steps.js';
import PLAIN from './plainStepsCopy.js';
import { Tx } from './MathText.jsx';
import { Tags } from './StatusBadge.jsx';

// The wrap-up tab of the equations page ("where the tally stands"): one row per equation with its status tags, then the downloads of steps 2 and 4.
// The status cell of the table says what each tag covers on that step (r[5]: one phrase per tag, in the order of the tags r[4]). The Young Learner reads a plain list (what was checked, what is an idea, what is open), with every count taken from the rows themselves; the table
// with its formulas and the downloads sit in a closed fold "For older readers". The rows are, in order, Maxwell (Calibration 1) and the steps of steps.js.
function download(name, text, type) { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } }

export const TALLY_IDS = ['maxwell', ...STEP_GROUPS.eq];

export default function TallySection({ lang = 'en', profile = 'Young Learner' }) {
  const l = COPY[lang] ? lang : 'en', t = COPY[l], yl = isLearner(profile), P = PLAIN[l].tally, rows = t.t.rows;
  const has = k => rows.filter(r => r[4].includes(k)).length;
  return <section className="eq" id="eq-tally" aria-labelledby="eq-t-h"><p className="eyebrow"><Tx>{t.t.eyebrow}</Tx></p><h2 id="eq-t-h"><Tx>{t.t.title}</Tx></h2><Intro lang={l} profile={profile} id="tally" lede={t.t.lede} />
    {yl && <div className="yl-tally"><h3><Tx>{P.h}</Tx></h3>
      <ul className="yl-tally-list">{rows.map((r, i) => { const id = TALLY_IDS[i]; return <li key={i} data-row={id}><Tx>{P.names[id]}</Tx> <span className="eq-cap">(<Tx>{P.where(id, id === 'maxwell' ? 0 : stepNo('eq', id))}</Tx>)</span> <Tags kinds={r[4]} lang={l} /></li>; })}</ul>
      {P.sums(rows.length, has('checked'), has('standard'), has('ours'), has('open'), has('input')).map((x, i) => <p key={i} className="yl-sum"><Tx>{x}</Tx></p>)}
      <p><Tx>{P.solve}</Tx></p></div>}
    <Formal profile={profile} lang={l}>
      <div className="eq-card" style={{ overflowX: 'auto' }}><table><thead><tr>{t.t.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{rows.map((r, i) => <tr key={i}><td><Tx>{r[0]}</Tx></td><td><Tx>{r[1]}</Tx></td><td><Tx>{r[2]}</Tx></td><td><Tx>{r[3]}</Tx></td><td><ul className="eq-status">{r[5].map(([k, ph]) => <li key={k}><Tags kinds={[k]} lang={l} /> <Tx>{ph}</Tx></li>)}</ul></td></tr>)}</tbody></table></div>
      <p><Tx>{t.t.note}</Tx></p><p className="eq-cap"><Tags kinds={['open']} lang={l} /> <Tx>{t.t.next}</Tx></p>
      <h3><Tx>{t.dl.h}</Tx></h3><p><Tx>{t.dl.text}</Tx></p><div><button className="eq-btn" onClick={() => download('equations_selfcheck.py', EQ_PY, 'text/x-python')}><Tx>{t.dl.py}</Tx></button><button className="eq-btn" onClick={() => download('dirac_matrix_check.py', DIRAC_PY, 'text/x-python')}><Tx>{t.dl.py2}</Tx></button><button className="eq-btn" onClick={() => download('equations.json', JSON.stringify(E.eq, null, 1), 'application/json')}><Tx>{t.dl.json}</Tx></button></div><p className="eq-mono eq-cap"><Tx>{t.dl.cmd}</Tx></p>
    </Formal>
    {yl && <p className="eq-cap yl-next"><Tags kinds={['open']} lang={l} /> <Tx>{P.next}</Tx></p>}</section>;
}
