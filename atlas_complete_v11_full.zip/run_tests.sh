#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# Run every test of the package, one line each: PASS, FAIL or SKIP (a test that exits 77 skipped itself and says why). Exit 1 if anything FAILED.
#   sh run_tests.sh            data tests, then browser tests (build first: sh build.sh)
#   sh run_tests.sh --data     only the tests that need nothing but node (and python3 for the check scripts)
#   sh run_tests.sh --browser  only the tests that drive a browser: they need dist/ (sh build.sh) and playwright's chromium
#   ATLAS_DIST=<folder>        test another build than <package>/dist;   TEST_TIMEOUT=<seconds> per test (default 1500; a test stopped by it FAILS with "timeout after <N>s");   test_logs/<name>.log keeps each output
# The tests are found by name (test_*.mjs and layout_check.mjs), so a new test is run without being listed. The browser group is the *_ui tests, layout_check, test_i18n_audit, test_label_bench,
# test_canvas_ui and test_real_renderers_ui (those two skip themselves when what they need is not there). test_contact_mutation takes a minute: it runs with the data group.
cd "$(dirname "$0")"
WANT=all
for a in "$@"; do case "$a" in --data) WANT=data;; --browser) WANT=browser;; *) echo "run_tests.sh: unknown option $a" >&2; exit 2;; esac; done
BROWSER_RE='_ui$|^layout_check$|^test_i18n_audit$|^test_label_bench$'
mkdir -p test_logs
FAILS=0; PASSES=0; SKIPS=0
TO=${TEST_TIMEOUT:-1500}; TIMED=0; command -v timeout >/dev/null 2>&1 && TIMED=1
run_one() {
  t=$1; start=$(date +%s)
  if [ "$TIMED" = 1 ]; then timeout "$TO" node "$t.mjs" > "test_logs/$t.log" 2>&1; else node "$t.mjs" > "test_logs/$t.log" 2>&1; fi
  rc=$?; secs=$(( $(date +%s) - start )); last=$(tail -1 "test_logs/$t.log" | cut -c1-110)
  case $rc in 0) r=PASS; PASSES=$((PASSES+1));; 77) r=SKIP; SKIPS=$((SKIPS+1));; *) r=FAIL; FAILS=$((FAILS+1));; esac
  # timeout(1) exits 124 when it stopped the test (some versions report the signal instead, so a failure that took the whole allowance counts too): say so, the last line is then not the reason
  if [ "$TIMED" = 1 ] && [ "$r" = FAIL ] && { [ "$rc" = 124 ] || [ "$secs" -ge "$TO" ]; }; then last="timeout after ${TO}s (stopped; last line of its log: ${last:-none})"; fi
  echo "$r $t (${secs}s): $last"
}
names() { ls test_*.mjs layout_check.mjs 2>/dev/null | sed 's/\.mjs$//'; }
if [ "$WANT" != browser ]; then
  for t in $(names | grep -Ev "$BROWSER_RE" ); do run_one "$t"; done
fi
if [ "$WANT" != data ]; then
  if [ ! -f "${ATLAS_DIST:-dist}/app.html" ]; then echo "run_tests.sh: no build found at ${ATLAS_DIST:-dist}/app.html: run  sh build.sh  first (BUILDING.md)" >&2; FAILS=$((FAILS+1)); else
    if [ ! -d node_modules/playwright ]; then echo "run_tests.sh: playwright is not installed (npm install; BUILDING.md): the browser tests cannot run" >&2; FAILS=$((FAILS+1)); else
      for t in $(names | grep -E "$BROWSER_RE"); do run_one "$t"; done
    fi
  fi
fi
echo "run_tests.sh: $PASSES passed, $FAILS failed, $SKIPS skipped"
[ "$FAILS" = 0 ]
