// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { StatusBadge } from './StatusBadge.jsx';
import { Tx } from './MathText.jsx';
import { NEEDS, KINDS, NEEDS_COPY, needLabel } from './inputsData.js';

// The "needs and inputs" strip of a tab (TabPanel puts it between the at-a-glance strip and the tab's content):
//   NEEDS   the tabs to read first, as links (each names its page first: "Equations · 2 · Commutators");
//   INPUTS  what the tab takes from outside the bit rule, one line each, every line tagged `input` and nothing else.
// The reader filter never hides it (readerFilter.js NEVER), and its lines are the INP rows of the claims table (one row for each line of the strip).
// The Young Learner reads two plain lines: the tabs to read first, and one plain sentence about what was brought in.
// The component does not know the page order: `resolve(word)` (given by TabPanel) turns a tab id or a page word into { page, sub, label }, or null when no such tab or page exists (then the need is plain text).
export const stripKey = (page, id) => (page === 'maxwell' ? 'maxwell/' + id : id);
export const stripId = key => 'ns-' + key.replace(/\//g, '-');
export const hasStrip = (page, id) => !!NEEDS[stripKey(page, id)];
const YL = 'Young Learner';
const hrefOf = t => '#' + t.page + (t.sub ? '/' + t.sub : '');

export default function NeedsStrip({ lang = 'en', profile, page, id, strings, resolve }) {
  const key = stripKey(page, id), e = NEEDS[key];
  if (!e) return null;
  const yl = profile === YL, c = NEEDS_COPY, words = (yl ? c.yl.words : c.words), pages = (yl ? c.yl.pages : c.pages);
  const links = e.needs.map(w => {
    const t = resolve ? resolve(w) : null;
    return t ? <a key={w} className="ns-need" href={hrefOf(t)} data-need={w} onClick={() => { if (t.page !== page) setTimeout(() => { try { window.scrollTo(0, 0); } catch { /* ignore */ } }, 30); }}><Tx>{needLabel(t, w, pages)}</Tx></a>
      : <span key={w} className="ns-need ns-plain" data-need={w}><Tx>{words[w] || c.words[w] || w}</Tx></span>;
  });
  const gl = t => <span className="gl-k"><Tx>{t.toUpperCase()}</Tx></span>;
  if (yl) {
    return <aside className="needs-strip" id={stripId(key)} data-needs={key} data-yl="1" aria-label={c.yl.aria}>
      {links.length > 0 && <p className="ns-row">{gl(c.yl.needs)}{links}</p>}
      {e.yl && <p className="ns-row ns-yl">{!e.none && <StatusBadge flag="input" lang={lang} strings={strings} />} <Tx>{e.yl}</Tx></p>}
    </aside>;
  }
  return <aside className="needs-strip" id={stripId(key)} data-needs={key} aria-label={c.aria}>
    <p className="ns-row">{gl(c.needs)}{links.length ? links : <span>{c.nothing}</span>}</p>
    {e.none && <p className="ns-row">{gl(c.inputs)}<span>{c.none}</span></p>}
    {e.inputs.length > 0 && <ul className="ns-list">{e.inputs.map(([kind, text], i) => <li key={i} data-kind={kind}><StatusBadge flag="input" lang={lang} strings={strings} /> <b className="ns-kind"><Tx>{KINDS[kind]}</Tx></b> <Tx>{text}</Tx></li>)}</ul>}
  </aside>;
}
