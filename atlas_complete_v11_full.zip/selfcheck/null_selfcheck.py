#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Null surfaces through the atlas: exact checks for the trial of arXiv:2504.13255v2
(Hsu, Barker, Hobson, Lasenby, "The radial metric function does not identify null surfaces").

Everything is built from the bit rule  e_a e_b = (-1)^N(a,b) * prod_{i in a&b} eta_i * e_{a xor b}
written from scratch below (no imports from the atlas package). Arithmetic is exact (Fractions) unless a
section says NUMERIC (Decimal, 60 digits). Each check prints PASS/FAIL, a tag and a one-line statement.
Tags: checked (computed here), standard (textbook, not proved here), ours (a reading), open.
Run:  python3 null_selfcheck.py                          run every check; exit code 0 only if all computed checks pass
      python3 null_selfcheck.py --write null.json        also write the data the page draws (checks, figure rows, portal numbers)
      python3 null_selfcheck.py --compare null.json      assert the portal data equals the rebuilt data
"""
import itertools, json, random, sys
from fractions import Fraction as Fr
from decimal import Decimal as D, getcontext

getcontext().prec = 60
random.seed(20261004)
RES = []
PORTAL = {}   # the numbers the page reads (kappa and exact samples of T(x) for the five horizons, the ladder counts, the Kerr ergosurface normals); the rest of the page is drawn from formulas that the tests recompute


def check(cid, tag, text, ok):
    """ok=None records a reading (a statement tagged 'ours' that nothing here computes); it is listed, never counted."""
    if ok is not None:
        ok = bool(ok)
    RES.append({"id": cid, "tag": tag, "text": text, "pass": ok})
    print(("READ " if ok is None else "PASS " if ok else "FAIL ") + cid + " [" + tag + "] " + text)
    return ok


# ---------------------------------------------------------------- bit-rule engine (from the rule)
def popc(x):
    return bin(x).count("1")


def rsign(a, b):
    """(-1)^N(a,b), N = number of pairs i in a, j in b with i > j"""
    s, a = 0, a >> 1
    while a:
        s += popc(a & b)
        a >>= 1
    return -1 if s & 1 else 1


class Cl:
    def __init__(self, eta):
        self.eta = [Fr(e) for e in eta]
        self.n = len(eta)
        self.N = 1 << self.n

    def bmul(self, a, b):
        c, m, i = rsign(a, b), a & b, 0
        c = Fr(c)
        while m:
            if m & 1:
                c *= self.eta[i]
            m >>= 1
            i += 1
        return c, a ^ b

    def mul(self, x, y):
        out = {}
        for a, xa in x.items():
            for b, yb in y.items():
                c, l = self.bmul(a, b)
                if c:
                    out[l] = out.get(l, 0) + c * xa * yb
        return {k: v for k, v in out.items() if v}

    def vec(self, comps):
        return {1 << i: Fr(c) for i, c in enumerate(comps) if c}

    def blade(self, *idx):
        m = 0
        for i in idx:
            m |= 1 << i
        return {m: Fr(1)}

    def dot(self, u, v):
        return sum(Fr(a) * Fr(b) * self.eta[i] for i, (a, b) in enumerate(zip(u, v)))


def add(x, y, k=1):
    out = dict(x)
    for m, v in y.items():
        out[m] = out.get(m, 0) + k * v
    return {m: v for m, v in out.items() if v}


def scal(x, k):
    return {m: v * k for m, v in x.items() if v * k}


def grade(x, k):
    return {m: v for m, v in x.items() if popc(m) == k}


def rev(x):
    return {m: v * (-1) ** (popc(m) * (popc(m) - 1) // 2) for m, v in x.items()}


def sc(x):
    return x.get(0, Fr(0))


def comm(cl, x, y):
    return add(cl.mul(x, y), cl.mul(y, x), -1)


def rank(rows):
    rows = [list(map(Fr, r)) for r in rows]
    rk, ncol = 0, len(rows[0]) if rows else 0
    for c in range(ncol):
        piv = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if piv is None:
            continue
        rows[rk], rows[piv] = rows[piv], rows[rk]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c] / rows[rk][c]
                rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        rk += 1
    return rk


def lmat(cl, n, masks):
    """matrix of x -> n*x restricted to the span of `masks` (columns), rows over all 2^n masks"""
    cols = []
    for m in masks:
        p = cl.mul(n, {m: Fr(1)})
        cols.append([p.get(k, Fr(0)) for k in range(cl.N)])
    return cols  # list of columns; rank is the same as of the transpose


def det(M):
    M = [list(map(Fr, r)) for r in M]
    n, d = len(M), Fr(1)
    for c in range(n):
        piv = next((i for i in range(c, n) if M[i][c] != 0), None)
        if piv is None:
            return Fr(0)
        if piv != c:
            M[c], M[piv] = M[piv], M[c]
            d = -d
        d *= M[c][c]
        for i in range(c + 1, n):
            f = M[i][c] / M[c][c]
            M[i] = [a - f * b for a, b in zip(M[i], M[c])]
    return d


def matmul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]


def T(A):
    return [list(r) for r in zip(*A)]


def inv2(A):
    (a, b), (c, d) = A
    dt = a * d - b * c
    return [[d / dt, -b / dt], [-c / dt, a / dt]]


# ================================================================ S0  engine self-tests
def s0():
    cl = Cl([1, -1, -1, -1])
    ok = True
    for _ in range(40):
        x = {m: Fr(random.randint(-3, 3)) for m in range(16) if random.random() < 0.4}
        y = {m: Fr(random.randint(-3, 3)) for m in range(16) if random.random() < 0.4}
        z = {m: Fr(random.randint(-3, 3)) for m in range(16) if random.random() < 0.4}
        ok &= cl.mul(cl.mul(x, y), z) == cl.mul(x, cl.mul(y, z))
    check("S0.1", "checked", "bit rule is associative on random elements of Cl(1,3) (40 triples)", ok)
    ok = True
    for eta in itertools.product([1, -1, 0], repeat=4):
        c = Cl(eta)
        I = c.blade(0, 1, 2, 3)
        sq = c.mul(I, I)
        prod = 1
        for e in eta:
            prod *= e
        pred = (-1) ** (4 * 3 // 2) * prod
        ok &= sq == ({0: Fr(pred)} if pred else {})
    check("S0.2", "checked", "I^2 = (-1)^(n(n-1)/2) * prod(eta) for all 81 signatures (+,-,0)^4 at n=4", ok)
    c = Cl([1, 1])
    check("S0.3", "checked", "Cl(2,0): (e01)^2 = -1", c.mul(c.blade(0, 1), c.blade(0, 1)) == {0: Fr(-1)})
    c = Cl([0])
    check("S0.4", "checked", "Cl(0,0,1): e0 e0 = 0 (null generator)", c.mul(c.blade(0), c.blade(0)) == {})
    c = Cl([1, -1])
    check("S0.5", "checked", "Witt cell Cl(1,1): (e01)^2 = +1", c.mul(c.blade(0, 1), c.blade(0, 1)) == {0: Fr(1)})


# ================================================================ S1  n = 1: the null seed
def s1():
    c0 = Cl([0])
    zd = []
    rng = range(-2, 3)
    ok = True
    for a, b, cc, d in itertools.product(rng, repeat=4):
        x, y = {0: Fr(a), 1: Fr(b)}, {0: Fr(cc), 1: Fr(d)}
        x = {k: v for k, v in x.items() if v}
        y = {k: v for k, v in y.items() if v}
        if x and y and not c0.mul(x, y):
            ok &= (a == 0 and cc == 0)
    check("S1.1", "checked", "Cl(0,0,1): (a + b n)(c + d n) = ac + (ad+bc) n; zero divisors are exactly the multiples of n (|coeff|<=2)", ok)
    ok = True
    for eta in (1, -1):
        for a in range(-5, 6):
            if a:
                ok &= (a * a * eta != 0)
    check("S1.2", "checked", "Cl(1,0) and Cl(0,1): no nonzero null vector (a^2 * eta != 0 for a != 0)", ok)


# ================================================================ S2  null vectors need both signs
def s2():
    ok = True
    for n in range(1, 5):
        for eta in itertools.product([1, -1], repeat=n):
            exists = any(any(v) and sum(a * a * e for a, e in zip(v, eta)) == 0
                         for v in itertools.product(range(-2, 3), repeat=n))
            ok &= (exists == (1 in eta and -1 in eta))
    check("S2.1", "checked", "n<=4, all signatures (+,-)^n: a nonzero null vector exists iff both signs occur (box |a_i|<=2)", ok)
    ok = all(sum(a * a * e for a, e in zip((0,) + sp, (1, -1, -1, -1))) < 0
             for sp in itertools.product(range(-3, 4), repeat=3) if any(sp))
    check("S2.2", "checked", "Cl(1,3): a vector with zero time component (a pure '-' bit vector) is never null (|a_i|<=3). "
          "So the covector d(f(x)) of a static slicing has no null value while the spatial algebra is definite", ok)

    # S2.3 (cube lens): a null vector with exactly two nonzero entries is a diagonal of the square spanned by one '+' bit and one '-' bit, with equal weights
    eta = (1, -1, -1, -1)
    ok = True
    for i1, i2 in itertools.combinations(range(4), 2):
        for a1 in range(-3, 4):
            for a2 in range(-3, 4):
                if a1 == 0 or a2 == 0:
                    continue
                null = a1 * a1 * eta[i1] + a2 * a2 * eta[i2] == 0
                ok &= null == (eta[i1] != eta[i2] and abs(a1) == abs(a2))
    check("S2.3", "checked", "Cl(1,3): a vector with exactly two nonzero entries (|a_i| <= 3) is null exactly when its two bits have opposite signs and equal weights: "
          "a null direction is a diagonal of a square of the bit cube, e.g. e0 + e1, with (e0+e1)^2 = 1 - 1 = 0", ok)


# ================================================================ S3  n = 2: the Witt pair and the three charts
def s3():
    cl = Cl([1, -1])
    e, f = cl.blade(0), cl.blade(1)
    I = cl.blade(0, 1)
    lp, lm = add(e, f), add(e, f, -1)
    check("S3.1", "checked", "Cl(1,1): l+ = e+f and l- = e-f are null (a pairing of nulls)", cl.mul(lp, lp) == {} and cl.mul(lm, lm) == {})
    n1, n2 = scal(lp, Fr(1, 2)), scal(lm, Fr(1, 2))
    p1, p2 = cl.mul(n1, n2), cl.mul(n2, n1)
    one_minus_I = scal(add({0: Fr(1)}, I, -1), Fr(1, 2))
    one_plus_I = scal(add({0: Fr(1)}, I), Fr(1, 2))
    check("S3.2", "checked", "n1 n2 + n2 n1 = 1; n1 n2 = (1-I)/2 and n2 n1 = (1+I)/2 are orthogonal idempotents (I = ef, I^2 = +1)",
          add(p1, p2) == {0: Fr(1)} and p1 == one_minus_I and p2 == one_plus_I
          and cl.mul(p1, p1) == p1 and cl.mul(p2, p2) == p2 and cl.mul(p1, p2) == {} and cl.mul(I, I) == {0: Fr(1)})
    tau = Fr(1, 3)
    R = add({0: Fr(1)}, scal(I, tau))
    Ri = scal(add({0: Fr(1)}, scal(I, tau), -1), 1 / (1 - tau * tau))
    ok = cl.mul(R, Ri) == {0: Fr(1)}
    a = cl.mul(cl.mul(R, lp), Ri)
    b = cl.mul(cl.mul(R, lm), Ri)
    lam_p = a[1] / lp[1] if 1 in a else None
    lam_m = b[1] / lm[1] if 1 in b else None
    ok &= a == scal(lp, lam_p) and b == scal(lm, lam_m) and lam_p * lam_m == 1
    check("S3.3", "checked", f"boost R = 1 + I/3 (rapidity phi with e^phi = 2) rescales the null pair: l+ -> {lam_p} l+, l- -> {lam_m} l-; "
          "a boost is a diagonal action on the two null lines, which are its only invariant lines", ok and {lam_p, lam_m} == {Fr(2), Fr(1, 2)})

    # --- three charts of the (t, r) plane at a point, signature (+,-): g = diag(a, -a k^2) in (t, r)
    for ip, (a_, k_) in enumerate([(Fr(3, 5), Fr(2)), (Fr(1, 7), Fr(5, 3)), (Fr(9, 4), Fr(1, 2))]):
        lam = Fr(4)
        G_tr = [[a_, 0], [0, -a_ * k_ * k_]]
        # tortoise: dr_bar = k dr
        Jt = [[1, 0], [0, 1 / k_]]  # d(t, r)/d(t, rbar)
        G_tb = matmul(matmul(T(Jt), G_tr), Jt)
        # Eddington-Finkelstein: v = t - rbar, rtilde with d rtilde = a d rbar ; t = v + rbar
        Jef = [[1, 1], [0, 1]]  # d(t, rbar)/d(v, rbar) = [[1,1],[0,1]]
        Jef2 = [[1, 0], [0, 1 / a_]]  # d(v, rbar)/d(v, rtilde)
        J = matmul(Jef, Jef2)  # d(t, rbar)/d(v, rtilde)
        G_ef = matmul(matmul(T(J), G_tb), J)
        ok_ef = G_ef == [[a_, 1], [1, 0]]
        # Kruskal-like with the paper's (7), (17): V = e^{(t+rbar)/lam}, U = -e^{(rbar-t)/lam}; choose E=e^{t/lam}, F=e^{rbar/lam}
        E, F = Fr(3, 2), Fr(5, 4)
        V, U = E * F, -F / E
        dUV = [[-U / lam, U / lam], [V / lam, V / lam]]  # d(U,V)/d(t, rbar)
        Jk = inv2(dUV)  # d(t, rbar)/d(U, V)
        G_k = matmul(matmul(T(Jk), G_tb), Jk)
        c = a_ * lam * lam / (F * F)
        ok_k = G_k == [[0, c / 2], [c / 2, 0]]
        d1, d2, d3 = det(G_tb), det(G_ef), det(G_k)
        ok_d = (d1 == -a_ * a_) and (d2 == -1) and (d3 == -c * c / 4)
        # the vector d/dt in the EF Witt pair: n1 = d/drtilde (null), n2 = d/dv - (a/2) d/drtilde
        Gm = G_ef
        g = lambda u, w: sum(u[i] * Gm[i][j] * w[j] for i in range(2) for j in range(2))
        dv, dr = [1, 0], [0, 1]
        N1, N2 = dr, [1, -a_ / 2]
        ok_w = g(N1, N1) == 0 and g(N2, N2) == 0 and g(N1, N2) == 1 and g(dv, dv) == a_
        # g_tt = 2 * (n1-weight of d/dt): d/dt = n2 + (a/2) n1
        # Killing vector in the Kruskal pair: xi = (-U/lam) d_U + (V/lam) d_V, xi^2 = c xi^U xi^V = a
        xi = [-U / lam, V / lam]
        ok_xi = (c * xi[0] * xi[1] == a_)
        # invariance of the covector norm n = d(rtilde): same scalar in the three charts, and = -g_tt
        Ginv_tr = inv2(G_tr)
        n_tr = [0, a_ * k_]  # d rtilde = a d rbar = a k dr
        nn_tr = Ginv_tr[1][1] * n_tr[1] ** 2
        nn_ef = inv2(G_ef)[1][1]  # n = d rtilde in (v, rtilde): (0,1)
        Gk_inv = inv2(G_k)
        nU, nV = a_ * lam / (2 * U), a_ * lam / (2 * V)  # d rtilde = a d rbar, rbar = (lam/2) ln(-UV)
        nn_k = Gk_inv[0][0] * nU * nU + 2 * Gk_inv[0][1] * nU * nV + Gk_inv[1][1] * nV * nV
        ok_n = (nn_tr == nn_ef == nn_k == -a_)
        # the proxy: n^2 for f = r is g^rr = -1/(a k^2); it differs from -a by the square of dr~/dr = a k
        proxy = Ginv_tr[1][1]
        ok_p = (proxy == -a_ * (1 / (a_ * k_) ** 2))
        check(f"S3.4.{ip + 1}", "checked", f"point (g_tt={a_}, g_rr/g_tt={k_**2}): Gram dets -g_tt^2 / -1 / -c^2/4 in tortoise / EF / Kruskal-like charts; "
              "EF = {n1, n2} Witt pair even at g_tt=0; xi^2 = g_tt in the Kruskal pair; n^2 of d(r~) = -g_tt in all three charts; "
              "g^rr differs from it by (dr~/dr)^2 = g_tt g_rr", ok_ef and ok_k and ok_d and ok_w and ok_xi and ok_n and ok_p)
    # the three limits for the same data: Schwarzschild-like Gram -> degenerate when the generators are rescaled
    a0 = Fr(0)
    check("S3.5", "checked", "at g_tt = 0 the EF Gram [[0,1],[1,0]] is still a Witt pair (det -1): d/dt = n2 is the null generator "
          "along the surface (Killing horizon), while the tortoise Gram diag(0,0) has det 0", det([[a0, 1], [1, 0]]) == -1 and det([[a0, 0], [0, -a0]]) == 0)
    # Killing flow acts on the Kruskal null pair as the boost exp(kappa t I): V -> e^{t/lam} V, U -> e^{-t/lam} U
    check("S3.6", "ours", "static = invariant under the hyperbolic rotation generated by the pseudoscalar I of the (t, r) cell; "
          "the null pair (U, V) are its eigen-coordinates (S3.2, S3.3, S3.4 compute the pieces); t is the rapidity. A reading: nothing here computes it as one statement", None)


# ================================================================ S4  n = 3, 4: Hodge dual and the Gram determinant
def hyperplane_basis(cl, n):
    w = [cl.eta[i] * Fr(n[i]) for i in range(cl.n)]
    p = next(i for i in range(cl.n) if w[i] != 0)
    basis = []
    for j in range(cl.n):
        if j == p:
            continue
        v = [Fr(0)] * cl.n
        v[j] = Fr(1)
        v[p] = -w[j] / w[p]
        basis.append(v)
    return basis


def tangent_det_test(cl, tests):
    """S4.1 body: for each normal n, B = b1^b2^b3 of n-perp = lambda * n I, det Gram = -B^2 = -lambda^2 n^2; null n lies in its tangent plane, spans the radical"""
    I = cl.blade(0, 1, 2, 3)
    ok_all = True
    null_seen = nonnull_seen = 0
    for nv in tests:
        if not any(nv):
            continue
        nvec = cl.vec(nv)
        n2 = cl.dot(nv, nv)
        bs = hyperplane_basis(cl, nv)
        prod = cl.mul(cl.mul(cl.vec(bs[0]), cl.vec(bs[1])), cl.vec(bs[2]))
        B = grade(prod, 3)
        dual = cl.mul(nvec, I)
        # B proportional to n I
        keys = set(B) | set(dual)
        lam = None
        prop = True
        for k in keys:
            if dual.get(k, 0) == 0:
                prop &= B.get(k, 0) == 0
            else:
                r = B.get(k, Fr(0)) / dual[k]
                lam = r if lam is None else lam
                prop &= (r == lam)
        gram = [[cl.dot(u, v) for v in bs] for u in bs]
        dg = det(gram)
        B2 = sc(cl.mul(B, B))
        ok1 = prop and lam is not None and dg == -B2 and dg == -lam * lam * n2 * 1
        ok_all &= ok1
        if n2 == 0:
            null_seen += 1
            # n lies in its own tangent plane and spans the radical of the induced form
            # solve n = sum c_i b_i
            p = next(i for i in range(4) if cl.eta[i] * Fr(nv[i]) != 0)
            idx = [j for j in range(4) if j != p]
            cvec = [Fr(nv[j]) for j in idx]
            recon = [sum(cvec[k] * bs[k][i] for k in range(3)) for i in range(4)]
            ok_all &= (recon == [Fr(x) for x in nv])
            ok_all &= all(sum(gram[i][j] * cvec[j] for j in range(3)) == 0 for i in range(3))
            ok_all &= (dg == 0)
        else:
            nonnull_seen += 1
            ok_all &= (dg != 0)
    return ok_all, null_seen, nonnull_seen


def s4():
    random.seed(4)
    cl = Cl([1, -1, -1, -1])
    I = cl.blade(0, 1, 2, 3)
    ok = cl.mul(I, I) == {0: Fr(-1)}
    check("S4.0", "checked", "Cl(1,3): I^2 = -1 (type M_2(H)), I anticommutes with every vector", ok and all(
        add(cl.mul(I, cl.vec([int(i == j) for j in range(4)])), cl.mul(cl.vec([int(i == j) for j in range(4)]), I)) == {} for i in range(4)))
    tests = [(1, 1, 0, 0), (5, 3, 4, 0), (3, 1, 2, 2), (9, 4, 4, 7), (1, 0, 0, 0), (2, 1, 0, 0), (0, 1, 0, 0), (3, 1, 1, 0), (7, 2, 3, 1)]
    tests += [tuple(random.randint(-4, 4) for _ in range(4)) for _ in range(30)]
    ok_all, null_seen, nonnull_seen = tangent_det_test(cl, tests)
    check("S4.1", "checked", f"Cl(1,3), {null_seen} null and {nonnull_seen} non-null normals n: the tangent 3-blade B = b1^b2^b3 of n-perp equals "
          "lambda * n I, det(Gram of the induced metric) = -B^2 = -lambda^2 n^2, so det h_ab = 0 exactly when n is null; "
          "for null n the vector n lies in its own tangent plane and spans the radical of h_ab", ok_all)
    # factorisation Cl(1,3) = Cl(1,1) (x) Cl(0,2): bits {0,1} and {2,3} anticommute generator by generator, masks multiply as a product set
    ok = all(add(cl.mul(cl.vec([int(i == a) for a in range(4)]), cl.vec([int(j == b) for b in range(4)])),
                 cl.mul(cl.vec([int(j == b) for b in range(4)]), cl.vec([int(i == a) for a in range(4)]))) == {}
             for i in (0, 1) for j in (2, 3))
    check("S4.2", "checked", "Cl(1,3) = Cl(1,1) (graded x) Cl(0,2): generators of the (t,r) pair anticommute with those of the sphere pair; 4 x 4 = 16 blades. "
          "A spherically symmetric static metric changes only the first factor", ok)
    # S4.5: the signature convention does not matter for nullness: same tests in Cl(3,1) (mostly plus)
    cl31 = Cl([-1, 1, 1, 1])
    ok31, nn31, nm31 = tangent_det_test(cl31, tests)
    check("S4.5", "checked", f"the same test in Cl(3,1) (mostly plus; type M_4(R), against M_2(H) for Cl(1,3)): {nn31} null and {nm31} non-null normals, the same identity det Gram = -B^2 = -lambda^2 n^2, "
          "so the null surfaces are the same in both conventions; only the type of the algebra changes", ok31 and nn31 == null_seen)

    # S4.3: the tangent space n-perp, classified by the sign of n^2 (bounded search over integer vectors)
    ok_t = ok_n = ok_s = True
    cnt = {"time": 0, "null": 0, "space": 0}
    rng = range(-3, 4)
    allv = [v for v in itertools.product(rng, repeat=4) if any(v)]
    for nv in itertools.product(range(-2, 3), repeat=4):
        if not any(nv):
            continue
        n2 = cl.dot(nv, nv)
        perp = [v for v in allv if cl.dot(nv, v) == 0]
        sq = [cl.dot(v, v) for v in perp]
        if n2 > 0:
            cnt["time"] += 1
            ok_t &= all(x < 0 for x in sq)
        elif n2 == 0:
            cnt["null"] += 1
            ok_n &= all(x <= 0 for x in sq)
            for v, x in zip(perp, sq):
                par = all(v[i] * nv[j] == v[j] * nv[i] for i in range(4) for j in range(4))
                ok_n &= (x == 0) == par
        else:
            cnt["space"] += 1
            ok_s &= any(x > 0 for x in sq)
    check("S4.3", "checked", f"Cl(1,3), all integer normals |n_i|<=2 ({cnt}), tangent vectors |v_i|<=3: if n^2 > 0 every tangent vector is spacelike (v^2 < 0), a spacelike surface; "
          "if n^2 = 0 every tangent vector has v^2 <= 0 and v^2 = 0 only for v parallel to n (the generator); if n^2 < 0 a timelike tangent vector exists (a timelike surface). "
          "Bounded search; the three statements are Sylvester's law of inertia", ok_t and ok_n and ok_s)

    # S4.4: a surface invariant under the static flow contains xi in its tangent space (n(xi) = 0). Pointwise, g = diag(a, -b1, -b2, -b3) in a (t, x) frame
    ok_pos = True
    for _ in range(30):
        a_, b1, b2, b3 = [Fr(random.randint(1, 9), random.randint(1, 5)) for _ in range(4)]
        for nv in itertools.product(range(-3, 4), repeat=3):          # covector with n_t = 0: F = F(x), static
            if any(nv):
                ok_pos &= -(nv[0] ** 2 / b1 + nv[1] ** 2 / b2 + nv[2] ** 2 / b3) < 0
    # interior of a static black hole: g_tt < 0 and the radial direction timelike: g = diag(-a, +b, -b2, -b3); a null static normal exists
    a_, b_, c_ = Fr(2, 3), Fr(5, 7), Fr(5, 7)
    n_in = (0, 1, 1, 0)
    gi = [-a_, b_, -c_, -c_]
    n2_in = sum(Fr(n_in[i]) ** 2 / gi[i] for i in range(4))
    check("S4.4", "checked", "static surfaces (F = F(x), covector n with n_t = 0, so the Killing field xi is tangent): where g_tt > 0 the normal n has n^2 = -(n1^2/b1 + n2^2/b2 + n3^2/b3) < 0 for every nonzero n "
          "(30 random exact metrics, |n_i| <= 3): no static surface is null there. Where g_tt < 0 and the radial direction is timelike (the interior of a static hole), "
          f"a static null normal exists at a point (n = (0,1,1,0), n^2 = {n2_in}). So null forces g_tt <= 0 on a static surface, and the only place xi is itself the null generator is g_tt = 0", ok_pos and n2_in == 0)


# ================================================================ S5  the tangent algebra of a null surface
def s5():
    cl = Cl([0, -1, -1])  # bit 0 = null generator (l = e_t + e_r), bits 1,2 = the sphere
    top = cl.blade(0, 1, 2)
    check("S5.1", "checked", "tangent algebra of a null hypersurface in 4D: Cl(0,2,1) (one null bit, two '-' bits); its volume element squares to 0 (det h_ab = 0)",
          cl.mul(top, top) == {})
    J = [m for m in range(8) if m & 1]
    Q = [m for m in range(8) if not m & 1]
    closed = all(not cl.bmul(a, b)[0] or ((a ^ b) & 1) for a in J for b in range(8)) and \
        all(not cl.bmul(b, a)[0] or ((a ^ b) & 1) for a in J for b in range(8))
    sq0 = all(cl.bmul(a, b)[0] == 0 for a in J for b in J)
    check("S5.2", "checked", f"the blades containing the null bit ({len(J)} of 8: the star of the null vertex, a facet of the 3-cube) form a two-sided ideal J with J*J = 0 "
          "(every product shares the null bit)", closed and sq0 and len(J) == 4)
    i_, j_, k_ = cl.blade(1), cl.blade(2), cl.blade(1, 2)
    quat = (cl.mul(i_, i_) == {0: Fr(-1)} and cl.mul(j_, j_) == {0: Fr(-1)} and cl.mul(k_, k_) == {0: Fr(-1)}
            and cl.mul(cl.mul(i_, j_), k_) == {0: Fr(-1)})
    check("S5.3", "checked", "quotient Cl(0,2,1)/J = span{1, e1, e2, e1e2} = quaternions (i^2=j^2=k^2=ijk=-1): the cross-section algebra; the null direction is a square-zero extension of it", quat)
    # even subalgebra equals that of the PGA R(2,0,1) of the atlas (bit 0 = epsilon, bits 1,2 square +1) up to signs on the bivectors
    pga = Cl([0, 1, 1])
    evens = [0, 3, 5, 6]
    found = []
    for s in itertools.product([1, -1], repeat=3):
        phi = {0: 1, 3: s[0], 5: s[1], 6: s[2]}
        ok = True
        for a in evens:
            for b in evens:
                c1, l1 = cl.bmul(a, b)
                c2, l2 = pga.bmul(a, b)
                ok &= (l1 == l2) and (c1 * phi[a] * phi[b] == c2 * phi[l1])
        if ok:
            found.append(s)
    check("S5.4", "checked", f"even subalgebra of Cl(0,2,1) (negative sphere) is isomorphic to that of the PGA R(2,0,1) of the atlas (positive sphere) by bivector signs {found[:1]}: "
          "the motors of the horizon are the motors of the plane PGA of steps 14 and 16", len(found) > 0)
    # the ladder: the tangent algebra of a null hypersurface in an n-dimensional spacetime is Cl(0, n-2 minus bits, 1 null bit), dimension 2^(n-1)
    ok = True
    dims = []
    for nsp in range(2, 7):
        m = nsp - 1
        c = Cl([0] + [-1] * (nsp - 2))
        top = (1 << m) - 1
        Jn = [x for x in range(1 << m) if x & 1]
        ok &= c.bmul(top, top)[0] == 0                                                  # volume element squares to 0: det h = 0
        ok &= all(c.bmul(a, b)[0] == 0 for a in Jn for b in Jn)                         # J * J = 0
        ok &= all((not c.bmul(a, b)[0]) or ((a ^ b) & 1) for a in Jn for b in range(1 << m))   # J is a left ideal
        ok &= all((not c.bmul(b, a)[0]) or ((a ^ b) & 1) for a in Jn for b in range(1 << m))   # and a right ideal
        ok &= len(Jn) == (1 << m) // 2                                                  # half the blades: a facet of the m-cube
        dims.append((nsp, 1 << m, len(Jn)))
    PORTAL["ladder"] = [{"n": n_, "dim": d_, "J": j_} for n_, d_, j_ in dims]
    c2 = Cl([0, -1])
    ok &= c2.mul(c2.blade(1), c2.blade(1)) == {0: Fr(-1)}                               # n = 3 horizon: the quotient Cl(0,1) is C
    check("S5.7", "checked", "the ladder: in an n-dimensional spacetime (n = 2 to 6) the tangent algebra of a null hypersurface is Cl(0, n-2 minus bits, 1 null bit): its volume element squares to 0, "
          "the blades through the null bit (half of them, a facet of the cube) form a two-sided ideal J with J*J = 0, and the quotient is the definite cell Cl(0, n-2). "
          f"(n, dim, dim J) = {dims}. n = 2: the horizon is the null seed itself (null generator); n = 3: quotient C", ok)
    # contraction s -> 0 of the tube r = const:  Cl(s,-1,-1): bits 0 = t (square s), 1, 2 = sphere
    out = {}
    for s in (1, 0, -1):
        c = Cl([s, -1, -1])
        B01, B02, B12 = c.blade(0, 1), c.blade(0, 2), c.blade(1, 2)
        k = comm(c, B01, B02)
        out[s] = (k, B12)
    sgn = -2 if out[1][0] == scal(out[1][1], -2) else 2
    ok = all(out[s][0] == scal(out[s][1], sgn * s) for s in (1, 0, -1))
    # the other two brackets do not depend on s: [J, K1] = 2 K2, [J, K2] = -2 K1, so the algebra is so(1,2) / iso(2) / so(3) by the sign of the last bracket
    for s in (1, 0, -1):
        c = Cl([s, -1, -1])
        K1, K2, J = c.blade(0, 1), c.blade(0, 2), c.blade(1, 2)
        ok &= comm(c, J, K1) == scal(K2, 2) and comm(c, J, K2) == scal(K1, -2)
        sq_s = {0: Fr(s)} if s else {}
        ok &= c.mul(K1, K1) == sq_s and c.mul(K2, K2) == sq_s           # the boost bivectors square to s: hyperbolic, parabolic (null rotation), elliptic
    check("S5.5", "checked", f"tangent algebra of the tube r = const, Cl(s,-1,-1) with s = g_tt: [B_t1, B_t2] = {sgn} s B_12 for s = +1, 0, -1: so(1,2), then iso(2) at s = 0 (the null surface), then so(3). "
          "The boost bivectors K1, K2 square to s: hyperbolic units for s = +1, null rotations (square zero) at s = 0, rotations for s = -1. "
          "This is the s-family of step 11 (hyperbolic / Euclid / elliptic) over the 2-plane base", ok)
    check("S5.6", "ours", "reading: crossing a static horizon takes the tangent algebra of the tubes through the three Klein geometries of the 2-plane (hyperbolic, Euclid, elliptic) as g_tt goes +, 0, -; "
          "the Carroll structure of null hypersurfaces is the s = 0 member (a pointer from memory, source unread here)", None)


# ================================================================ S6  characteristics: null = zero divisor of the symbol
def s6():
    cl = Cl([1, -1, -1, -1])
    biv = [m for m in range(16) if popc(m) == 2]
    even = [m for m in range(16) if popc(m) % 2 == 0]
    allm = list(range(16))
    res = {}
    for name, nv in [("null (1,1,0,0)", (1, 1, 0, 0)), ("null (5,3,4,0)", (5, 3, 4, 0)), ("timelike (2,1,0,0)", (2, 1, 0, 0)), ("spacelike (0,1,0,0)", (0, 1, 0, 0))]:
        n = cl.vec(nv)
        res[name] = tuple(len(m) - rank(lmat(cl, n, m)) for m in (biv, even, allm))
    ok = all(res[k] == (2, 4, 8) for k in res if k.startswith("null")) and all(res[k] == (0, 0, 0) for k in res if not k.startswith("null"))
    check("S6.1", "checked", f"kernel of F -> nF (the principal symbol of dF = J, and of the Dirac equation, in Cl(1,3)) on bivectors / even elements / all: {res}. "
          "Nonzero exactly for null n: 2 polarizations for Maxwell", ok)
    n = cl.vec((1, 1, 0, 0))
    F = cl.mul(n, cl.vec((0, 0, 1, 0)))
    check("S6.2", "checked", "the null plane wave F = n e2 with n = e0+e1 (n.e2 = 0) has nF = 0: the wavefront of the Charges tab is a null surface", cl.mul(n, F) == {})
    # no mirror (reflection) in a null vector: n has no inverse, 1 is not in n*Cl
    cols = lmat(cl, n, allm)
    r0 = rank(cols)
    r1 = rank(cols + [[Fr(1) if k == 0 else Fr(0) for k in range(16)]])
    a = cl.vec((2, 1, 0, 0))
    inv = scal(a, 1 / cl.dot((2, 1, 0, 0), (2, 1, 0, 0)))
    check("S6.3", "checked", "step 3: a mirror x -> -a x a^-1 needs a.a != 0. For a null n, 1 is not in n*Cl (rank rises from %d to %d on adding 1): no inverse, no mirror. "
          "A non-null a has a^-1 = a/a^2" % (r0, r1), r1 == r0 + 1 and cl.mul(a, inv) == {0: Fr(1)})

    # S6.4 (steps 9-10, forms are the all-null cell): the pullback to the surface of the volume form with the normal inserted, vol(N, b1, b2, b3) = det[N, b1, b2, b3],
    # vanishes exactly when N lies in its own tangent plane, i.e. when N is null
    tests = [(1, 1, 0, 0), (5, 3, 4, 0), (9, 4, 4, 7), (3, 1, 2, 2), (2, 1, 0, 0), (0, 1, 0, 0), (3, 1, 1, 0), (7, 2, 3, 1), (1, 0, 0, 0), (4, 0, 3, 0), (2, 2, 2, 0)]
    ok = True
    nn = 0
    for nv in tests:
        bs = hyperplane_basis(cl, nv)
        d = det([[Fr(x) for x in nv], bs[0], bs[1], bs[2]])
        isnull = cl.dot(nv, nv) == 0
        nn += isnull
        ok &= (d == 0) == isnull
    check("S6.4", "checked", f"the volume form with the normal inserted, vol(N, b1, b2, b3), on the tangent frame of n-perp ({len(tests)} normals, {nn} null): zero exactly when N is null, "
          "that is when the normal lies in its own tangent plane. Forms are the all-null cell of steps 9 and 10 (null generator: the wedge sign is the null product); det h_ab = 0 is this vanishing", ok)

    # S6.5 (step 11): the null directions through a point are the points P(x) = o + x - (1/2) x^2 eps of the 2-plane (the celestial sphere); eps = e0 + e1 is the point at infinity
    eps = cl.vec((1, 1, 0, 0))
    o = cl.vec((Fr(1, 2), Fr(-1, 2), 0, 0))
    ok = cl.mul(eps, eps) == {} and cl.mul(o, o) == {} and add(cl.mul(eps, o), cl.mul(o, eps)) == {0: Fr(2)}
    pts = [(a, b) for a in range(-3, 4) for b in range(-3, 4)]

    def P(x):
        x2 = cl.dot((0, 0) + x, (0, 0) + x)                       # x^2 = -(x1^2 + x2^2) in the negative base
        return add(add(o, cl.vec((0, 0) + x)), eps, -x2 / 2)

    def dotv(u, v):                                               # the vector inner product of two vectors given as blade dicts
        return (cl.mul(u, v).get(0, Fr(0)) + cl.mul(v, u).get(0, Fr(0))) / 2
    for x in pts:
        ok &= cl.mul(P(x), P(x)) == {}
    for x in pts[::5]:
        for y in pts[::7]:
            ok &= dotv(P(x), P(y)) == Fr((x[0] - y[0]) ** 2 + (x[1] - y[1]) ** 2, 2)
    # every null vector is on the list: v = beta P(x / beta) with beta = a - b when beta != 0, and v is a multiple of eps when beta = 0
    nnull = 0
    for v in itertools.product(range(-4, 5), repeat=4):
        if not any(v) or cl.dot(v, v) != 0:
            continue
        nnull += 1
        beta = Fr(v[0] - v[1])
        if beta != 0:
            x = (Fr(v[2]) / beta, Fr(v[3]) / beta)
            ok &= cl.vec(v) == scal(P(x), beta)
        else:
            ok &= v[2] == 0 and v[3] == 0 and v[0] == v[1]
    check("S6.5", "checked", f"(all {nnull} nonzero integer null vectors with |v_i| <= 4 are beta P(x/beta) or a multiple of eps.) Cl(1,3), eps = e0 + e1 (the horizon's null generator), o = (e0 - e1)/2, {{eps, o}} = 2 (a pairing of nulls), base = the two sphere bits: P(x) = o + x - (1/2) x^2 eps is null for all 49 x in |x_i| <= 3, "
          "and P(x).P(y) = (1/2)|x - y|^2 (tested on a 7 x 7 subsample): the null directions through a point are the points of the plane, which is the celestial sphere (its point at infinity is eps). "
          "This is step 11's null pair P(x), computed in the spacetime cell", ok)


# ================================================================ S7  stationary axisymmetric, Boyer-Lindquist = Gram-Schmidt
def s7():
    random.seed(7)
    ok = True
    for _ in range(25):
        S, M, Ph, Th = [Fr(random.randint(-9, 9), random.randint(1, 5)) for _ in range(4)]
        if Ph == 0:
            continue
        omega = M / Ph
        e0 = [1, omega]  # d_t + omega d_phi in the (t, phi) block
        G = [[S, M], [M, -Ph]]
        g = lambda u, w: sum(u[i] * G[i][j] * w[j] for i in range(2) for j in range(2))
        Tt = S + M * M / Ph
        ok &= g(e0, e0) == Tt and g([0, 1], e0) == 0 and det(G) == -Ph * Tt
        h = [[S, 0, M], [0, -Th, 0], [M, 0, -Ph]]
        ok &= det(h) == Th * Ph * Tt
    check("S7.1", "checked", "paper Eqs. (21)-(24): shearing d_t -> d_t + (M/Phi) d_phi (Gram-Schmidt, determinant 1) makes the (t,phi) block diagonal, diag(T, -Phi) with T = S + M^2/Phi; "
          "det of the induced metric on r = const is Theta*Phi*T. The bit rule applies in the sheared (orthogonal) basis, where the time generator has square T", ok)
    # Kerr, mostly-minus: M=5, a=3, r_+ = 9
    Mm, a = Fr(5), Fr(3)

    def kerr(r, c2):
        s2 = 1 - c2
        Sig = r * r + a * a * c2
        Dl = r * r - 2 * Mm * r + a * a
        gtt = 1 - 2 * Mm * r / Sig
        gtp = 2 * Mm * a * r * s2 / Sig
        gpp = -((r * r + a * a) ** 2 - Dl * a * a * s2) * s2 / Sig
        S, Mf, Ph = gtt, gtp, -gpp
        Tt = S + Mf * Mf / Ph
        return S, Mf, Ph, Tt, Dl, Sig, s2
    S, Mf, Ph, Tt, Dl, Sig, s2 = kerr(Fr(9), Fr(1, 4))
    ok1 = Dl == 0 and Tt == 0 and S != 0 and S < 0
    S2, M2, P2, T2, D2, Sg2, s22 = kerr(Fr(19, 2), Fr(19, 36))
    ok2 = S2 == 0 and T2 != 0 and D2 != 0
    ok3 = True
    for r, c2 in [(Fr(11), Fr(1, 3)), (Fr(7), Fr(1, 2)), (Fr(13, 2), Fr(2, 3)), (Fr(20), Fr(1, 5))]:
        S, Mf, Ph, Tt, Dl, Sig, s2 = kerr(r, c2)
        ok3 &= Tt == Dl * Sig / ((r * r + a * a) ** 2 - Dl * a * a * s2)
    check("S7.2", "checked", "Kerr (M=5, a=3, r_+=9, exact): at r=9, cos^2=1/4: T=0 (null, Delta=0) while S=g_tt=-27/333 < 0 (inside the ergoregion); "
          "at r=19/2, cos^2=19/36: S=0 (stationary limit surface) while T != 0 (not null). T = Delta Sigma / ((r^2+a^2)^2 - Delta a^2 sin^2) at 4 more points", ok1 and ok2 and ok3)
    # S7.8: the null generator of the Kerr horizon is d_t + Omega d_phi with Omega = M/Phi = a/(r_+^2 + a^2), the same at every angle
    omegas = []
    for c2 in (Fr(1, 4), Fr(1, 3), Fr(2, 3), Fr(1, 5), Fr(9, 10)):
        S_, Mf_, Ph_, Tt_, Dl_, Sig_, s2_ = kerr(Fr(9), c2)
        omegas.append(Mf_ / Ph_)
    off = [kerr(Fr(11), c2) for c2 in (Fr(1, 4), Fr(2, 3))]
    off_om = [o[1] / o[2] for o in off]
    check("S7.8", "checked", f"Kerr r_+ = 9: Omega = M/Phi (the paper's Eq. (23)) = {omegas[0]} = a/(r_+^2 + a^2) = 3/90 at five different polar angles: the generator of the null surface rotates rigidly, "
          f"as a Killing horizon's does; off the horizon (r = 11) Omega depends on the angle ({[str(x) for x in off_om]})", all(o == Fr(3, 90) for o in omegas) and off_om[0] != off_om[1])
    # Teo: T = N^2
    ok = True
    for _ in range(10):
        N, Kk, r, c2, om = [Fr(random.randint(1, 9), random.randint(1, 4)) for _ in range(5)]
        Phi = r * r * Kk * Kk * (1 - c2)
        if Phi == 0:                      # sin^2 = 0 is the axis: skip it
            continue
        S = N * N - Phi * om * om
        Mf = Phi * om
        ok &= S + Mf * Mf / Phi == N * N
    check("S7.3", "checked", "Teo metric (30) is already in Boyer-Lindquist form: T = S + M^2/Phi = N^2, so the throat is null iff the redshift function N = 0", ok)
    # Ellis: g_tt g_rr = -1 so the proxy is exact; Eq. (18) example
    ok = all((1 - g * g) * (1 / (1 - g * g)) == 1 for g in (Fr(1, 3), Fr(1, 2), Fr(2, 3)))
    check("S7.4", "checked", "Ellis drainhole (25): g_tt g_rr = (1-g^2)/(1-g^2) = 1, so g^rr = -g_tt and the proxy agrees with g_tt = 0 (null iff g^2 = 1)", ok)
    rows = []
    for r in (Fr(1, 10), Fr(1, 100), Fr(1, 1000)):
        Tt, Rr = r, r ** 3
        k = r  # sqrt(R/T) = r
        grr = -1 / Rr
        eq1 = grr * 1 ** 2  # g^rr (d g_tt/dr)^2 with d g_tt/dr = 1
        rt_deriv_sq = Tt * Rr
        n2_rt = grr * rt_deriv_sq  # n^2 for f = r~
        rows.append((r, grr, eq1, n2_rt, n2_rt == -Tt))
    check("S7.5", "checked", "Eq. (18), ds^2 = r dt^2 - r^3 dr^2: at r = 1/10, 1/100, 1/1000 g^rr = -1/r^3 and Vollick's Eq. (1) both diverge, "
          "but n^2 for the regular defining function r~ = r^3/3 is -r -> 0 = -g_tt; the tortoise r_bar = r^2/2 is finite at r=0 so no Kruskal chart", all(x[4] for x in rows) and rows[-1][1] == -10 ** 9)
    # Eq. (1) = -g_tt (dg_tt/dr~)^2 exactly
    ok = True
    for _ in range(20):
        Tt = Fr(random.randint(1, 9), random.randint(1, 7))
        Rr = Fr(random.randint(1, 9), random.randint(1, 7))
        Tp = Fr(random.randint(1, 9), random.randint(1, 7))  # dT/dr
        lhs = (-1 / Rr) * Tp ** 2  # g^rr (d_r g_tt)^2
        dTdrt2 = Tp ** 2 / (Tt * Rr)  # (dT/dr~)^2, dr~/dr = sqrt(T R)
        ok &= lhs == -Tt * dTdrt2
    check("S7.6", "checked", "Vollick's Eq. (1) in the spherical case equals -g_tt (dg_tt/dr~)^2 identically. It vanishes at the surface iff g_tt does, provided dg_tt/dr~ stays finite "
          "(for Schwarzschild it is 2 kappa = 1/r_S). This is the paper's 'same rate and nonzero derivative' condition in one line", ok)
    # Eq. (15): prefactor
    rS = Fr(3)
    r = rS * (1 + Fr(1, 10 ** 6))
    Tt = 1 - rS / r
    Rr = 1 / Tt
    Tp = rS / r ** 2
    val = Tp ** 2 / Rr
    ratio_mine = val / Tt
    check("S7.7", "checked", f"Schwarzschild r_S = 3: (1/R)(dT/dr)^2 / T = {float(ratio_mine):.8f} -> 1/r_S^2 = {float(1/rS**2):.8f} (so (1/R)(dT/dr)^2 -> T/r_S^2). "
          "Eq. (15) as I read it prints 4 r_S T; the limit 0 is the same, the prefactor is not (printed 4 r_S = 12 against 1/r_S^2 = 1/9)", abs(ratio_mine - 1 / rS ** 2) < Fr(1, 10 ** 5))


# ================================================================ S8  embedding signature flip (paper Eq. 28-29): the type table
def s8():
    out = {}
    for name, eta in [("(3,0)", (1, 1, 1)), ("(2,1)", (1, 1, -1))]:
        c = Cl(eta)
        I = c.blade(0, 1, 2)
        sq = c.mul(I, I)
        central = all(c.mul(I, {1 << i: Fr(1)}) == c.mul({1 << i: Fr(1)}, I) for i in range(3))
        out[name] = (sq.get(0, 0), central)
    ok = out["(3,0)"] == (-1, True) and out["(2,1)"] == (1, True)
    check("S8.1", "checked", f"embedding space of the spatial slice, sgn[R-1] dz^2 + dr^2 + r^2 dphi^2: signature (3,0) for R>1 has I^2 = -1 central (type M_2(C)); "
          "(2,1) for R<1 has I^2 = +1 central (M_2(R) + M_2(R)). One generator flips sign: the cell moves along its row of the lattice [R,C]: C = 3 -> 1", ok)


# ================================================================ S9  NUMERIC: Einstein-aether formulas (26), (27)
def eae(K, R, sg, rS=D(1), want_r=True):
    """Eq. (26) for T and Eq. (27) for r, transcribed term by term. r_-(R) has a zero denominator at R = 1 (it is infinite there, as the paper says)."""
    two = D(2)
    a = (two - K).sqrt()
    A = (two.sqrt() - a) / (two.sqrt() + a)
    q = (two + K * (R - 1)).sqrt()
    B = (q - a) / (q + a)
    s = (two / (two - K)).sqrt()
    Tv = ((A ** sg) * B) ** (sg * s)
    r = None
    if want_r:
        r = rS * (2 * K * R).sqrt() / ((4 + 2 * K * (R - 1)).sqrt() + sg * 2) * ((q + a) / (q - a)) ** (D(sg) / (4 - 2 * K).sqrt())
    return Tv, r, A, s


def s9():
    ok_all = True
    notes = []
    for K in (D("0.5"), D(1), D("1.5")):
        Tm1, _, A, s = eae(K, D(1), -1, want_r=False)
        c1 = abs(Tm1 - 1) < D("1e-50")                                   # T_-(1) = 1
        Tp_inf, rp, _, _ = eae(K, D("1e40"), +1)
        Tm_inf, rm, _, _ = eae(K, D("1e40"), -1)
        c2 = abs(Tp_inf - A ** s) < D("1e-18") and abs(Tm_inf - A ** s) < D("1e-18") and A ** s > D("0.01")   # converges like R^(-1/2)   # same finite nonzero value at the throat
        c3 = abs(rp - 1) < D("1e-15") and abs(rm - 1) < D("1e-15")       # both branches -> r_S as R -> infinity
        # far side: T_+ -> 0 and r_+ -> infinity as R -> 0. Derived exponent: r_+ ~ R^(1/2 - 1/sqrt(4-2K)), negative for every 0 < K < 2
        R1, R2 = D("1e-40"), D("1e-30")
        T1, r1, _, _ = eae(K, R1, +1)
        T2, r2, _, _ = eae(K, R2, +1)
        slope = (r2.ln() - r1.ln()) / (R2.ln() - R1.ln())
        expo = D("0.5") - 1 / (4 - 2 * K).sqrt()
        c4 = T2 < D("1e-10") and abs(slope - expo) < D("1e-3") and expo < 0 and r2 > r1 * 0 + 1
        # near side: r_- -> infinity as R -> 1 (checked as 1/(R-1) growth)
        _, ra, _, _ = eae(K, D(1) + D("1e-30"), -1)
        _, rb, _, _ = eae(K, D(1) + D("1e-20"), -1)
        c5 = abs(((ra / rb) / D(10 ** 10)) - 1) < D("1e-6")
        # the throat is the minimum of the Schwarzschild-like radius: both branches stay above r_S, approaching it as 1/(2R)
        c6 = all(eae(K, D(R), sg)[1] > 1 for R in ("1.5", "10", "100", "10000") for sg in (1, -1))
        c7 = all(abs((eae(K, D("1e8"), sg)[1] - 1) * D("1e8") - D("0.5")) < D("1e-3") for sg in (1, -1))
        ok_all &= c1 and c2 and c3 and c4 and c5 and c6 and c7
        notes.append(f"K_B={K}: T_-(1)={float(Tm1):.3f}, T_(+/-)(R->inf)={float(Tp_inf):.4f}, r_+ ~ R^{float(expo):.3f} as R->0")
    check("S9.1", "checked", "NUMERIC (60 digits). Eqs. (26)-(27), K_B = 0.5, 1, 1.5: T_-(1) = 1; T_+ and T_- take the same finite nonzero value A^s as R -> infinity (throat: g^rr = -1/R -> 0 "
          "while g_tt does not vanish); r_+ and r_- -> r_S there; T_+ -> 0 and r_+ -> infinity as R -> 0 (null singularity, far side; the exponent of r_+ is 1/2 - 1/sqrt(4-2K) < 0 for every K); "
          "r_- ~ 1/(R-1) as R -> 1 (near side flat); r_+ and r_- stay above r_S and approach it as 1/(2R), from the same side (the throat is the minimum of r, so 'from either side' reads as either side of the wormhole). " + "; ".join(notes), ok_all)


# ================================================================ S10  NUMERIC: the constant 2 r_S in Eq. (7) against 1/kappa
def s10():
    # Reissner-Nordstrom r_+ = 2, r_- = 1: T = (1-2/r)(1-1/r), kappa = (r_+ - r_-)/(2 r_+^2) = 1/8, 1/(2 r_S) = 1/4
    def rbar(r):
        return r + 4 * (r - 2).ln() - (r - 1).ln()

    h = D("1e-20")
    r0 = D("3.7")
    T0 = (1 - 2 / r0) * (1 - 1 / r0)
    drb = (rbar(r0 + h) - rbar(r0 - h)) / (2 * h)
    chk = abs(drb - 1 / T0) < D("1e-12")

    def cc(r, lam):
        Tt = (1 - 2 / r) * (1 - 1 / r)
        F2 = (2 * rbar(r) / lam).exp()
        return lam * lam * Tt / F2

    rows = []
    for e in (3, 6, 9, 12):
        r = 2 + D(10) ** (-e)
        rows.append((e, cc(r, D(4)), cc(r, D(8))))
    grows = rows[-1][1] / rows[0][1] > D(10) ** 8
    conv = abs(rows[-1][2] - rows[-2][2]) / rows[-1][2] < D("1e-5") and rows[-1][2] > 0
    check("S10.1", "checked", "NUMERIC, Reissner-Nordstrom r_+=2, r_-=1 (kappa = 1/8, not 1/(2 r_+) = 1/4). Kruskal-like coefficient c = lam^2 T / F^2 of Eq. (10a) at r - r_+ = 1e-3..1e-12: "
          "with the paper's lam = 2 r_+ = 4 it diverges like 1/(r - r_+) (%s ... %s); with lam = 1/kappa = 8 it converges (%s ... %s). "
          "Eq. (7)'s constant 2 r_S is Schwarzschild's 1/kappa; the argument is unaffected if it is read as 1/kappa" %
          (f"{float(rows[0][1]):.3g}", f"{float(rows[-1][1]):.3g}", f"{float(rows[0][2]):.6g}", f"{float(rows[-1][2]):.6g}"), chk and grows and conv)


# ================================================================ S11  the same name, different elements: quaternions and complex-like units
def versor_action_det(cl, a, mask):
    """matrix of x -> (-1)^k a x a^-1 on the generators (k = grade of the blade a); returns (det, is_pure_vector_map)"""
    sq = cl.mul(a, a)
    assert set(sq) <= {0} and sq.get(0, 0) != 0
    ainv = scal(a, 1 / sq[0])
    cols = []
    for i in range(cl.n):
        x = cl.vec([int(i == j) for j in range(cl.n)])
        y = cl.mul(cl.mul(a, x), ainv)
        if popc(mask) % 2:
            y = scal(y, -1)
        if not all(popc(m) == 1 for m in y):
            return None, False
        cols.append([y.get(1 << j, Fr(0)) for j in range(cl.n)])
    return det(cols), True


def s11():
    # --- S11.1: two quaternions
    c2 = Cl([-1, -1])                                   # Cl(0,2): labels {0,1,2,3}, grades 0,1,1,2
    c3 = Cl([1, 1, 1])                                  # Cl(3,0): even labels {0,3,5,6}, grades 0,2,2,2
    LA, LB = [0, 1, 2, 3], [0, 3, 5, 6]
    closedA = all(c2.bmul(a, b)[0] != 0 and c2.bmul(a, b)[1] in LA for a in LA for b in LA)
    closedB = all(c3.bmul(a, b)[0] != 0 and c3.bmul(a, b)[1] in LB for a in LB for b in LB)
    i_, j_, k_ = c2.blade(0), c2.blade(1), c2.blade(0, 1)
    one_m = {0: Fr(-1)}
    hamA = (c2.mul(i_, i_) == one_m and c2.mul(j_, j_) == one_m and c2.mul(k_, k_) == one_m
            and c2.mul(i_, j_) == k_ and c2.mul(j_, k_) == i_ and c2.mul(k_, i_) == j_)
    unitsB = None
    for sg in itertools.product([1, -1], repeat=3):
        iB, jB, kB = scal(c3.blade(1, 2), sg[0]), scal(c3.blade(0, 2), sg[1]), scal(c3.blade(0, 1), sg[2])
        if (c3.mul(iB, iB) == one_m and c3.mul(jB, jB) == one_m and c3.mul(kB, kB) == one_m
                and c3.mul(iB, jB) == kB and c3.mul(jB, kB) == iB and c3.mul(kB, iB) == jB):
            unitsB = sg
            break
    gradesA = sorted(popc(m) for m in LA)
    gradesB = sorted(popc(m) for m in LB)
    psi = {0: 0, 3: 3, 5: 1, 6: 2}                      # label map: e12 -> e12', e13 -> e1', e23 -> e2' (multiply by the normal e3)
    iso = []
    for sg in itertools.product([1, -1], repeat=3):
        phi = {0: 1, 3: sg[0], 5: sg[1], 6: sg[2]}
        ok = True
        for a in LB:
            for b in LB:
                cc1, l1 = c3.bmul(a, b)
                cc2, l2 = c2.bmul(psi[a], psi[b])
                ok &= (l2 == psi[l1]) and (cc1 * phi[a] * phi[b] == cc2 * phi[l1])
        if ok:
            iso.append(sg)
    detsB = {m: versor_action_det(c3, c3.blade(*[i for i in range(3) if m >> i & 1]), m)[0] for m in (3, 5, 6)}
    detsA = {m: versor_action_det(c2, c2.blade(*[i for i in range(2) if m >> i & 1]), m)[0] for m in (1, 2, 3)}
    ok = (closedA and closedB and hamA and unitsB is not None and LA != LB and gradesA != gradesB and len(iso) > 0
          and all(v == 1 for v in detsB.values()) and detsA == {1: -1, 2: -1, 3: 1})
    check("S11.1", "checked", f"two quaternions. (a) Cl(0,2) = span of the labels {LA} (grades {gradesA}); units i = e1, j = e2, k = e12, ij = k. "
          f"(b) the even subalgebra of Cl(3,0) = span of the labels {LB} (grades {gradesB}, no vectors); units i, j, k = signed e23, e13, e12 with signs {unitsB}. "
          f"Both close (as sets of blades) and both are H, but they are different sets of elements. The label map e13 -> e1, e23 -> e2, e12 -> e12 (multiply by the normal e3) is a sign-isomorphism (found for sign patterns {iso[:1]}). "
          f"The same element acts differently: every element of (b) acts on R^3 by a rotation (det {sorted(set(int(v) for v in detsB.values()))}), while e1 and e2 of (a) act on the plane as mirrors (det {detsA[1]}) and only e12 as a half-turn (det {detsA[3]})", ok)

    # --- S11.2: a third kind, the ideals of Cl(0,3) = H + H
    c03 = Cl([-1, -1, -1])
    I = c03.blade(0, 1, 2)
    central = all(c03.mul(I, c03.vec([int(i == j) for j in range(3)])) == c03.mul(c03.vec([int(i == j) for j in range(3)]), I) for i in range(3))
    one = {0: Fr(1)}
    Pp, Pm = scal(add(one, I), Fr(1, 2)), scal(add(one, I, -1), Fr(1, 2))
    idem = c03.mul(Pp, Pp) == Pp and c03.mul(Pm, Pm) == Pm and c03.mul(Pp, Pm) == {} and add(Pp, Pm) == one
    allb = [c03.blade(*[i for i in range(3) if m >> i & 1]) for m in range(8)]
    dimP = rank([[x.get(m, Fr(0)) for m in range(8)] for x in [c03.mul(Pp, b) for b in allb]])
    dimM = rank([[x.get(m, Fr(0)) for m in range(8)] for x in [c03.mul(Pm, b) for b in allb]])
    up = [c03.mul(Pp, c03.blade(i)) for i in range(3)]
    um = [c03.mul(Pm, c03.blade(i)) for i in range(3)]
    sqp = all(c03.mul(u, u) == scal(Pp, -1) for u in up) and all(c03.mul(u, u) == scal(Pm, -1) for u in um)
    orient_p = c03.mul(c03.mul(up[0], up[1]), up[2])
    orient_m = c03.mul(c03.mul(um[0], um[1]), um[2])
    ok = central and I and c03.mul(I, I) == one and idem and dimP == 4 and dimM == 4 and sqp and orient_p == Pp and orient_m == scal(Pm, -1)
    mixed = sorted({popc(m) for m in up[0]})
    check("S11.2", "checked", f"a third kind: Cl(0,3) = H + H. I = e123 is central with I^2 = +1, P+- = (1 +- I)/2 are orthogonal central idempotents summing to 1, each ideal has dimension {dimP} and {dimM}; "
          f"its units P+- e_i square to -P+-, and the product of the three units is +P+ in one ideal and -P- in the other (the two orientations ijk = +-1). Its elements mix grades (P+ e1 has grades {mixed}), "
          "so this H is neither of the two above", ok)

    # --- S11.3: complex-like units {1, u}, u^2 = s, by the grade k of u (a product of k bits) and s = -1, 0, +1
    sig = {(1, -1): [-1], (1, 0): [0], (1, 1): [1],
           (2, -1): [-1, -1], (2, 0): [0, -1], (2, 1): [1, -1],
           (3, -1): [1, 1, 1], (3, 0): [0, -1, -1], (3, 1): [-1, -1, -1]}
    rows = []
    ok = True
    for (k, sv), eta in sig.items():
        c = Cl(eta)
        mask = (1 << k) - 1
        u = c.blade(*range(k))
        sq = c.mul(u, u).get(0, Fr(0))
        ok &= sq == sv and set(c.mul(u, u)) <= {0}
        cen = all(c.mul(u, c.vec([int(i == j) for j in range(k)])) == c.mul(c.vec([int(i == j) for j in range(k)]), u) for i in range(k))
        if sv != 0:
            dt, pure = versor_action_det(c, u, mask)
            ok &= pure
            rows.append((k, sv, tuple(eta), cen, int(dt)))
        else:
            rows.append((k, sv, tuple(eta), cen, None))
    # expected: k=1: a mirror (det -1), not central unless k=1 alone; k=2: det +1, not central in a bigger algebra; k=3: central, acts as the point reflection (det -1 on R^3)
    exp_det = {1: -1, 2: 1, 3: -1}
    ok &= all(r[4] is None or r[4] == exp_det[r[0]] for r in rows)
    ok &= all(r[3] for r in rows if r[0] == 3)                                  # the trivector unit is central
    ok &= all(not r[3] for r in rows if r[0] == 2)                              # the bivector unit is not
    check("S11.3", "checked", "complex-like units {1, u}, u^2 = s, with u a product of k bits (k = grade): s = -1 is C, s = 0 the dual numbers, s = +1 the split-complex numbers (hyperbolic), "
          "for k = 1 (a vector: Cl(0,1), Cl(0,0,1), Cl(1,0)), k = 2 (a bivector: the even part of Cl(0,2), of Cl(0,1,1), of Cl(1,1)), k = 3 (the pseudoscalar of Cl(3,0), Cl(0,2,1), Cl(0,3)). "
          "Signatures used and (k, s, central, det of the versor action): " + str(rows) + ". The vector unit acts as a mirror, the bivector unit as a half-turn in its plane and is not central, the trivector unit is central and acts as the point reflection", ok)



# ================================================================ Test 3: exact calculus over Fractions (forward-mode derivatives)
class Dual:
    """value and gradient over n coordinates, exact (Fractions): enough calculus for Christoffel symbols"""
    __slots__ = ("v", "g")

    def __init__(self, v, g):
        self.v = Fr(v)
        self.g = tuple(Fr(x) for x in g)

    @staticmethod
    def const(c, n):
        return Dual(c, [0] * n)

    @staticmethod
    def var(i, x, n):
        return Dual(x, [1 if j == i else 0 for j in range(n)])

    def _l(self, o):
        return o if isinstance(o, Dual) else Dual(o, [0] * len(self.g))

    def __add__(s, o):
        o = s._l(o)
        return Dual(s.v + o.v, [a + b for a, b in zip(s.g, o.g)])
    __radd__ = __add__

    def __neg__(s):
        return Dual(-s.v, [-a for a in s.g])

    def __sub__(s, o):
        return s + (-s._l(o))

    def __rsub__(s, o):
        return s._l(o) - s

    def __mul__(s, o):
        o = s._l(o)
        return Dual(s.v * o.v, [s.v * b + o.v * a for a, b in zip(s.g, o.g)])
    __rmul__ = __mul__

    def __truediv__(s, o):
        o = s._l(o)
        return Dual(s.v / o.v, [(a * o.v - s.v * b) / (o.v * o.v) for a, b in zip(s.g, o.g)])

    def __rtruediv__(s, o):
        return s._l(o) / s

    def __pow__(s, k):
        out = Dual(1, [0] * len(s.g))
        for _ in range(k):
            out = out * s
        return out


def inv(M):
    n = len(M)
    A = [[Fr(x) for x in row] + [Fr(int(i == j)) for j in range(n)] for i, row in enumerate(M)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0)
        A[c], A[p] = A[p], A[c]
        pv = A[c][c]
        A[c] = [x / pv for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c]
                A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return [row[n:] for row in A]


def chrs(metric, x0):
    """metric(x) -> n x n list of Dual (x = Dual variables at the point x0). Returns the Dual metric, g, g^-1, d_s g_ij and Gamma^l_mq."""
    n = len(x0)
    x = [Dual.var(i, x0[i], n) for i in range(n)]
    G = metric(x)
    g = [[G[i][j].v for j in range(n)] for i in range(n)]
    gi = inv(g)
    dg = [[[G[i][j].g[s] for j in range(n)] for i in range(n)] for s in range(n)]
    Gam = [[[sum(gi[l][p] * (dg[m][p][q] + dg[q][p][m] - dg[p][m][q]) for p in range(n)) / 2 for q in range(n)] for m in range(n)] for l in range(n)]
    return G, g, gi, dg, Gam


def kdata(metric, xi_up, x0):
    """Killing-vector data at x0: xi^a, xi_a, d_b xi_a, nabla_m xi_q, V = xi.xi and dV."""
    n = len(x0)
    G, g, gi, dg, Gam = chrs(metric, x0)
    x = [Dual.var(i, x0[i], n) for i in range(n)]
    X = xi_up(x)
    zero = Dual.const(0, n)
    xl = [sum((G[a][b] * X[b] for b in range(n)), zero) for a in range(n)]
    nab = [[xl[q].g[m] - sum(Gam[l][m][q] * xl[l].v for l in range(n)) for q in range(n)] for m in range(n)]
    V = sum((X[a] * xl[a] for a in range(n)), zero)
    return {"n": n, "g": g, "gi": gi, "Gam": Gam, "xu": [q.v for q in X], "xl": [q.v for q in xl],
            "dxl": [[xl[a].g[b] for b in range(n)] for a in range(n)], "nab": nab, "V": V.v, "dV": list(V.g)}


def accel(d):
    """a_m = xi^n nabla_n xi_m"""
    return [sum(d["xu"][nu] * d["nab"][nu][m] for nu in range(d["n"])) for m in range(d["n"])]


def killing_ok(d):
    n = d["n"]
    return all(d["nab"][a][b] + d["nab"][b][a] == 0 for a in range(n) for b in range(n))


def norm2(gi, cov):
    n = len(cov)
    return sum(gi[a][b] * cov[a] * cov[b] for a in range(n) for b in range(n))


def twist(d):
    """largest |(xi ^ d xi)_abc|: zero exactly when xi is hypersurface-orthogonal (Frobenius)"""
    n, xl, dx = d["n"], d["xl"], d["dxl"]
    best = Fr(0)
    for a, b, c in itertools.combinations(range(n), 3):
        t = xl[a] * (dx[c][b] - dx[b][c]) + xl[b] * (dx[a][c] - dx[c][a]) + xl[c] * (dx[b][a] - dx[a][b])
        best = max(best, abs(t))
    return best


def nabla2(d):
    n, gi, N = d["n"], d["gi"], d["nab"]
    return sum(gi[a][c] * gi[b][e] * N[a][b] * N[c][e] for a in range(n) for b in range(n) for c in range(n) for e in range(n))


def parallel(u, w):
    """u and w are proportional (all 2 x 2 minors vanish)"""
    return all(u[a] * w[b] == u[b] * w[a] for a in range(len(u)) for b in range(len(u)))


FIG = {}

# ---------------------------------------------------------------- metrics used in Test 3
def ef_metric(Tf, rf, Cf=None):
    """(v, x, theta, phi) at the equator: ds^2 = T dv^2 + 2 C dv dx - r(x)^2 dOmega^2 (C = 1 unless given). The sin^2(theta) slope is 0 at theta = pi/2."""
    def m(c):
        x = c[1]
        T, r = Tf(x), rf(x)
        C = Dual.const(1, 4) if Cf is None else Cf(x)
        z = Dual.const(0, 4)
        return [[T, C, z, z], [C, z, z, z], [z, z, -(r * r), z], [z, z, z, -(r * r)]]
    return m


XI_V = lambda c: [Dual.const(1, 4), Dual.const(0, 4), Dual.const(0, 4), Dual.const(0, 4)]

EF_CASES = [("Schwarzschild r_S=3", lambda x: 1 - 3 / x, lambda x: x, Fr(3)),
            ("Reissner-Nordstrom outer (r+=2, r-=1)", lambda x: (1 - 2 / x) * (1 - 1 / x), lambda x: x, Fr(2)),
            ("Reissner-Nordstrom inner", lambda x: (1 - 2 / x) * (1 - 1 / x), lambda x: x, Fr(1)),
            ("extremal Reissner-Nordstrom (M=1)", lambda x: (1 - 1 / x) ** 2, lambda x: x, Fr(1)),
            ("areal radius x^2, T=(x-2)(x+1)/(x+3)", lambda x: (x - 2) * (x + 1) / (x + 3), lambda x: x * x, Fr(2))]


# ================================================================ S12  Test 3a: photon geodesics
def s12():
    rng = random.Random(1203)
    # --- S12.1 the generator of the null surface is a photon that stands still
    ok_null = ok_geo = ok_rad = ok_kill = True
    kaps = []
    for name, Tf, rf, xh in EF_CASES:
        kap = Tf(Dual.var(0, xh, 1)).g[0] / 2              # kappa = (1/2) dT/dx, computed in one variable
        d = kdata(ef_metric(Tf, rf), XI_V, [Fr(0), xh, Fr(1, 2), Fr(0)])
        a = accel(d)
        ok_null &= d["V"] == 0 and killing_ok(d) and d["xl"] == [0, 1, 0, 0]
        ok_geo &= all(a[m] == -kap * d["xl"][m] for m in range(4))
        h = [[d["g"][i][j] for j in (0, 2, 3)] for i in (0, 2, 3)]       # induced metric on x = const, in (v, theta, phi)
        ok_rad &= all(sum(h[i][j] * w for j, w in enumerate([1, 0, 0])) == 0 for i in range(3)) and [d["gi"][m][1] for m in range(4)] == [1, 0, 0, 0]
        for _ in range(4):                                      # off the surface: a_m = -(1/2) d_m V, the Killing identity
            x1 = xh + Fr(rng.randint(1, 9), rng.randint(2, 7))
            d1 = kdata(ef_metric(Tf, rf), XI_V, [Fr(0), x1, Fr(1, 2), Fr(0)])
            ok_kill &= killing_ok(d1) and all(accel(d1)[m] == -d1["dV"][m] / 2 for m in range(4))
        kaps.append(f"{name}: kappa = {kap}")
        samples = {str(xh + Fr(k, 4)): str(Tf(xh + Fr(k, 4))) for k in (-2, -1, 1, 2)}      # exact T(x) near the horizon: the page draws these curves
        PORTAL.setdefault("kappa", []).append({"name": name, "kappa": str(kap), "xh": str(xh), "T": samples})
    check("S12.1", "checked", "Test 3a. On the surface x = const where T = 0 (regular chart ds^2 = T dv^2 + 2 dv dx - r^2 dOmega^2, 5 cases incl. inner and extremal horizons and an areal radius that is not x): "
          "the Killing vector xi = d_v is null, it spans the radical of the induced metric and it is the null normal's direction; its integral curves are null geodesics with xi^n nabla_n xi_m = -kappa xi_m, "
          "kappa = (1/2) dT/dx (computed independently), kappa = 0 for the extremal horizon; off the surface a_m = -(1/2) d_m(xi.xi) at 20 points. These are Vishveshwara's 'light rays that stand still'. " + "; ".join(kaps),
          ok_null and ok_geo and ok_rad and ok_kill)

    # --- S12.2 any null hypersurface: the normal is a geodesic, in a spacetime with no Killing vector (conformal metric (1+t^2) eta)
    def conf(c):
        t = c[0]
        om2 = 1 + t * t
        z = Dual.const(0, 4)
        return [[om2, z, z, z], [z, -om2, z, z], [z, z, -om2, z], [z, z, z, -om2]]
    ok_pl = ok_id = ok_non = True
    for _ in range(8):                                                   # planes f = t - x (null) and f = t - 2x (not null): n_a constant
        pt = [Fr(rng.randint(-6, 6), rng.randint(1, 4)) for _ in range(4)]
        G, g, gi, dg, Gam = chrs(conf, pt)
        for nco, null in (([1, -1, 0, 0], True), ([1, -2, 0, 0], False)):
            nup = [sum(gi[a][b] * nco[b] for b in range(4)) for a in range(4)]
            a_m = [-sum(Gam[l][nu][m] * nup[nu] * nco[l] for nu in range(4) for l in range(4)) for m in range(4)]
            half_dn2 = [sum(-dg[m][p][q] * nup[p] * nup[q] for p in range(4) for q in range(4)) / 2 for m in range(4)]
            ok_id &= a_m == half_dn2                                      # n^b nabla_b n_a = (1/2) d_a (n.n) for n = df
            if null:
                ok_pl &= norm2(gi, nco) == 0 and not any(a_m)             # null plane: affinely parametrised generators
            elif pt[0] != 0:
                ok_non &= norm2(gi, nco) != 0 and not parallel(a_m, nco)
    ok_cone = True
    kaps_c = []
    for pc in ([3, 1, 2, 2], [7, 2, 3, 6], [9, 1, 4, 8], [5, 3, 0, 4]):   # points of the light cone f = t^2 - x^2 - y^2 - z^2 = 0 of the origin
        pt = [Fr(x) for x in pc]
        G, g, gi, dg, Gam = chrs(conf, pt)
        nco = [2 * pt[0], -2 * pt[1], -2 * pt[2], -2 * pt[3]]            # n_m = d_m f
        nup = [sum(gi[a][b] * nco[b] for b in range(4)) for a in range(4)]
        hess = [2, -2, -2, -2]                                           # d_n d_m f = 2 eta_nm
        a_m = [sum(nup[nu] * ((hess[m] if nu == m else 0) - sum(Gam[l][nu][m] * nco[l] for l in range(4))) for nu in range(4)) for m in range(4)]
        x = [Dual.var(i, pt[i], 4) for i in range(4)]
        nn = ((2 * x[0]) ** 2 - (2 * x[1]) ** 2 - (2 * x[2]) ** 2 - (2 * x[3]) ** 2) / (1 + x[0] * x[0])      # n.n as a function
        kap_c = 2 / (1 + pt[0] * pt[0])
        ok_cone &= nn.v == 0 and a_m == [q / 2 for q in nn.g] and a_m == [kap_c * q for q in nco] and any(a_m)
        kaps_c.append(str(kap_c))
    check("S12.2", "checked", "Test 3a, beyond the paper's classes. Metric (1+t^2) eta: no Killing vector, not static. The null planes t - x = const have n.n = 0 and affinely parametrised generators (n^b nabla_b n_a = 0); "
          "the light cone t^2 = x^2 + y^2 + z^2 of the origin (4 exact points) has n.n = 0 and n^b nabla_b n_a = kappa n_a with kappa = 2/(1+t^2) = " + ", ".join(kaps_c) + " (a non-affine null geodesic, computed with the Hessian and the Christoffel symbols, "
          "and equal to (1/2) d_a(n.n) computed separately); for the non-null plane t - 2x = const the normal is not parallel to its acceleration. "
          "The identity n^b nabla_b n_a = (1/2) d_a(n.n), n = df, holds at every point tested (16 plane points); it is what makes the generators of any null hypersurface geodesics (standard theorem, checked here in these examples)", ok_pl and ok_id and ok_non and ok_cone)

    # --- S12.3 radial photon rates: regular chart against r chart, horizon against throat
    ok = True
    for _ in range(12):
        T = Fr(rng.randint(1, 9), rng.randint(1, 5))
        q = Fr(rng.randint(1, 9), rng.randint(1, 5))          # q = sqrt(T R), chosen rational
        R = q * q / T
        dv = Fr(rng.randint(1, 9), rng.randint(1, 5))
        dr = -T * dv / (2 * q)
        dt = dv + (q / T) * dr                                 # v = t - rbar, d rbar = sqrt(R/T) dr = (q/T) dr
        ok &= T * dt * dt - R * dr * dr == 0                   # it is a null direction of T dt^2 - R dr^2
        ok &= (dr / dv) ** 2 == T / (4 * R) and R * (dr / dv) ** 2 == T / 4
    sch = []
    for k in (3, 6, 9):
        eps = Fr(1, 10 ** k)
        r = 1 + eps
        T = 1 - 1 / r
        sch.append((T / 2, T / 4))                              # (dr/dv, (dl/dv)^2) for Schwarzschild r_S = 1: R = 1/T
    ell = []
    for k in (3, 6, 9):
        r = 1 + Fr(1, 10 ** k)
        ell.append(((r * r - 1) / (4 * r * r), Fr(1, 4)))       # Ellis: T = 1, R = r^2/(r^2-1): ((dr/dv)^2, (dl/dv)^2)
    ok_s = all(sch[i][0] > sch[i + 1][0] > 0 for i in range(2)) and sch[-1][1] < Fr(1, 10 ** 9)
    ok_e = all(e[1] == Fr(1, 4) for e in ell) and ell[-1][0] < Fr(1, 10 ** 8) and ell[0][0] > ell[-1][0]
    check("S12.3", "checked", "Test 3a. The outgoing radial photon in the Schwarzschild-like chart: dr/dv = -T/(2 sqrt(TR)), so (dr/dv)^2 = T/(4R) and its proper radial rate squared R (dr/dv)^2 = T/4 (exact, 12 random T, R). "
          f"Schwarzschild (r_S = 1, R = 1/T): at r - 1 = 1e-3, 1e-6, 1e-9 both the r-rate ({[float(s[0]) for s in sch]}) and the proper rate go to 0. "
          f"Ellis (T = 1): the r-rate squared goes to 0 ({[float(e[0]) for e in ell]}) while the proper rate squared stays exactly 1/4. In the regular chart the rate is dx/dv = -T/2, zero exactly where T is", ok and ok_s and ok_e)

    # --- S12.4 g^rr = 0 is a neck of the static slice, in both cases; T decides whether the neck is a horizon
    ok = True
    for _ in range(8):
        T = Fr(rng.randint(1, 9), rng.randint(1, 5))
        R = Fr(rng.randint(1, 9), rng.randint(1, 5))
        rr0 = Fr(rng.randint(2, 9), rng.randint(1, 3))
        zc = Dual.const(0, 4)
        met = lambda c, T=T, R=R: [[Dual.const(T, 4), zc, zc, zc], [zc, Dual.const(-R, 4), zc, zc], [zc, zc, -(c[1] * c[1]), zc], [zc, zc, zc, -(c[1] * c[1])]]
        ok &= chrs(met, [Fr(0), rr0, Fr(0), Fr(0)])[2][1][1] == -1 / R        # g^rr from the inverse metric
    # Schwarzschild r_S = 1: proper length l(r) = sqrt(r(r-1)) + ln(sqrt(r) + sqrt(r-1)); r - 1 ~ l^2/4 at the horizon (a neck: dr/dl = 0)
    def ell_s(r):
        return (r * (r - 1)).sqrt() + (r.sqrt() + (r - 1).sqrt()).ln()
    rr = [D(1) + D(10) ** -k for k in (8, 10, 12)]
    ratios = [ell_s(r) ** 2 / (r - 1) for r in rr]
    h = D(10) ** -20
    rp = D("1.7")
    dl = (ell_s(rp + h) - ell_s(rp - h)) / (2 * h)
    ok_s = all(abs(x - 4) < D("1e-3") for x in ratios) and abs(dl - 1 / (1 - 1 / rp).sqrt()) < D("1e-15")
    # Ellis: r^2 = 1 + l^2, so dr/dl = l/r = 0 at l = 0 and r'' = 1 (a minimum), with T = 1 there
    Lv = Dual.var(0, Fr(0), 1)
    ok_e = True
    for l0, r0 in ((Fr(0), Fr(1)), (Fr(3, 4), Fr(5, 4)), (Fr(4, 3), Fr(5, 3))):
        ok_e &= r0 * r0 == 1 + l0 * l0 and (l0 / r0) ** 2 == 1 - 1 / (r0 * r0)       # (dr/dl)^2 = -g^rr = 1 - 1/r^2
    ok_e &= (Lv * Lv + 1).g[0] == 0
    check("S12.4", "checked", "Test 3a. g^rr = -1/R = -(dr/dl)^2, l the proper radial length on the static slice: g^rr = 0 exactly where r is stationary along the slice, a neck, whatever T does. "
          f"Schwarzschild (R = 1/T): l(r)^2/(r-1) = {[round(float(x), 6) for x in ratios]} -> 4 as r -> r_S, so r = r_S + l^2/4: the slice has a neck at the horizon (the bifurcation sphere), with T = 0 there. "
          "Ellis: r^2 = 1 + l^2, dr/dl = l/r = 0 at l = 0, a neck with T = 1. The two necks look alike on the slice; T = 0 or not is what separates a horizon from a wormhole throat (ours, from the checked identity)", ok and ok_s and ok_e)

    # --- S12.5 stationary axisymmetric: the radical of h_ab is the paper's L = 0 photon (Eq. 23), the same on every angle of the Kerr horizon (Vishveshwara's mixed Killing vector)
    Mm, a = Fr(5), Fr(3)

    def kerr(r, w):                         # Boyer-Lindquist, mostly-minus, as in S7.2; w = cos^2(theta)
        s2 = 1 - w
        Sig = r * r + a * a * w
        Dl = r * r - 2 * Mm * r + a * a
        S = 1 - 2 * Mm * r / Sig
        Mf = 2 * Mm * a * r * s2 / Sig
        Ph = ((r * r + a * a) ** 2 - Dl * a * a * s2) * s2 / Sig
        return S, Mf, Ph, Sig, Dl

    ok_k = True
    omegas = []
    for w in (Fr(1, 4), Fr(1, 3), Fr(2, 3), Fr(1, 5), Fr(9, 10)):
        S, Mf, Ph, Sig, Dl = kerr(Fr(9), w)
        h = [[S, 0, Mf], [0, -Sig, 0], [Mf, 0, -Ph]]
        om = Mf / Ph
        ok_k &= Dl == 0 and [sum(h[i][j] * v for j, v in enumerate([1, 0, om])) for i in range(3)] == [0, 0, 0] and det(h) == 0
        ok_k &= S + 2 * Fr(1, 30) * Mf - Fr(1, 30) ** 2 * Ph == 0 and om == Fr(1, 30)          # chi = d_t + Omega_H d_phi is null on r_+
        omegas.append(om)
    S, Mf, Ph, Sig, Dl = kerr(Fr(11), Fr(1, 4))
    h = [[S, 0, Mf], [0, -Sig, 0], [Mf, 0, -Ph]]
    ok_off = det(h) != 0 and S + 2 * Fr(1, 30) * Mf - Fr(1, 30) ** 2 * Ph != 0
    ok_ph = True
    for _ in range(10):                                                                      # the L = 0 photon: d_phi = (M/Phi) d_t turns the (t, phi) block into T dt^2
        S_, M_, P_, R_ = [Fr(rng.randint(1, 9), rng.randint(1, 5)) for _ in range(4)]
        dt = Fr(rng.randint(1, 9), rng.randint(1, 5))
        dp = M_ / P_ * dt
        ok_ph &= S_ * dt * dt + 2 * M_ * dt * dp - P_ * dp * dp == (S_ + M_ * M_ / P_) * dt * dt
    check("S12.5", "checked", "Test 3a, stationary. Kerr (M=5, a=3, r_+=9) at five polar angles: the induced metric on r = const has determinant 0 and its radical is (1, 0, M/Phi) with M/Phi = 1/30 = a/(r_+^2+a^2) at every angle, "
          "which is the paper's L = 0 photon (dphi/dt = M/Phi, Eq. 23); the constant-coefficient Killing vector d_t + (1/30) d_phi is null on r_+ (Vishveshwara's 'mixed' Killing vector: he finds a rho = 2 m r_+ at alpha = 45 degrees, his B.17, i.e. the same Omega = a/(2 m r_+)) "
          "but not at r = 11; and along that photon S dt^2 + 2M dt dphi - Phi dphi^2 = T dt^2 exactly (10 random values), so its radial null condition is T dt^2 = R dr^2, the static one",
          ok_k and ok_off and ok_ph)

    # --- S12.6 Kruskal: the r = const curves are timelike and become the photon line as T -> 0
    ok = True
    for rv, tv in (("1.5", "0.3"), ("2", "-0.7"), ("3.2", "1.1"), ("1.05", "0.2")):
        r, t = D(rv), D(tv)
        rb = r + (r - 1).ln()                                  # tortoise, r_S = 1
        u, v = t - rb, t + rb
        U, V = -(-u / 2).exp(), (v / 2).exp()
        Tk, Xk = (V + U) / 2, (V - U) / 2
        ok &= abs(Xk * Xk - Tk * Tk - (r - 1) * r.exp()) < D("1e-50")                       # X^2 - T^2 = (r-1) e^r
        coef = (1 - 1 / r) * 4 / ((r - 1) * r.exp())                                         # ds^2 = (1-1/r) du dv, du dv = -4 dU dV/(U V)
        ok &= abs(coef - 4 * (-r).exp() / r) < D("1e-50")
    sl = []
    for f in (Fr(1), Fr(1, 10), Fr(1, 1000), Fr(1, 10 ** 6)):
        Tt = Fr(1)
        sl.append(f / (f + Tt * Tt))                                                         # 1 - (dX/dT)^2 on X^2 = f + T^2
    ok &= all(0 < sl[i + 1] < sl[i] for i in range(3)) and sl[-1] < Fr(1, 10 ** 5)
    check("S12.6", "checked", "Test 3a. Kruskal chart for Schwarzschild (r_S = 1): U = -exp(-u/2), V = exp(v/2), X^2 - T^2 = -UV = (r - 1) e^r, and ds^2 = (4 e^(-r)/r) dU dV is finite and nonzero at r = 1 (50 digits, 4 points). "
          "On a curve r = const (X^2 = f + T^2, f = (r-1)e^r) the tangent has 1 - (dX/dT)^2 = f/(f + T^2) > 0, so the curve is timelike, and at T = 1 this goes 0.5, 0.0909, 0.000999, 1e-6 as f falls: "
          "the surface r = const flattens onto the 45-degree photon line as T -> 0", ok)

    # --- S12.7 the surface gravity as a photon property: finite kappa means the photon never arrives; Eq. (18) has infinite kappa and it arrives
    ok = True
    for u0 in (Fr(1, 2), Fr(1, 3), Fr(3, 4)):
        uu = Dual.var(0, u0, 1)
        xx = uu * uu * uu / 3                                       # x = u^3/3, so T = (3x)^(1/3) = u
        vv = uu * uu
        ok &= vv.g[0] / xx.g[0] == 2 / u0                           # dv/dx = 2/T along the outgoing photon, T = u
    check("S12.7", "checked", "Test 3a. Along the outgoing photon dx/dv = -T/2. Eq. (18), T = (3x)^(1/3): with x = u^3/3 one has T = u and v = u^2, so dv/dx = 2/T exactly (3 values) and the photon reaches x = 0 after the finite interval v = u^2 = T^2; "
          "for a simple zero T = 2 kappa x the same rate gives dv = dx/(kappa x), a logarithm: each halving of x costs ln 2/kappa and the sum diverges (standard), so the photon only approaches. "
          "Infinite d T/dx (infinite kappa) is the singular case of the paper's Eq. (18)", ok)


# ================================================================ S13  Test 3b: is g_tt = 0 the criterion?
def perm_sign(p):
    s = 1
    p = list(p)
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i] > p[j]:
                s = -s
    return s


def omega2(d):
    """omega_r omega^r for the rotation vector omega^r = (-g)^(-1/2) eps^{rspq} xi_s xi_{p;q} (Vishveshwara's definition)"""
    n, g, N, xl = d["n"], d["g"], d["nab"], d["xl"]
    w = [Fr(0)] * n
    for perm in itertools.permutations(range(n)):
        r, s, p, q = perm
        w[r] += perm_sign(perm) * xl[s] * N[q][p]                  # xi_{p;q} = nabla_q xi_p
    return sum(g[a][b] * w[a] * w[b] for a in range(n) for b in range(n)) / (-det(g))


def s13():
    rng = random.Random(1304)
    Z4 = lambda: Dual.const(0, 4)
    XI_T = XI_V                                                      # (1, 0, 0, 0): the time-like Killing vector

    def sph(c):                                                      # static, spherical, equator
        r = c[1]
        T = (r - 2) * (r + 1) / (r + 3)
        R = (r + 5) / (r - 1)
        return [[T, Z4(), Z4(), Z4()], [Z4(), -R, Z4(), Z4()], [Z4(), Z4(), -(r * r), Z4()], [Z4(), Z4(), Z4(), -(r * r)]]

    def gen(c):                                                      # static, depends on all three space coordinates
        x, y, w = c[1], c[2], c[3]
        return [[1 + x * x * y - w + x / 3, Z4(), Z4(), Z4()], [Z4(), -(2 + y * y + x * w), Z4(), Z4()],
                [Z4(), Z4(), -(3 + x + w * w), Z4()], [Z4(), Z4(), Z4(), -(1 + x * y * w + y * y)]]
    Om = Fr(1, 2)

    def rot(c):                                                      # Minkowski in rotating cylindrical coordinates (t, rho, phi', z)
        rho = c[1]
        return [[1 - Om * Om * rho * rho, Z4(), -(Om * rho * rho), Z4()], [Z4(), Dual.const(-1, 4), Z4(), Z4()],
                [-(Om * rho * rho), Z4(), -(rho * rho), Z4()], [Z4(), Z4(), Z4(), Dual.const(-1, 4)]]

    def pts(kind):
        if kind == "sph":
            return [[Fr(0), Fr(rng.randint(30, 100), 10), Fr(0), Fr(0)] for _ in range(5)]
        if kind == "gen":
            return [[Fr(0)] + [Fr(rng.randint(1, 9), rng.randint(1, 4)) for _ in range(3)] for _ in range(5)]
        return [[Fr(0), Fr(rng.randint(1, 30), 7), Fr(0), Fr(0)] for _ in range(5)]
    data = {k: [kdata(m, XI_T, p) for p in pts(k)] for k, m in (("sph", sph), ("gen", gen), ("rot", rot))}

    def b2(d):                                                       # Vishveshwara (B.2): xi_a xi_{b;c} + xi_b xi_{c;a} + xi_c xi_{a;b} = 0
        n, xl, N = d["n"], d["xl"], d["nab"]
        return all(xl[a] * N[c][b] + xl[b] * N[a][c] + xl[c] * N[b][a] == 0 for a in range(n) for b in range(n) for c in range(n))

    def ident(d):                                                    # its contraction with xi^a: V nabla_b xi_c = (1/2)(xi_c d_b V - xi_b d_c V)
        n, xl, dV, N, V = d["n"], d["xl"], d["dV"], d["nab"], d["V"]
        return all(V * N[b][c] == (xl[c] * dV[b] - xl[b] * dV[c]) / 2 for b in range(n) for c in range(n))
    ok_st = all(killing_ok(d) and b2(d) and ident(d) and twist(d) == 0 for k in ("sph", "gen") for d in data[k])
    ok_rot = all(killing_ok(d) and twist(d) != 0 and not b2(d) for d in data["rot"]) and not all(ident(d) for d in data["rot"])
    check("S13.1", "checked", "Test 3b. Vishveshwara's Eq. (B.2), xi_[a xi_b;c] = 0 in the form xi_a xi_b;c + xi_b xi_c;a + xi_c xi_a;b = 0, holds for the time-like Killing vector of two static metrics "
          "(a spherical one and a generic one with all three space coordinates, 5 random points each; the twist xi ^ d xi is exactly 0), and its consequence V nabla_b xi_c = (1/2)(xi_c d_b V - xi_b d_c V), V = xi.xi, holds too. "
          "It fails for the Killing vector d_t of flat space in rotating coordinates (twist != 0), which is not hypersurface-orthogonal", ok_st and ok_rot)

    # --- S13.2 Vishveshwara's (B.8): the norm of the normal is proportional to xi.xi
    ok_b8 = True
    ratios = []
    for k in ("sph", "gen"):
        for d in data[k]:
            nvec = [sum(d["nab"][aa][b] * d["xu"][b] for b in range(4)) for aa in range(4)]     # n_a = xi_{b;a} xi^b
            ok_b8 &= nvec == [q / 2 for q in d["dV"]]                                          # = (1/2) d_a (xi.xi), his (B.7)
            n2 = norm2(d["gi"], nvec)
            F = nabla2(d)                                                                      # xi_{b;c} xi^{b;c}
            ok_b8 &= n2 == d["V"] * F / 2                                                       # his (B.8)
            ratios.append(F)
    n_rot_bad = any(norm2(d["gi"], [q / 2 for q in d["dV"]]) != d["V"] * nabla2(d) / 2 for d in data["rot"])
    check("S13.2", "checked", "Test 3b. Vishveshwara's (B.7) and (B.8), n_a = xi_b;a xi^b = (1/2) d_a(xi.xi) and n.n = (1/2)(xi.xi)(xi_b;c xi^b;c), hold exactly at the 10 static points "
          "(the factor F = xi_b;c xi^b;c is finite at each). They fail for the non-hypersurface-orthogonal rotating Killing vector. "
          "The step 'n.n vanishes when xi.xi does' needs F to stay finite as the surface is approached from the static side", ok_b8 and n_rot_bad)

    # --- S13.3 in a regular chart the gradient of xi.xi is parallel to xi on xi.xi = 0
    def mink(c):
        return [[Dual.const(1, 4), Z4(), Z4(), Z4()], [Z4(), Dual.const(-1, 4), Z4(), Z4()], [Z4(), Z4(), Dual.const(-1, 4), Z4()], [Z4(), Z4(), Z4(), Dual.const(-1, 4)]]
    boost = lambda c: [c[1], c[0], Dual.const(0, 4), Dual.const(0, 4)]
    ok_b = True
    for tv in (Fr(1), Fr(2), Fr(7, 3), Fr(-5, 2)):
        for sgn in (1, -1):
            d = kdata(mink, boost, [tv, sgn * tv, Fr(1), Fr(2)])
            ok_b &= d["V"] == 0 and any(d["dV"]) and parallel(d["dV"], d["xl"]) and norm2(d["gi"], d["dV"]) == 0 and twist(d) == 0
    dd = kdata(mink, boost, [Fr(2), Fr(1), Fr(0), Fr(0)])
    ok_b &= dd["V"] != 0 and not parallel(dd["dV"], dd["xl"])
    ok_e = True
    for name, Tf, rf, xh in EF_CASES:
        d = kdata(ef_metric(Tf, rf), XI_V, [Fr(0), xh, Fr(1, 2), Fr(0)])
        if name.startswith("extremal"):
            ok_e &= not any(d["dV"])                                  # grad V = 0 on the extremal horizon: no regular level set
        else:
            ok_e &= any(d["dV"]) and parallel(d["dV"], d["xl"]) and norm2(d["gi"], d["dV"]) == 0
    check("S13.3", "checked", "Test 3b. In a regular chart d(xi.xi) is parallel to xi and null on xi.xi = 0: the boost Killing vector of Minkowski space (8 points on the two horizons t = +-x, hypersurface-orthogonal, twist 0; off the horizon not parallel), "
          "and xi = d_v in the Eddington-Finkelstein-like chart of 4 non-extremal horizons. On the extremal horizon grad(xi.xi) = 0, so xi.xi = const is not a regular surface there, which is the case Vishveshwara assumes away ('the gradient does not vanish')",
          ok_b and ok_e)

    # --- S13.4 rotating flat space: g_tt = 0 is a timelike surface (the light cylinder); Vishveshwara's stationary formula
    ok_r = True
    for rho in (Fr(2),):
        d = kdata(rot, XI_T, [Fr(0), rho, Fr(0), Fr(0)])
        n2 = norm2(d["gi"], d["dV"])
        ok_r &= d["V"] == 0 and n2 == -4 * Om * Om and n2 != 0 and not parallel(d["dV"], d["xl"]) and twist(d) != 0 and d["gi"][1][1] == -1
    def kerr_w(c):                                                    # Kerr in (t, r, w = cos^2 theta, phi): every component is rational in (r, w)
        r, w = c[1], c[2]
        Mk, ak = Fr(5), Fr(3)
        s2 = 1 - w
        Sig = r * r + ak * ak * w
        Dl = r * r - 2 * Mk * r + ak * ak
        gtt = 1 - 2 * Mk * r / Sig
        gtp = 2 * Mk * ak * r * s2 / Sig
        gpp = -((r * r + ak * ak) ** 2 - Dl * ak * ak * s2) * s2 / Sig
        return [[gtt, Z4(), Z4(), gtp], [Z4(), -Sig / Dl, Z4(), Z4()], [Z4(), Z4(), -Sig / (4 * w * s2), Z4()], [gtp, Z4(), Z4(), gpp]]
    neg = lambda m: (lambda c: [[-e for e in row] for row in m(c)])
    ok_f = True
    pts_k = [[Fr(0), Fr(11), Fr(1, 3), Fr(0)], [Fr(0), Fr(7), Fr(2, 5), Fr(0)], [Fr(0), Fr(19, 2), Fr(19, 36), Fr(0)]]
    dlist = data["rot"] + data["sph"] + data["gen"] + [kdata(kerr_w, XI_T, p) for p in pts_k] + [kdata(neg(rot), XI_T, [Fr(0), rr_, Fr(0), Fr(0)]) for rr_ in (Fr(1), Fr(3, 2))]
    nonzero = 0
    for d in dlist:
        n2 = norm2(d["gi"], [q / 2 for q in d["dV"]])
        w2 = omega2(d)
        ok_f &= n2 == d["V"] * nabla2(d) / 2 + w2 / 4
        nonzero += w2 != 0
    ok_f &= nonzero >= 7
    check("S13.4", "checked", "Test 3b. Flat space in rotating coordinates, Omega = 1/2: g_tt = 1 - Omega^2 rho^2 = 0 at rho = 2, but the normal d rho has d rho . d rho = -1 (spacelike normal: the light cylinder is a timelike surface), "
          "d(g_tt) is not parallel to xi and (grad g_tt)^2 = -4 Omega^2 = -1 != 0. For a Killing vector that is not hypersurface-orthogonal the exact identity is n.n = (1/2)(xi.xi) F + (1/4) omega.omega, "
          "n_a = (1/2) d_a(xi.xi), F = xi_b;c xi^b;c, omega^r = (-g)^(-1/2) eps^{rspq} xi_s xi_p;q (checked at 20 points: rotating flat space, Kerr at 3 points, 10 static points with omega = 0, and the sign-flipped signature, which gives the same relation). "
          "Vishveshwara's printed form is (1/2)[(xi.xi) F - omega.omega]: the coefficient and sign differ from what I get; his conclusion (on xi.xi = 0 the surface is null iff omega is null there) is the same", ok_r and ok_f)

    # --- S13.5 Kerr ergosurface: g_tt = 0 is not null, the horizon is; (B.12), (B.13)
    Mm, a = Fr(5), Fr(3)
    rows = []
    ok_ke = True
    for s_ in (Fr(5), Fr(24, 5), Fr(9, 2), Fr(13, 3), Fr(17, 4), Fr(21, 5), Fr(4)):
        w = (25 - s_ * s_) / 9                                      # cos^2(theta) with 25 - 9 w = s^2, r_E = 5 + s
        rE = Mm + s_
        rv, wv = Dual.var(0, rE, 2), Dual.var(1, w, 2)
        Sig = rv * rv + a * a * wv
        Sg = 1 - 2 * Mm * rv / Sig                                  # g_tt
        Dl = rE * rE - 2 * Mm * rE + a * a
        fr_, fw = Sg.g[0], Sg.g[1]
        n2 = -(Dl * fr_ * fr_ + 4 * w * (1 - w) * fw * fw) / Sig.v   # g^rr f_r^2 + g^thth f_th^2, f_th^2 = 4 w (1-w) f_w^2
        ok_ke &= Sg.v == 0 and ((n2 < 0) if w != 1 else (n2 == 0 and Dl == 0))
        rows.append((str(w), str(rE), "pole" if w == 1 else str(n2 < 0)))
        PORTAL.setdefault("kerr", []).append({"w": str(w), "r": str(rE), "n2": str(n2)})
    # twist of d_t at an ergosurface point (r, w) = (19/2, 19/36): xi_t = S, xi_phi = M
    rv, wv = Dual.var(0, Fr(19, 2), 2), Dual.var(1, Fr(19, 36), 2)
    Sig = rv * rv + a * a * wv
    St = 1 - 2 * Mm * rv / Sig
    Mp = 2 * Mm * a * rv * (1 - wv) / Sig
    tw_r = St.v * Mp.g[0] - Mp.v * St.g[0]
    tw_w = St.v * Mp.g[1] - Mp.v * St.g[1]
    ok_ke &= St.v == 0 and tw_r != 0 and tw_w != 0
    check("S13.5", "checked", "Test 3b. Kerr (M=5, a=3, r_+=9), Vishveshwara's Section III: d_t becomes null on r_0(theta) = M + sqrt(M^2 - a^2 cos^2 theta) (his B.12, the ergosurface); at 7 points of it "
          "(cos^2 = 0, 49/225, 19/36, 56/81, 37/48, 184/225, and the pole 1) the normal to g_tt = const has n.n = -(Delta (d_r g_tt)^2 + (d_theta g_tt)^2)/Sigma < 0 (spacelike normal, so a timelike surface) except at the pole, "
          "where it touches the horizon (Delta = 0, n.n = 0); the twist of d_t is not zero there. The surface where d_t is null is not the null surface r_+ (his B.13)", ok_ke)

    # --- S13.6 the factor: F = (grad xi)^2 = -2 kappa^2 on the horizon, and Eq. (1) = (grad V)^2 = 2 V F with three behaviours near the surface
    ok_F = True
    for name, Tf, rf, xh in EF_CASES:
        if name.startswith("RN inner") or "inner" in name:
            continue
        kap = Tf(Dual.var(0, xh, 1)).g[0] / 2
        d = kdata(ef_metric(Tf, rf), XI_V, [Fr(0), xh, Fr(1, 2), Fr(0)])
        ok_F &= nabla2(d) == -2 * kap * kap
        x1 = xh + Fr(1, 3)
        d1 = kdata(ef_metric(Tf, rf), XI_V, [Fr(0), x1, Fr(1, 2), Fr(0)])
        ok_F &= norm2(d1["gi"], d1["dV"]) == 2 * d1["V"] * nabla2(d1)
    cases = {"simple zero T = x": lambda x: x, "extremal T = x^2": lambda x: x * x}
    ex = {}
    for nm, Tf in cases.items():
        vals = []
        for xv in (Fr(1, 192), Fr(8, 192)):
            d = kdata(ef_metric(Tf, lambda x: x), XI_V, [Fr(0), xv, Fr(1, 2), Fr(0)])
            vals.append(norm2(d["gi"], d["dV"]))
        ex[nm] = vals[1] / vals[0]
    vals = []
    for uv in (Fr(1, 4), Fr(1, 2)):                                   # Eq. (18) in the chart u = (3x)^(1/3): ds^2 = u dv^2 + 2 u^2 dv du
        d = kdata(ef_metric(lambda u: u, lambda u: u, Cf=lambda u: u * u), XI_V, [Fr(0), uv, Fr(1, 2), Fr(0)])
        vals.append(norm2(d["gi"], d["dV"]))
        ok_F &= vals[-1] == -1 / uv ** 3 == -1 / (3 * (uv ** 3 / 3))
    ex["Eq. (18)"] = vals[1] / vals[0]
    ok_ex = ex["simple zero T = x"] == 8 and ex["extremal T = x^2"] == 8 ** 4 and ex["Eq. (18)"] == Fr(1, 8)
    check("S13.6", "checked", "Test 3b. In the regular chart the factor F = xi_b;c xi^b;c equals -2 kappa^2 at the horizon (4 cases) and (grad V)^2 = 2 V F exactly off it; so F is finite iff dT/dx is. "
          "Vollick's Eq. (1), (grad V)^2 = -T (dT/dx)^2, scales as x for a simple zero, x^4 for an extremal zero, and 1/(3x) for Eq. (18) (x -> 8x multiplies it by 8, 4096, 1/8): it goes to 0 at the first two and diverges at the third, "
          "all three surfaces being null (T = 0, n = dx has n.n = -T). This is what 'the proportionality factor diverges' can mean, and it is the case where the argument by (B.8) fails while the surface is still null", ok_F and ok_ex)

    # --- S13.7 the other direction: a null surface invariant under a Killing flow with xi.xi != 0
    eta = [[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, -1]]
    n_cov = [1, 0, -1, 0]                                              # f = t - y
    xi_x = [0, 1, 0, 0]
    n2 = sum(eta[i][j] * n_cov[i] * n_cov[j] for i in range(4) for j in range(4))
    nxi = sum(n_cov[i] * xi_x[i] for i in range(4))
    Vx = sum(eta[i][j] * xi_x[i] * xi_x[j] for i in range(4) for j in range(4))
    check("S13.7", "checked", "Test 3b, scope. Minkowski space, space-like Killing vector xi = d_x (hypersurface-orthogonal, xi.xi = -1 everywhere): the surface t - y = 0 is null (n.n = 0), invariant under the flow (n.xi = 0, so xi is tangent to it) "
          "and has xi.xi = -1 != 0. So xi.xi = 0 is not necessary for a xi-invariant surface to be null; it is the criterion for the boundary of the region where xi is time-like (same point as S4.4 for the interior of a static hole)",
          n2 == 0 and nxi == 0 and Vx == -1)


# ================================================================ S14  the data behind the figures (the Doc draws exactly these rows)
def s14():
    import math
    r4 = lambda x: round(float(x), 5)
    # --- F1: the surface r = r_S in two spacetimes (photon paths and a throat), as line segments (mx / my: also draw the mirror image in X / in T)
    rows = []

    def seg(p, s, kind, rv, P, Q, mx=0, my=0):
        rows.append({"p": p, "s": s, "kind": kind, "rv": rv, "a1": r4(P[0]), "b1": r4(P[1]), "a2": r4(Q[0]), "b2": r4(Q[1]), "mx": mx, "my": my})
    for rv in (1.1, 1.3, 1.7):                                       # Schwarzschild exterior, Kruskal chart, r_S = 1: X^2 - T^2 = (r - 1) e^r (right branch, mirrored in X)
        f = (rv - 1) * math.exp(rv)
        for k in range(15):
            T0, T1 = -3 + 0.4 * k, -3 + 0.4 * (k + 1)
            seg("k", f"r = {rv}", "static", rv, (math.sqrt(f + T0 * T0), T0), (math.sqrt(f + T1 * T1), T1), mx=1)
    for rv, nm in ((0.5, "r = 0.5 (inside)"), (0.0, "r = 0 (singularity)")):   # interior: T^2 - X^2 = (1 - r) e^r (upper branch, mirrored in T)
        ff = (1 - rv) * math.exp(rv)
        for k in range(14):
            X0, X1 = -2.8 + 0.4 * k, -2.8 + 0.4 * (k + 1)
            seg("k", nm, "interior", rv, (X0, math.sqrt(ff + X0 * X0)), (X1, math.sqrt(ff + X1 * X1)), my=1)
    seg("k", "r = 1 (horizon): null", "surface", 1.0, (-3.0, -3.0), (3.0, 3.0), mx=1)           # X = +-T
    Xs = 4.0                                                      # the ingoing photon X + T = 1.5, from X = 4 to the singularity (1.5 - T)^2 - T^2 = -1
    Ts = (1.5 * 1.5 + 1.0) / 3.0
    seg("k", "photon: crosses the horizon", "photon", None, (Xs, 1.5 - Xs), (1.5 - Ts, Ts))
    seg("k", "bifurcation sphere (neck of t = 0)", "neck", 1.0, (0.0, 0.0), (0.0, 0.0))
    for rv in (1.1, 1.3, 1.7):                                       # Ellis: l = +-sqrt(r^2 - 1), T = 1 so t is proper time
        seg("e", f"r = {rv}", "static", rv, (math.sqrt(rv * rv - 1), -3.0), (math.sqrt(rv * rv - 1), 3.0), mx=1)
    seg("e", "r = 1 (throat): timelike", "surface", 1.0, (0.0, -3.0), (0.0, 3.0))
    seg("e", "photon: crosses the throat", "photon", None, (-3.0, -3.0), (3.0, 3.0), mx=1)
    seg("e", "throat (neck of t = 0)", "neck", 1.0, (0.0, 0.0), (0.0, 0.0))
    FIG["f1"] = rows
    ok1 = True
    for rw in rows:
        if rw["p"] == "k" and rw["kind"] == "static":
            for X, T in ((rw["a1"], rw["b1"]), (rw["a2"], rw["b2"])):
                ok1 &= abs(X * X - T * T - (rw["rv"] - 1) * math.exp(rw["rv"])) < 2e-4
        if rw["p"] == "k" and rw["kind"] == "interior":
            for X, T in ((rw["a1"], rw["b1"]), (rw["a2"], rw["b2"])):
                ok1 &= abs(T * T - X * X - (1 - rw["rv"]) * math.exp(rw["rv"])) < 2e-4 and abs(X) <= 2.8 + 1e-9 and abs(T) <= 3.0
        if rw["p"] == "e" and rw["kind"] == "static":
            for L, t in ((rw["a1"], rw["b1"]), (rw["a2"], rw["b2"])):
                ok1 &= abs(L * L - (rw["rv"] ** 2 - 1)) < 1e-4
        if rw["kind"] == "photon":                               # null: a straight line with |dX| = |dT| (slope -+1)
            ok1 &= abs(abs(rw["a2"] - rw["a1"]) - abs(rw["b2"] - rw["b1"])) < 1e-3
        if rw["kind"] == "surface" and rw["p"] == "k":
            ok1 &= abs(rw["a1"] - rw["b1"]) < 1e-9 and abs(rw["a2"] - rw["b2"]) < 1e-9          # the null lines X = +-T
        if rw["kind"] == "surface" and rw["p"] == "e":
            ok1 &= rw["a1"] == 0 == rw["a2"]                                                      # the timelike line l = 0
        if rw["kind"] == "neck":
            ok1 &= rw["a1"] == rw["b1"] == 0                                                      # both necks sit at the origin, r = 1 there
    ph = [r_ for r_ in rows if r_["p"] == "k" and r_["kind"] == "photon"][0]
    ok1 &= abs(ph["a2"] ** 2 - ph["b2"] ** 2 + 1.0) < 1e-3 and abs(ph["a1"] + ph["b1"] - 1.5) < 1e-9 and abs(ph["a2"] + ph["b2"] - 1.5) < 1e-4   # it ends on the singularity and stays on X + T = 1.5
    # --- F2: photon rates, r chart against proper length, Schwarzschild against Ellis (segments)
    rows = []
    def rate(case, kk, r):
        Ts = 1 - 1 / r
        if case == "Schwarzschild":
            return 0.5 * math.sqrt(Ts * Ts) if kk == "dr/dv" else 0.5 * math.sqrt(Ts)
        return 0.5 * math.sqrt((r * r - 1) / (r * r)) if kk == "dr/dv" else 0.5
    for case in ("Schwarzschild", "Ellis"):
        for kk in ("dr/dv", "dℓ/dv"):
            for k in range(20):
                r0, r1 = 1.0 + k * 0.1, 1.0 + (k + 1) * 0.1
                rows.append({"cs": case, "q": kk, "r1": r4(r0), "v1": r4(rate(case, kk, r0)), "r2": r4(r1), "v2": r4(rate(case, kk, r1))})
    FIG["f2"] = rows
    ok2 = True
    for x in rows:
        for rr_, vv in ((x["r1"], x["v1"]), (x["r2"], x["v2"])):
            if x["cs"] == "Schwarzschild" and x["q"] == "dr/dv":
                ok2 &= abs(vv - 0.5 * (1 - 1 / rr_)) < 1e-4                   # exactly T/2
            if x["cs"] == "Schwarzschild" and x["q"] == "dℓ/dv":
                ok2 &= abs(vv * vv - 0.25 * (1 - 1 / rr_)) < 1e-4             # (dl/dv)^2 = T/4
            if x["cs"] == "Ellis" and x["q"] == "dℓ/dv":
                ok2 &= vv == 0.5
            if x["cs"] == "Ellis" and x["q"] == "dr/dv":
                ok2 &= abs(vv * vv - 0.25 * (1 - 1 / rr_ ** 2)) < 1e-4        # (dr/dv)^2 = T/(4R), R = r^2/(r^2 - 1), T = 1
    # --- F3: Vollick's Eq. (1), |(grad V)^2|, three surfaces that are all null (segments on log-log axes)
    rows = []
    cases = (("simple zero", lambda x: x), ("extremal", lambda x: 4 * x ** 4), ("Eq. (18)", lambda x: 1 / (3 * x)))
    for nm, fn in cases:
        for k in range(12):
            x0, x1 = 10 ** (-3 + 0.25 * k), 10 ** (-3 + 0.25 * (k + 1))
            rows.append({"c": nm, "x1": float("%.6g" % x0), "m1": float("%.6g" % fn(x0)), "x2": float("%.6g" % x1), "m2": float("%.6g" % fn(x1)), "lab": {"simple zero": "simple zero: ∝ x → 0", "extremal": "extremal: ∝ x⁴ → 0 faster", "Eq. (18)": "Eq. (18): ∝ 1/x → ∞"}[nm] if k == 6 else ""})
    FIG["f3"] = rows
    # --- F4: Kerr, M = 5, a = 3: horizon r_+ = 9 and ergosurface r_E = 5 + sqrt(25 - 9 cos^2) in the oblate coordinates x = sqrt(r^2 + a^2) sin, z = r cosine (quadrant, mirrored in the figure)
    rows = []
    ok4 = True
    for kind, nm in (("horizon", "horizon r = 9: null"), ("ergosurface", "ergosurface g_tt = 0: timelike")):
        for k in range(15):
            pts = []
            for kk in (k, k + 1):
                th = math.radians(kk * 6)
                c, sn = math.cos(th), math.sin(th)
                r = 9.0 if kind == "horizon" else 5 + math.sqrt(25 - 9 * c * c)
                pts.append((r4(math.sqrt(r * r + 9) * sn), r4(r * c)))
                Sig = r * r + 9 * c * c
                ok4 &= abs(1 - 10 * r / Sig) < 1e-9 if kind == "ergosurface" else abs(r * r - 10 * r + 9) < 1e-12
            rows.append({"kind": kind, "s": nm, "x1": pts[0][0], "z1": pts[0][1], "x2": pts[1][0], "z2": pts[1][1], "th": k * 6})
    FIG["f4"] = rows
    # --- F5: three label sets on the 3-cube, computed with the bit rule
    c2 = Cl([-1, -1])
    c3 = Cl([1, 1, 1])
    cn = Cl([-1, -1, 0])                                              # Cl(0,2,1): bits 0, 1 definite, bit 2 the null bit
    LA = [m for m in range(4)]
    LB = [0, 3, 5, 6]
    J = [m for m in range(8) if m & 4]
    Q = [m for m in range(8) if not m & 4]
    clos_A = all(c2.bmul(x, y)[1] in LA for x in LA for y in LA)
    clos_B = all(c3.bmul(x, y)[1] in LB for x in LB for y in LB)
    even3 = sorted(m for m in range(8) if popc(m) % 2 == 0)
    ideal = all((cn.bmul(x, y)[0] == 0) or (cn.bmul(x, y)[1] in J) for x in J for y in range(8)) and all((cn.bmul(y, x)[0] == 0) or (cn.bmul(y, x)[1] in J) for x in J for y in range(8))
    square0 = all(cn.bmul(x, y)[0] == 0 for x in J for y in J)
    quot = all(cn.bmul(x, y) == c2.bmul(x, y) for x in Q for y in Q)
    verts = [{"v": v, "inA": v in LA, "inB": v in LB, "inJ": v in J, "inQ": v in Q,
              "t1": "c1" if v in LA else "none", "t2": "c2" if v in LB else "none", "t3": "c1" if v in Q else "c3"} for v in range(8)]
    edges = []
    for i in range(8):
        for j in range(i + 1, 8):
            one = popc(i ^ j) == 1
            if one:
                edges.append({"k": 1, "i": i, "j": j, "tone": "c1" if (i in LA and j in LA) else "none"})
                edges.append({"k": 2, "i": i, "j": j, "tone": "none"})
                edges.append({"k": 3, "i": i, "j": j, "tone": "c1" if (i in Q and j in Q) else ("c3" if (i in J and j in J) else "none")})
            elif i in LB and j in LB:
                edges.append({"k": 2, "i": i, "j": j, "tone": "c2"})
    FIG["f5"] = {"verts": verts, "edges": edges}
    ok5 = clos_A and clos_B and even3 == LB and ideal and square0 and quot and Q == LA
    check("S14.1", "checked", f"the sets drawn in the cube figure are computed with the bit rule: Cl(0,2) closes on the labels {LA} (grades 0,1,1,2); the even part of Cl(3,0) closes on the even-weight corners {LB} (grades 0,2,2,2); "
          f"in Cl(0,2,1) (bit 2 null) the labels containing bit 2, {J}, form a two-sided ideal with J.J = 0, and the quotient on the other four labels {Q} multiplies exactly as Cl(0,2): "
          "so the quotient of the horizon's tangent algebra is the first quaternion (a face of the cube), the ideal is the opposite face, and the second quaternion is the tetrahedron", ok5)
    ok3 = True
    for nm, slope in (("simple zero", 1.0), ("extremal", 4.0), ("Eq. (18)", -1.0)):
        for x in (r_ for r_ in FIG["f3"] if r_["c"] == nm):
            ok3 &= abs((math.log10(x["m2"]) - math.log10(x["m1"])) / (math.log10(x["x2"]) - math.log10(x["x1"])) - slope) < 5e-3
    check("S14.2", "checked", "the numbers the Doc plots are the script's own, as line segments. F1: the Kruskal rows satisfy X^2 - T^2 = (r-1)e^r (exterior) and T^2 - X^2 = (1-r)e^r (interior) at both ends of every segment (2e-4); the horizon rows are X = +-T; "
          "the plotted photon is a straight line X + T = 1.5 that ends on the singularity; the Ellis rows satisfy l^2 = r^2 - 1 and the throat is the line l = 0; both necks are at the origin. "
          "F2: Schwarzschild dr/dv = (1/2)(1 - 1/r) and (dl/dv)^2 = (1/4)(1 - 1/r); Ellis dl/dv = 1/2 and (dr/dv)^2 = (1/4)(1 - 1/r^2). F3: the log-log slopes of the three Eq. (1) curves are 1, 4 and -1. "
          "F4: g_tt = 0 on the ergosurface (1e-9) and Delta = 0 on the horizon", ok1 and ok2 and ok3 and ok4)


def main():
    for f in (s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14):
        f()
    computed = [r for r in RES if r["pass"] is not None]
    n_ok = sum(r["pass"] for r in computed)
    n_read = len(RES) - len(computed)
    PORTAL["summary"] = {"computed": len(computed), "passed": n_ok, "readings": n_read}
    print(f"\n{n_ok} of {len(computed)} computed checks pass; {n_read} readings listed, not counted")
    data = json.loads(json.dumps({"checks": RES, "portal": PORTAL, "figs": FIG}))     # the same round trip as the file, so --compare is exact
    args = sys.argv[1:]
    if "--write" in args:
        json.dump(data, open(args[args.index("--write") + 1], "w"), indent=1)
    if "--compare" in args:
        want = json.load(open(args[args.index("--compare") + 1]))
        same = want == data
        print("portal data equals the rebuilt data" if same else "PORTAL DATA DIFFERS from the rebuilt data")
        if not same:
            sys.exit(1)
    sys.exit(0 if n_ok == len(computed) else 1)


if __name__ == "__main__":
    main()
