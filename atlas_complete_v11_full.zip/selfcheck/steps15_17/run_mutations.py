#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Mutation test of the clock, gauge-gravity and finite-groups scripts: each mutant changes ONE line of one script; the matching script must then FAIL
(assertion, FAIL line, traceback, timeout).  A mutant that still prints the all-pass line is SURVIVED = a check without teeth.
   python3 run_mutations.py        (from this folder; the five scripts are read from here; about 4 minutes, so run_tests.sh does not run it)"""
import os, sys, shutil, subprocess, tempfile, concurrent.futures as cf
HERE = os.path.dirname(os.path.abspath(__file__)); SRC = HERE; KEEP = ('bitcliff.py', 'permgroup.py', 'labels_check.py', 'groups_check.py', 'gtg_check.py')
PASS = {'labels_check.py': 'ALL LABELS CHECKS PASS', 'groups_check.py': 'ALL GROUP CHECKS PASS', 'gtg_check.py': 'ALL GTG/RDK CHECKS PASS'}
# (id, file mutated, old, new, script to run, args)
# NOTE: M2 (k(k+1)/2 -> k(k-1)/2 in the identity) is an EQUIVALENT mutant: on the even-weight code the two address forms coincide (k = 2j: both are j mod 2).
M = [
 ('B1 engine: sign rule loses its shift',            'bitcliff.py',      "    a >>= 1\n    s = 0\n", "    s = 0\n", 'labels_check.py', []),
 ('B2 engine: textbook table H <-> H2 swapped',      'bitcliff.py',      "['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']", "['R', 'R2', 'R', 'C', 'H2', 'H', 'H', 'C']", 'labels_check.py', []),
 ('L1 labels: polar form = anticommutation sign flipped', 'labels_check.py', "(1 - A.comm_sign(a, b)) // 2", "(1 + A.comm_sign(a, b)) // 2", 'labels_check.py', []),
 ('G1 groups A: |O+-(2)| formula sign',              'groups_check.py',  "(2 ** m - eps)", "(2 ** m + eps)", 'groups_check.py', ['A']),
 ('G2 groups A: transvection generators wrong',      'groups_check.py',  "gens.append(tuple(idx[x ^ v] if B(x, v) else idx[x] for x in pts))", "gens.append(tuple(idx[x ^ v] if Q[x] else idx[x] for x in pts))", 'groups_check.py', ['A']),
 ('G3 groups B: blade-square formula k(k-1)/2 -> k(k+1)/2', 'groups_check.py', "(pc(a) * (pc(a) - 1) // 2) & 1", "(pc(a) * (pc(a) + 1) // 2) & 1", 'groups_check.py', ['B']),
 ('G4 groups B: E_n Dynkin tree changed (node 0 gets a 4th arm)',            'groups_check.py',  "edge(0, 1); edge(0, 2); edge(2, 3)", "edge(0, 1); edge(0, 2); edge(0, 3)", 'groups_check.py', ['B']),
 ('G5 groups C: Pin-lift normalisation /2 -> /3',    'groups_check.py',  "return {k: v / 2 for k, v in A.mul(vec(*a), vec(*b)).items()}", "return {k: v / 3 for k, v in A.mul(vec(*a), vec(*b)).items()}", 'groups_check.py', ['C']),
 ('G6 groups D: Turyn construction third block wrong', 'groups_check.py', "((a ^ b ^ x) << 16)", "((a ^ x) << 16)", 'groups_check.py', ['D']),
 ('G7 groups E: ord_p(2) off by one',                'groups_check.py',  "d = 1; x = 2 % p", "d = 2; x = 2 % p", 'groups_check.py', ['E']),
 ('G8 groups F: Pfaffian loses a term',              'groups_check.py',  "return (g(0, 1) & g(2, 3)) ^ (g(0, 2) & g(1, 3)) ^ (g(0, 3) & g(1, 2))", "return (g(0, 1) & g(2, 3)) ^ (g(0, 2) & g(1, 3))", 'groups_check.py', ['F']),
 ('G9 groups F: Pfaffian sign over Z',               'groups_check.py',  "pf = Bc[(0, 1)] * Bc[(2, 3)] - Bc[(0, 2)] * Bc[(1, 3)]", "pf = Bc[(0, 1)] * Bc[(2, 3)] + Bc[(0, 2)] * Bc[(1, 3)]", 'groups_check.py', ['F']),
 ('T1 gtg R: translation rotor sign',                'gtg_check.py',     "Tr = A5.add({0: 1}, A5.mul(av, ninf), Fr(-1, 2))", "Tr = A5.add({0: 1}, A5.mul(av, ninf), Fr(1, 2))", 'gtg_check.py', ['R']),
 ('T2 gtg R: Riesz bivector sign',                   'gtg_check.py',     "B = {3: 0.5, 9: 0.5, 6: -0.5, 12: -0.5}", "B = {3: 0.5, 9: 0.5, 6: -0.5, 12: 0.5}", 'gtg_check.py', ['R']),
 ('T3 gtg G: horizon square g^2-1 -> g^2+1',          'gtg_check.py',     "v = A.add(er, et, gv); sq = scal(A.mul(v, v))", "v = A.add(er, et, gv); sq = scal(A.mul(v, v)) + 2", 'gtg_check.py', ['G']),
 ('T4 gtg S: spacetime algebra signature (1,3)->(3,1)', 'gtg_check.py',   "A = Alg(sig(1, 3)); g = [{1 << i: 1} for i in range(4)]", "A = Alg(sig(3, 1)); g = [{1 << i: 1} for i in range(4)]", 'gtg_check.py', ['S']),
 ('T5 gtg F: extra generators in the transvection set', 'gtg_check.py',  "if B(1 << i, v) else (1 << i) for i in range(n)) for v in tv]", "if (B(1 << i, v) or Q[1 << i]) else (1 << i) for i in range(n)) for v in tv]", 'gtg_check.py', ['F']),
 # --- added after the independent cross-check: mutants aimed at checks that were print-only or missing
 ('M1 groups B3: S_{n+1} point-permutation identity, wrong coordinate map phi', 'groups_check.py', "if (x >> i) & 1: y ^= (3 << i)", "if (x >> i) & 1: y ^= (5 << i)", 'groups_check.py', ['B']),
 ('M2 groups B3: address form in the identity perturbed on the even-weight code', 'groups_check.py', "Qn1 = [((pc(a) * (pc(a) + 1)) // 2) & 1 for a in range(1 << (n + 1))]", "Qn1 = [(((pc(a) * (pc(a) + 1)) // 2) + (a & 1)) & 1 for a in range(1 << (n + 1))]", 'groups_check.py', ['B']),
 ('M3 groups A3: wrong simple-group name (A6 -> A7)', 'groups_check.py', "360: 'A6'", "360: 'A7'", 'groups_check.py', ['A']),
 ('M4 groups A3: wrong simple-group name (U4(2) -> U4(3))', 'groups_check.py', "25920: 'U4(2)=S4(3)'", "25920: 'U4(3)'", 'groups_check.py', ['A']),
 ('M5 groups B: E_n -> GL(n,2) kernel expectation wrong at n=7', 'groups_check.py', "KERNEL = {3: 2, 4: 1, 5: 1, 6: 1, 7: 2, 8: 2}", "KERNEL = {3: 2, 4: 1, 5: 1, 6: 1, 7: 1, 8: 2}", 'groups_check.py', ['B']),
 ('M6 groups A5: Gauss-sum exponent pos(a)-neg(a) -> pos(a)+neg(a)', 'groups_check.py', "k = (pc(a & ((1 << p) - 1)) - pc(a >> p)) % 4", "k = (pc(a & ((1 << p) - 1)) + pc(a >> p)) % 4", 'groups_check.py', ['A']),
 ('M7 gtg F: reflection length one too long in the R2 rows', 'gtg_check.py', "tot = len(dist); mx = max(dist.values()); mean", "tot = len(dist); mx = max(dist.values()) + (1 if cls == 'R2' else 0); mean", 'gtg_check.py', ['F']),
 ('M8 gtg F: reflection length one too long in the H2 rows', 'gtg_check.py', "tot = len(dist); mx = max(dist.values()); mean", "tot = len(dist); mx = max(dist.values()) + (1 if cls == 'H2' else 0); mean", 'gtg_check.py', ['F']),
 ('M9 gtg F: mean/excess count changed (rank counted with the identity column dropped)', 'gtg_check.py', "rk = rank2([h[i] ^ (1 << i) for i in range(n)])", "rk = rank2([h[i] ^ (1 << i) for i in range(1, n)])", 'gtg_check.py', ['F']),
 ('M10 gtg G: reciprocal frame replaced by the plain frame', 'gtg_check.py', "gr_ = [g[0]] + [A.scal(g[i], -1) for i in (1, 2, 3)]", "gr_ = [g[0]] + [A.scal(g[i], 1) for i in (1, 2, 3)]", 'gtg_check.py', ['G']),
 ('M11 labels s11: a complex root forced in Cl(1,3)', 'labels_check.py', "if abs(lam1.imag) > 1e-9: cplx += 1", "if abs(lam1.imag) > 1e-9 or cell == (1, 3): cplx += 1", 'labels_check.py', []),
 ('M12 labels s11: a complex root forced in the PGA cell Cl(3,0,1)', 'labels_check.py', "if abs(lam1.imag) > 1e-9: cplx += 1", "if abs(lam1.imag) > 1e-9 or cell == (3, 0, 1): cplx += 1", 'labels_check.py', []),
 ('M13 gtg G: Painleve-Gullstrand shear with g^2 = 3M/r instead of 2M/r (mass 3M/2)', 'gtg_check.py', "metric_of(gtr(2.0), 'pg')", "metric_of(gtr(3.0), 'pg')", 'gtg_check.py', ['G']),
 ('M14 gtg G: point-mass Weyl map B + 3 sigma_r B sigma_r -> B + 2 sigma_r B sigma_r', 'gtg_check.py', "A.mul(A.mul(srr, {a: 1}), srr), 3)", "A.mul(A.mul(srr, {a: 1}), srr), 2)", 'gtg_check.py', ['G']),
 ('M15 gtg G: Kerr-Schild time shift g/(1+g) -> g/(2+g)', 'gtg_check.py', "shift(Gpg, gv / (1 + gv))", "shift(Gpg, gv / (2 + gv))", 'gtg_check.py', ['G']),
 ('M16 gtg S: Dirac action, mass term of D with the wrong sign', 'gtg_check.py', "Dv = A.add(Dv, A.mul(mvec(psi), g[0]), -mm)", "Dv = A.add(Dv, A.mul(mvec(psi), g[0]), mm)", 'gtg_check.py', ['S']),
]
def run(m):
    mid, f, old, new, script, args = m
    d = tempfile.mkdtemp(prefix='mut_')
    try:
        for fn in os.listdir(SRC):
            if fn in KEEP: shutil.copy(os.path.join(SRC, fn), d)
        p = os.path.join(d, f); s = open(p).read()
        n_ = s.count(old)
        if n_ == 0: return (mid, 'ANCHOR NOT FOUND', '')
        open(p, 'w').write(s.replace(old, new))
        try:
            r = subprocess.run([sys.executable, script] + args, cwd=d, capture_output=True, text=True, timeout=240)
            out = r.stdout + r.stderr
            passed = (r.returncode == 0) and (PASS[script] in out) and ('FAIL' not in out) and ('Traceback' not in out)
            status = 'SURVIVED' if passed else 'caught'
            why = ('exit %d' % r.returncode) + ('; FAIL lines: %d' % out.count('  FAIL ')) + ('; traceback' if 'Traceback' in out else '')
        except subprocess.TimeoutExpired:
            status, why = 'caught', 'timeout (never reached the all-pass line)'
        return (mid, status, why)
    finally:
        shutil.rmtree(d, ignore_errors=True)
if __name__ == '__main__':
    with cf.ThreadPoolExecutor(2) as ex: res = list(ex.map(run, M))
    bad = 0
    for mid, st, why in res:
        print('%-8s %s   [%s]' % (st, mid, why)); bad += (st != 'caught')
    print('\n%d mutants, %d caught, %d not caught' % (len(res), len(res) - bad, bad))
    sys.exit(1 if bad else 0)
