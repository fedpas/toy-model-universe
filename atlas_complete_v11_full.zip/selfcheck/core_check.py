#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""core_check.py: the core statements of the bit rule, recomputed with the Python standard library only (exact integers and rationals; B13 reads one phase from a sum of roots of unity with a float tolerance of 1e-9).

  python3 core_check.py                    run every check and print one line per check id (core·B1 ...)
  python3 core_check.py --write f.json     also write the rows (id, tag, text, ok) and the small data tables
  python3 core_check.py --compare f.json   check that the rows equal the file

The bit rule: blades are bit masks a in F_2^n; e_a e_b = s(a,b) e_{a xor b} with s = (reordering sign) x (product of the squares eps_i of the
common generators), eps_i in {+1, -1, 0}.  A generator that squares to +1 is counted in p, to -1 in q, to 0 in r (the atlas convention).
The class of the sign on F_2^n is the quadratic form Q(a) = [e_a^2 = -1]; pi(a) = |a| mod 2; the Z_4 form is w = pi + 2Q.

What is NOT here: T1 to T20 of researchers_checks (they stay where they are). These rows are the ones the core statements of the atlas need and no
other script had: the Z_4 refinement w, the Brown invariant as the clock, the mirror Q -> Q + pi, Q against the type, the tensor and grading
structure with null generators, the doubling, Furey's axes as a Lagrangian, the symmetry group of (V, Q, pi), the Gauss-Milgram phase of E_n, Kepler against the projective step, the reversion of the all-positive cell."""
import argparse, itertools, json, sys
from fractions import Fraction as F

ROWS, DATA = [], {}
def pc(a): return bin(a).count('1')
def row(i, tag, text, ok):
    ROWS.append({'id': i, 'tag': tag, 'text': text, 'ok': bool(ok)})
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    return ok

# ---------------------------------------------------------------- the bit rule (eps_i in {+1,-1,0}; the product is 0 when a common generator is null)
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Q(a, eps): return 1 if sgn(a, a, eps) == -1 else 0          # Q(a) = [e_a^2 = -1]
def pi(a): return pc(a) % 2
def w4(a, eps): return (pi(a) + 2 * Q(a, eps)) % 4
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
def cells(n, r=0): return [(p, n - r - p, r) for p in range(n - r + 1)]

# ---------------------------------------------------------------- Gaussian integers (re, im) for the exact Gauss sums
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def gpow(x, k):
    r = (1, 0)
    for _ in range(k): r = gmul(r, x)
    return r
I_POW = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def gsum(exps):
    re = im = 0
    for k in exps:
        z = I_POW[k % 4]; re += z[0]; im += z[1]
    return (re, im)
def brown_target(p, q): return gmul(gpow((1, 1), p), gpow((1, -1), q))      # (1+i)^p (1-i)^q = 2^{n/2} e^{i pi (p-q)/4}

# ================================================================ B1 .. B4: the Z_4 form, the clock, the mirror
def B1():
    ok = True
    for n in range(1, 6):
        for p, q, r in cells(n):
            e = sig(p, q)
            for a in range(1 << n):
                for b in range(1 << n):
                    if (w4(a ^ b, e) - w4(a, e) - w4(b, e)) % 4 != (2 * pc(a & b)) % 4: ok = False
    row('core·B1', 'checked', 'w = pi + 2Q is a Z_4-valued quadratic refinement of the dot product: w(a+b) - w(a) - w(b) = 2|a & b| mod 4 for every blade pair of every Cl(p,q), n <= 5', ok)
def B2():
    ok = True
    for n in range(1, 7):
        for p, q, r in cells(n):
            e = sig(p, q); P = (1 << p) - 1; Qm = ((1 << q) - 1) << p
            for a in range(1 << n):
                if (pc(a & P) - pc(a & Qm)) % 4 != w4(a, e): ok = False
    row('core·B2', 'checked', 'the exponent of the clock sum of the atlas, |a & P| - |a & Q| (P the +1 bits, Q the -1 bits), equals w(a) mod 4 for every blade of every Cl(p,q), n <= 6; so the atlas Gauss sum is the sum of i^w', ok)
def B3():
    ok = True; ph = {}
    for n in range(1, 9):
        for p, q, r in cells(n):
            e = sig(p, q)
            S = gsum([w4(a, e) for a in range(1 << n)])
            if S != brown_target(p, q): ok = False
            ph[f'{p},{q}'] = (p - q) % 8
    for r in (1, 2):                                   # null bits add nothing to the exponent: the sum is 2^r times the sum of the nondegenerate part
        for n in range(r + 1, 7):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r)
                S = gsum([(pc(a & ((1 << p) - 1)) - pc(a & (((1 << q) - 1) << p))) for a in range(1 << n)])
                T = brown_target(p, q)
                if S != (T[0] << r, T[1] << r): ok = False
    DATA['clock'] = ph
    row('core·B3', 'checked', 'the Gauss sum of i^w over all blades equals (1+i)^p (1-i)^q exactly, so its phase is pi (p-q)/4: the clock p - q mod 8 is the Brown invariant of (V, w); n <= 8 (r = 0) and 2^r times it for r = 1, 2 null generators (n <= 6)', ok)
def B4():
    ok = ok2 = True
    for n in range(1, 7):
        for p, q, r in cells(n):
            e = sig(p, q); m = [-x for x in e]
            for a in range(1 << n):
                if (Q(a, e) + pi(a)) % 2 != Q(a, m): ok = False
                if (w4(a, m) + w4(a, e)) % 4 != 0: ok2 = False
    row('core·B4', 'checked', 'the mirror: Q of Cl(q,p) is Q of Cl(p,q) plus pi on every blade, n <= 6 (the graded opposite changes Q by the parity)', ok)
    row('core·B4b', 'checked', 'the mirror sends w to -w mod 4 on every blade, n <= 6; with B3 the Brown invariant goes to its negative, p - q to q - p', ok2)

# ================================================================ B5: bivector squares are mirror-invariant, vector squares are not
def B5():
    ok = True; table = {}
    for n in range(1, 7):
        for p, q, r in cells(n):
            e = sig(p, q); m = [-x for x in e]
            for a in range(1, 1 << n):
                sa, sm = sgn(a, a, e), sgn(a, a, m)
                same = (sa == sm)
                g = pc(a)
                if same != (g % 2 == 0): ok = False
                table.setdefault(g, set()).add(same)
    DATA['mirror_square_invariant_by_grade'] = {str(k): sorted(v) for k, v in sorted(table.items())}
    row('core·B5', 'checked', 'under the mirror (eps -> -eps) the square of a blade is unchanged exactly when its grade is even (bivectors, 4-vectors), and flips when it is odd (vectors, trivectors); every blade of every Cl(p,q), n <= 6', ok)
    ok = True
    for n in range(2, 7):
        for r0 in (0, 1, 2):                                # r0 null generators among the n
            for p, q, r in cells(n, r0):
                e = sig(p, q, r)
                for i in range(n):
                    for j in range(n):
                        if i != j and sgn((1 << i) | (1 << j), (1 << i) | (1 << j), e) != -e[i] * e[j]: ok = False
    row('core·B5b', 'checked', 'the square of the bivector e_i e_j (i != j) is -eps_i eps_j: +1 for one plus and one minus generator (boost), -1 for two of the same sign (rotation), 0 if either is null; every Cl(p,q,r) with r = 0, 1, 2 null generators, n <= 6', ok)

def B5c():
    ok = True
    for n in range(2, 7):
        for p, q, r in cells(n):
            e = sig(p, q); m = [-x for x in e]
            for a in range(1 << n):
                for b in range(1 << n):
                    if pc(a) % 2 or pc(b) % 2: continue
                    f = lambda x: (-1) ** (pc(x) // 2)
                    if sgn(a, b, m) != sgn(a, b, e) * f(a) * f(b) * f(a ^ b): ok = False
    row('core·B5c', 'checked', 'the mirror leaves the even part alone: on even blades the mirror sign equals the original sign times f(a) f(b) f(a xor b) with f(a) = (-1)^{|a|/2}, so e_a -> f(a) e_a is an isomorphism Cl0(p,q) -> Cl0(q,p), every Cl(p,q), n <= 6 (spin and bivector content is mirror-invariant)', ok)

# ================================================================ B6: Q alone gives the ungraded type, not the cell
TYPE = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']
def polar(a, b, e): return (Q(a ^ b, e) + Q(a, e) + Q(b, e)) % 2
def q_invariants(e):
    n = len(e); V = range(1 << n)
    rad = [a for a in V if all(polar(a, b, e) == 0 for b in V)]
    zeros = sum(1 for a in V if Q(a, e) == 0)
    return (len(rad), tuple(sorted(Q(a, e) for a in rad)), zeros)
def isometries(Qa, Qb, n, pia=None, pib=None, count=True):
    """linear bijections T of F_2^n with Qb(Tv) = Qa(v) (and pib(Tv) = pia(v) if given); backtracking on the images of the basis vectors"""
    Ba = [[(Qa[(1 << i) ^ (1 << j)] + Qa[1 << i] + Qa[1 << j]) % 2 for j in range(n)] for i in range(n)]
    found = [0]
    def rec(i, imgs):
        if i == n:
            span = {0}
            for v in imgs: span |= {s ^ v for s in span}
            if len(span) == 1 << n:
                found[0] += 1; return not count
            return False
        for v in range(1 << n):
            if Qb[v] != Qa[1 << i]: continue
            if pia is not None and pib[v] != pia[1 << i]: continue
            if any((Qb[v ^ imgs[j]] + Qb[v] + Qb[imgs[j]]) % 2 != Ba[i][j] for j in range(i)): continue
            if rec(i + 1, imgs + [v]): return True
        return False
    rec(0, [])
    return found[0]
def Qtable(e): return [Q(a, e) for a in range(1 << len(e))]
def Ptable(n): return [pi(a) for a in range(1 << n)]
def B6():
    ok = True; summary = {}
    for n in range(1, 7):
        classes = {}
        for p, q, r in cells(n):
            classes.setdefault(q_invariants(sig(p, q)), []).append((p, q))
        part_Q = sorted(sorted(c) for c in classes.values())
        types = {}
        for p, q, r in cells(n): types.setdefault(TYPE[(p - q) % 8], []).append((p, q))
        part_T = sorted(sorted(c) for c in types.values())
        if part_Q != part_T: ok = False
        summary[str(n)] = {'Q_classes': len(part_Q), 'ungraded_types': len(part_T)}
    DATA['Q_class_vs_type'] = summary
    row('core·B6', 'checked', 'for n <= 6 the isometry class of the F_2 form Q (invariants: radical size, Q on the radical, number of zeros) splits the cells Cl(p,q) exactly as the ungraded algebra type does (R, R+R, C, H, H+H): Q gives the type and nothing finer', ok)
    ok = all(TYPE[s] == TYPE[(2 - s) % 8] for s in range(8))
    row('core·B6b', 'checked', 'the ungraded type table is invariant under p - q -> 2 - (p - q) mod 8, which is Cl(p,q) ~ Cl(q+1, p-1): the identification Q cannot undo', ok)
    ok = True; pairs = []; same_cell = []
    for n in range(2, 6):
        cs = cells(n)
        for x in range(len(cs)):
            for y in range(x, len(cs)):
                (p1, q1, _), (p2, q2, _) = cs[x], cs[y]
                e1, e2 = sig(p1, q1), sig(p2, q2)
                has_Q = isometries(Qtable(e1), Qtable(e2), n, count=False) == 1
                has_QP = isometries(Qtable(e1), Qtable(e2), n, Ptable(n), Ptable(n), count=False) == 1
                if has_QP != ((p1 - q1) % 8 == (p2 - q2) % 8): ok = False          # (V,Q,pi) isomorphic  <=>  same n and same p - q mod 8
                if has_Q != (q_invariants(e1) == q_invariants(e2)): ok = False
                if has_Q and not has_QP: pairs.append(f'Cl({p1},{q1}) ~ Cl({p2},{q2})')
                if has_QP and (p1, q1) != (p2, q2): same_cell.append(f'Cl({p1},{q1}) = Cl({p2},{q2})')
    DATA['same_Q_different_cell'] = pairs; DATA['same_cell_V_Q_pi'] = same_cell
    row('core·B6c', 'checked', 'for every pair of cells with the same n <= 5: (V,Q,pi) are isomorphic (an isometry of Q that also keeps pi exists) exactly when p - q is the same mod 8; Q alone is isometric for more pairs (Cl(2,0) and Cl(1,1) is the smallest). The cell is (V, Q, pi), and the cells Cl(4,0), Cl(0,4) (p - q = +-4) are one and the same (V, Q, pi)', ok)

# ================================================================ B7 .. B9: null generators
def sort_perm(e):                                    # nondegenerate bits first, null bits last
    nd = [i for i in range(len(e)) if e[i] != 0]; nu = [i for i in range(len(e)) if e[i] == 0]
    return nd + nu
def B7():
    ok = True
    for n in range(1, 6):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e)
            if e != [x for x in e if x != 0] + [0] * e.count(0): continue          # sorted order: nondegenerate first, null last
            m = n - e.count(0)
            for a in range(1 << n):
                for b in range(1 << n):
                    aD, aN, bD, bN = a & ((1 << m) - 1), a >> m, b & ((1 << m) - 1), b >> m
                    ext = 0 if aN & bN else (-1) ** sum(1 for i in range(n - m) if aN >> i & 1 for j in range(n - m) if bN >> j & 1 and j < i)
                    want = (-1) ** (pc(aN) * pc(bD)) * sgn(aD, bD, e[:m]) * ext
                    if sgn(a, b, e) != want: ok = False
    row('core·B7', 'checked', 'Cl(p,q,r) = Cl(p,q) (x)^ Lambda(R^r): with the null bits last the bit-rule sign is (-1)^{|a_N||b_D|} s_D(a_D,b_D) ext(a_N,b_N), exactly the graded tensor product of the nondegenerate part and the exterior algebra (every eps in {+,-,0}^n, n <= 5)', ok)
    ok = True
    for n in range(2, 5):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e); perm = sort_perm(e); es = [e[i] for i in perm]; pos = {old: new for new, old in enumerate(perm)}
            def g(a):                                         # f_a = f_i1 f_i2 ... (increasing old bits), f_i = e_{pos i} of the sorted algebra: a signed blade s e_lab
                s, lab = 1, 0
                for i in range(n):
                    if a >> i & 1:
                        s *= sgn(lab, 1 << pos[i], es); lab ^= 1 << pos[i]
                return s, lab
            for a in range(1 << n):
                for b in range(1 << n):
                    sa, la = g(a); sb, lb = g(b); sab, lab = g(a ^ b)
                    if sa * sb * sgn(la, lb, es) != sgn(a, b, e) * sab or (la ^ lb) != lab: ok = False
    row('core·B7b', 'checked', 'the position of the null bits is a gauge: moving them to the end is an algebra isomorphism e_a -> +-e_{perm a} (every eps in {+,-,0}^n, every n <= 4)', ok)
def partial_product_ok(e):
    n = len(e); N = sum(1 << i for i in range(n) if e[i] == 0)
    for a in range(1 << n):
        for b in range(1 << n):
            if (sgn(a, b, e) == 0) != bool(a & b & N): return False
    for a in range(1 << n):
        for b in range(1 << n):
            for c in range(1 << n):
                l = sgn(a, b, e) * sgn(a ^ b, c, e) if sgn(a, b, e) else 0
                r = sgn(b, c, e) * sgn(a, b ^ c, e) if sgn(b, c, e) else 0
                if l != r: return False
    return True
def B8():
    ok = True
    for n in range(1, 5):
        for e in itertools.product((1, -1, 0), repeat=n):
            if not partial_product_ok(list(e)): ok = False
    row('core·B8', 'checked', 'with null generators the product of two blades is 0 exactly when they share a null bit and is +-e_{a xor b} otherwise; the sign function is associative with the zeros in place: the labels form a monoid with zero and s is a 2-cocycle on it (every eps in {+,-,0}^n, n <= 4)', ok)
def snf_diag(M):
    """diagonal of a diagonalisation of an integer matrix by row and column operations: Z^N / (row space) = Z^(N - rank) + sum of Z/d_i"""
    M = [r[:] for r in M]; R, C = len(M), len(M[0]); d = []; t = 0
    while t < min(R, C):
        best = None
        for i in range(t, R):
            for j in range(t, C):
                if M[i][j] and (best is None or abs(M[i][j]) < abs(M[best[0]][best[1]])): best = (i, j)
        if best is None: break
        i, j = best; M[t], M[i] = M[i], M[t]
        for row in M: row[t], row[j] = row[j], row[t]
        while True:
            changed = False
            for i in range(t + 1, R):
                if M[i][t]:
                    q = M[i][t] // M[t][t]; M[i] = [x - q * y for x, y in zip(M[i], M[t])]
                    if M[i][t]: M[t], M[i] = M[i], M[t]; changed = True
            for j in range(t + 1, C):
                if M[t][j]:
                    q = M[t][j] // M[t][t]
                    for row in M: row[j] -= q * row[t]
                    if M[t][j]:
                        for row in M: row[t], row[j] = row[j], row[t]
                        changed = True
            if not changed: break
        d.append(abs(M[t][t])); t += 1
    return d
def grading_group(e):
    n = len(e); N = 1 << n; rel = []
    for a in range(N):
        for b in range(N):
            if sgn(a, b, e):
                r = [0] * N; r[a] += 1; r[b] += 1; r[a ^ b] -= 1; rel.append(r)
    d = snf_diag(rel); free = N - len(d); tors = sorted(x for x in d if x > 1)
    return free, tors
def B9():
    ok = True; tab = {}
    for n in range(1, 5):
        for p, q, r in [(p, n - r - p, r) for r in range(n + 1) for p in range(n - r + 1)]:
            free, tors = grading_group(sig(p, q, r))
            tab[f'{p},{q},{r}'] = [free, tors]
            if free != r or tors != [2] * (p + q): ok = False
    DATA['grading_group'] = tab
    row('core·B9', 'checked', 'the universal group of the label grading (generators g_a, relations g_a + g_b = g_{a xor b} whenever e_a e_b != 0, Smith normal form) is Z_2^{p+q} x Z^r for every Cl(p,q,r), n <= 4: a group grading only on the nondegenerate bits, a Z-grading by the number of null bits, so null bits live in a monoid, not a group', ok)

# ================================================================ B10: doubling, Cl(V) (x)^ Cl(-V) = End Cl(V); blade labels = spinor weights
def mats(e):
    n = len(e); N = 1 << n
    def L(i):                                        # left multiplication by e_i on Cl(V)
        M = [[0] * N for _ in range(N)]
        for a in range(N): s = sgn(1 << i, a, e); M[a ^ (1 << i)][a] = s
        return M
    def R(i):                                        # twisted right multiplication  R'_i x = alpha(x) e_i
        M = [[0] * N for _ in range(N)]
        for a in range(N): s = sgn(a, 1 << i, e) * (-1) ** pc(a); M[a ^ (1 << i)][a] = s
        return M
    return [L(i) for i in range(n)], [R(i) for i in range(n)]
def mm(A, B):
    N = len(A); return [[sum(A[i][k] * B[k][j] for k in range(N) if A[i][k]) for j in range(N)] for i in range(N)]
def eqm(A, B): return A == B
def neg(A): return [[-x for x in r] for r in A]
def ident(N): return [[int(i == j) for j in range(N)] for i in range(N)]
def rank_mod(vecs, P=1000003):
    vecs = [[x % P for x in v] for v in vecs]; rank = 0; ncol = len(vecs[0])
    for c in range(ncol):
        piv = next((i for i in range(rank, len(vecs)) if vecs[i][c]), None)
        if piv is None: continue
        vecs[rank], vecs[piv] = vecs[piv], vecs[rank]; inv = pow(vecs[rank][c], P - 2, P)
        vecs[rank] = [x * inv % P for x in vecs[rank]]
        for i in range(len(vecs)):
            if i != rank and vecs[i][c]:
                f = vecs[i][c]; vecs[i] = [(x - f * y) % P for x, y in zip(vecs[i], vecs[rank])]
        rank += 1
    return rank
def B10():
    ok = ok2 = ok3 = True
    for n in range(1, 5):
        for p in range(n + 1):
            e = sig(p, n - p); N = 1 << n; Ls, Rs = mats(e); I = ident(N)
            gens = [(Ls[i], e[i]) for i in range(n)] + [(Rs[i], -e[i]) for i in range(n)]
            for i, (A, sq) in enumerate(gens):
                if mm(A, A) != [[sq * x for x in r] for r in I]: ok = False
                for j, (B, _) in enumerate(gens):
                    if i < j and mm(A, B) != neg(mm(B, A)): ok = False
            vecs = []                                    # the rank of the 4^n ordered products, for every signature (r = 0) up to n = 4
            for S in range(1 << (2 * n)):
                M = I
                for k in range(2 * n):
                    if S >> k & 1: M = mm(M, gens[k][0])
                vecs.append([x for r in M for x in r])
            if rank_mod(vecs) != 1 << (2 * n): ok2 = False
            Bs = [mm(Ls[i], Rs[i]) for i in range(n)]
            for i in range(n):                           # B_i = L_i R'_i : square +1, commuting, blade e_a is an eigenvector with eigenvalue (-1)^[i in a] eps_i
                if mm(Bs[i], Bs[i]) != I: ok3 = False
                for j in range(i + 1, n):
                    if mm(Bs[i], Bs[j]) != mm(Bs[j], Bs[i]): ok3 = False
            wts = set()
            for a in range(N):
                wv = []
                for i in range(n):
                    Bi = Bs[i]; col = [Bi[r][a] for r in range(N)]
                    ev = (-1) ** (a >> i & 1) * e[i]
                    if col != [ev if r == a else 0 for r in range(N)]: ok3 = False
                    wv.append(ev)
                wts.add(tuple(wv))
            if len(wts) != N: ok3 = False
    row('core·B10', 'checked', 'doubling: left multiplications L_i (square eps_i) and twisted right multiplications R_i (x -> alpha(x) e_i, square -eps_i) on Cl(V) generate Cl(n,n): the Clifford relations hold and the 4^n ordered products are linearly independent (rank 4^n = dim End Cl(V)), so Cl(V) (x)^ Cl(-V) = End Cl(V) as algebras; every non-degenerate Cl(p,q) (r = 0) with n <= 4', ok and ok2)
    row('core·B10b', 'checked', 'in that Cl(n,n) the commuting bivectors B_i = L_i R_i square to +1 and every blade e_a is a joint eigenvector with eigenvalue (-1)^[i in a] eps_i, all 2^n sign patterns occurring once: the blade labels are the spinor weights of so(V + (-V)); every non-degenerate Cl(p,q) (r = 0) with n <= 4', ok3)

def B10c():
    ok = True; counts = {}
    for e in ([1] * 8, [-1] * 8):
        n = 8; wts = {}
        for a in range(1 << n):
            w = []
            for i in range(n):
                g = 1 << i
                s1 = sgn(a, g, e) * (-1) ** pc(a)             # R'_i e_a = alpha(e_a) e_i
                s2 = sgn(g, a ^ g, e)                         # L_i (e_{a xor g}) = s e_a
                if (a ^ g) ^ g != a: ok = False
                w.append(s1 * s2)
                if w[-1] != (-1) ** (a >> i & 1) * e[i]: ok = False
            wts[a] = tuple(w)
        neg_even = {a for a in range(1 << n) if sum(1 for x in wts[a] if x == -1) % 2 == 0}
        counts[str(e[0])] = len(neg_even)
        if len(set(wts.values())) != 256: ok = False
        if neg_even != {a for a in range(1 << n) if pc(a) % 2 == 0} and e[0] == 1: ok = False
    row('core·B10c', 'checked', 'at n = 8 (Cl(8,0) and Cl(0,8)) the joint eigenvalues of the 8 commuting bivectors L_i R_i on the 256 blades are 256 distinct sign vectors; for Cl(8,0) the 128 even blades carry exactly the sign vectors with an even number of minus signs (the 128 half-spinor weights of E8 = so(16) + 128; the 112 roots of D8 are the other part of 112 + 128 = 240)', ok and counts['1'] == 128)

# ================================================================ B11: Furey's axes
def B11():
    lines = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
    gens = [sum(1 << (k - 1) for k in L) | (1 << 7) for L in lines]
    span = {0}
    for g in gens: span |= {s ^ g for s in span}
    e8 = [-1] * 8
    w = sorted(pc(x) for x in span); enum = {k: w.count(k) for k in sorted(set(w))}
    comm = all(sgn(a, b, e8) == sgn(b, a, e8) for a in span for b in span)
    sq = all(sgn(a, a, e8) == 1 for a in span)
    iso = all(Q(a, e8) == 0 for a in span) and all(polar(a, b, e8) == 0 for a in span for b in span)
    dual = {v for v in range(256) if all(pc(v & c) % 2 == 0 for c in span)}
    row('core·B11', 'checked', f'Furey\'s seven Fano-line blades g_a g_b g_c g_8 in Cl(0,8) span {len(span)} labels with weights {enum} (the extended Hamming code [8,4,4], doubly even and self-dual), commute and square to +1: a Lagrangian (maximal isotropic, dimension 4 = n/2) of Q_Cl(0,8); the 16 coordinate axes of V are its characters', len(span) == 16 and enum == {0: 1, 4: 14, 8: 1} and comm and sq and iso and dual == span)

# ================================================================ B12: symmetry of (V, Q, pi): where an order-3 element can come from
def B12():
    data = {}; ok = True
    for n in range(2, 6):
        for p in range(n + 1):
            q = n - p; e = sig(p, q); Qt = Qtable(e); Pt = Ptable(n)
            a = isometries(Qt, Qt, n); b = isometries(Qt, Qt, n, Pt, Pt)
            data[f'{p},{q}'] = [a, b]
            if (b % 3 == 0) != (max(p, q) >= 3): ok = False
    DATA['aut_V_Q_pi'] = data
    row('core·B12', 'checked', 'size of O(V,Q) (isometries of the F_2 form) and of Aut(V,Q,pi) (those that also keep the parity), every Cl(p,q), n = 2..5 (data table): 3 divides |Aut(V,Q,pi)| exactly when three generators have the same sign (a cyclic permutation of them); in Cl(0,2) = H, O(V,Q) = S_3 permutes i, j, k but only order 2 keeps pi. An order-3 symmetry is cheap; compatibility with the matter data is the question', ok and data['0,2'] == [6, 2])

# ================================================================ B13: Gauss-Milgram phase of the discriminant form of E_n = signature mod 8
def cartan_E(n):
    A = [[0] * n for _ in range(n)]
    for i in range(n): A[i][i] = 2
    for i, j in [(0, 2), (1, 3), (2, 3)] + [(k, k + 1) for k in range(3, n - 1)]:
        if i < n and j < n: A[i][j] = A[j][i] = -1
    return A
def det_adj(M):
    n = len(M); Mf = [[F(x) for x in r] + [F(int(i == j)) for j in range(n)] for i, r in enumerate(M)]; d = F(1)
    for c in range(n):
        piv = next(i for i in range(c, n) if Mf[i][c] != 0)
        if piv != c: Mf[c], Mf[piv] = Mf[piv], Mf[c]; d = -d
        d *= Mf[c][c]; Mf[c] = [x / Mf[c][c] for x in Mf[c]]
        for i in range(n):
            if i != c and Mf[i][c] != 0: f = Mf[i][c]; Mf[i] = [x - f * y for x, y in zip(Mf[i], Mf[c])]
    return d, [r[n:] for r in Mf]
def B13():
    ok = True; out = {}
    for n in (3, 4, 5, 6, 7, 8):
        C = cartan_E(n); d, inv = det_adj(C); D = int(d)
        if D != 9 - n: ok = False
        # sum over the box {0..D-1}^n of exp(i pi z^T C^{-1} z) counts each class of Z^n / C Z^n D^{n-1} times; the phase in eighths of a turn is read exactly with Gaussian integers (D <= 6)
        eighths = {}
        from math import gcd
        tot = {}
        for z in itertools.product(range(D), repeat=n):
            q = sum(F(z[i]) * inv[i][j] * z[j] for i in range(n) for j in range(n)) / 2        # q(x) in Q/Z, the discriminant quadratic form
            k = (q % 1); tot[k] = tot.get(k, 0) + 1
        re = im = 0
        import math
        for k, c in tot.items(): re += c * math.cos(2 * math.pi * float(k)); im += c * math.sin(2 * math.pi * float(k))
        mag = math.hypot(re, im) / D ** (n - 1)
        ph = round((math.atan2(im, re) / (2 * math.pi)) * 8) % 8
        out[str(n)] = {'disc': D, 'phase8': ph}
        if ph != n % 8 or abs(mag - D ** 0.5) > 1e-9: ok = False
    # E10 = II_{9,1}: det -1, signature 9 - 1 = 8, trivial discriminant group, phase 0
    d10, _ = det_adj(cartan_E(10)); out['10'] = {'disc': int(abs(d10)), 'signature': 8, 'phase8': 0}
    if int(d10) != -1: ok = False
    DATA['milgram_E'] = out
    row('core·B13', 'checked', 'for the even lattices E_3..E_8 the Gauss sum of the discriminant form (order 9 - n) has modulus sqrt(9 - n) and phase 2 pi n / 8, i.e. signature mod 8, the same Z_8 as the clock p - q mod 8 of Cl(n,0); det E_10 = -1 (even unimodular, signature (9,1), 9 - 1 = 8 = 0 mod 8). Supports the open item "is the E_n stop related to period 8"; it does not settle it (the stop itself is det = 9 - n)', ok)

# ================================================================ B14: the top blade, central for odd n; squares to +1 (splits) only if r = 0 and p - q = 1 mod 4
def B14():
    ok = True; table = {}
    for n in range(1, 8, 2):
        for r in range(0, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); top = (1 << n) - 1
                central = all(sgn(top, 1 << i, e) == sgn(1 << i, top, e) for i in range(n))
                sq = sgn(top, top, e)
                want = 0 if r else (1 if (p - q) % 4 == 1 else -1)
                if not central or sq != want: ok = False
                table[f'{p},{q},{r}'] = sq
    DATA['top_blade_square'] = table
    row('core·B14', 'checked', 'for odd n the top blade is central in every Cl(p,q,r) and squares to +1 exactly when r = 0 and p - q = 1 mod 4 (it splits the algebra in two: Cl(1,0), Cl(2,1), Cl(3,2), Cl(4,3), the signed cells [n,+1]), to -1 for the mirrors, and to 0 whenever r >= 1: in the null-spectator algebras Cl(0,0,1), Cl(1,1,1), Cl(2,2,1) it is central, nilpotent and splits nothing; n <= 7', ok and table['0,0,1'] == 0 and table['1,1,1'] == 0 and table['2,2,1'] == 0 and table['4,3,0'] == 1)

# ================================================================ B15: S_{n+1} permuting the n+1 positive generators acts on the labels of Cl(0,n) = Cl0(n+1,0) by isometries of Q
def B15():
    ok = True; sizes = []
    for n in range(2, 9):
        N = n + 1; t = n                                    # generators e_0 .. e_{n-1} and e_t = e_n of Cl(n+1, 0)
        big = [1] * N; small = [-1] * n
        def phi(a):                                         # label a of Cl(0,n) -> the even label of Cl(n+1,0): f_a = f_i1 f_i2 ... with f_i = e_i e_t is +- e_{phi(a)}
            return a ^ ((pc(a) % 2) << t)
        for a in range(1 << n):                             # f_a really is +- the even blade e_phi(a), and its square is Q of Cl(0,n)
            s_, lab = 1, 0
            for i in range(n):
                if a >> i & 1:
                    for g in (1 << i, 1 << t):
                        s_ *= sgn(lab, g, big); lab ^= g
            if lab != phi(a) or abs(s_) != 1: ok = False
            if Q(a, small) != Q(phi(a), big): ok = False
        phi_inv = {phi(a): a for a in range(1 << n)}
        for i in range(N - 1):                              # adjacent transpositions generate S_{n+1}
            def perm(x):
                y = x & ~((1 << i) | (1 << (i + 1)))
                if x >> i & 1: y |= 1 << (i + 1)
                if x >> (i + 1) & 1: y |= 1 << i
                return y
            for a in range(1 << n):
                b = phi_inv[perm(phi(a))]
                if Q(b, small) != Q(a, small): ok = False
        sizes.append(n)
    row('core·B15', 'checked', 'S_{n+1}, permuting the n+1 generators of Cl(n+1,0), acts on the even labels, which are the labels of Cl(0,n) = Cl0(n+1,0) through f_i = e_i e_{n+1}, by isometries of Q_{Cl(0,n)}; f_a = +- e_{a + parity(a) e_{n+1}} and the square of f_a equals the square of that blade (n = 2..8). So "S_{n+1} permutes the positive generators" is a theorem, not a reading; that it fills O(Q) only for n <= 5 stays as groups_check.py has it', ok)

# ================================================================ B16: Kepler (Baez) against the projective step: opposite printed squares, the same three algebras
def mv_mul(A, B, eps):
    out = {}
    for a, ca in A.items():
        for b, cb in B.items():
            c = ca * cb * sgn(a, b, eps)
            if c: out[a ^ b] = out.get(a ^ b, 0) + c
    return {k: v for k, v in out.items() if v != 0}
def bivector_basis(n): return [(1 << i) | (1 << j) for i in range(n) for j in range(i + 1, n)]
def structure(eps):
    """structure constants c[x][y] = {z: coefficient} of the commutator [B_x, B_y] of the bivector blades in the basis of bivector blades (it must close on them)"""
    biv = bivector_basis(len(eps)); c = {}
    for x in biv:
        for y in biv:
            xy, yx = mv_mul({x: F(1)}, {y: F(1)}, eps), mv_mul({y: F(1)}, {x: F(1)}, eps)
            comm = {k: xy.get(k, 0) - yx.get(k, 0) for k in set(xy) | set(yx)}
            comm = {k: v for k, v in comm.items() if v != 0}
            if any(k not in biv for k in comm): return None
            c[(x, y)] = comm
    return biv, c
def signature_of(M):
    """(positive, negative, zero) of a symmetric rational matrix by exact congruence diagonalisation"""
    n = len(M); A = [[F(x) for x in r] for r in M]; pos = neg = 0; active = list(range(n))
    while active:
        piv = next((i for i in active if A[i][i] != 0), None)
        if piv is None:
            pair = next(((i, j) for i in active for j in active if i < j and A[i][j] != 0), None)
            if pair is None: break
            i, j = pair
            for k in range(n): A[i][k] += A[j][k]
            for k in range(n): A[k][i] += A[k][j]
            piv = i
            if A[i][i] == 0: break
        d = A[piv][piv]
        if d > 0: pos += 1
        else: neg += 1
        for i in active:
            if i != piv and A[i][piv] != 0:
                f = A[i][piv] / d
                for k in range(n): A[i][k] -= f * A[piv][k]
                for k in range(n): A[k][i] -= f * A[k][piv]
        active.remove(piv)
    return (pos, neg, len(M) - pos - neg)
def killing_signature(eps):
    st = structure(eps)
    if st is None: return None
    biv, c = st; m = len(biv); idx = {b: k for k, b in enumerate(biv)}
    ad = []
    for x in biv:
        Mx = [[F(0)] * m for _ in range(m)]
        for y in biv:
            for z, v in c[(x, y)].items(): Mx[idx[z]][idx[y]] += v
        ad.append(Mx)
    K = [[sum(ad[i][r][t] * ad[j][t][r] for r in range(m) for t in range(m)) for j in range(m)] for i in range(m)]
    return signature_of(K)
def B16():
    sig_b = {e: killing_signature([1, 1, 1, e]) for e in (1, 0, -1)}         # Baez: base squares +1, fourth generator epsilon
    sig_s = {s: killing_signature([-1, -1, -1, s]) for s in (-1, 0, 1)}      # projective step: base squares -1, extra generator s
    want = {1: (0, 6, 0), 0: (0, 3, 3), -1: (3, 3, 0)}                       # so(4), e(3), so(3,1) for epsilon = +1, 0, -1
    ok = all(sig_b[e] == want[e] for e in sig_b) and all(sig_s[s] == want[-s] for s in sig_s)
    ok2 = True; planes = {}
    for e in (1, 0, -1):
        eb, es = [1, 1, 1, e], [-1, -1, -1, -e]
        sb, ss = structure(eb), structure(es)
        if sb is None or ss is None or sb[0] != ss[0]: ok2 = False; continue
        if any({z: -v for z, v in sb[1][k].items()} != ss[1][k] for k in sb[1]): ok2 = False      # [B_x, B_y]' = -[B_x, B_y]: B -> -B is a Lie algebra isomorphism
        planes[str(e)] = [sgn(b_, b_, eb) for b_ in (0b1001, 0b1010, 0b1100)]                    # squares of the three bivectors that carry the fourth generator
        if planes[str(e)] != [-e] * 3 or [sgn(b_, b_, es) for b_ in (0b1001, 0b1010, 0b1100)] != [-e] * 3: ok2 = False
    DATA['kepler_step9'] = {'killing_signature_baez': {str(e): list(v) for e, v in sig_b.items()}, 'killing_signature_step9': {str(s): list(v) for s, v in sig_s.items()}, 'fourth_generator_bivector_squares': planes}
    row('core·B16', 'checked', 'Kepler (Baez) against the projective step: the algebras with generator squares (+1,+1,+1,eps) (Baez: base +1, fourth generator eps) and (-1,-1,-1,s) (projective step: base -1, extra generator s) have the Killing form of their six bivectors of signature (positive, negative, zero) = (0,6,0), (0,3,3), (3,3,0) for eps = +1, 0, -1 and for s = -1, 0, +1 (exact rationals): the same three algebras so(4), e(3), so(3,1) with eps = -s. The printed squares have opposite signs; B -> -B is a Lie algebra isomorphism between the bivector algebras of (+1,+1,+1,eps) and (-1,-1,-1,-eps) (every commutator of two bivector blades has the opposite coefficients), and the three bivectors that carry the fourth generator square to -eps in both conventions: the classes of the bivectors (rotation for eps = +1, translation for 0, boost for -1) agree', ok and ok2)

# ================================================================ B17: the reversion of Cl(p,q) is not the restriction of the reversion of the all-positive cell
def rev_mv(A):
    """reversion of the all-positive cell: a blade of grade k gets (-1)^(k(k-1)/2)"""
    return {m: c * (-1) ** (pc(m) * (pc(m) - 1) // 2) for m, c in A.items()}
def B17():
    ok = True; nrel = nrot = 0; image = {}
    for n in range(1, 6):
        for q in range(1, n + 1):
            p = n - q; big = [1] * (n + 2); P = mv_mul({1 << n: F(1)}, {1 << (n + 1): F(1)}, big)
            if mv_mul(P, P, big) != {0: F(-1)}: ok = False
            gens = [{1 << j: F(1)} if j < p else mv_mul({1 << j: F(1)}, P, big) for j in range(n)]       # a negative generator e_j becomes f_j = e_j P
            for j, g in enumerate(gens):
                if mv_mul(g, g, big) != {0: F(1 if j < p else -1)}: ok = False                            # f_j squares to the sign of its generator
                for i in range(j):
                    a, b = mv_mul(gens[i], g, big), mv_mul(g, gens[i], big)
                    if any(a.get(k, 0) + b.get(k, 0) for k in set(a) | set(b)): ok = False                # the images anticommute
                if rev_mv(g) != (g if j < p else {k: -v for k, v in g.items()}): ok = False               # the restricted reversion negates every negative generator; the reversion of Cl(p,q) fixes each generator
            nrel += 1
            if p < 1: continue                                                                            # a (+,-) plane needs a positive and a negative generator
            B = mv_mul(gens[0], gens[p], big)                                                            # B = f_0 f_p, B^2 = +1
            if mv_mul(B, B, big) != {0: F(1)}: ok = False
            R = {0: F(5, 4), **{k: F(3, 4) * v for k, v in B.items()}}                                   # R = cosh t + B sinh t with cosh t = 5/4, sinh t = 3/4
            Rt = {0: F(5, 4), **{k: F(-3, 4) * v for k, v in B.items()}}                                 # the reversion of Cl(p,q) reverses f_0 f_p to f_p f_0 = -B
            if mv_mul(R, Rt, big) != {0: F(1)}: ok = False                                               # R R~ = 1 in Cl(p,q): a boost
            prod = mv_mul(R, rev_mv(R), big)
            if prod != {0: F(17, 8), **{k: F(15, 8) * v for k, v in B.items()}}: ok = False              # R R^dagger = 17/8 + (15/8) B, not 1
            image[f'{p},{q}'] = {str(k): str(v) for k, v in sorted(prod.items())}
            nrot += 1
    DATA['reversion_not_restricted'] = image
    row('core·B17', 'checked', f'the all-positive cell does not carry the reversion: with f_j = e_j P (P = e_(n+1) e_(n+2), P^2 = -1) in place of each negative generator of Cl(p,q), the images satisfy the Clifford relations of Cl(p,q) ({nrel} cells, 1 <= q <= n <= 5), the reversion of Cl(n+2,0) sends every negative f_j to -f_j while the reversion of Cl(p,q) fixes every generator, and a boost rotor R = cosh t + B sinh t of a (+,-) plane ({nrot} cells) has R R~ = 1 in Cl(p,q) but R R^dagger = 17/8 + (15/8) B, not 1, for the involution restricted from Cl(n+2,0). This is a statement about algebras with their grading; the reversion, and with it rotors and norms, is not preserved', ok)

def run():
    for f in (B1, B2, B3, B4, B5, B5c, B6, B7, B8, B9, B10, B10c, B11, B12, B13, B14, B15, B16, B17): f()
    return {'rows': ROWS, 'data': DATA, 'summary': {'rows': len(ROWS), 'ok': sum(r['ok'] for r in ROWS)}}

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--write'); ap.add_argument('--compare'); a = ap.parse_args()
    d = run()
    print(f"\n{d['summary']['ok']}/{d['summary']['rows']} core checks hold." + ('  ALL CORE CHECKS PASS' if d['summary']['ok'] == d['summary']['rows'] else '  SOME CHECK FAILED'))
    if a.write: json.dump(d, open(a.write, 'w'), indent=1, ensure_ascii=False); print('wrote', a.write)
    if a.compare: assert json.load(open(a.compare)) == json.loads(json.dumps(d)), 'the stored core data differs from the rebuilt data'; print('stored data == rebuilt data')
    sys.exit(0 if d['summary']['ok'] == d['summary']['rows'] else 1)
