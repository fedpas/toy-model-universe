// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { parseMath, isVariable, scriptIsLabel, visibleText } from './mathTextCore.js';

// <Tx>{text}</Tx> draws the formulas that sit inside a sentence: D^μF_{μν} = J_ν becomes D with a superscript μ, F with a subscript μν, math letters in italic.
// Text without a formula comes back untouched (the same string), other children pass through. The rules live in mathTextCore.js.
const CSS = `.mt{font-family:"STIX Two Text","STIX Two Math","Cambria Math","Latin Modern Math","Times New Roman",serif;font-size:1.07em;line-height:1;color:inherit}
.mt i{font-style:italic}.mt-s{white-space:nowrap}
.mt sub,.mt sup{font-size:.7em;line-height:0;position:relative;vertical-align:baseline}.mt sup{top:-.48em}.mt sub{top:.26em}
.mt .mt-st{display:inline-flex;flex-direction:column;vertical-align:-.5em;font-size:.7em;line-height:1.05;text-align:left}
.mt .mt-st sub,.mt .mt-st sup{font-size:1em;position:static;top:auto}`;
if (typeof document !== 'undefined' && !document.getElementById('mt-style')) { const st = document.createElement('style'); st.id = 'mt-style'; st.textContent = CSS; document.head.appendChild(st); }

const Chars = ({ s, upright }) => {
  const out = []; let buf = '', ital = false, n = 0;
  const flush = () => { if (!buf) return; out.push(ital && !upright ? <i key={n++}>{buf}</i> : buf); buf = ''; };
  for (const ch of s) { const v = /\p{M}/u.test(ch) ? ital : isVariable(ch); if (v !== ital) { flush(); ital = v; } buf += ch; }   // a combining mark (M̃, σ⃗) stays with its letter
  flush(); return <>{out}</>;
};
const Script = ({ text }) => {
  if (scriptIsLabel(text)) return <Chars s={text} upright />;
  const nodes = parseMath(text);
  return <>{nodes.map((x, i) => (x.k === 'text' ? <Chars key={i} s={x.s} /> : <Run key={i} run={x} />))}</>;
};
const Sym = ({ p }) => {
  const sub = p.sub ? <sub><Script text={p.sub} /></sub> : null, sup = p.sup ? <sup><Script text={p.sup} /></sup> : null;
  return <span className="mt-s"><Chars s={p.base} upright={p.named} />{sub && sup ? <span className="mt-st">{sup}{sub}</span> : <>{sup}{sub}</>}</span>;
};
const Run = ({ run }) => <span className="mt" data-raw={run.raw}>{run.parts.map((p, i) => (p.k === 'sym' ? <Sym key={i} p={p} /> : <Chars key={i} s={p.s} />))}</span>;

const cache = new Map();
const typeset = s => {
  let r = cache.get(s);
  if (r === undefined) {
    const nodes = parseMath(s);
    r = nodes.length === 1 && nodes[0].k === 'text' ? s : nodes.map((x, i) => (x.k === 'text' ? <React.Fragment key={i}>{x.s}</React.Fragment> : <Run key={i} run={x} />));
    if (cache.size > 5000) cache.clear();
    cache.set(s, r);
  }
  return r;
};
const walk = c => (typeof c === 'string' ? typeset(c) : Array.isArray(c) ? c.map((x, i) => (typeof x === 'string' ? <React.Fragment key={'m' + i}>{typeset(x)}</React.Fragment> : x)) : c);
export function Tx({ children }) { return <>{walk(children)}</>; }

// SVG labels (<text>) cannot hold HTML: <SvgTx>{'Q_L'}</SvgTx> draws the script as a smaller <tspan> moved down (sub) or up (sup) with dy,
// followed by a zero-width <tspan> that moves back to the baseline (dy rather than baseline-shift, which not every browser draws).
const SF = 0.72, DSUB = 0.25, DSUP = -0.42;
export function SvgTx({ children }) {
  const s = children; if (typeof s !== 'string') return s ?? null;
  const nodes = parseMath(s); if (nodes.length === 1 && nodes[0].k === 'text') return s;
  const out = []; let k = 0;
  const put = x => out.push(<React.Fragment key={k++}>{x}</React.Fragment>);
  const script = (t, d) => { out.push(<tspan key={k++} dy={(d / SF).toFixed(3) + 'em'} fontSize={SF * 100 + '%'}>{visibleText(parseMath(t))}</tspan>); out.push(<tspan key={k++} dy={(-d).toFixed(3) + 'em'}>{'\u200B'}</tspan>); };
  for (const n of nodes) {
    if (n.k === 'text') { put(n.s); continue; }
    for (const p of n.parts) { if (p.k !== 'sym') { put(p.s); continue; } put(p.base); if (p.sup) script(p.sup, DSUP); if (p.sub) script(p.sub, DSUB); }
  }
  return <>{out}</>;
}
export default Tx;
