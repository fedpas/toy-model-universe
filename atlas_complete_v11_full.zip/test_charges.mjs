// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import M from './maxwellData.js';
import { TERMS, FIELDS, force, SPEC, PRESET_IDS, defaults, initRun, advance, readout } from './chargeEngine.js';
let bad = 0; const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };
const CH = M.charges, S = JSON.parse(fs.readFileSync('./selfcheck/maxwell.json', 'utf8')).charges;
ok(JSON.stringify(CH) === JSON.stringify(S), 'charges data equals the rebuilt JSON');
ok(CH.sign === 1 && CH.counts.exact === 9 && CH.counts.numeric === 5 && CH.rows.length === 14, 'rows: 9 exact and 5 numeric');
ok(CH.rows.filter(r => r.kind === 'exact').map(r => r.id).join() === 'force_is_grade1,force_is_contraction,speed_limit,circle_and_hyperbola,drift_frame,invariants,parallel,point_charge,light_wave', 'exact rows');
ok(['2', '3', '4'].every(d => CH.worlds[d].terms.length === (+d + 1) * +d), 'terms: two per edge, n(n-1) in all');
ok(CH.worlds['2'].incidence_ratio === -1 && CH.worlds['3'].incidence_ratio === -1 && CH.worlds['4'].incidence_ratio === -1, 'force terms are the contract incidences up to the fixed sign rule');

// ---- the table against an independent Clifford product (bit rule: XOR with a sign, generator 0 squares to +1 and the others to -1)
const pc = m => (m.toString(2).match(/1/g) || []).length;
const prod = (a, b) => { let s = 1; for (let t = a >> 1; t; t >>= 1) if (pc(t & b) % 2) s = -s; let c = a & b, i = 0; while (c) { if (c & 1) s *= i < 1 ? 1 : -1; c >>= 1; i++; } return [a ^ b, s]; };
const gp = (A, B) => { const R = {}; for (const [a, x] of Object.entries(A)) for (const [b, y] of Object.entries(B)) { const [m, s] = prod(+a, +b); R[m] = (R[m] || 0) + s * x * y; } return R; };
const cell = M.cells['1,3'], order = cell.conventions.field_order, sg = cell.conventions.signs, mask = {}; cell.incidences.forEach(i => { mask[i.field] = i.source; });
const rnd = (() => { let a = 12345; return () => { a = (a * 1103515245 + 12345) & 0x7fffffff; return (a % 2001) / 100 - 10; }; })();
for (let trial = 0; trial < 40; trial++) {
  const f = {}; FIELDS.forEach(n => { f[n] = rnd(); }); const u = [rnd(), rnd(), rnd(), rnd()];
  const F6 = FIELDS.map(n => f[n]), got = force(F6, u);
  const F = {}; FIELDS.forEach(n => { F[mask[n]] = sg[order.indexOf(n)] * f[n]; });
  const U = {}; u.forEach((x, a) => { U[1 << a] = a === 0 ? x : -x; });
  const A = gp(F, U), B = gp(U, F), want = [0, 1, 2, 3].map(a => ((A[1 << a] || 0) - (B[1 << a] || 0)) / 2 * (a === 0 ? 1 : -1));
  ok(want.every((x, a) => Math.abs(x - got[a]) < 1e-9), `force table vs Clifford product ${trial}`);
  const tb = [F6[0] * u[1] + F6[1] * u[2] + F6[2] * u[3], u[0] * F6[0] + F6[5] * u[2] - F6[4] * u[3], u[0] * F6[1] - F6[5] * u[1] + F6[3] * u[3], u[0] * F6[2] + F6[4] * u[1] - F6[3] * u[2]];
  ok(tb.every((x, a) => Math.abs(x - got[a]) < 1e-9), `force table vs textbook ${trial}`);
  ok(Math.abs(got[0] * u[0] - got[1] * u[1] - got[2] * u[2] - got[3] * u[3]) < 1e-8, 'force is perpendicular to u');
}

// ---- the runs against the numeric rows of the script
const run = (id, p, T, dt = 0.1) => { const r = initRun(id, p); for (let t = 0; t < T; t += dt) advance(r, p, dt); return r; };
{ const p = { ...defaults('circle') }, r = run('circle', p, 12), o = readout(r, p); ok(o.check && Math.abs(o.check.measured - o.check.formula) < 1e-6 && Math.abs(o.check.formula - CH.numeric.cyclotron.radius_formula) < 1e-6, `circle radius ${o.check && o.check.measured} vs ${CH.numeric.cyclotron.radius_formula}`); ok(Math.abs(o.u2) < 1e-9, 'circle u.u'); }
{ const p = { ...defaults('hyper') }, r = run('hyper', p, 9.99), o = readout(r, p); ok(o.check.diff < 1e-6 && o.speed < 1 && o.check.newton > 1, `hyper diff ${o.check.diff}`); ok(Math.abs(o.u2) < 1e-8, 'hyper u.u'); }
{ const p = { ...defaults('crossed') }, r = run('crossed', p, 90), o = readout(r, p); ok(o.check.kind === 'drift' && o.check.measured !== null && Math.abs(o.check.measured - 0.6) < 1e-6, `drift ${o.check.measured}`); ok(Math.abs(o.u2) < 1e-8, 'drift u.u');
  const p2 = { ...p, rho: 1.3 }, r2 = run('crossed', p2, 40), o2 = readout(r2, p2); ok(o2.check.kind === 'runaway' && o2.speed > 0.97, `runaway speed ${o2.speed}`); }
{ const p = { ...defaults('spiral') }, r = run('spiral', p, 30), o = readout(r, p); ok(o.check.diff < 1e-6 * Math.max(1, Math.abs(o.check.formula)), `spiral diff ${o.check.diff} of ${o.check.formula}`); ok(Math.abs(o.u2) < 1e-6 * o.gamma * o.gamma, 'spiral u.u'); }
{ const p = { ...defaults('orbit') }, r = run('orbit', p, 70, 0.05), o = readout(r, p); const L = o.check.L, form = 360 * (1 / Math.sqrt(1 - p.kappa * p.kappa / (L * L)) - 1);
  ok(o.check.kind === 'orbit' && o.check.measured !== null && Math.abs(o.check.measured - o.check.formula) < 0.05 && Math.abs(o.check.formula - form) < 1e-9, `orbit (default) ${o.check && o.check.measured} vs ${o.check && o.check.formula}`); ok(Math.abs(o.u2) < 1e-7, 'orbit u.u');
  // the starting speed of the script's numeric row: the same number as in the data
  const q = { ...p, v0: 0.5 }, r5 = run('orbit', q, 60, 0.05), o5 = readout(r5, q); ok(o5.check.measured !== null && Math.abs(o5.check.measured - CH.numeric.relativistic_orbit.advance_degrees_formula) < 0.01 && Math.abs(o5.check.formula - CH.numeric.relativistic_orbit.advance_degrees_formula) < 1e-3, `orbit (script) ${o5.check.measured} vs ${CH.numeric.relativistic_orbit.advance_degrees_formula}`);
  const p3 = { ...p, kappa: 0.5 }, r3 = initRun('orbit', p3); ok(readout(r3, p3).check === null, 'no claim before the run starts');
  const p4 = { ...p, v0: 0.1, kappa: 0.5 }, r4 = run('orbit', p4, 10, 0.05); ok(readout(r4, p4).check.kind === 'falls', 'kappa above L: falls in');
  const p6 = { ...p, kappa: -0.3 }, r6 = run('orbit', p6, 10, 0.05); ok(readout(r6, p6).check.kind === 'repulsive' && readout(r6, p6).speed < 1, 'repulsion: scattered'); }
{ const p = { ...defaults('wave') }, r = run('wave', p, 40), o = readout(r, p); ok(o.check.diff < 1e-6 && Math.abs(o.check.conserved - 1) < 1e-8 && o.check.measured !== null && Math.abs(o.check.measured - 0.36) < 1e-5, `wave ${JSON.stringify(o.check)}`); }
// L3-003 (M14): the closed form printed beside the wave run is a^2 / (4 + a^2), derived here, not read from the engine: u_t - u_z = 1 and u_x = a sin(tau) give <u_z> = a^2/4, so <u_z>/<u_t> = (a^2/4) / (1 + a^2/4)
for (const a of [0.5, 1, 1.5, 2, 3]) { const p = { ...defaults('wave'), a }, r = run('wave', p, 40), o = readout(r, p), want = a * a / (4 + a * a);
  ok(Math.abs(o.check.formula - want) < 1e-12 && o.check.measured !== null && Math.abs(o.check.measured - want) < 2e-3, `wave a=${a}: printed formula ${o.check.formula}, measured ${o.check.measured}, derived ${want}`); }
// a change of the fields in flight: the closed forms stop being claimed, the invariants still hold
{ const p = { ...defaults('circle') }, r = initRun('circle', p); for (let i = 0; i < 40; i++) advance(r, p, 0.1); r.changed = true; const p2 = { ...p, B: 2 }; for (let i = 0; i < 60; i++) advance(r, p2, 0.1); const o = readout(r, p2); ok(o.check === null && Math.abs(o.u2) < 1e-9, 'live change: no closed-form claim, u.u still 1'); }
// the speed limit: a strong field never gives speed 1
for (const id of PRESET_IDS) { const p = defaults(id), r = run(id, p, 20, 0.1), o = readout(r, p); ok(o.speed < 1 && Number.isFinite(o.speed), `${id} speed below 1`); }
console.log(bad ? `${bad} FAILURES` : 'ALL CHARGES TESTS PASS'); process.exit(bad ? 1 : 0);
