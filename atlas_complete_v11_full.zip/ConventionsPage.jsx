// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { CONV } from './conventionsCopy.js';
import ConventionsSection from './ConventionsSection.jsx';
import { LabelsFrame, ClockTab, LABELS_STYLE } from './LabelsTabs.jsx';
import { TabBar, TabPanel, useSub } from './StoryShell.jsx';

// The Conventions page (page 3): two tabs. The first, Conventions (not a numbered step), states the choices of words, the invariants, the ideas and the glossary
// (conventionsCopy.js, ConventionsSection.jsx). The second is Step 1, the clock and the trinity (labelsCopy.js tabs.clock), the first step of the story: every later page uses it.
// The tab frame (glance, eyebrow, lede) is the one of the other two steps of the labels, which sit on the equations page (gauge gravity) and on the lenses page (the finite groups).
export default function ConventionsPage({ lang, profile, go }) {
  const L = lang === 'it' ? 'it' : 'en', yl = profile === 'Young Learner', [sub, setSub] = useSub('conventions'), c = CONV[L];
  return <><style>{LABELS_STYLE}</style><TabBar lang={L} page="conventions" active={sub} onPick={setSub} profile={profile} />
    <TabPanel lang={L} page="conventions" id={sub} onPick={setSub} goMap={go} profile={profile} ownGlance>
      {sub === 'clock'
        ? <ClockTab lang={L} profile={profile} words={() => setSub('conventions')} />
        : <LabelsFrame lang={L} profile={profile} c={c} id="cv-conventions" eyebrow={yl ? c.eyebrowY : c.eyebrow} body={<ConventionsSection lang={L} yl={false} />} fold={<ConventionsSection lang={L} yl />} />}</TabPanel></>;
}
