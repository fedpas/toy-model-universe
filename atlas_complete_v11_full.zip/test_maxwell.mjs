// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import M from './maxwellData.js';
import {MAXWELL_PY} from './maxwellSelfcheckSource.js';
import {cliffordCell} from './genesis_audit_v3.js';
import { STORY } from './storyCopy.js';
import { SHORT } from './audienceCopy.js';
const M_PY_SRC = fs.readFileSync('./selfcheck/maxwell_selfcheck.py', 'utf8');
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}};
const J=JSON.parse(fs.readFileSync('./selfcheck/maxwell.json','utf8'));
ok(JSON.stringify(J)===JSON.stringify(JSON.parse(JSON.stringify(M))),'data equals rebuilt JSON');
ok(MAXWELL_PY===fs.readFileSync('./selfcheck/maxwell_selfcheck.py','utf8'),'embedded script equals file');
const norm=t=>t.replace(/[²2]$/,'');
// space ladder Cl(1,d) and time ladder Cl(k,1) against the independent JS engine
for(const l of M.ladder){const c=cliffordCell(l.p,l.q);ok(c.N===l.matrix_size&&norm(c.kind)===norm(l.type),`Cl(${l.p},${l.q})`)}
for(const l of M.time_ladder){const c=cliffordCell(l.k,1);ok(c.N===l.matrix_size&&norm(c.kind)===norm(l.type),`Cl(${l.k},1) ${c.kind}${c.N} vs ${l.type}${l.matrix_size}`);
 const m=cliffordCell(1,l.k);ok(m.N===l.mirror_matrix_size&&norm(m.kind)===norm(l.mirror_type),`mirror Cl(1,${l.k})`)}
// period 8 along time: Cl(k+8,1) = Cl(k,1) tensor M16(R)
for(let k=1;k<=11;k++){const a=cliffordCell(k,1),b=cliffordCell(k+8,1);ok(a.kind===b.kind&&b.N===16*a.N,`period 8 at k=${k}`)}
ok(M.ladder.map(l=>l.equations_total).join()==='1,2,4,8,15,26,42,64,93','equation counts n+C(n,3)');
ok(M.time_ladder.map(l=>l.equations_total).join()==='2,4,8,15,26,42,64,93,130','time-ladder equation counts');
// independent blade product: generators below k square +1, the rest -1
const pc=m=>(m.toString(2).match(/1/g)||[]).length;
const prod=(a,b,k)=>{let s=1;for(let t=a>>1;t;t>>=1)if(pc(t&b)%2)s=-s;let c=a&b,i=0;while(c){if(c&1)s*=i<k?1:-1;c>>=1;i++}return[a^b,s]};
const C=(n,r)=>r<0||r>n?0:r===0?1:n*C(n-1,r-1)/r;
const incExp={2:2,3:9,4:24,5:50,6:90,7:147};
const byN={};
for(const key of Object.keys(M.cells)){const D=M.cells[key],k=D.k,d=D.d,n=k+d;
 ok(key===`${k},${d}`&&D.n===n&&D.blades.length===1<<n,`${key} blades`);
 ok(D.counts.E===k*d&&D.counts.T===C(k,2)&&D.counts.B===C(d,2),`${key} field counts`);
 const order=D.conventions.field_order,sg=D.conventions.signs,sF={};
 D.incidences.forEach(i=>{sF[i.source]=sg[order.indexOf(i.field)]});
 ok(D.incidences.length===incExp[n],`${key} incidences ${D.incidences.length}`);
 for(const i of D.incidences){const[m,s]=prod(1<<i.axis,i.source,k);ok(m===i.target&&s*sF[i.source]===i.sign,`${key} ${i.field} d${i.axis_name}`);ok((i.source^(1<<i.axis))===i.target,'XOR rule')}
 ok(D.equations.length===n+C(n,3),`${key} equations`);
 for(const e of D.equations){const tt=D.incidences.filter(i=>i.target===e.target).length;ok(e.terms.length===tt,`${key} terms ${e.id}`);ok(e.op==='contract'?e.terms.length===n-1:e.terms.length===3,`${key} term count by op ${e.id}`)}
 ok(D.cube.edges.length===n*2**(n-1)&&D.cube.edges.every(([a,b,ax])=>(a^b)===(1<<ax)),`${key} cube`);
 ok(D.conventions.found===2&&D.checks.conventions===2,`${key} two conventions`);
 ok(D.checks.wave_equation&&D.checks.only_grades_1_and_3&&D.checks.charge_conservation,`${key} checks`);
 // symbol class
 const mn=Math.min(k,d),cl=mn===0?'elliptic':mn===1?'hyperbolic':'ultrahyperbolic';ok(D.symbol.class===cl,`${key} symbol ${D.symbol.class}`);
 // algebra against independent engine
 const c=cliffordCell(k,d);ok(c.N===D.algebra.matrix_size&&norm(c.kind)===norm(D.algebra.type),`${key} algebra`);
 // mirror
 ok(D.mirror.mirror_of[0]===d&&D.mirror.mirror_of[1]===k&&D.mirror.vector_equations_factor===-1&&D.mirror.triple_equations_factor===(n>=3?1:null),`${key} mirror factors`);
 (byN[n]=byN[n]||[]).push(D);}
// same n => same incidence structure (source, axis, target) in every split
for(const n in byN){const sets=byN[n].map(D=>JSON.stringify(D.incidences.map(i=>[i.source,i.axis,i.target]).sort()));ok(new Set(sets).size===1,`n=${n} same incidence set across splits`)}
ok(Object.keys(M.cells).length===15,'fifteen cells k,d<=4 and k+d<=7');
// Maxwell k=1 physical facts
const by3=Object.fromEntries(M.cells['1,3'].equations.map(e=>[e.id,e]));
ok(by3.gauss.terms.join()==='+∂xEx,+∂yEy,+∂zEz','3D Gauss terms');
ok(M.cells['1,3'].equations.filter(e=>e.id.startsWith('far_')).length===3,'3D Faraday count');
ok(M.cells['1,4'].equations.filter(e=>e.id.startsWith('far_')).length===6&&M.cells['1,4'].equations.filter(e=>e.id.startsWith('bian_')).length===4,'d=4 Faraday/Bianchi counts');
// first genuinely new regime
ok(Object.values(M.cells).filter(c=>c.symbol.class==='ultrahyperbolic').map(c=>`${c.k},${c.d}`).sort().join()==='2,2,2,3,2,4,3,2,3,3,3,4,4,2,4,3','ultrahyperbolic cells');
// the n = 6, 7 cells: (3,3) is self-mirror; the (3,4)/(4,3) mirror pair has different algebras
{const g=(k,d)=>M.cells[`${k},${d}`];
 ok(g(3,3).algebra.type==='R'&&g(3,3).algebra.matrix_size===8&&g(3,3).mirror.mirror_of.join()==='3,3'&&!g(3,3).algebra.splits_in_two,'(3,3)');
 ok(g(4,3).algebra.type==='R2'&&g(4,3).algebra.matrix_size===8&&g(4,3).algebra.splits_in_two&&g(4,3).algebra.pseudoscalar_square===1,'(4,3) splits');
 ok(g(3,4).algebra.type==='C'&&g(3,4).algebra.matrix_size===8&&!g(3,4).algebra.splits_in_two&&g(3,4).algebra.pseudoscalar_central&&g(3,4).algebra.pseudoscalar_square===-1,'(3,4) does not split');
 ok(g(3,3).counts.E===9&&g(3,3).counts.T===3&&g(3,3).counts.B===3&&g(3,4).counts.E===12&&g(3,4).counts.T===3&&g(3,4).counts.B===6&&g(4,3).counts.T===6&&g(4,3).counts.B===3,'(3,3),(3,4),(4,3) counts');
 ok(g(3,3).equations.length===26&&g(3,4).equations.length===42,'equation counts at n=6,7')}
// d=7 = Cl(0,8) as algebra; splitting at d=0,4,8
{const a=cliffordCell(1,7),b=cliffordCell(0,8);ok(a.N===16&&b.N===16&&a.kind===b.kind,'Cl(1,7)=Cl(0,8)');
 ok(M.ladder.filter(l=>l.same_algebra_as_Cl08).map(l=>l.d).join()==='7','only d=7');
 ok(M.ladder.filter(l=>l.splits_in_two).map(l=>l.d).join()==='0,4,8','splits d=0,4,8');
 for(const l of M.ladder){const n=l.n,I=(1<<n)-1;let c=true;for(let a=0;a<n;a++)if(prod(I,1<<a,1)[1]!==prod(1<<a,I,1)[1])c=false;ok(c===l.pseudoscalar_central&&prod(I,I,1)[1]===l.pseudoscalar_square,`n=${n} pseudoscalar`)}
 for(const l of M.time_ladder){const n=l.n,I=(1<<n)-1;ok(prod(I,I,l.k)[1]===l.pseudoscalar_square,`time n=${n} I^2`)}}
ok(/--compare/.test(MAXWELL_PY)&&/ALL MAXWELL CHECKS PASS/.test(MAXWELL_PY),'script interface');
// the plain copy of a section lives in its .jsx file: bundle it with esbuild and read the exported object
import { buildSync } from 'esbuild';
const jsxModule = f => import('data:text/javascript;base64,' + Buffer.from(buildSync({ absWorkingDir: PKG, entryPoints: [f], bundle: true, write: false, format: 'esm', platform: 'node', loader: { '.js': 'jsx' }, logLevel: 'silent', alias: { streamdown: './stubs/streamdown.jsx', '@streamdown/math': './stubs/smath.js', 'react-katex': './stubs/katex.jsx' } }).outputFiles[0].text).toString('base64'));
const YL_COPY = [...await jsxModule('./MaxwellSection.jsx').then(m => [['maxwell views and ladders', m.MAXWELL_YL.en, m.MAXWELL_YL.it]]), ...await jsxModule('./ChargesWidget.jsx').then(m => [['maxwell charges', m.CHARGES_YL.en, m.CHARGES_YL.it]])];
// v9 Young Learner: the plain copy of this page exists in English and Italian with the same keys, the Italian does not read as English, and it holds
// no formula symbol and no technical word (the patterns are read from test_yl_ui.mjs, the acceptance test of the young learner pages)
{ const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (typeof o === 'function') { for (let a = 0; a <= 10; a++) { try { strs(o(a, a % 2 === 0, 3, 4, 5, 6), out); } catch { /* not defined for this argument */ } } } else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  for (const [name, en, it] of YL_COPY) {
    ok(en && it && JSON.stringify(shape(en)) === JSON.stringify(shape(it)), `${name}: plain copy in EN and IT with the same keys`);
    const se = strs(en), si = strs(it); ok(se.length >= 3 && se.length === si.length, `${name}: ${se.length} EN and ${si.length} IT plain strings`);
    for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `${name}: formula or technical word "${m && m[0]}" in the plain copy: ${s.slice(0, 90)}`); }
    // status keys are the same in both; v11 writes new text in English and uses it in the Italian slots too, so the one calibration sentence is listed here and nothing else is
    const EN_IN_IT = ['A warm-up is a run on something whose answer we already know. It shows what we had to put in.'];   // the Young Learner pages are named Warm-up 1 and 2, so the defining sentence says warm-up
    se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || /^(checked|standard|ours|open)$/.test(s) || EN_IN_IT.includes(s), `${name}: the Italian plain copy reads as English: ${s.slice(0, 80)}`));
    if (name === 'maxwell views and ladders') ok(en.calib === EN_IN_IT[0] && it.calib === EN_IN_IT[0] && !/calibration/i.test(en.calib + it.calib), `${name}: the defining sentence is in the plain copy, EN and IT, and says warm-up`);
  }
}
// the page's own copy (v11): Calibration 1 sentence, the wave-type note with its check, the Furey algebra statement, and the sentence that these checks can fail
{ const jsx = fs.readFileSync('./MaxwellSection.jsx', 'utf8');
  ok(jsx.includes('calib: \'A calibration is a run on something whose answer is known, to show which inputs the method needs; it is not a test of a new theory.\''), 'Maxwell: the calibration defining sentence');
  ok(/check_T18\.py part F, floating point, random search\)\. That a hyperbolic symbol gives a well-posed initial-value problem is standard PDE theory, not proved here/.test(jsx), 'Maxwell: the hyperbolic direction is checked (T18 part F); only well-posedness is standard PDE theory');
  ok(jsx.includes('whose algebra End(V) is isomorphic to Cl(0,8)'), 'Maxwell: Furey algebra End(V) is isomorphic to Cl(0,8)');
  ok((jsx.match(/title: 'Maxwell’s equations: the algebra and three notations'/g) || []).length === 2 && /in the algebra, which carries the signs, and in three notations for its labels: on a simplex, on a cube and on whole numbers; the three notations see which generators are used, not their squares\./.test(jsx) && /light up in all the views\./.test(jsx) && !/four views|four ways/.test(jsx), 'Maxwell: the page title and lede say one algebra view and three notations (EN and IT slot)');
  ok(jsx.includes('These checks can fail: for every split (k, d) of time and space'), 'Maxwell: the checks that can fail are named'); }
// the calibration is "not a test of a new theory" everywhere it is defined (the Maxwell checks can fail, so it is never "a test that could have failed" in the negative), and the signs are said to be found by search, not predicted
{ const SIGNS = 'every term and the wave equation, with the signs found by search against the textbook equations (two solutions, differing by an overall sign); nothing is predicted';
  for (const l of ['en', 'it']) { const p = STORY[l].pages; ok(p.maxwell.tags[0][1] === SIGNS && p.maxwell.tags[0][0] === 'checked standard' && /it is not a test of a new theory\.$/.test(p.maxwell.does) && /it is not a test of a new theory\.$/.test(p.furey.does) && !/could have failed/.test(JSON.stringify(p)), `${l}: the story says the signs are found by search and a calibration is not a test of a new theory`); }
  ok(/Every term and the wave equation are checked exactly, with the signs found by search against the textbook equations \(two solutions, differing by an overall sign\)/.test(SHORT.en.maxwell[1]) && !/Every term, sign and wave equation is exact/.test(SHORT.en.maxwell[1]) && /find_conventions/.test(M_PY_SRC) && /len\(matches\) == 2/.test(M_PY_SRC), 'the Mathematician reading says the signs are found by search, and the script asserts the two solutions'); }
console.log(bad?bad+' FAILURES':'ALL MAXWELL TESTS PASS');process.exit(bad?1:0)
