// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_needs.mjs: the data of the "needs and inputs" strips (inputsData.js; v11, gatherC C-013), without a browser.
//   1. the keys of NEEDS are tabs of the router (SUBS in StoryShell.jsx; the three Maxwell tabs as maxwell/<tab>); every tab has a strip except the ones named here;
//   2. every input has a kind of KINDS, a text of 40 to 230 characters ending in a full stop, and says "derived" only to say it is not derived; the counts of the kinds are pinned;
//   3. every tab has a plain line for the Young Learner (not empty, at most 190 characters, no SYMBOLS and no JARGON, both read from test_yl_ui.mjs);
//   4. every need is a tab, a page or one of the two plain-text fallbacks; no need points forward in the order of the pages;
//   5. the INP rows of the claims table are the inputs of this file, in order (text, page, anchor, flag);
//   6. INPUT_FLAGS is ['input']; no entry has a flag of its own (a line is tagged input, never standard, never checked).      Run: node test_needs.mjs
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs';
import { STEP_GROUPS } from './steps.js';
import { PAGES } from './storyCopy.js';
import { NEEDS, KINDS, NEEDS_COPY, INPUT_FLAGS, needLabel } from './inputsData.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8');

// ---- the tabs of every page, from the source of the router, in the order of the pages
const subsSrc = rd('StoryShell.jsx').match(/export const SUBS = (\{[^\n]*\});/)[1];
const SUBS = new Function('STEP_GROUPS', 'return ' + subsSrc)(STEP_GROUPS);
const TABS = []; for (const p of PAGES) for (const t of SUBS[p] || []) TABS.push({ page: p, id: t, key: p === 'maxwell' ? 'maxwell/' + t : t });
ok(TABS.length >= 30 && new Set(TABS.map(t => t.id)).size === TABS.length, `${TABS.length} tabs, every tab id on one page only (a need names a tab by its id alone)`);
const WITHOUT = ['conventions', 'tally'];   // tabs that take nothing from outside and carry no strip (conventions: the page of the conventions; tally: the wrap-up)
const keys = Object.keys(NEEDS);
ok(keys.every(k => TABS.some(t => t.key === k)), 'every key of NEEDS is a tab of the router: ' + keys.filter(k => !TABS.some(t => t.key === k)).join(' '));
ok(TABS.every(t => (WITHOUT.includes(t.id) ? !NEEDS[t.key] : !!NEEDS[t.key])), 'every tab has a strip except ' + WITHOUT.join(', ') + ': ' + TABS.filter(t => !!NEEDS[t.key] === WITHOUT.includes(t.id)).map(t => t.key).join(' '));
ok(keys.length === 31, `31 strips (${keys.length})`);
ok(keys.every(k => !k.includes('/') || /^maxwell\/(views|charges|ladders)$/.test(k)), 'the only keys with a slash are the three Maxwell tabs');
ok(keys.every(k => Object.keys(NEEDS[k]).every(f => ['needs', 'inputs', 'yl', 'none'].includes(f)) && Array.isArray(NEEDS[k].needs) && Array.isArray(NEEDS[k].inputs) && typeof NEEDS[k].yl === 'string'), 'an entry has needs, inputs and yl (and none), nothing else');

// ---- the inputs
const INPUTS = []; for (const k of keys) for (const [kind, text] of NEEDS[k].inputs) INPUTS.push({ key: k, kind, text });
ok(INPUTS.length === 98, `98 input lines (${INPUTS.length})`);
ok(INPUTS.every(i => KINDS[i.kind]), 'every input has a kind of KINDS: ' + INPUTS.filter(i => !KINDS[i.kind]).map(i => i.key + ':' + i.kind).join(' '));
ok(Object.keys(KINDS).length === 10 && Object.values(KINDS).every(v => typeof v === 'string' && v.length > 3), 'KINDS: ten names');
const count = {}; INPUTS.forEach(i => { count[i.kind] = (count[i.kind] || 0) + 1; });
const WANT = { postulate: 15, chart: 12, grade: 6, representation: 1, convention: 15, data: 23, time: 7, complex: 7, involution: 9, solution: 3 };
ok(JSON.stringify(Object.fromEntries(Object.keys(WANT).map(k => [k, count[k] || 0]))) === JSON.stringify(WANT), 'kind counts ' + JSON.stringify(count) + ' (pinned: ' + JSON.stringify(WANT) + ')');
ok(INPUTS.every(i => typeof i.text === 'string' && i.text.length >= 40 && i.text.length <= 230 && /\.$/.test(i.text)), 'every input text is 40 to 230 characters and ends in a full stop: ' + INPUTS.filter(i => !(i.text.length >= 40 && i.text.length <= 230 && /\.$/.test(i.text))).map(i => i.key + ' (' + i.text.length + ')').join(' '));
const SAYS_NOT = /\b(does not derive|do not derive|not derived)\b/gi;
ok(INPUTS.every(i => !/\bderiv(e|es|ed|ing)\b/i.test(i.text.replace(SAYS_NOT, ''))), 'an input says "derived" only to say it is not: ' + INPUTS.filter(i => /\bderiv(e|es|ed|ing)\b/i.test(i.text.replace(SAYS_NOT, ''))).map(i => i.key).join(' '));
ok(keys.filter(k => NEEDS[k].none).join() === 'comm' && keys.every(k => !!NEEDS[k].none === (NEEDS[k].inputs.length === 0)), 'the only tab with "none" is comm, and exactly the tabs without an input line: ' + keys.filter(k => !!NEEDS[k].none !== (NEEDS[k].inputs.length === 0)).join(' '));
ok(keys.every(k => { const t = NEEDS[k].inputs.map(x => x[1]); return new Set(t).size === t.length; }), 'no tab says one input twice');

// ---- the plain line of the Young Learner (SYMBOLS and JARGON are the ones of test_yl_ui.mjs)
const ylSrc = rd('test_yl_ui.mjs'), lit = n => { const m = ylSrc.match(new RegExp('^const ' + n + ' = (\\/.*\\/[a-z]*);\\s*$', 'm')); return m ? new Function('return ' + m[1])() : null; };
const SYMBOLS = lit('SYMBOLS'), JARGON = lit('JARGON');
ok(SYMBOLS instanceof RegExp && JARGON instanceof RegExp, 'SYMBOLS and JARGON were read from test_yl_ui.mjs');
const yl = keys.map(k => [k, NEEDS[k].yl]);
ok(yl.every(([, y]) => y && y.length >= 20 && y.length <= 190), 'every plain line is 20 to 190 characters: ' + yl.filter(([, y]) => !(y && y.length >= 20 && y.length <= 190)).map(([k, y]) => k + ' (' + (y && y.length) + ')').join(' '));
ok(yl.every(([, y]) => !SYMBOLS.test(y)), 'no plain line holds a symbol: ' + yl.filter(([, y]) => SYMBOLS.test(y)).map(([k]) => k).join(' '));
ok(yl.every(([, y]) => !JARGON.test(y)), 'no plain line holds a word of the jargon list: ' + yl.filter(([, y]) => JARGON.test(y)).map(([k, y]) => k + ' "' + (y.match(JARGON) || [])[0] + '"').join(' '));
ok(yl.every(([, y]) => /[.!?]$/.test(y)), 'every plain line ends in a full stop');
const ylCopy = [NEEDS_COPY.yl.aria, NEEDS_COPY.yl.script, NEEDS_COPY.yl.needs, NEEDS_COPY.yl.help, ...Object.values(NEEDS_COPY.yl.words), ...Object.values(NEEDS_COPY.yl.pages)];
ok(ylCopy.every(y => typeof y === 'string' && y && !SYMBOLS.test(y) && !JARGON.test(y)), 'the plain words of the strip (title, labels, help, page words) hold no symbol and no jargon');

// ---- the needs
const WORDS = Object.keys(NEEDS_COPY.words);   // a page word with a fallback in plain text: 'conventions' (no such page yet) and 'maxwell' (a page)
ok(WORDS.join() === 'conventions,maxwell' && WORDS.every(w => NEEDS_COPY.yl.words[w]), 'the plain-text words of a need are conventions and maxwell, both in the plain reading too');
const tabIds = new Set(TABS.map(t => t.id)), resolves = w => tabIds.has(w) || PAGES.includes(w) || WORDS.includes(w);
const unresolved = []; for (const k of keys) for (const w of NEEDS[k].needs) if (!resolves(w)) unresolved.push(k + '>' + w);
ok(unresolved.length === 0, 'every need is a tab, a page or a plain-text word: ' + unresolved.join(' '));
ok(keys.every(k => NEEDS[k].needs.every(w => w !== k.replace('maxwell/', '')) && new Set(NEEDS[k].needs).size === NEEDS[k].needs.length && NEEDS[k].needs.length <= 4), 'a strip names at most four distinct needs, never itself');
const noPage = [...new Set(keys.flatMap(k => NEEDS[k].needs).filter(w => !tabIds.has(w) && !PAGES.includes(w)))];
const HAS_CONV = tabIds.has('conventions') || PAGES.includes('conventions');   // the Conventions tab (or page) of the story builder: until it exists, a need for it is plain text
ok(noPage.join() === (HAS_CONV ? '' : 'conventions'), 'the needs that name no tab and no page are plain text: ' + noPage.join(' ') + ' (a need for the conventions is a link once the Conventions tab or page exists, plain text before)');
// the needs that point forward in the order of the pages (a tab named by a tab that comes before it): none. The page order is the dependency order:
// the Conventions page (the conventions and the clock) comes before Maxwell, the equations in the order of their needs, and Furey after the equations it uses.
const at = {}; TABS.forEach((t, i) => { at[t.id] = i; });
const forward = []; for (const k of keys) { const me = at[k.replace('maxwell/', '')]; for (const w of NEEDS[k].needs) if (w in at && at[w] > me) forward.push(k + '>' + w); }
ok(forward.length === 0, `no need points forward in the order of the pages (${keys.length} strips): ${forward.join(' ') || 'none'}`);

// the label of a link to a tab names its page first (the step numbers repeat from page to page: 2 is the demicube on the shapes page and the commutators on the equations page)
const PAGE_WORDS = ['conventions', 'maxwell', 'shapes', 'equations', 'furey', 'lenses'];
ok(JSON.stringify(Object.keys(NEEDS_COPY.pages)) === JSON.stringify(PAGE_WORDS) && JSON.stringify(Object.keys(NEEDS_COPY.yl.pages)) === JSON.stringify(PAGE_WORDS), 'the strip has a page word, in the reading of the Physicist and of the Young Learner, for every page that holds a tab: ' + PAGE_WORDS.join(' '));
ok(TABS.every(t => PAGE_WORDS.includes(t.page)), 'every tab is on a page that has a page word');
const L = (t, w, yl = false) => needLabel(t, w, yl ? NEEDS_COPY.yl.pages : NEEDS_COPY.pages);
ok(L({ page: 'shapes', sub: 'demi', label: '2 · The demicube' }, 'demi') === 'Shapes · 2 · The demicube' && L({ page: 'equations', sub: 'comm', label: '2 · Commutators' }, 'comm') === 'Equations · 2 · Commutators', 'the links to the demicube and to the commutators name their page');
ok(L({ page: 'conventions', sub: 'clock', label: '1 · Clock · trinity' }, 'clock') === 'Conventions · 1 · Clock · trinity' && L({ page: 'furey', sub: 'dictionary', label: 'The dictionary' }, 'dictionary') === 'Furey · The dictionary', 'the clock and the dictionary name their page');
ok(L({ page: 'conventions', sub: 'conventions', label: 'Conventions' }, 'conventions') === 'Conventions' && L({ page: 'conventions', sub: 'conventions', label: 'Our words' }, 'conventions', true) === 'Our words', 'a tab that carries the word of its page is not named twice');
ok(L({ page: 'maxwell', sub: 'views', label: 'Calibration 1 · Maxwell' }, 'maxwell') === 'Calibration 1 · Maxwell', 'a need that is a page keeps the name of the page');
ok(L({ page: 'shapes', sub: 'orth', label: '1 · Two poles on every line' }, 'orth', true) === 'Shapes · 1 · Two poles on every line', 'the Young Learner reads the plain page word too');

// ---- what the strips say, line by line (each pin is a present statement of the page it belongs to)
const text = k => NEEDS[k].inputs.map(i => i[1]).join(' ');
ok(!/Schuller/.test(text('spin')) && /Eelbode’s lecture/.test(text('spin')), 'the spin strip names Eelbode’s lecture and not Schuller’s');
ok(/hyperbolic wave operator \(T18\)/.test(text('maxwell/ladders')) && !/is physics/.test(text('maxwell/ladders')), 'the ladders strip says that a Lorentzian split gives a hyperbolic wave operator');
ok(NEEDS.gauge.inputs.every(i => i[0] !== 'involution') && !/Kerr|Hsu/.test(text('gauge')) && /Schwarzschild metric \(a point mass\)/.test(text('gauge')), 'the gauge strip names the Schwarzschild point mass only and takes no involution');
ok(['grav1', 'gauge', 'clock', 'dirac', 'grav2'].every(k => NEEDS[k].inputs.some(i => i[0] === 'convention')), 'the strips of the clock, the Dirac step, gravity I and II and gauge gravity each carry a sign-convention line');
ok(NEEDS.spring.needs.includes('spin') && NEEDS.rigid.needs.includes('spring') && NEEDS.threegen.needs.join() === 'dictionary,findings', 'the needs of spring (spin), rigid (spring) and three generations (dictionary, findings) name the pages their text leans on');
ok(NEEDS.matter.inputs.filter(i => i[0] === 'representation').length === 1 && NEEDS.matter.inputs.every(i => i[0] !== 'grade' || !/representation is a choice/.test(i[1])), 'the choice of representation is a line of its own kind in the matter strip, not a grade');
ok(['coupling', 'matter', 'spin', 'mirrors'].every(k => NEEDS[k].inputs.some(i => i[0] === 'time')) && ['coupling', 'matter', 'findings'].every(k => NEEDS[k].inputs.some(i => i[0] === 'complex')) && NEEDS['maxwell/charges'].inputs.some(i => i[0] === 'solution'), 'the strips of the coupling, matter, spin and mirrors steps list the time direction, coupling and matter list the complex structure, the charges tab lists its given fields');
ok(NEEDS.demi.inputs.length === 1 && !NEEDS.demi.none && /Furey box/.test(text('demi')) && NEEDS.orth.inputs.some(i => i[0] === 'data' && /Baez, Bokor and Boyle/.test(i[1])), 'the demicube strip lists the Furey box, the orthoplex strip the charge formulas of Baez, Bokor and Boyle');
ok(NEEDS.earlier.inputs.length === 1 && NEEDS.help.inputs.length === 1 && NEEDS.earlier.needs.join() === 'dictionary' && NEEDS.help.needs.join() === 'threegen', 'her papers and what may help carry a strip of their own');
ok(NEEDS.category.inputs.some(i => i[0] === 'involution' && /dagger/.test(i[1])) && NEEDS.category.inputs.some(i => i[0] === 'data' && /T4, T6 and T8/.test(i[1])) && NEEDS.baez.inputs.some(i => /Madelung/.test(i[1])) && /simplicity of the large groups/.test(text('groups')) && /2\^\{1\+24\}/.test(text('groups')), 'category (dagger, recalled theorems), Baez (Madelung order) and groups (four quoted items) are complete');

// ---- the INP rows of the claims table are these inputs, in order
const CLAIMS = (await import('./claimsData.js')).CLAIMS, INP = CLAIMS.filter(c => c.group === 'INP');
ok(INP.length === INPUTS.length && INP.every((c, i) => c.id === 'INP-' + String(i + 1).padStart(3, '0')), `${INP.length} INP rows, numbered in order, one for each input line`);
const bad5 = INP.map((c, i) => [c, INPUTS[i]]).filter(([c, i]) => !i || c.en.length !== 1 || c.en[0].text !== i.text || c.it.length !== 1 || c.it[0].text !== i.text || c.anchor !== 'ns-' + i.key.replace(/\//g, '-') || c.page !== TABS.find(t => t.key === i.key).page || c.flags.join() !== INPUT_FLAGS.join() || c.known !== false);
ok(bad5.length === 0, 'each INP row has the text, the page, the anchor and the flag of its input line (English in both slots): ' + bad5.slice(0, 3).map(([c]) => c.id).join(' '));
ok(CLAIMS.filter(c => c.group !== 'INP').every(c => !/^ns-/.test(c.anchor || '')), 'no other claim points at a strip');

// ---- the flag
ok(Array.isArray(INPUT_FLAGS) && INPUT_FLAGS.length === 1 && INPUT_FLAGS[0] === 'input', "INPUT_FLAGS is ['input']");
ok(INPUTS.every(i => Array.isArray([i.kind, i.text]) && !('flags' in NEEDS[i.key])), 'no entry has a flag of its own: a line of the strip is input, never standard, never checked');
const src = rd('NeedsStrip.jsx');
ok(/StatusBadge flag="input"/.test(src) && !/flag="(standard|checked|ours|open)"/.test(src), 'NeedsStrip.jsx draws one badge, flag="input"');
ok(/\.needs-strip/.test(rd('readerFilter.js')), 'the reader filter leaves the strip alone (readerFilter.js NEVER)');

console.log(bad ? `${bad} FAILURES of ${checks}` : `NEEDS DATA OK (${checks} checks)`);
process.exit(bad ? 1 : 0);
