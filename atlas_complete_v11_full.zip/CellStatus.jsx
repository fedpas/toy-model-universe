// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { StatusBadge } from './StatusBadge.jsx';
import { Tx } from './MathText.jsx';
import { YL_STATUS } from './ylAtlas.js';
import { CELL_STATUS } from './cellStatusCopy.js';

// The status line under the title of a cell card. It carries two badges and says what each one covers:
//   checked  the algebra type of the cell: a script recomputes Cl(p,q) from the bit rule and the classification table (drawn for every cell that has one);
//   ours     the name in the title: a reading we propose (the five speculative cells also carry `open`).
// The status words are the badges' accessible names; the words printed beside them say what the badge covers, not how sure we are.
// The words are in cellStatusCopy.js (a plain module, so that the node tests can read them).
export default function CellStatus({ record, lang, yl, S }) {
  const L = lang === 'it' ? 'it' : 'en', w = yl ? (YL_STATUS[L] || YL_STATUS.en) : CELL_STATUS[L];
  const spec = record.auditStatus === 'speculative', typeText = record.auditStatus === 'realigned' ? w.realigned : w.verified;
  const badge = flag => <StatusBadge flag={flag} lang={lang} strings={S} />;
  const sig = !yl && record.auditedCell ? <> (<Tx>{record.auditedCell}</Tx>)</> : null;   // the signature in brackets, after the words it belongs to
  return <p className="audit-line" data-audit={record.auditStatus}>
    {record.cell && <>{badge('checked')} <Tx>{typeText}</Tx>{sig}{' · '}</>}
    {record.cell && <>{badge('ours')} <Tx>{w.name}</Tx></>}
    {spec && <>{record.cell && ' · '}{badge('open')} <Tx>{w.speculative}</Tx></>}
    {!record.cell && sig}
  </p>;
}
