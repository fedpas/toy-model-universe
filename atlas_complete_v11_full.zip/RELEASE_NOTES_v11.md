# Release notes, v11 (7 October 2026)

v11 states the Cascade Atlas as what it is: **a labelling plus primordial ideas, not ground truth**. The bit rule gives every Clifford algebra a basis of bit-mask blades and a product by XOR with a sign; what is solid is what a script recomputes and what the lens chapters carry. The physics pages are calibrations with named inputs. Every text of the package is in the present tense. `README.md` says what the package is; `BUILDING.md` says how to build and test it.

## What v11 holds

**The core, as it is.**
- Page 1 and the atlas state the bit rule as a labelling. A cell is the triple (V, Q, π): the vector space with the quadratic form of the generator squares and the grading by the number of generators. The clock is the Brown invariant of the Z4-valued form w = π + 2Q. The mirror is Q → Q + π. The null part is Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(R^r), with the labels that carry a null bit forming a monoid with zero.
- The Genesis story stays visible as primordial ideas (*ours*): ideas A and B reach the neutral cells Cl(k,k,r); idea C, the budget of 8, is the scope of the first tour and is not universal.
- The 25 cell cards show the algebra type as a *checked* badge and the role name as an *ours* badge; the Spatial/Temporal toggle is a reading. The four views of a cell are one algebra view and three notations for the label group.
- A **Conventions** page holds the clock as its first step, the Atlas convention and the three literature conventions, the mirror invariants and a glossary of the words the pages use ("label", "label 0", "base" and "fibre", "clock").
- `selfcheck/core_check.py` recomputes the core statements in 25 checks, `core·B1` to `core·B17`, with the Python standard library in about 3 seconds; it has a row on the For researchers page and a downloadable mirror (`coreSelfcheckSource.js`).

**A status system with five flags.** *Standard*, *checked*, *ours*, *open* and the new *input*: a choice or datum that a page needs and the algebra does not supply. The flags are icons with the word as accessible name and hover text, one legend per page. Known ground is a statement that is standard and checked and none of the other three; the reader filter hides it. Each tab of the tabbed pages opens with a strip, "needs / inputs", that says what the tab reads first and what it brings in from outside.

**Calibrations.** The Maxwell page is Calibration 1 and Furey's page is Calibration 2 (for the Young Learner, Warm-up 1 and 2). A calibration reproduces an answer that is already known and shows which inputs were needed.

**Physics statements, as they stand.** The Dirac kernel at a given momentum has one sign of energy; the real-linear chirality exists and the chiral coupling is the input that is missing; the projective chapter names the signature of its base; Maxwell's wave type is half settled by Theorem T18; the gauge-gravity step is titled for the horizon where the radial gradient is null; the generator square and the element square are two things; the Kepler signs of Baez's paper and of the projective step have opposite signs and the same three algebras; the null-surface step states what it computes; the three-generations sentences are scoped to Furey's model; the coupling for n ≥ 5 is consistent with a projected source.

**Order.** The pages follow the order in which a page needs what the previous ones give: the clock and hyperbolicity before Maxwell, the algebra core at the head of the equations page, gravity in the order of its dependencies, Furey after the gauge, matter and spin steps, the finite groups with the lenses. The eleven pages are the rule, the atlas, the Conventions page (step 1, the clock), Maxwell, the shapes, the equations (steps 2 to 16 and the tally), Furey, the lenses (steps 17 to 20), the Map, For researchers and Ask. An address of the form `#labels`, `#labels/clock`, `#labels/conventions`, `#labels/gauge` or `#labels/groups` opens the tab that holds that content.

**Reports.** Six reports ship as single pages in `reports/html/`, copied by the build to `dist/reports/html/`: the category lens, Baez, Schuller, Hestenes and Lasenby–Doran–Gull, Furey, and the Pumplün dictionary. The For researchers page lists them with their check scripts.

**Every text states what is true now.** The package narrates no earlier state of itself: a mathematical dead end is a present fact, and a statement that a check guards names its check id in its own line. `test_no_history.mjs` reads the app text in both languages, the reports, the scripts, the READMEs and the source comments, and fails on any text that narrates an earlier state.

## The Italian slots carry English

New and changed text of v11 is written in English and used in the Italian slots too. The Italian audit of `test_i18n_audit.mjs` (English prose and English labels on the Italian pages, checks 3 and 3b) is off through one constant, `V11_ENGLISH_IN_ITALIAN`; its report lists what it finds. The unchanged Italian text stays Italian.

## Host files

Three host files need small edits. `GenesisCanvas.jsx` and `canvasFacts.js` must use the strings of the Genesis story (ideas A, B and C, a tour of 8 stages) in their legend and header comment:
- English legend: set `budget: 'budget'` to `budget: 'tour'`, and `reset: 'budget spent: the types repeat (period 8)'` to `reset: 'end of this tour: the types repeat (period 8)'`.
- Italian legend: set `budget: 'budget'` to `budget: 'tour'`, and `reset: 'budget esaurito: i tipi si ripetono (periodo 8)'` to `reset: 'end of this tour: the types repeat (period 8)'` (new text is English in the Italian slot).
- Header comment: write "idea A/B/C" where it reads "axiom A/B/C".
- `SimplexCanvas.jsx`, the label of the picture: add `import { stepAudience } from './steps.js';` and `import { YL_VIEW_NAMES } from './ylAtlas.js';`, and where the component returns the canvas `div`, write `const yl = stepAudience() === 'Young Learner', plain = (YL_VIEW_NAMES[lang] || YL_VIEW_NAMES.en)[activeView] || activeView;` before it and give the `div` the label ``aria-label={yl ? (lang === 'it' ? `Immagine: ${plain}` : `${plain} picture`) : `${activeView} visualization`}``. The tests of the Young Learner pages read this label.

## The package

`README.md` says what the package is and `BUILDING.md` how to build it; this file says what v11 holds; the READMEs of the speed test, the replication kit, the reports and the check folders say what those hold. `build.sh` copies `reports/html/` to `dist/reports/html/`. New tests: `test_core.mjs` (the core script, its data, its mirror and six sabotaged copies) and `test_no_history.mjs`. `test_regen.mjs` covers `regen_core.sh`.
