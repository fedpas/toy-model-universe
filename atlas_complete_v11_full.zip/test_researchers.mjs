// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The data of the "For researchers" page (v11), in node: the 760 statements and their five flags, known ground computed from the flags, the
// frozen Genesis rows and the 15 tally rows, the filters of the claims table (claimMatches), the translation matrix (131 rows x 22 columns,
// grades E S A), the lists of researchersData.js and reportsData.js (schema; no errata list), the words of the page in English and Italian with the same keys, the plain pointer of
// the Young Learner, the page wiring (page 10 of 11), and no e-mail address or mail link in any new file.   Run: node test_researchers.mjs
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs'; process.chdir(PKG);
import { CLAIMS, CLAIMS_META } from './claimsData.js';
import { MATRIX_META, MATRIX_COLUMNS, MATRIX_SOURCES, MATRIX_ROWS } from './translationMatrixData.js';
import * as RD from './researchersData.js';
import { RS, VERSION } from './researchersCopy.js';
import { FLAGS, GROUNDS, GRADES, isKnown, isPlainCitation, claimMatches, claimHaystack, flagCounts, whereOf, groundOfReaderFilter, rowMatches, columnCounts, noneIn } from './researchersModel.js';
import { REPORTS } from './reportsData.js';
import { RULE_KINDS, RULE_KIND_LIST, RULE_COL_LONG } from './ruleKinds.js';
import { PAGES, STORY, STORY_YL } from './storyCopy.js';
import { SHORT } from './audienceCopy.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const count = f => CLAIMS.filter(f).length;
const TOTAL = 760;   // 270 audited statements + 98 input lines (INP) + 392 statements of the Lenses page (LNP, LNC, LNB, LNS)

// ---- 1. the claims: unique ids, five flag names, lines in order, known ground computed from the flags
ok(CLAIMS.length === TOTAL && CLAIMS_META.total === TOTAL, `${TOTAL} statements (${CLAIMS.length}, meta ${CLAIMS_META.total})`);
ok(new Set(CLAIMS.map(c => c.id)).size === CLAIMS.length && CLAIMS.every(c => /^[A-Z]{2,3}-\d{3}$/.test(c.id)), 'every id is unique and of the form ABC-123');
const badFlags = CLAIMS.filter(c => !Array.isArray(c.flags) || !c.flags.every(f => FLAGS.includes(f)) || !c.en.length || !c.en.every(l => Array.isArray(l.flags) && l.flags.every(f => FLAGS.includes(f)) && typeof l.text === 'string' && l.text.trim() && ['line', 'theorem', 'reading'].includes(l.label)));
ok(!badFlags.length, 'every statement and every line carries only the five flag names, and every line a text and a label: ' + badFlags.map(c => c.id).join(' '));
// the filters and counts read the flags of the statement (flags_final); a line may carry a flag the statement does not (the provisional file has such rows): reported, not failed
const lineOnly = CLAIMS.filter(c => c.en.some(l => l.flags.some(f => !c.flags.includes(f)))); if (lineOnly.length) console.log(`NOTE ${lineOnly.length} statements have a line flag that the statement's own flags lack: ${lineOnly.map(c => c.id).join(' ')}`);
const noFlag = CLAIMS.filter(c => !c.flags.length); if (noFlag.length) console.log(`NOTE ${noFlag.length} statements carry no flag in claimsData.js (the page marks them "no flag"): ${noFlag.map(c => c.id).join(' ')}`);
// the columns of the table are for the reader: no note about who ran or read what, no "not displayed" line, no builder's note field
ok(!CLAIMS.some(c => /\bthe owner\b|not displayed|left unchanged/i.test(JSON.stringify([c.standardRef, c.checkedBy, c.en, c.it]))) && CLAIMS.every(c => !('note' in c)) && CLAIMS.filter(c => c.en.some(l => l.notShown)).every(c => c.en.length === 1 && c.en[0].text === 'No statement: a list of tags that no page draws.'), 'the claims table shows no process note (no "the owner ran", no "not displayed", no note field)');
ok(CLAIMS.every(c => c.en.length === 1 || c.en.every(l => l.label === 'line') || (c.en[0].label === 'theorem' && c.en.slice(1).every(l => l.label !== 'theorem'))), 'a split statement shows its theorem line first (voices and paragraphs of one card are plain lines)');
ok(CLAIMS.every(c => c.it === null || c.it === undefined || (Array.isArray(c.it) && c.it.length === c.en.length)), 'an Italian text, where there is one, has one entry per English line');
const known = count(c => isKnown(c.flags));
ok(CLAIMS.every(c => c.known === isKnown(c.flags)), 'the stored "known" of every statement equals standard AND checked AND NOT ours AND NOT open: ' + CLAIMS.filter(c => c.known !== isKnown(c.flags)).map(c => c.id).join(' '));
const fc = flagCounts(CLAIMS);
ok(fc.known === known && fc.total === TOTAL && FLAGS.every(k => fc[k] === count(c => c.flags.includes(k))), `the page counts (flagCounts) equal the claims: known ground ${fc.known}, ` + FLAGS.map(k => k + ' ' + fc[k]).join(', '));
ok(count(c => isPlainCitation(c.flags)) === count(c => c.flags.join() === 'standard'), 'a plain citation is a statement whose only flag is standard');
// the frozen Genesis rows and the tally rows
const frozen = CLAIMS.filter(c => c.frozen), tally = CLAIMS.filter(c => c.tally);
ok(frozen.length === 9 && frozen.every(c => /^GEN-00\d$/.test(c.id)) && count(c => c.group === 'GEN') === 9, `the nine Genesis rows are the frozen ones (${frozen.map(c => c.id).join(' ')})`);
ok(RS.en.claims.frozen && RS.it.claims.frozen, 'the frozen marker has a word in both languages (the Italian slot holds the English word, V11_SPEC rule 9; the browser test checks it on every frozen row)');
ok(tally.length === 15 && tally.every(c => /^EQN-0(0[6-9]|1\d|20)$/.test(c.id)), `the 15 tally rows are EQN-006..020 (${tally.length})`);

// ---- 2. the filters of the claims table
const shown = o => CLAIMS.filter(c => claimMatches(c, o));
ok(shown({}).length === TOTAL, 'no filter: every statement');
ok(shown({ ground: 'known' }).length === known && shown({ ground: 'known' }).every(c => isKnown(c.flags)), `known ground only: ${known}`);
const hide = shown({ ground: 'hide' }), hideStd = shown({ ground: 'hide+std' });
ok(hide.length === TOTAL - known + count(c => c.tally && isKnown(c.flags)) && hide.every(c => c.tally || !isKnown(c.flags)), `everything except known ground: ${hide.length} (the tally rows stay)`);
ok(tally.every(c => hide.includes(c) && hideStd.includes(c)), 'the tally rows are never hidden by the two hiding choices');
// ... also when a tally row is known ground or a plain citation (none is in the present file, so the rule is checked on made-up rows too)
{ const mk = (flags, t) => ({ id: 'EQN-099', group: 'EQN', flags, en: [{ label: 'line', text: 'x', flags }], tally: t });
  ok(['hide', 'hide+std'].every(g => claimMatches(mk(['standard', 'checked'], true), { ground: g }) && claimMatches(mk(['standard'], true), { ground: g })) && !claimMatches(mk(['standard', 'checked'], false), { ground: 'hide' }) && !claimMatches(mk(['standard'], false), { ground: 'hide+std' }) && claimMatches(mk(['standard'], false), { ground: 'hide' }), 'a known-ground or plain-citation tally row stays; the same row without the tally mark is hidden'); }
ok(hideStd.length === hide.length - count(c => !c.tally && isPlainCitation(c.flags)) && hideStd.every(c => c.tally || !isPlainCitation(c.flags)), `also hide plain citations: ${hideStd.length}`);
for (const [a, b] of [['ours', 'open'], ['standard', 'checked']]) {
  ok(shown({ flags: [a, b], mode: 'all' }).length === count(c => c.flags.includes(a) && c.flags.includes(b)), `flags ${a} AND ${b}`);
  ok(shown({ flags: [a, b], mode: 'any' }).length === count(c => c.flags.includes(a) || c.flags.includes(b)), `flags ${a} OR ${b}`);
}
ok(shown({ group: 'ATL' }).length === count(c => c.group === 'ATL') && shown({ group: 'ATL' }).length === 25, 'group filter: 25 atlas cells');
ok(shown({ q: 'ATL-007' }).map(c => c.id).join() === 'ATL-007', 'a search for an id finds that statement only');
ok(shown({ q: 'cl(3,1)' }).length > 0 && shown({ q: 'cl(3,1)' }).every(c => claimHaystack(c).includes('cl(3,1)')), 'a search is case-blind and reads the text');
ok(groundOfReaderFilter('known') === 'hide' && groundOfReaderFilter('known+std') === 'hide+std' && groundOfReaderFilter('off') === 'all' && groundOfReaderFilter('x') === null && GROUNDS.join() === 'all,known,hide,hide+std', 'the reader filter (main[data-rf]: off, known, known+std) maps onto the ground switch');
ok(JSON.stringify(whereOf('equations/tally', PAGES)) === '{"page":"equations","anchor":"tally"}' && JSON.stringify(whereOf({ page: 'equations', anchor: 'eq-tally' }, PAGES)) === '{"page":"equations","anchor":"eq-tally"}' && whereOf('nowhere', PAGES) === null && whereOf(null) === null && whereOf('map', PAGES).page === 'map', 'the "page" of a statement is read as page/anchor, page#anchor or {page, anchor}');
ok(CLAIMS.every(c => c.page == null || whereOf(c.page, PAGES)), 'every statement that names a page names a page of the app');
// the groups: an Italian name for each
const groups = [...new Set(CLAIMS.map(c => c.group))];
ok(groups.length === 26 && groups.includes('INP') && groups.every(g => RS.it.groups[g]) && Object.keys(RS.it.groups).every(g => groups.includes(g)), 'every group of the claims has an Italian name, and no other: ' + groups.filter(g => !RS.it.groups[g]).join(' '));

// ---- 3. the translation matrix
ok(MATRIX_ROWS.length === 131 && MATRIX_COLUMNS.length === 22 && MATRIX_META.rows === 131 && MATRIX_META.columns === 22, `131 rows x 22 columns (${MATRIX_ROWS.length} x ${MATRIX_COLUMNS.length})`);
ok(MATRIX_SOURCES.map(s => s.key + ' ' + s.rows).join() === 'schuller 43,baez 48,category 40' && MATRIX_SOURCES.every(s => MATRIX_ROWS.filter(r => r.src === s.key).length === s.rows), 'three sources: Schuller 43, Baez 48, category 40');
const cols = new Set(MATRIX_COLUMNS.map(c => c.key)), cells = MATRIX_ROWS.flatMap(r => Object.entries(r.cells));
ok(cells.every(([k, x]) => cols.has(k) && GRADES.includes(x.grade) && typeof x.note === 'string' && x.note.trim()), 'every cell sits in a known column, has a grade in {E, S, A} and a note');
ok(GRADES.every(g => cells.filter(([, x]) => x.grade === g).length === MATRIX_META.grades[g]) && cells.length === MATRIX_META.cells, `grade counts: ${GRADES.map(g => g + ' ' + MATRIX_META.grades[g]).join(', ')}`);
ok(new Set(MATRIX_ROWS.map(r => r.uid)).size === 131 && MATRIX_ROWS.every(r => r.title && (r.uid === r.id || r.uid.startsWith(r.id + '-'))), 'every row has a unique anchor id (matrix-<uid>) and a title');
ok(MATRIX_ROWS.filter(r => r.uid !== r.id).every(r => MATRIX_ROWS.filter(x => x.id === r.id).length > 1), 'only ids that repeat across sources get a source suffix');
ok(MATRIX_ROWS.filter(r => !Object.keys(r.cells).length).length === MATRIX_META.gaps, `rows with no cell (gaps): ${MATRIX_META.gaps}`);
const cc = columnCounts(MATRIX_ROWS, MATRIX_COLUMNS);
ok(MATRIX_COLUMNS.every(c => GRADES.reduce((s, g) => s + cc[c.key][g], 0) + noneIn(MATRIX_ROWS, c.key).length === 131), 'per column: E + S + A + "none in" = 131');
ok(MATRIX_ROWS.filter(r => rowMatches(r, { src: 'baez', col: 'maxwell', grades: ['E'] })).length === MATRIX_ROWS.filter(r => r.src === 'baez' && r.cells.maxwell?.grade === 'E').length && MATRIX_ROWS.filter(r => rowMatches(r, { grades: ['A'] })).length === MATRIX_ROWS.filter(r => Object.values(r.cells).some(x => x.grade === 'A')).length, 'matrix filters: source, column and grade');
ok(MATRIX_COLUMNS.every(c => RS.it.matrix.cols[c.key]?.length === 2 && RS.it.matrix.cols[c.key].every(Boolean) && RS.it.matrix.cols[c.key][0] !== c.short || ['maxwell', 'furey', 'dirac', 'ym', 'spin', 'gauge'].includes(c.key)) && Object.keys(RS.it.matrix.cols).length === 22, 'every column has an Italian short and long name (the short one differs from the English one unless it is a name)');
ok(MATRIX_SOURCES.every(s => RS.it.matrix.sources[s.key]), 'the three sources have Italian names');
// the rule column mixes three kinds of content (A-40): every one of its cells is assigned exactly one kind, and the grades are unchanged
{ const rc = MATRIX_ROWS.filter(r => r.cells.rule), kc = k => rc.filter(r => RULE_KINDS[r.uid] === k).length;
  ok(rc.length === 43 && rc.every(r => RULE_KIND_LIST.includes(RULE_KINDS[r.uid])) && Object.keys(RULE_KINDS).length === 43 && Object.keys(RULE_KINDS).every(u => rc.some(r => r.uid === u)) && kc('labels') === 13 && kc('product') === 26 && kc('module') === 4, 'the 43 cells of the rule column are each assigned one kind: 13 labels, 26 product, 4 module');
  ok(rc.filter(r => r.cells.rule.grade === 'E').length === 34 && rc.filter(r => r.cells.rule.grade === 'S').length === 7 && rc.filter(r => r.cells.rule.grade === 'A').length === 2 && /\(labels · product · module\)$/.test(RULE_COL_LONG), 'the grades of the rule column stay (E 34, S 7, A 2) and its header names the three kinds'); }
ok(/^\/\/ GENERATED by make_matrix_data\.mjs/m.test(fs.readFileSync('translationMatrixData.js', 'utf8')) && fs.existsSync('make_matrix_data.mjs'), 'translationMatrixData.js says it is generated by make_matrix_data.mjs');

// ---- 4. researchersData.js: the schema the page reads (English only)
const str = x => typeof x === 'string';
const T = RD.THEOREMS, Q = RD.QUESTIONS, S = RD.SOURCES, R = RD.RUN, G = RD.GENESIS_NOTE;
ok([T, Q, S, R, REPORTS].every(a => Array.isArray(a) && a.length) && G && str(G.text) && !('ERRATA' in RD) && !('sortErrata' in RD), 'five lists: THEOREMS, QUESTIONS, SOURCES, RUN (researchersData.js) and REPORTS (reportsData.js), and GENESIS_NOTE as one present-tense text; no errata list');
ok(T.every(t => str(t.id) && str(t.title) && str(t.statement) && ['proved', 'reduced', 'range', 'open'].includes(t.status) && ['verified', 'gaps'].includes(t.verifier) && str(t.script) && Array.isArray(t.usedFor) && Array.isArray(t.limits) && t.limits.every(str) && !('corrections' in t)), 'theorems: id, title, statement, status (proved, reduced, range, open), verifier (verified, gaps), script, usedFor, limits (present-tense list of strings, no corrections history)');
ok(T.every(t => t.verifier !== 'gaps' || str(t.verifierNote) && t.verifierNote.trim()), 'a theorem verified with gaps names its gaps');
const ids = new Set(CLAIMS.map(c => c.id));
ok(T.every(t => t.usedFor.every(id => ids.has(id))), 'every statement a theorem backs or corrects is in the claims: ' + T.flatMap(t => t.usedFor).filter(id => !ids.has(id)).join(' '));
// the Reports block (D-032): the six reports of the package, each with its page, its check scripts, its suite and the tabs that condense it
ok(REPORTS.length === 6 && REPORTS.map(r => r.id).join() === 'category,baez,schuller,hestenes,furey,pumplun' && REPORTS.every(r => ['id', 'file', 'title', 'line', 'suite'].every(k => str(r[k]) && r[k].trim()) && /^reports\/html\/[a-z_]+\.html$/.test(r.file) && Array.isArray(r.script) && r.script.every(([f, c]) => /\.py$/.test(f) && (c === null || Number.isInteger(c))) && Array.isArray(r.on)) && new Set(REPORTS.map(r => r.file)).size === 6, 'reports: six, each with id, file (reports/html/*.html), title, line, scripts (name, count or null), suite, on');
// the Reports block says what reports/html/index.json (written by reports/make_package.py from the pages and the logs) says: file, title, one-line summary, check scripts with their counts
{ const ixf = path.join(PKG, 'reports', 'html', 'index.json');
  if (!fs.existsSync(ixf)) console.log('NOTE reports/html/index.json is not in the package: the Reports block is not compared with it');
  else { const IX = JSON.parse(fs.readFileSync(ixf, 'utf8')).reports, nz = x => x.replace(/’/g, "'").replace(/\.$/, ''), base = f => f.split('/').pop();
    ok(IX.length === REPORTS.length && IX.every((x, i) => REPORTS[i].id === x.id && REPORTS[i].file === x.file && nz(REPORTS[i].title) === nz(x.title) && nz(REPORTS[i].line) === nz(x.line)), 'the Reports block has the id, file, title and line of reports/html/index.json: ' + IX.filter((x, i) => !(REPORTS[i].id === x.id && REPORTS[i].file === x.file && nz(REPORTS[i].title) === nz(x.title) && nz(REPORTS[i].line) === nz(x.line))).map(x => x.id).join(' '));
    ok(IX.every((x, i) => JSON.stringify(REPORTS[i].script.map(([f]) => f)) === JSON.stringify(x.scripts.map(base)) && x.scripts.length === x.logs.length && REPORTS[i].script.reduce((a, [, c]) => a + c, 0) === x.checks), 'the check scripts of the Reports block are the scripts of index.json, and their counts add up to its number of checks: ' + IX.filter((x, i) => !(JSON.stringify(REPORTS[i].script.map(([f]) => f)) === JSON.stringify(x.scripts.map(base)) && REPORTS[i].script.reduce((a, [, c]) => a + c, 0) === x.checks)).map(x => x.id).join(' '));
    // every count is the number of ok lines of the log of its script (read here, not typed twice)
    const okLines = f => { const lf = path.join(PKG, f); return fs.existsSync(lf) ? fs.readFileSync(lf, 'utf8').split('\n').filter(l => /^\s*ok\b/i.test(l)).length : null; };
    const counted = IX.map(x => x.logs.map(okLines)); if (counted.every(a => a.every(c => c !== null))) ok(IX.every((x, i) => REPORTS[i].script.every(([, c], j) => c === counted[i][j])), 'every count of the Reports block is the number of ok lines of its log: ' + IX.filter((x, i) => !REPORTS[i].script.every(([, c], j) => c === counted[i][j])).map(x => x.id).join(' ')); } }
ok(Q.every(q => ['id', 'topic', 'ask', 'whom', 'checked', 'notChecked'].every(k => str(q[k]))), 'questions: id, topic, ask, whom, checked, notChecked');
ok(S.every(s => ['id', 'source', 'itSays', 'weComputed', 'verdict'].every(k => str(s[k])) && typeof s.deadEnd === 'boolean'), 'sources: id, source, itSays, weComputed, verdict, deadEnd');
ok(R.every(r => ['script', 'what', 'checks', 'command'].every(k => str(r[k]))), 'run: script, what, checks, command');
ok(REPORTS.every(r => r.script.every(([f]) => R.some(x => x.script.endsWith('/' + f)))) && R.some(x => x.script === 'reports/run_report_tests.sh' && /run_report_tests\.sh/.test(x.command)), 'the run list has a row for every check script of every report, and one for the runner of the six reports (reports/run_report_tests.sh)');
ok(R.some(r => r.script === 'selfcheck/core_check.py' && /ALL CORE CHECKS PASS/.test(r.checks) && /core_check\.py/.test(r.command)), 'the run list names core_check.py (the core statements, rows core·B1 to B17)');
ok(/primordial ideas \(tag ours\)/.test(G.text) && /GEN-001 to GEN-009/.test(G.text) && !/frozen|later|recorded for later/i.test(G.text), 'the Genesis note: one present-tense text (the nine node texts are our primordial ideas, tag ours), no frozen or later list');
if (T.length < 20) console.log(`NOTE researchersData.js holds ${T.length} theorems: it is the placeholder; the full file (T1..T20) replaces it at merge`);

// ---- 5. the words of the page: English and Italian with the same keys (the name maps are Italian only: English reads the names from the data)
const NAME_MAPS = new Set(['groups', 'matrix.sources', 'matrix.cols']);
const shape = (a, b, p = '') => { const out = []; for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) { const q = p ? p + '.' + k : k; if (NAME_MAPS.has(q)) continue; const x = a[k], y = b[k];
  if (typeof x !== typeof y) out.push(q); else if (typeof x === 'function') { if (x.length !== y.length || !str(x(3, 4, 5)) || !str(y(3, 4, 5))) out.push(q + '()'); } else if (x && typeof x === 'object') out.push(...shape(x, y, q)); else if (!str(x) || (!x.trim() || !y.trim()) && (x || y)) out.push(q + ' (empty in one language)'); } return out; };
const diff = shape(RS.en, RS.it); ok(!diff.length, 'researchersCopy.js: English and Italian have the same keys, each filled: ' + diff.join(' '));
ok(RS.en.pointer === 'This page is for grown-up researchers: it lists, one by one, what we looked up, what we checked with a program and what is only our way of reading. Everything here is also written in the pages.', 'the Young Learner pointer, as asked');
ok(RS.it.enNote === 'Questa sezione è in inglese.', 'the Italian note of an English section');
ok(RS.en.theorems.caption === 'proved here = derived and independently re-derived once by a second reader; no specialist has reviewed it yet' && RS.en.theorems.caption.startsWith(RS.en.theorems.status.proved + ' =') && RS.it.theorems.caption.startsWith(RS.it.theorems.status.proved + ' ='), 'the caption of the theorem status, in both languages');
ok(VERSION === 'v11', 'version v11');
// the Young Learner reads plain words only (the lists of test_yl_ui.mjs, read from that file)
{ const Y = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(/^const SYMBOLS = \/(.+)\/;$/m.exec(Y)[1], 'u'), JAR = new RegExp(/^const JARGON = \/(.+)\/i;$/m.exec(Y)[1], 'i');
  for (const l of ['en', 'it']) for (const [w, t] of [['pointer', RS[l].pointer], ['frame', JSON.stringify(STORY_YL[l].pages.researchers)], ['short reading', SHORT[l].page_researchers[0]]]) { const m = SYM.exec(t) || JAR.exec(t); ok(!m, `${l} ${w} for the Young Learner is plain${m ? ' (' + m[0] + ')' : ''}`); } }

// ---- 6. wiring: page 10 of 11, between the Map and Ask; nav, frame and short readings in both languages; one route line in App.jsx
ok(PAGES.length === 11 && PAGES.indexOf('researchers') === 9 && PAGES[8] === 'map' && PAGES[10] === 'ask', 'the page for researchers is page 10 of 11, after the Map and before Ask');
ok(STORY.en.nav.researchers === 'For researchers' && STORY.it.nav.researchers === 'Per i ricercatori', 'nav labels: For researchers / Per i ricercatori');
for (const l of ['en', 'it']) { const p = STORY[l].pages.researchers, y = STORY_YL[l].pages.researchers; ok(p && p.h && p.does && p.before && p.after && p.tags.length === 3 && p.tags.every(([k]) => FLAGS.includes(k)) && y && y.h && y.does && y.tags.map(([k]) => k).join() === p.tags.map(([k]) => k).join(), `${l}: the frame of the page, and its plain twin with the same tags`); ok(SHORT[l].page_researchers?.length === 2, `${l}: two short readings`); }
const app = fs.readFileSync('App.jsx', 'utf8');
ok(app.split('\n').filter(x => x.includes("page==='researchers'")).length === 1 && app.includes("{page==='researchers'&&<><Tx>{intro}</Tx><ResearchersSection lang={lang} profile={profile} go={go}/></>}") && /^import ResearchersSection from '\.\/ResearchersSection';$/m.test(app), 'App.jsx: one import and one route line');

// ---- 7. no e-mail address and no mail link in the new files
const NEW = ['ResearchersSection.jsx', 'researchersCopy.js', 'researchersModel.js', 'researchersData.js', 'reportsData.js', 'ruleKinds.js', 'inputsData.js', 'claimsData.js', 'translationMatrixData.js', 'make_matrix_data.mjs', 'test_researchers.mjs', 'test_researchers_ui.mjs'];
const MAIL = new RegExp('[A-Za-z0-9._%+-]+' + '@' + '[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}'), LINK = new RegExp('mail' + 'to:', 'i');
for (const f of NEW) { ok(fs.existsSync(f), f + ' exists'); if (!fs.existsSync(f)) continue; const t = fs.readFileSync(f, 'utf8'); ok(!MAIL.test(t) && !LINK.test(t), f + ': no e-mail address, no mail link'); }

console.log(bad ? `${bad} FAILURES of ${n}` : `RESEARCHERS DATA OK (${n} checks): ${TOTAL} statements, known ground ${known}, matrix 131 x 22, ${T.length} theorems, ${REPORTS.length} reports`);
process.exit(bad ? 1 : 0);
