// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The category chapter (#lenses/category, step 18) in a real browser: English and Italian, the three audiences, 1100 and 375 px, and once in the light theme.
// No page error; the step reads STEP 18 OF 20; no sideways scroll of the page; the in-page menu has one button per section of the audience, every target exists
// and a click scrolls it to the top; the five widgets and the widgets' script box are each placed once, in their own anchor, for every audience (found by
// [data-widget] only, so the test passes with the A agent's stub and with the B agent's widgets); the folds start closed for the Physicist and open for the
// Mathematician, and the Young Learner has one closed fold "For older readers"; the honesty bar shows 27 / 6 / 2 / 5 and the matrix (Physicist and
// Mathematician) its 40 rows; the script box downloads selfcheck/reports/cat_check.py byte for byte; the Young Learner's own text (outside the widgets and the
// closed fold) has no formula and no technical word; with ?filter=known every known-ground line of the chapter is hidden, every other line stays, every tag
// sits in a line the filter knows, and the page notice counts what the page hides.   Run: node test_lens_category_ui.mjs   (ATLAS_DIST=<dist folder>)
import fs from 'node:fs';
import { chromium } from 'playwright';
import { APP_HTML, PKG } from './paths.mjs';
import { KNOWN_SELECTOR } from './readerFilter.js';
import { FOLD } from './audienceCopy.js';
import { MATRIX_ROWS } from './translationMatrixData.js';
import { COPY } from './categoryCopy.js';
process.chdir(PKG);   // the script compared with the download is named relative to the package folder
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const SCRIPT = fs.readFileSync('selfcheck/reports/cat_check.py', 'utf8');
const ROWS = MATRIX_ROWS.filter(r => r.src === 'category'), cellsOf = g => ROWS.reduce((a, r) => a + Object.values(r.cells).filter(x => x.grade === g).length, 0);
const LM = `${ROWS.length},${cellsOf('E')},${cellsOf('S')},${cellsOf('A')},${ROWS.filter(r => !Object.keys(r.cells).length).length}`;
const WIDGETS = { CW1: 'cat-w-label0', CW5: 'cat-w-twozeros', CW2: 'cat-w-frobenius', CW3: 'cat-w-moves', CW4: 'cat-w-top', CW6: 'cat-w-cube', CategoryWidgetsScript: 'cat-w-script' };   // CW6 (Sign the cube) is the optional one: the stub and the widgets file both export it
const MENU = { yl: 11, p: 17, m: 18 };
// the lists of test_yl_ui.mjs (formulas, technical words) and the words DECISIONS X0 keeps from the Young Learner
const SYMBOLS = /[∇∂∫∑∏⊗⊕⊙≅≈≠≤≥∈∉∀∃⟨⟩†ℝℂℍ𝕆𝔹𝕊𝕍ℤℕ→↔⇒⇔√∞∧∨⊂⊃∪∩⊥ωψφθΩλμνρσκτΣΔΓΛΠΦΨΘαβγδεζηιξπχ]|[₀-₉⁰¹⁴-⁹]|\^|[A-Za-z0-9)\]}]_[A-Za-z0-9{(]|\bCl\(|\bdet\b|[²³ⁿ±½⅓¼¾ℏ]|\b[a-zA-Z]\s*=\s*[−+-]?[a-zA-Z0-9]|\b[b-df-hj-np-tv-zB-DF-HJ-NP-TV-Z]\s?[−±]\s?\d/u;
const JARGON = /isomorph|idempotent|pseudoscalar|bivector|involution|automorphism|tensor|commutator|anticommut|Clifford|quadratic form|Hodge|spinor|algebra|radical|Frobenius|Jordan|Nakayama|Loewy|nilpot|functor|funtor|Euler|Cartan|Dynkin/i;
const b = await chromium.launch();
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: page error ${e.message}`)); pg.on('console', m => { if (m.type() === 'error') ok(false, `${tag}: console error ${m.text()}`); }); };
async function open(lang, prof, w, query = '') {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce', acceptDownloads: true });
  await ctx.addInitScript(([l, a]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, [lang, prof]);
  const pg = await ctx.newPage(), tag = `${lang} ${prof} ${w}${query ? ' ' + query : ''}`; onErr(pg, tag);
  await pg.goto(APP_HTML + query + '#lenses/category'); await pg.waitForTimeout(400);
  return [ctx, pg, tag];
}
const voiceOf = p => (p === 'Young Learner' ? 'yl' : p === 'Physicist' ? 'p' : 'm');

for (const lang of ['en', 'it']) for (const prof of ['Young Learner', 'Physicist', 'Mathematician']) for (const w of [1100, 375]) {
  const [ctx, pg, tag] = await open(lang, prof, w), v = voiceOf(prof);
  const s = await pg.evaluate(([WIDGETS, older]) => {
    const sec = document.getElementById('ln-category'); if (!sec) return null;
    const shut = e => !!e.closest('details:not([open])');
    const wd = Object.fromEntries(Object.entries(WIDGETS).map(([k, id]) => [k, [sec.querySelectorAll(`[data-widget="${k}"]`).length, !!document.querySelector(`#${id} [data-widget="${k}"]`)]]));
    const details = [...sec.querySelectorAll('details')];
    const olderFolds = details.filter(d => d.querySelector(':scope > summary')?.textContent.trim() === older);
    return { voice: sec.dataset.voice, eyebrow: sec.querySelector('.eyebrow')?.textContent || '', over: document.documentElement.scrollWidth - window.innerWidth, wd,
      menu: [...sec.querySelectorAll('nav.ln-menu [data-goto]')].map(x => x.dataset.goto), targets: [...sec.querySelectorAll('nav.ln-menu [data-goto]')].every(x => document.getElementById(x.dataset.goto)),
      details: details.length, openDetails: details.filter(d => d.open).length, older: olderFolds.map(d => d.open), stmVisible: [...sec.querySelectorAll('[data-stm]')].filter(e => !shut(e)).map(e => e.dataset.stm),
      hb: sec.querySelector('#cat-bar .ln-hb')?.dataset.hb || null, lm: sec.querySelector('#cat-bar [data-lm-counts]')?.dataset.lmCounts || null,
      untagged: [...sec.querySelectorAll('.tag')].filter(t => !t.closest('.eq-pt') && !(t.parentElement.parentElement === sec && [...t.parentElement.children].every(c => c.classList.contains('tag')))).length };
  }, [WIDGETS, (FOLD[lang] || FOLD.en).older]);
  if (!s) { ok(false, `${tag}: no #ln-category`); await ctx.close(); continue; }
  ok(s.voice === v, `${tag}: the ${prof} voice (${s.voice})`);
  ok(s.eyebrow.startsWith(lang === 'en' ? 'STEP 18 OF 20 · ' : 'PASSO 18 DI 20 · '), `${tag}: the eyebrow reads step 18 of 20: ${s.eyebrow}`);
  ok(s.over <= 1, `${tag}: no sideways scroll of the page (${s.over} px)`);
  for (const [k, [n, inWrap]] of Object.entries(s.wd)) ok(n === 1 && inWrap, `${tag}: widget ${k} placed once, in #${WIDGETS[k]} (${n})`);
  ok(s.menu.length === MENU[v] && s.targets && new Set(s.menu).size === s.menu.length, `${tag}: the menu has ${MENU[v]} buttons, each with its section (${s.menu.length})`);
  ok(s.hb === '27,6,2,5', `${tag}: the honesty bar shows 27 / 6 / 2 / 5 (${s.hb})`);   // row W5 (clock) is S
  ok(v === 'yl' ? s.lm === null : s.lm === LM, `${tag}: the translation matrix ${v === 'yl' ? 'is not drawn for the Young Learner' : 'shows its ' + LM}: ${s.lm}`);
  ok(s.untagged === 0, `${tag}: every tag of the chapter sits in a line the reader filter knows (or in the status strip): ${s.untagged} outside`);
  if (v === 'yl') ok(s.older.length === 1 && s.older[0] === false && s.stmVisible.length === 0, `${tag}: one closed fold "For older readers" holds the formal text (${JSON.stringify(s.older)})`);
  if (v === 'p') ok(s.openDetails === 0 && s.details >= 10 && s.stmVisible.length === 0, `${tag}: the Physicist's folds start closed (${s.openDetails} of ${s.details} open)`);
  if (v === 'm') ok(s.openDetails === s.details && s.stmVisible.join() === 'A.1,A.2,A.3,A.4,A.5,A.6,A.7,A.8,A.9', `${tag}: the Mathematician reads every fold open and the statements A.1–A.9 (${s.openDetails} of ${s.details}; ${s.stmVisible.join(' ')})`);
  if (v === 'p') { await pg.locator('#cat-first details > summary').first().click(); await pg.waitForTimeout(120);
    const st = await pg.evaluate(() => [...document.querySelectorAll('#cat-first [data-stm]')].filter(e => !e.closest('details:not([open])')).map(e => e.dataset.stm).join());
    ok(st === 'A.1,A.2,A.3,A.4,A.5,A.6,A.7,A.8', `${tag}: the full introduction opens on a click and holds A.1–A.8 (A.9 is the Mathematician's): ${st}`); }
  // the Young Learner's own text: no formula, no technical word, no code, outside the widgets and the closed fold
  if (v === 'yl') { const hits = await pg.evaluate(([sym, jar]) => { const SYM = new RegExp(sym, 'u'), JAR = new RegExp(jar, 'i'), out = [], sec = document.getElementById('ln-category');
      const w = document.createTreeWalker(sec, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) { const el = n.parentElement, t = n.nodeValue.replace(/\s+/g, ' ').trim(); if (!t || el.closest('style,[data-widget],details:not([open])')) continue;
        if (el.closest('code,pre')) out.push('code: ' + t); else if (SYM.test(t) || JAR.test(t)) out.push(t.slice(0, 80)); }
      return out; }, [SYMBOLS.source, JARGON.source]);
    ok(hits.length === 0, `${tag}: the Young Learner's text has no formula, no code, no technical word: ${hits.slice(0, 3).join(' | ')}`); }
  if (lang === 'it') { const en = await pg.evaluate(() => document.getElementById('ln-category').textContent);
    ok(!/The honest list|What we checked|Zero means three things|Every corner has an opposite/.test(en), `${tag}: no English heading on the Italian page`); }
  // 1100 px: every menu button scrolls its section to the top; the script box downloads the script
  if (w === 1100) {
    let far = [];
    for (const id of s.menu) { await pg.locator(`nav.ln-menu [data-goto="${id}"]`).click(); await pg.waitForTimeout(60);
      const [top, end] = await pg.evaluate(id => { const e = document.getElementById(id); return e ? [e.getBoundingClientRect().top, window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2] : [NaN, false]; }, id);   // a missing target is a failure, not a crash
      if (!(top >= 0 && (top < 260 || end))) far.push(`${id}@${Math.round(top)}`); }
    ok(far.length === 0, `${tag}: a menu click brings its section to the top of the window (or the page to its end, for the last sections): ${far.join(' ')}`);
    if (v === 'yl') { await pg.evaluate(() => { const d = document.querySelector('#cat-older details'); if (d) d.open = true; }); await pg.waitForTimeout(150); }
    const btn = pg.locator('[data-download="selfcheck/reports/cat_check.py"]');
    ok(await btn.count() === 1, `${tag}: one download button for cat_check.py`);
    if (await btn.count() === 1) { await btn.scrollIntoViewIfNeeded(); const [dl] = await Promise.all([pg.waitForEvent('download', { timeout: 5000 }), btn.click()]);
      const p = await dl.path(), got = p ? fs.readFileSync(p, 'utf8') : '';
      ok(dl.suggestedFilename() === 'cat_check.py' && got === SCRIPT, `${tag}: the download is cat_check.py, byte for byte (${got.length} of ${SCRIPT.length} characters)`); }
    { const rl = pg.locator('#ln-category [data-report-link]'); ok(await rl.count() === 1 && await rl.locator('a').getAttribute('href') === 'reports/html/category_atlas_report.html', `${tag}: the chapter ends with one link to its full report (for the Young Learner inside the fold for older readers)`); }
  }
  await ctx.close();
}

// ---- the reader filter: ?filter=known hides exactly the known-ground lines of the chapter, and the notice counts what the page hides
for (const prof of ['Physicist', 'Mathematician']) for (const lang of ['en', 'it']) {
  const [ctx, pg, tag] = await open(lang, prof, 1100, '?filter=known');
  const r = await pg.evaluate(sel => {
    const sec = document.getElementById('ln-category'), kinds = e => [...e.querySelectorAll(':scope > div > .tag')].map(t => t.getAttribute('data-flag'));
    const known = k => k.includes('standard') && k.includes('checked') && !k.includes('ours') && !k.includes('open');
    const pts = [...sec.querySelectorAll('.eq-pt')].map(e => ({ k: kinds(e), shown: getComputedStyle(e).display !== 'none' }));
    const n = document.querySelector('.rf-notice'), main = document.querySelector('main');
    const all = new Set(main.querySelectorAll(sel)); let outer = 0; for (const e of all) { let up = e.parentElement, inner = false; for (; up && up !== main; up = up.parentElement) if (all.has(up)) { inner = true; break; } if (!inner) outer++; }
    return { rf: main.getAttribute('data-rf'), knownHidden: pts.filter(p => known(p.k) && !p.shown).length, knownAll: pts.filter(p => known(p.k)).length, otherShown: pts.filter(p => !known(p.k) && p.k.length && p.shown).length, otherAll: pts.filter(p => !known(p.k) && p.k.length).length, notice: n ? Number(n.dataset.rfHidden) : null, outer };
  }, KNOWN_SELECTOR);
  ok(r.rf === 'known', `${tag}: ?filter=known sets main[data-rf="known"]`);
  ok(r.knownAll > 5 && r.knownHidden === r.knownAll, `${tag}: every known-ground line of the chapter is hidden (${r.knownHidden} of ${r.knownAll})`);
  ok(r.otherAll > 30 && r.otherShown === r.otherAll, `${tag}: every other tagged line stays (${r.otherShown} of ${r.otherAll})`);
  ok(r.notice !== null && r.notice === r.outer && r.notice >= r.knownAll, `${tag}: the page notice counts the ${r.outer} lines the page hides (${r.notice}), the chapter's ${r.knownAll} among them`);
  await ctx.close();
}
// ---- the light theme (the automatic inversion of the dark one): the chapter draws without error
{ const [ctx, pg, tag] = await open('en', 'Physicist', 1100, '?theme=light');
  ok(await pg.evaluate(() => document.documentElement.getAttribute('data-theme')) === 'light' && await pg.locator('#ln-category .eq-pt').count() > 50, `${tag}: the chapter in the light theme`);
  await ctx.close(); }
ok(COPY.en.menu && COPY.it.menu, 'copy loaded');
await b.close();
console.log(`${checks} checks`); console.log(bad ? `${bad} FAILURES` : 'ALL CATEGORY CHAPTER UI TESTS PASS'); process.exit(bad ? 1 : 0);
