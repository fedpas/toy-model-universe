// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Plain-words copy for the Young Learner on steps 5, 11 and 13 to 16 of the equations page and on the tally (English and Italian).
// No formulas and no technical words here, except very easy arithmetic; every count is read from the data files, never typed in.
// The formal pages are untouched: the Young Learner sees this text and the pictures with plain labels, and the formal content sits
// in a closed fold "For older readers". test_plain_steps.mjs checks this file (both languages, same shape, no formula or jargon pattern).
import PJ from './projectiveData.js';
import FQ from './forqueData.js';
import SPD from './spinData.js';
import SRD from './springData.js';
import PGD from './pgadynData.js';
import NUD from './nullData.js';
import { stepNo, numWord } from './steps.js';

const FC = FQ.fq.counts, FA = FQ.fq.paper.authors, SC = SPD.spm.counts, SA = SPD.spm.paper.authors, LEC = SPD.spm.lecture, SR = SRD.summary, PG = PGD.summary, NU = NUD.portal.summary;
const SCHK = SC.ok + SC.note, FQN = stepNo('eq', 'forque');
const comma = s => s.replace('.', ',');
const pl = (k, one, many) => (k === 1 ? one : many);

const en = {
  hedgesH: 'What we checked, what is an idea, what is open',
  projective: {
    title: 'Flat, curved like a ball, curved like a saddle: one more switch',
    story: [
      'Every space has its own moves: you can slide a thing, turn it, and in space and time you can also speed it up. Here we add one more switch to the rule of the cube, and the switch can be set in three ways.',
      'Set one way, it gives flat space, the space of school geometry. Set the other two ways, it gives a space curved like a ball or a space curved like a saddle. With time added, the same three settings give flat space-time and two curved space-times that physicists call de Sitter and anti-de Sitter.',
    ],
    tryH: 'Try it',
    try: 'Pick space only or space and time, a setting, and a number of directions. The picture puts the directions round a circle and the new switch in the middle. Each spoke joins a direction to the new switch, and its number says what that move does: −1 a turn that comes back round, +1 a stretch that never comes back, 0 a plain slide.',
    kinds: { space: 'space only', lorentz: 'space and time' },
    sLabel: { '0': 'flat', '-1': 'curved like a ball', '1': 'curved like a saddle' },
    names: { 'space,0': 'Flat space', 'space,-1': 'Space curved like a ball', 'space,1': 'Space curved like a saddle', 'lorentz,0': 'Flat space-time', 'lorentz,-1': 'Curved space-time (de Sitter)', 'lorentz,1': 'Curved space-time (anti-de Sitter)' },
    picH: 'The new switch in the middle',
    line: (name, moves, n) => `${name}: ${moves} basic moves with ${n} directions. Change the setting: the number of moves stays the same.`,
    cap: kind => `The dots are the directions${kind === 'lorentz' ? ' (the filled one is time)' : ''}; the circle in the middle is the new switch.`,
    nullH: 'Two more switches',
    nullCap: 'Two more switches, one set to +1 and one to −1, make two special directions: the red line and the blue line. Each has length zero, like a ray of light. With them a point, a flat wall and a ball become the same kind of thing, and growing, shrinking and turning space inside out through a ball become moves like the others.',
    hedges: [
      ['checked', 'A computer rebuilt every count on this page with exact arithmetic, and a second, independent check agrees.'],
      ['standard', 'These spaces and their moves are textbook mathematics; we did not invent them.'],
      ['ours', 'Reading the new switch as one more direction of the cube is our idea: an idea we try, not a result.'],
      ['open', 'Nothing moves by itself yet: pushes and spins come in a later step. The new switch is a kind of space, not a new force, and we claim no role in nature for it.'],
    ],
  },
  forque: {
    title: 'Push and spin as one line: we check a published paper',
    story: [
      'Push a box near one corner and it slides and turns at the same time. Two researchers, ' + FA.join(' and ') + ', wrote a paper that puts the push and the turn together in one object, so that one short rule moves the box.',
      `We typed their equations into our rule, one by one, and checked the numbers with a computer, exactly. ${FC.ok} of their ${FC.rows} lines came out exactly as printed, ${FC.note} came out right after a small adjustment, and ${FC.not_checked} we did not check. A line that does not come out letter for letter may be a typo, a different way of writing it or a slip of ours, so we wrote each one down for the authors: they can re-run every check too.`,
    ],
    tryH: 'Try it: the tennis racket',
    try: 'Throw a racket or a book in the air with a spin. About its longest side and its shortest side it spins smoothly; about the middle side it flips over and over. The three sliders say how hard the object is to turn about each side. Watch the three curves.',
    sl: ['side 1', 'side 2', 'side 3'],
    cap: 'The three curves show how fast the object spins about each side; time runs to the right.',
    out: r => (r.lam > 1e-3
      ? [`Spinning about side ${r.m + 1}, the middle one: a small wobble grows and the object flips. The formula predicts a growth of ${r.lam.toFixed(4)}; measured here: ${r.measured === null ? '—' : r.measured.toFixed(4)}.`]
      : ['Two sliders are equal: there is no middle side, and the spin stays steady.']),
    hedges: [
      ['checked', `We typed their equations into our rule and checked the numbers with exact arithmetic: ${FC.ok} lines agree exactly and ${FC.note} after a small adjustment we wrote down. The authors can re-run every check.`],
      ['standard', 'The equations are the authors’; the laws of pushes and spins they rest on are textbook physics.'],
      ['ours', 'Writing their equations on our rule is our translation, and seeing one of its switches as the new switch of the previous step is an idea we try, not a result. Each line shows its check, so that anyone can judge.'],
      ['open', `${FC.not_checked} items were not checked, and we read only this one paper: what other researchers wrote on the same subject we do not know yet.`],
    ],
  },
  spin: {
    title: 'Things that need two full turns to come back: a paper and a lecture, side by side',
    story: [
      'Hold a cup flat on your hand and turn it one full turn, keeping it level: your arm ends up twisted. Keep turning the same way for a second full turn, and your arm is straight again. Some things in physics behave like that: after one full turn they are not back as they were, after two they are.',
      `A paper by ${SA.slice(0, 2).join(', ')} and ${SA[2]}, and a lecture by ${LEC.speaker}, explain how to build such things out of mirrors. We typed their statements into our rule and checked them with a computer, exactly: ${SC.ok} agree exactly, ${SC.note} came out right after a small adjustment we wrote down for the authors, and ${SC.not_checked} we could not check. The authors can check our work too.`,
      'One letter, i, is used in these sources for four different things. We list the four and check how each behaves: that list is our reading, an idea we try, not a result.',
    ],
    tryH: 'Try it: the dial and the arrow',
    try: 'Drag the slider. The dial on the right turns; the arrow on the left turns twice as far. When the dial is half way round, the arrow is back home but the dial is not: it shows −1. Only a full turn of the dial brings both home.',
    dial: { h: 'The dial and the arrow', lede: '', slider: 'Turn the dial', play: 'Play', pause: 'Pause', vecLbl: 'the arrow', rotLbl: 'the dial',
      cap: 'Left: the arrow; the dashed line is where it starts. Right: the dial.',
      line1: deg => `The dial has turned ${deg}°.`, line2: deg => `The arrow has turned ${deg}°: twice as far, going round again after each full turn.`,
      states: ['the dial shows +1: home', 'the dial shows −1: not home', 'the dial is a quarter of the way round', 'the dial is three quarters of the way round'], back: 'the arrow is back where it started',
      double: 'The arrow is home, but the dial shows −1. Only a full turn of the dial brings both home.' },
    hedges: [
      ['checked', `${SCHK} of ${SC.rows} statements were typed into our rule and checked with exact arithmetic (${SC.ok} exactly, ${SC.note} after a small adjustment we wrote down). The authors can re-run every check.`],
      ['standard', 'The ideas are the authors’ and the lecturer’s: building these things out of mirrors, and the two turns, are theirs.'],
      ['ours', 'Laying the two sources side by side, and the list of four meanings of i, is our reading: an idea we try, not a result.'],
      ['open', `${SC.not_checked} statements were not checked. We saw the lecture only as slides and did not read two papers the authors build on, so whether we read the lecturer the way he meant in every case, nobody knows yet.`],
    ],
  },
  spring: {
    title: 'A spring on the cube: weights on the corners, springs on the edges',
    story: [
      'A weight sits on every corner of the cube, and a spring joins every two neighbours. Pull one weight and let go: the whole cube starts to wobble.',
      'The wobble is made of a few pure tones, like a bell. Each tone is a pattern of ups and downs, named with a corner label such as 101. The more 1s in the pattern, the faster it wobbles, and patterns with the same number of 1s wobble at the same speed.',
    ],
    tryH: 'Try it',
    try: 'Pick a pattern with the switches, or choose “Pluck a corner” and click a corner. Blue dots are above rest, amber dots below. When you pluck a corner every pattern joins in, and the total energy stays the same all the time: the check mark says the computer agrees.',
    cube: { h: 'Weights and springs on the cube', lede: '', nLbl: 'Size', sizes: { 2: 'square', 3: 'cube', 4: '4D cube' }, viewLbl: 'What to show', views: { mode: 'One pattern', pluck: 'Pluck a corner' }, bitsLbl: 'Switches of the pattern', bit: i => `switch ${i}:`, slider: 'Time', play: 'Play', pause: 'Pause',
      cap: 'The corners of the cube drawn flat; each dot moves up and down. The springs are the edges.',
      capMode: 'One pattern: every weight moves up and down in time with the others, some up while others go down.', capPluck: 'One corner is pulled up and let go; the others start at rest. Click a corner to pluck another one.',
      modeInfo: (s, j, w2, m) => `Pattern ${s} has ${numWord('en', j)} ${pl(j, '1', '1s')}. ${m} ${pl(m, 'pattern', 'patterns')} with ${numWord('en', j)} ${pl(j, '1', '1s')} ${pl(m, 'wobbles', 'wobble')} at this same speed.`,
      pluckInfo: v => `Plucked corner ${v}. At the start only it is pulled; then every pattern joins in.`,
      econs: (e, e0) => `Energy now ${e}, at the start ${e0}`,
      shareCols: ['number of 1s', 'patterns', 'share of the pluck'] },
    hedges: [
      ['checked', `A computer checked all ${SR.ok} claims on this page with exact arithmetic, including three tests that must fail on a wrong network, and do.`],
      ['standard', 'Springs, tones and the patterns of the cube are textbook physics and mathematics.'],
      ['ours', 'Seeing the corners, edges and faces of the cube as weights, springs and loops is our idea: an idea we try, not a result.'],
      ['open', 'Here each weight moves only up and down; real springs move every way. Whether the springs with signs have anything to do with the electron’s equation, nobody knows yet.'],
    ],
  },
  rigid: {
    title: 'One solid thing that moves: from a stick to a 4D cube',
    story: [
      'The same rule moves them all: the stick only slides, the square can also spin, and the cube and the 4D cube slide and turn every way. While the body moves, every corner keeps its label, such as 101.',
      `Then three bigger examples from a public collection: a book thrown in the air flips about its middle side, the Moon goes round the Earth in about ${PGD.moon.period_days} days, and the Sun and five planets pull on each other.`,
    ],
    tryH: 'Try it: hang it from a spring',
    try: 'Pick a shape and which corner is hooked (one switch per direction), set how stiff the spring is and how strong gravity is, then press Drop. A little friction makes it settle. The check marks say the computer agrees: the total energy stays the same (unless friction is on), and every body stays solid.',
    hang: { lede: '', nLbl: 'Shape', segment: 'Stick', square: 'Square', cube: 'Cube', tesseract: '4D cube', nbLbl: 'Bodies in the chain', bodies: q => (q === 1 ? '1 body' : `${q} bodies`), topLbl: 'Hooked corner, switch by switch', bit: i => `switch ${i}:`,
      k: 'How stiff the spring is', g: 'Gravity', al: 'Friction', tilt: 'Starting tilt', time: 'time', view: 'Viewing angle', pause: 'Pause', drop: 'Drop', step: 'Step', reset: 'Reset',
      cap: 'Bodies hanging from the ceiling by springs (the zigzags). The hooked corner is amber; the dotted lines are the paths of the centres.',
      attach: (b, name, cb) => `Hooked at corner ${b}; the opposite corner ${cb} is where the next body hooks on.`,
      energy: (k, u, s, e) => `Energy of motion ${k}, of height ${u}, in the springs ${s}; total ${e}`,
      damped: 'Friction is on: the total energy goes down, as it should.', drift: () => 'The total energy has stayed the same.',
      norm: () => 'Every body has stayed solid.', speed: () => '',
      rest: () => 'Tilt 0: the chain started in balance and has not moved.' },
    hedges: [
      ['checked', `A computer checked all ${PG.ok} claims on this page with exact arithmetic, and compared some of them with a free library that others use (ganja.js).`],
      ['standard', `The laws of motion used here (Newton, Hooke, Euler) are textbook, and so is the way of writing them, from the paper checked in step ${FQN}.`],
      ['ours', 'Giving a corner of the cube, a piece of the rule and the number that moves it one and the same label is our idea: an idea we try, not a result.'],
      ['open', 'How much faster the labels make a computer is measured, not proved, and depends on the machine. The planets come from a printed table we could not compare with the official one. Bumps, joints and friction against a floor are not here.'],
    ],
  },
  nullsurf: {
    title: 'Light that stays on a surface: the edge of a black hole',
    story: [
      'Light always moves. But at the edge of a black hole, light that points straight out stays where it is: it runs along the edge and never gets away. So the edge is a surface made of light that stands still.',
      `Four researchers (Hsu, Barker, Hobson and Lasenby) wrote a paper about such surfaces. We rebuilt four of their claims on our rule and checked them with a computer: ${NU.passed} of ${NU.computed} checks pass, and ${NU.readings} statements are ideas of ours that the computer does not check. The claims hold, with care: a popular test for finding the edge works only in some cases, and the page shows where it fails.`,
    ],
    tryH: 'Try it',
    try: 'Pick an example and move the slider. The coloured line is a test surface near the edge, and the little cones show where light can go. On one side of the edge a slow traveller could stay on the test surface; on the edge only light can; on the other side nothing can, not even light.',
    cone: { caseH: 'Which example', probe: 'Distance of the test surface from the edge', onSurf: 'Put it on the edge',
      aria: 'Little light cones along a line, a test surface across it, and the edge',
      cases: { schw: 'a black hole', rn_out: 'a charged black hole, outer edge', rn_in: 'a charged black hole, inner edge', extremal: 'the two edges joined', areal: 'a fifth test case' },
      kinds: { timelike: 'a slow traveller could stay on it', null: 'only light can stay on it: this is the edge', spacelike: 'nothing can stay on it, not even light' },
      surface: 'The test surface:',
      lab: { xi: 'light along it', n: 'across', surface: 'test surface' },
      cap: 'Grey: little cones showing where light can go at each place. Colour: the cone at the test surface. When the test surface reaches the edge, one side of its cone lies flat along the surface: light pointing that way stays on the surface. On the left, the dot sits on the upright line exactly when the test surface is on the edge.' },
    hedges: [
      ['checked', `${NU.passed} of ${NU.computed} checks pass, recomputed with exact fractions by a script that anyone can run.`],
      ['standard', 'Black holes and their edges are textbook physics.'],
      ['ours', `${NU.readings} statements are our own readings, for example that the rules of the edge look like one face of the cube. They are ideas we try, not results, and the computer does not check them.`],
      ['open', 'One part of the paper is not rebuilt here, we read only a little of the papers it cites, and nobody else has gone through our checks yet.'],
    ],
  },
  tally: {
    h: 'What was checked, what is an idea, what is open',
    names: { maxwell: 'Light and electricity', comm: 'Turns where the order matters', dirac: 'The electron', coupling: 'Electron and light together', ym: 'Stronger forces', matter: 'Matter with colour labels', grav1: 'Gravity: how space twists', grav2: 'Gravity: Einstein’s equation', mirrors: 'Mirrors', projective: 'Flat and curved spaces', gauge: 'Gravity at the edge of a black hole', forque: 'Push and spin: a published paper', spin: 'Two turns to come back: a paper and a lecture', spring: 'Springs on a cube', rigid: 'A solid body that moves', nullsurf: 'Light that stays on a surface' },
    where: (k, step) => (k === 'maxwell' ? 'Warm-up 1' : `step ${step}`),
    sums: (n, c, s, o, q, i) => [
      (c === n ? `All ${n} rows were checked by a computer.` : `${c} of the ${n} rows were checked by a computer.`),
      `${s} rows rebuild textbook mathematics or physics.`,
      `${o} rows also carry an idea of ours: an idea we try, not a result.`,
      `${q} rows also say what is not done here or still open.`,
      `${i} rows also say what is brought in from outside.`,
    ],
    solve: 'Most rows show where the pieces of an equation sit and check its rules; they do not solve it. The springs and the moving bodies are also followed in time, and checked.',
    next: 'Not drawn yet: how left and right hands feel different forces, the electron in curved space, gravity pulling on matter, and the answers to any of these equations.',
  },
};

const it = {
  hedgesH: 'Che cosa abbiamo controllato, che cosa è un’idea, che cosa è aperto',
  projective: {
    title: 'Piatto, curvo come una palla, curvo come una sella: un interruttore in più',
    story: [
      'Ogni spazio ha i suoi movimenti: puoi far scivolare una cosa, girarla, e nello spazio-tempo puoi anche farla andare più veloce. Qui aggiungiamo un interruttore alla regola del cubo, e l’interruttore si può mettere in tre modi.',
      'In un modo dà lo spazio piatto, quello della geometria di scuola. Negli altri due modi dà uno spazio curvo come una palla o uno spazio curvo come una sella. Aggiungendo il tempo, le stesse tre posizioni danno lo spazio-tempo piatto e due spazi-tempo curvi che i fisici chiamano de Sitter e anti-de Sitter.',
    ],
    tryH: 'Prova',
    try: 'Scegli solo spazio oppure spazio e tempo, una posizione dell’interruttore e un numero di direzioni. Il disegno mette le direzioni in cerchio e il nuovo interruttore al centro. Ogni raggio unisce una direzione al nuovo interruttore, e il suo numero dice che cosa fa quel movimento: −1 un giro che torna al punto di partenza, +1 uno stiramento che non torna più, 0 una semplice scivolata.',
    kinds: { space: 'solo spazio', lorentz: 'spazio e tempo' },
    sLabel: { '0': 'piatto', '-1': 'curvo come una palla', '1': 'curvo come una sella' },
    names: { 'space,0': 'Spazio piatto', 'space,-1': 'Spazio curvo come una palla', 'space,1': 'Spazio curvo come una sella', 'lorentz,0': 'Spazio-tempo piatto', 'lorentz,-1': 'Spazio-tempo curvo (de Sitter)', 'lorentz,1': 'Spazio-tempo curvo (anti-de Sitter)' },
    picH: 'Il nuovo interruttore al centro',
    line: (name, moves, n) => `${name}: ${moves} movimenti di base con ${n} direzioni. Cambia la posizione: il numero dei movimenti resta lo stesso.`,
    cap: kind => `I punti sono le direzioni${kind === 'lorentz' ? ' (quello pieno è il tempo)' : ''}; il cerchio al centro è il nuovo interruttore.`,
    nullH: 'Due interruttori in più',
    nullCap: 'Due interruttori in più, uno messo a +1 e uno a −1, danno due direzioni speciali: la linea rossa e la linea blu. Ciascuna ha lunghezza zero, come un raggio di luce. Con loro un punto, una parete piatta e una palla diventano lo stesso tipo di cosa, e ingrandire, rimpicciolire e rovesciare lo spazio attraverso una palla diventano movimenti come gli altri.',
    hedges: [
      ['checked', 'Un computer ha ricostruito ogni conteggio di questa pagina con aritmetica esatta, e un secondo controllo indipendente è d’accordo.'],
      ['standard', 'Questi spazi e i loro movimenti sono matematica da manuale; non li abbiamo inventati noi.'],
      ['ours', 'Leggere il nuovo interruttore come una direzione in più del cubo è una nostra idea: un’idea che proviamo, non un risultato.'],
      ['open', 'Per ora niente si muove da solo: spinte e rotazioni arrivano in un passo successivo. Il nuovo interruttore è un tipo di spazio, non una forza nuova, e non gli attribuiamo alcun ruolo in natura.'],
    ],
  },
  forque: {
    title: 'Spinta e rotazione in una sola riga: controlliamo un articolo pubblicato',
    story: [
      'Spingi una scatola vicino a un angolo: scivola e gira nello stesso momento. Due ricercatori, ' + FA.join(' e ') + ', hanno scritto un articolo che mette insieme la spinta e la rotazione in un solo oggetto, così che una sola regola breve muove la scatola.',
      `Abbiamo scritto le loro equazioni nella nostra regola, una per una, e abbiamo controllato i numeri con un computer, in modo esatto. ${FC.ok} delle loro ${FC.rows} righe escono esattamente come sono stampate, ${FC.note} tornano dopo un piccolo aggiustamento, e ${FC.not_checked} non le abbiamo controllate. Una riga che non esce lettera per lettera può essere un refuso, un modo diverso di scriverla o una nostra svista, quindi le abbiamo scritte tutte per gli autori: anche loro possono rifare ogni controllo.`,
    ],
    tryH: 'Prova: la racchetta da tennis',
    try: 'Lancia in aria una racchetta o un libro facendoli girare. Attorno al lato più lungo e a quello più corto girano tranquilli; attorno al lato di mezzo si ribaltano di continuo. I tre cursori dicono quanto è difficile far girare l’oggetto attorno a ciascun lato. Guarda le tre curve.',
    sl: ['lato 1', 'lato 2', 'lato 3'],
    cap: 'Le tre curve mostrano quanto in fretta l’oggetto gira attorno a ciascun lato; il tempo scorre verso destra.',
    out: r => (r.lam > 1e-3
      ? [`Gira attorno al lato ${r.m + 1}, quello di mezzo: un piccolo tremolio cresce e l’oggetto si ribalta. La formula prevede una crescita di ${comma(r.lam.toFixed(4))}; misurata qui: ${r.measured === null ? '—' : comma(r.measured.toFixed(4))}.`]
      : ['Due cursori sono uguali: non c’è un lato di mezzo, e la rotazione resta tranquilla.']),
    hedges: [
      ['checked', `Abbiamo scritto le loro equazioni nella nostra regola e controllato i numeri con aritmetica esatta: ${FC.ok} righe tornano esattamente e ${FC.note} dopo un piccolo aggiustamento che abbiamo annotato. Gli autori possono rifare ogni controllo.`],
      ['standard', 'Le equazioni sono degli autori; le leggi di spinte e rotazioni su cui poggiano sono fisica da manuale.'],
      ['ours', 'Scrivere le loro equazioni sulla nostra regola è una nostra traduzione, e vedere uno dei suoi interruttori come il nuovo interruttore del passo precedente è un’idea che proviamo, non un risultato. Ogni riga mostra il suo controllo, perché chiunque possa giudicare.'],
      ['open', `${FC.not_checked} voci non sono state controllate, e abbiamo letto solo questo articolo: che cosa abbiano scritto altri ricercatori sullo stesso tema non lo sappiamo ancora.`],
    ],
  },
  spin: {
    title: 'Cose che tornano come prima solo dopo due giri: un articolo e una lezione, affiancati',
    story: [
      'Tieni una tazza in piano sulla mano e falle fare un giro intero, sempre in piano: il braccio finisce attorcigliato. Continua a girare nello stesso verso per un secondo giro, e il braccio torna dritto. Alcune cose della fisica si comportano così: dopo un giro intero non sono tornate come prima, dopo due sì.',
      `Un articolo di ${SA.slice(0, 2).join(', ')} e ${SA[2]}, e una lezione di ${LEC.speaker}, spiegano come costruire cose del genere con gli specchi. Abbiamo scritto le loro affermazioni nella nostra regola e le abbiamo controllate con un computer, in modo esatto: ${SC.ok} tornano esattamente, ${SC.note} tornano dopo un piccolo aggiustamento che abbiamo annotato per gli autori, e ${SC.not_checked} non abbiamo potuto controllarle. Anche gli autori possono controllare il nostro lavoro.`,
      'In queste fonti una sola lettera, i, è usata per quattro cose diverse. Le elenchiamo e controlliamo come si comporta ciascuna: quell’elenco è una nostra lettura, un’idea che proviamo, non un risultato.',
    ],
    tryH: 'Prova: il quadrante e la freccia',
    try: 'Trascina il cursore. Il quadrante a destra gira; la freccia a sinistra gira il doppio. Quando il quadrante è a metà giro, la freccia è tornata a casa ma il quadrante no: segna −1. Solo un giro intero del quadrante riporta a casa tutti e due.',
    dial: { h: 'Il quadrante e la freccia', lede: '', slider: 'Gira il quadrante', play: 'Avvia', pause: 'Pausa', vecLbl: 'la freccia', rotLbl: 'il quadrante',
      cap: 'A sinistra: la freccia; la linea tratteggiata è il punto di partenza. A destra: il quadrante.',
      line1: deg => `Il quadrante ha girato di ${deg}°.`, line2: deg => `La freccia ha girato di ${deg}°: il doppio, e ricomincia da capo dopo ogni giro intero.`,
      states: ['il quadrante segna +1: a casa', 'il quadrante segna −1: non è a casa', 'il quadrante ha fatto un quarto di giro', 'il quadrante ha fatto tre quarti di giro'], back: 'la freccia è tornata dov’era partita',
      double: 'La freccia è a casa, ma il quadrante segna −1. Solo un giro intero del quadrante riporta a casa tutti e due.' },
    hedges: [
      ['checked', `${SCHK} affermazioni su ${SC.rows} sono state scritte nella nostra regola e controllate con aritmetica esatta (${SC.ok} esattamente, ${SC.note} dopo un piccolo aggiustamento annotato). Gli autori possono rifare ogni controllo.`],
      ['standard', 'Le idee sono degli autori e del docente: costruire queste cose con gli specchi, e i due giri, sono loro.'],
      ['ours', 'Affiancare le due fonti, e l’elenco dei quattro significati di i, è una nostra lettura: un’idea che proviamo, non un risultato.'],
      ['open', `${SC.not_checked} affermazioni non sono state controllate. Abbiamo visto la lezione solo come diapositive e non abbiamo letto due articoli su cui gli autori si basano, quindi se abbiamo sempre letto il docente come intendeva lui, nessuno lo sa ancora.`],
    ],
  },
  spring: {
    title: 'Una molla sul cubo: pesi sugli angoli, molle sugli spigoli',
    story: [
      'Su ogni angolo del cubo c’è un peso, e una molla unisce ogni coppia di vicini. Tira un peso e lascialo andare: tutto il cubo comincia a tremolare.',
      'Il tremolio è fatto di pochi toni puri, come una campana. Ogni tono è uno schema di su e giù, con il nome di un angolo come 101. Più 1 ci sono nello schema, più in fretta tremola, e gli schemi con lo stesso numero di 1 tremolano alla stessa velocità.',
    ],
    tryH: 'Prova',
    try: 'Scegli uno schema con gli interruttori, oppure scegli «Pizzica un angolo» e fai clic su un angolo. I punti blu sono sopra la quiete, quelli ambra sotto. Quando pizzichi un angolo entrano tutti gli schemi, e l’energia totale resta sempre la stessa: il segno di spunta dice che il computer è d’accordo.',
    cube: { h: 'Pesi e molle sul cubo', lede: '', nLbl: 'Grandezza', sizes: { 2: 'quadrato', 3: 'cubo', 4: 'cubo 4D' }, viewLbl: 'Che cosa mostrare', views: { mode: 'Uno schema', pluck: 'Pizzica un angolo' }, bitsLbl: 'Interruttori dello schema', bit: i => `interruttore ${i}:`, slider: 'Tempo', play: 'Avvia', pause: 'Pausa',
      cap: 'Gli angoli del cubo disegnati in piano; ogni punto sale e scende. Le molle sono gli spigoli.',
      capMode: 'Uno schema: tutti i pesi salgono e scendono a tempo, alcuni su mentre altri vanno giù.', capPluck: 'Un angolo viene tirato su e lasciato andare; gli altri partono fermi. Fai clic su un angolo per pizzicarne un altro.',
      modeInfo: (s, j, w2, m) => `Lo schema ${s} ha ${pl(j, 'un solo 1', numWord('it', j) + ' 1')}. ${m} ${pl(m, 'schema', 'schemi')} con ${pl(j, 'un solo 1', numWord('it', j) + ' 1')} ${pl(m, 'tremola', 'tremolano')} a questa stessa velocità.`,
      pluckInfo: v => `Angolo pizzicato ${v}. All’inizio solo lui è tirato; poi entrano tutti gli schemi.`,
      econs: (e, e0) => `Energia adesso ${e}, all’inizio ${e0}`,
      shareCols: ['numero di 1', 'schemi', 'quota della pizzicata'] },
    hedges: [
      ['checked', `Un computer ha controllato tutte le ${SR.ok} affermazioni di questa pagina con aritmetica esatta, compresi tre test che devono fallire su una rete sbagliata, e falliscono.`],
      ['standard', 'Molle, toni e gli schemi del cubo sono fisica e matematica da manuale.'],
      ['ours', 'Vedere angoli, spigoli e facce del cubo come pesi, molle e giri chiusi è una nostra idea: un’idea che proviamo, non un risultato.'],
      ['open', 'Qui ogni peso si muove solo su e giù; le molle vere si muovono in ogni verso. Se le molle con i segni abbiano a che fare con l’equazione dell’elettrone, nessuno lo sa ancora.'],
    ],
  },
  rigid: {
    title: 'Una sola cosa solida che si muove: da un bastoncino a un cubo 4D',
    story: [
      'La stessa regola li muove tutti: il bastoncino scivola soltanto, il quadrato può anche girare, e il cubo e il cubo 4D scivolano e girano in ogni verso. Mentre il corpo si muove, ogni angolo tiene la sua etichetta, come 101.',
      `Poi tre esempi più grandi da una raccolta pubblica: un libro lanciato in aria si ribalta attorno al lato di mezzo, la Luna gira attorno alla Terra in circa ${comma(PGD.moon.period_days)} giorni, e il Sole e cinque pianeti si attirano tra loro.`,
    ],
    tryH: 'Prova: appendilo a una molla',
    try: 'Scegli una forma e quale angolo è agganciato (un interruttore per direzione), decidi quanto è dura la molla e quanto è forte la gravità, poi premi Lascia cadere. Un po’ di attrito lo fa fermare. I segni di spunta dicono che il computer è d’accordo: l’energia totale resta la stessa (se l’attrito è spento), e ogni corpo resta solido.',
    hang: { lede: '', nLbl: 'Forma', segment: 'Bastoncino', square: 'Quadrato', cube: 'Cubo', tesseract: 'Cubo 4D', nbLbl: 'Corpi nella catena', bodies: q => (q === 1 ? '1 corpo' : `${q} corpi`), topLbl: 'Angolo agganciato, interruttore per interruttore', bit: i => `interruttore ${i}:`,
      k: 'Quanto è dura la molla', g: 'Gravità', al: 'Attrito', tilt: 'Inclinazione iniziale', time: 'tempo', view: 'Angolo di vista', pause: 'Pausa', drop: 'Lascia cadere', step: 'Passo', reset: 'Azzera',
      cap: 'Corpi appesi al soffitto con molle (gli zigzag). L’angolo agganciato è ambra; le linee punteggiate sono i percorsi dei centri.',
      attach: (b, name, cb) => `Agganciato all’angolo ${b}; l’angolo opposto ${cb} è dove si aggancia il corpo successivo.`,
      energy: (k, u, s, e) => `Energia del moto ${k}, dell’altezza ${u}, nelle molle ${s}; totale ${e}`,
      damped: 'L’attrito è acceso: l’energia totale scende, com’è giusto.', drift: () => 'L’energia totale è rimasta la stessa.',
      norm: () => 'Ogni corpo è rimasto solido.', speed: () => '',
      rest: () => 'Inclinazione 0: la catena è partita in equilibrio e non si è mossa.' },
    hedges: [
      ['checked', `Un computer ha controllato tutte le ${PG.ok} affermazioni di questa pagina con aritmetica esatta, e ne ha confrontate alcune con una libreria libera usata da altri (ganja.js).`],
      ['standard', `Le leggi del moto usate qui (Newton, Hooke, Eulero) sono da manuale, e lo è anche il modo di scriverle, preso dall’articolo controllato nel passo ${FQN}.`],
      ['ours', 'Dare a un angolo del cubo, a un pezzo della regola e al numero che lo muove una sola e stessa etichetta è una nostra idea: un’idea che proviamo, non un risultato.'],
      ['open', 'Di quanto le etichette rendano più veloce un computer è misurato, non dimostrato, e dipende dalla macchina. I pianeti vengono da una tabella stampata che non abbiamo potuto confrontare con quella ufficiale. Urti, giunti e attrito contro un pavimento non ci sono.'],
    ],
  },
  nullsurf: {
    title: 'Luce che resta su una superficie: il bordo di un buco nero',
    story: [
      'La luce si muove sempre. Ma al bordo di un buco nero, la luce che punta dritto verso l’esterno resta dov’è: corre lungo il bordo e non riesce mai ad allontanarsi. Così il bordo è una superficie fatta di luce ferma.',
      `Quattro ricercatori (Hsu, Barker, Hobson e Lasenby) hanno scritto un articolo su queste superfici. Abbiamo ricostruito quattro delle loro affermazioni sulla nostra regola e le abbiamo controllate con un computer: ${NU.passed} controlli su ${NU.computed} riescono, e ${NU.readings} affermazioni sono idee nostre che il computer non controlla. Le affermazioni reggono, con attenzione: un test molto usato per trovare il bordo funziona solo in alcuni casi, e la pagina mostra dove fallisce.`,
    ],
    tryH: 'Prova',
    try: 'Scegli un esempio e muovi il cursore. La linea colorata è una superficie di prova vicino al bordo, e i piccoli coni mostrano dove può andare la luce. Da una parte del bordo un viaggiatore lento potrebbe restare sulla superficie di prova; sul bordo solo la luce può; dall’altra parte niente può, nemmeno la luce.',
    cone: { caseH: 'Quale esempio', probe: 'Distanza della superficie di prova dal bordo', onSurf: 'Mettila sul bordo',
      aria: 'Piccoli coni di luce lungo una linea, una superficie di prova che la attraversa, e il bordo',
      cases: { schw: 'un buco nero', rn_out: 'un buco nero carico, bordo esterno', rn_in: 'un buco nero carico, bordo interno', extremal: 'i due bordi uniti', areal: 'un quinto caso di prova' },
      kinds: { timelike: 'un viaggiatore lento potrebbe restarci', null: 'solo la luce può restarci: questo è il bordo', spacelike: 'niente può restarci, nemmeno la luce' },
      surface: 'La superficie di prova:',
      lab: { xi: 'luce lungo di essa', n: 'di traverso', surface: 'superficie di prova' },
      cap: 'Grigio: piccoli coni che mostrano dove può andare la luce in ogni punto. Colore: il cono sulla superficie di prova. Quando la superficie di prova arriva al bordo, un lato del suo cono si posa lungo la superficie: la luce che punta da quella parte resta sulla superficie. A sinistra, il punto sta sulla linea verticale esattamente quando la superficie di prova è sul bordo.' },
    hedges: [
      ['checked', `${NU.passed} controlli su ${NU.computed} riescono, ricalcolati con frazioni esatte da uno script che chiunque può eseguire.`],
      ['standard', 'I buchi neri e i loro bordi sono fisica da manuale.'],
      ['ours', `${NU.readings} affermazioni sono letture nostre, per esempio che le regole del bordo somigliano a una faccia del cubo. Sono idee che proviamo, non risultati, e il computer non le controlla.`],
      ['open', 'Una parte dell’articolo non è ricostruita qui, abbiamo letto solo poco degli articoli che cita, e nessun altro ha ancora ripercorso i nostri controlli.'],
    ],
  },
  tally: {
    h: 'Che cosa è controllato, che cosa è un’idea, che cosa è aperto',
    names: { maxwell: 'Luce ed elettricità', comm: 'Rotazioni in cui l’ordine conta', dirac: 'L’elettrone', coupling: 'Elettrone e luce insieme', ym: 'Forze più forti', matter: 'Materia con etichette di colore', grav1: 'Gravità: come si torce lo spazio', grav2: 'Gravità: l’equazione di Einstein', mirrors: 'Specchi', projective: 'Spazi piatti e curvi', gauge: 'Gravità al bordo di un buco nero', forque: 'Spinta e rotazione: un articolo pubblicato', spin: 'Due giri per tornare: un articolo e una lezione', spring: 'Molle su un cubo', rigid: 'Un corpo solido che si muove', nullsurf: 'Luce che resta su una superficie' },
    where: (k, step) => (k === 'maxwell' ? 'Warm-up 1' : `passo ${step}`),
    sums: (n, c, s, o, q, i) => [
      (c === n ? `Tutte le ${n} righe sono state controllate da un computer.` : `${c} righe su ${n} sono state controllate da un computer.`),
      `${s} righe ricostruiscono matematica o fisica da manuale.`,
      `${o} righe portano anche una nostra idea: un’idea che proviamo, non un risultato.`,
      `${q} righe dicono anche che cosa non è fatto qui o è ancora aperto.`,
      `${i} rows also say what is brought in from outside.`,
    ],
    solve: 'Quasi tutte le righe mostrano dove stanno i pezzi di un’equazione e ne controllano le regole; non la risolvono. Le molle e i corpi in movimento sono anche seguiti nel tempo, e controllati.',
    next: 'Non ancora disegnati: come la mano sinistra e la destra sentono forze diverse, l’elettrone nello spazio curvo, la gravità che tira la materia, e le risposte di tutte queste equazioni.',
  },
};

export const PLAIN = { en, it };
export default PLAIN;
