// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The widgets of the Schuller chapter (step 20, SchullerWidgets.jsx) in a real browser, through the real route #lenses/schuller: every widget is found by
// its data-widget, opened if a fold holds it, and driven (stones, chips, sliders, number fields, the null toggle, the seats, the magnets); the readout must
// show what schullerEngine.js and the stored fixture (schullerWidgetData.js) give, the badge must say live / stored / live = stored correctly, and the twin
// table must hold the numbers of the picture. In English and Italian, for the three audiences, at 1100 and 375 px, in the dark and the light theme: no page
// error, no horizontal scroll, and for the Young Learner no formula and no technical word in what a widget shows. Who sees which widget is the chapter's
// choice (DECISIONS.md §3): a widget listed for an audience must be there; one that is there is driven.
// Run: node test_lens_schuller_widgets_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist; QUICK=1 drives one view per audience)
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import * as E from './schullerEngine.js';
import DATA from './schullerWidgetData.js';
import { SWC } from './schullerWidgetsCopy.js';
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const AUD = { SW1: 'YPM', SW2: 'YPM', SW3: 'YPM', SW4: 'PM', SW5: 'YPM', SW6: 'YPM', SW7: 'YP' };   // DECISIONS.md §3: who must see each widget
const PROF = { Y: 'Young Learner', P: 'Physicist', M: 'Mathematician' };
const SYMBOLS = /[∇∂∫∑∏⊗⊕⊙≅≈≠≤≥∈∉∀∃⟨⟩†ℝℂℍ𝕆𝔹𝕊𝕍ℤℕ→↔⇒⇔√∞∧∨⊂⊃∪∩⊥ωψφθΩλμνρσκτΣΔΓΛΠΦΨΘαβγδεζηιξπχ]|[₀-₉⁰¹⁴-⁹]|\^|[A-Za-z0-9)\]}]_[A-Za-z0-9{(]|\bCl\(|\bM\d*\(|\bdet\b|\bTr\b|[²³ⁿ±½⅓¼¾ℏ]|\b[a-zA-Z]\s*=\s*[−+-]?[a-zA-Z0-9]|\b[b-df-hj-np-tv-zB-DF-HJ-NP-TV-Z]\s?[−±]\s?\d/;   // test_yl_ui.mjs (its main part)
const JARGON = /isomorph|idempotent|pseudoscalar|bivector|multivector|\bWitt\b|involution|eigen(value|vector)|Lagrangian|Hamiltonian|manifold|automorphism|Casimir|Lie algebra|tensor|commutator|anticommut|Clifford algebra|quadratic form|covariant|gauge|Hodge|spinor|rotor|versor|axiom|assiom|quaternion/i;
const clean = t => t.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json|md|html|txt|sh)\b/g, ' ');
const nums = t => (t.replace(/−/g, '-').replace(/(\d),(\d)/g, '$1.$2').match(/-?\d+(\.\d+)?/g) || []).map(Number);

async function open(w, lang, prof, theme, tag) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce' }), pg = await ctx.newPage(), errs = [];
  pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => m.type() === 'error' && errs.push('console: ' + m.text()));
  await pg.goto(APP + (theme === 'light' ? '?theme=light' : '') + '#lenses/schuller'); await pg.waitForTimeout(400);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(500);
  await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { if (d.querySelector('[data-widget]')) d.open = true; })); await pg.waitForTimeout(200);
  return { ctx, pg, errs, tag };
}
const W = (pg, id) => pg.locator(`[data-widget="${id}"]`).first();
const txt = async loc => (await loc.innerText()).replace(/\s+/g, ' ').trim();
const click = async loc => { await loc.scrollIntoViewIfNeeded(); await loc.click(); await loc.page().waitForTimeout(90); };
const badges = loc => loc.locator('[data-badge]').evaluateAll(es => es.map(e => e.dataset.badge));
const twinOk = async (loc, name) => (await loc.locator(`[data-twin="${name}"] tbody tr`).evaluateAll(rs => rs.map(r => [...r.children].map(c => c.textContent.trim())))).every(r => r[1] === r[2]);

async function sw1(pg, lang, y, tag) {
  const w = W(pg, 'SW1'), t = SWC[lang].sw1[y ? 'yl' : 'pm'];
  ok(await w.locator('[data-stone]').evaluateAll(es => es.map(e => e.dataset.grade).join('')) === 'SEESSSA', tag + ' SW1: seven stones graded S, E, E, S, S, S, A');
  await click(w.locator('[data-stone="3"]'));
  ok(await w.locator('[data-stone="3"]').getAttribute('aria-pressed') === 'true' && (await txt(w.locator('[data-out="sw1"]'))).includes(t.grades.E), tag + ' SW1: stone 3 is pressed and the readout names its grade: ' + await txt(w.locator('[data-out="sw1"]')));
  await click(w.locator('[data-open-grid]'));
  const cells = await w.locator('[data-grid] td[data-cell]').evaluateAll(es => es.map(e => [e.dataset.cell, e.dataset.kind]));
  ok(cells.length === 52 && cells.every(([c, k]) => DATA.p1.cells[c] === k) && cells.filter(c => c[1] === 'hyperbolic').length === 15, tag + ` SW1: the grid of stone 3 shows the 52 cells of n = 2..9 as stored, 15 pass (${cells.length})`);
  await w.locator('[data-stone="5"]').focus(); await pg.keyboard.press('Enter'); await pg.waitForTimeout(80);
  ok(await w.locator('[data-stone="5"]').getAttribute('aria-pressed') === 'true' && (await txt(w.locator('[data-panel="5"]'))).length > 20, tag + ' SW1: the keyboard opens stone 5');
  const bd = await badges(w); ok(bd.includes('fig') && bd.includes('match') && !bd.includes('differ'), tag + ' SW1: badges stored (Fig. 1) and live = stored: ' + bd);
  if (!y) ok(await twinOk(w, 'sw1'), tag + ' SW1: the twin table holds the live and the stored hyperbolic cells, equal');
}
async function sw2(pg, lang, y, tag) {
  const w = W(pg, 'SW2'), t = SWC[lang].sw2[y ? 'yl' : 'pm'];
  for (const sq of [[1, -1], [0, 1], [-1, -1, 0], [0, 0, 0]]) {
    const cur = await w.locator('[data-chips="n"] [aria-pressed="true"]').getAttribute('data-v'); if (+cur !== sq.length) await click(w.locator(`[data-chips="n"] [data-v="${sq.length}"]`));
    for (let i = 0; i < sq.length; i++) await click(w.locator(`[data-chips="sq${i}"] [data-v="${sq[i]}"]`));
    const signs = await w.locator('[data-table] td[data-ab]').evaluateAll(es => es.map(e => +e.dataset.sign)), T = E.productTable(sq), st = DATA.p1c[sq.join(',')];
    ok(signs.length === 4 ** sq.length && signs.every((s, i) => s === T[Math.floor(i / (1 << sq.length))][i % (1 << sq.length)].sign), tag + ` SW2 ${sq}: the table shows the bit-rule signs`);
    const out = nums(await txt(w.locator('[data-out="sw2"]')));
    ok(out.includes(st.zeros) && out.includes(st.minus), tag + ` SW2 ${sq}: the readout shows ${st.zeros} vanishing products and ${st.minus} minus signs`);
    ok((await badges(w)).includes('match'), tag + ` SW2 ${sq}: live = stored`);
    if (!y) ok(await twinOk(w, 'sw2'), tag + ` SW2 ${sq}: the twin table, live = stored`);
  }
  await click(w.locator('[data-preset="plus"]')); ok((await w.locator('[data-table] td[data-sign="0"]').count()) === 0, tag + ' SW2: the preset all plus leaves no vanishing product');
}
async function sw3(pg, lang, y, tag) {
  const w = W(pg, 'SW3');
  for (const k of [2, 7, 0]) {
    await w.locator('[data-sl="k"]').fill(String(k)); await pg.waitForTimeout(250);
    const r = DATA.p3.rows[k], out = await txt(w.locator('[data-out="sw3"]')), v = nums(out);
    if (y) ok(v.includes(r.outside) && v.includes(r.inside) && out.includes(SWC[lang].typesYl[r.base_type]), tag + ` SW3 k = ${k}: outside ${r.outside}, inside ${r.inside}, ${SWC[lang].typesYl[r.base_type]}: ${out}`);
    else ok(v.includes(r.fibre_dim) && v.includes(r.double_dim) && out.includes(`${r.base_type} | ${r.fibre_type}`), tag + ` SW3 k = ${k}: commutant ${r.fibre_dim}, double ${r.double_dim}, types ${r.base_type} | ${r.fibre_type}: ${out.slice(0, 120)}`);
    ok((await badges(w))[0] === 'match', tag + ` SW3 k = ${k}: live = stored`);
  }
  if (y) return;
  const lr = w.locator('[data-lr]');
  await click(lr.locator('[data-chips="lrsig"] [data-v="[2,2]"]'));
  let out = await txt(lr.locator('[data-out="sw3lr"]')); ok(/✓/.test(out) && nums(out).includes(256) && (await badges(lr)).includes('match'), tag + ' SW3: Cl(2,2): the 256 products L_a R′_b have rank 256, live = stored: ' + out.slice(0, 100));
  await lr.locator('[data-null]').check(); await pg.waitForTimeout(150); out = await txt(lr.locator('[data-out="sw3lr"]'));
  ok(nums(out).includes(DATA.p3b['2,1,1'].rank_LRt) && /e4/.test(out) && (await badges(lr)).includes('match'), tag + ` SW3: the last generator made null: rank ${DATA.p3b['2,1,1'].rank_LRt} and R′ = L for e4: ` + out.slice(0, 160));
  await click(lr.locator('[data-chips="lrgen"] [data-v="3"]'));
  const same = await lr.locator('svg').evaluateAll(s => { const r = v => [...v.querySelectorAll('rect')].map(x => x.outerHTML).join(''); return r(s[0]) === r(s[1]) && s[0].querySelectorAll('rect').length > 2; }); ok(same, tag + ' SW3: for the null generator the pictures of L_4 and R′_4 are the same matrix');
}
async function sw4(pg, lang, y, tag) {
  const w = W(pg, 'SW4');
  if (y) { ok((await w.locator('input').count()) === 0, tag + ' SW4: the Young Learner gets the plain note only'); return; }
  const t = SWC[lang].sw4.pm, det = async () => (await w.locator('[data-det]').innerText()).replace(/−/g, '-');
  ok(await det() === DATA.p1.det['1,3'].det && (await badges(w))[0] === 'match', tag + ' SW4: Cl(1,3) at the default input: det as stored, live = stored');
  for (const c of ['2,2', '0,5', '4,1']) {
    await click(w.locator(`[data-cell="${c}"] button`)); const st = DATA.p1.det[c];
    ok(await det() === st.det && (await badges(w))[0] === 'match' && (await w.locator('[data-out="sw4"] [data-kind]').getAttribute('data-kind')) === DATA.p1.cells[c], tag + ` SW4: Cl(${c}) picked: det ${st.det.slice(0, 12)}… as stored, ${DATA.p1.cells[c]}`);
  }
  await click(w.locator('[data-cell="1,3"] button')); await w.locator('[data-mom="0"]').fill('3'); await w.locator('[data-mass]').fill('2'); await pg.waitForTimeout(150);
  const r = E.symbolDet(E.sigOf(1, 3), [3, 2, 0, 1], 2);
  ok(await det() === String(r.det) && (await badges(w))[0] === 'live' && /✓/.test(await txt(w.locator('[data-out="sw4"]'))), tag + ` SW4: another input: det ${r.det} = (m² − Q)^8 live (the badge says live)`);
  await click(w.locator('[data-chips="extra"] [data-v="-1"]')); let x = await txt(w.locator('[data-out="sw4x"]'));
  ok(/Cl\(1,4\)/.test(x) && /✓/.test(x) && x.includes(t.shells['-1'].slice(0, 6)), tag + ' SW4: extra generator −1: total Cl(1,4), the mass shell: ' + x.slice(0, 120));
  await click(w.locator('[data-chips="extra"] [data-v="0"]')); x = await txt(w.locator('[data-out="sw4x"]'));
  ok(/Cl\(1,3,1\)/.test(x) && /✓/.test(x), tag + ' SW4: extra generator 0: total Cl(1,3,1), the momentum never enters');
  await click(w.locator('[data-chips="bim"] [data-v="[3,1]"]')); const bm = nums(await txt(w.locator('[data-out="sw4b"]'))), g = E.quadQ(E.sigOf(1, 3), [3, 2, 0, 1]), h = E.quadQ(E.sigOf(3, 1), [3, 2, 0, 1]);
  ok(bm.includes(g) && bm.includes(h) && bm.includes(g * h), tag + ` SW4: a second metric: (G·k)(H·k) = ${g} × ${h}`);
}
async function sw5(pg, lang, y, tag) {
  const w = W(pg, 'SW5');
  for (const [g, l] of [[1.5, 0.75], [-2, 1], [0, 1]]) {
    await w.locator('[data-sl="g"]').fill(String(g)); await w.locator('[data-sl="l"]').fill(String(l)); await pg.waitForTimeout(200);
    const st = DATA.p2.comb.find(c => c.g === g && c.l === l).edges, bd = await badges(w);
    ok(bd.includes('numerical') && bd.includes('match'), tag + ` SW5 comb g = ${g}, l = ${l}: badges numerical and live = stored: ` + bd);
    if (!y) { const shown = nums((await txt(w.locator('[data-edges]'))).split(':').slice(1).join(':')); ok(shown.length === st.length && shown.every((e, i) => Math.abs(e - st[i]) < 1e-4), tag + ` SW5 comb g = ${g}, l = ${l}: the ${st.length} edges shown are the stored ones`); ok(await twinOk(w, 'sw5'), tag + ' SW5: twin table live = stored'); }
    for (const En of [-6, 5, 11, 30]) {
      await w.locator('[data-sl="E"]').fill(String(En)); await pg.waitForTimeout(60);
      const want = E.floquetClass(E.combCell(En, g, l).half); ok(await w.locator('[data-out="sw5"]').getAttribute('data-cls') === want, tag + ` SW5 comb g = ${g}, l = ${l}, E = ${En}: ${want}`);
    }
  }
  if (y) return;
  await click(w.locator('[data-chips="mode"] [data-v="g5"]'));
  ok(nums((await txt(w.locator('[data-edges]'))).split(':').slice(1).join(':')).length === 7 && (await badges(w)).includes('match'), tag + ' SW5: the two-step potential: 7 edges, live = stored');
  await click(w.locator('[data-chips="mode"] [data-v="exact"]'));
  for (const [p, cls] of [['cat', 'gap'], ['I', 'scalar'], ['minusI', 'scalar'], ['T', 'edge'], ['S', 'band']]) {
    await click(w.locator(`[data-chips="preset"] [data-v="${p}"]`)); ok(await w.locator('[data-out="sw5"]').getAttribute('data-cls') === cls && (await badges(w)).includes('match'), tag + ` SW5 exact: preset ${p} is ${cls}, live = stored`);
  }
  await click(w.locator('[data-gen="clear"]')); await click(w.locator('[data-gen="U"]')); await click(w.locator('[data-gen="U"]')); await click(w.locator('[data-gen="S"]'));
  const want = E.sl2Class(E.wordMatrix(['U', 'U', 'S'])).cls; ok(await w.locator('[data-out="sw5"]').getAttribute('data-cls') === want && (await badges(w)).includes('live'), tag + ` SW5 exact: the word U U S is ${want}, live`);
  await click(w.locator('[data-chips="mode"] [data-v="comb"]'));
}
async function sw6(pg, lang, y, tag) {
  const w = W(pg, 'SW6'), t = SWC[lang].sw6[y ? 'yl' : 'pm'];
  await click(w.locator('[data-seat="1"]')); ok(await w.locator('[data-seat="1"]').getAttribute('aria-pressed') === 'true' && (await txt(w.locator('[data-out="sw6"]'))).includes('110'), tag + ' SW6: seat 2 filled: pattern 110');
  await click(w.locator('[data-add="0"]')); let out = await txt(w.locator('[data-out="sw6"]'));
  ok(out.includes(y ? t.addRead(1, null) : '= 0'), tag + ' SW6: one more particle in the full seat 1 gives nothing: ' + out);
  await click(w.locator('[data-add="2"]')); out = await txt(w.locator('[data-out="sw6"]')); const r = E.putParticle(3, 2);
  ok(out.includes('111') && (y || out.includes((r[1] < 0 ? '−' : '+') + '|111')), tag + ` SW6: one more in the empty seat 3: 111 (sign ${r[1]}): ` + out);
  ok((await badges(w)).includes('match'), tag + ' SW6: live = stored');
  const layers = await w.locator('[data-layer]').evaluateAll(es => es.map(e => e.querySelectorAll('span:not(.scw-lab)').length)); ok(JSON.stringify(layers) === '[1,3,3,1]', tag + ' SW6: the patterns by number: 1, 3, 3, 1');
  if (!y) { const sq = await w.locator('[data-pauli] td[data-blade]').evaluateAll(es => es.map(e => +e.dataset.sq)); ok(sq.length === 16 && sq.filter(s => s === 1).length === 6, tag + ' SW6: the Pauli table: 16 strings, 6 square to +1'); ok(await twinOk(w, 'sw6'), tag + ' SW6: twin table live = stored'); }
}
async function sw7(pg, lang, y, tag) {
  const w = W(pg, 'SW7'), t = SWC[lang].sw7[y ? 'yl' : 'pm'];
  let out = await txt(w.locator('[data-out="sw7"]')); ok(out.includes(t.words['1/2']) && out.includes('25%'), tag + ' SW7: z, x, z: half, half, 25%: ' + out);
  await click(w.locator('[data-chips="mag1"] [data-v="z"]')); out = await txt(w.locator('[data-out="sw7"]')); ok(out.includes(t.words['1']) && out.includes('100%'), tag + ' SW7: z, z, z: all pass, 100%');
  await click(w.locator('[data-chips="mag2"] [data-v="-z"]')); out = await txt(w.locator('[data-out="sw7"]')); ok(out.includes(t.words['0']) && out.includes('0%'), tag + ' SW7: z, z, −z: none pass, 0%');
  ok((await badges(w)).includes('match'), tag + ' SW7: live = stored');
  if (!y) { ok(/≠/.test(await txt(w.locator('[data-out="sw7o"]'))), tag + ' SW7: P_z P_x ≠ P_x P_z'); ok(await twinOk(w, 'sw7'), tag + ' SW7: twin table live = stored'); }
}
const DRIVE = { SW1: sw1, SW2: sw2, SW3: sw3, SW4: sw4, SW5: sw5, SW6: sw6, SW7: sw7 };

const VIEWS = [];
for (const lang of ['en', 'it']) for (const p of 'YPM') { VIEWS.push([1100, lang, p, 'dark', true]); VIEWS.push([375, lang, p, 'light', true]); VIEWS.push([375, lang, p, 'dark', false]); VIEWS.push([1100, lang, p, 'light', false]); }
for (const [w, lang, p, theme, drive] of process.env.QUICK ? VIEWS.filter(v => v[0] === 1100 && v[3] === 'dark') : VIEWS) {
  const prof = PROF[p], y = p === 'Y', tag = `${lang}/${p}/${w}/${theme}`, { ctx, pg, errs } = await open(w, lang, prof, theme, tag);
  ok(await pg.evaluate(() => document.documentElement.dataset.theme) === theme, tag + ': the theme is ' + theme);
  const present = await pg.locator('[data-widget]').evaluateAll(es => es.map(e => e.dataset.widget));
  for (const [id, aud] of Object.entries(AUD)) if (aud.includes(p)) ok(present.includes(id), `${tag}: ${id} is shown (DECISIONS §3)`);
  ok(await pg.locator('[data-widget]').evaluateAll(es => es.every(e => e.classList.contains('ln-card'))), tag + ': every widget root is an .ln-card');
  for (const id of Object.keys(DRIVE).filter(i => present.includes(i))) {
    if (id !== 'SW4' || !y) ok((await W(pg, id).locator('[aria-live]').count()) >= 1, `${tag} ${id}: has an aria-live readout`);
    if (drive) { try { await DRIVE[id](pg, lang, y, tag); } catch (e) { ok(false, `${tag} ${id}: driving failed: ${e.message.split('\n')[0]}`); } }
    ok(!(await badges(W(pg, id))).includes('differ'), `${tag} ${id}: no badge says live and stored differ`);
  }
  if (present.includes('SchullerWidgetsScript')) ok((await W(pg, 'SchullerWidgetsScript').locator('[data-download="selfcheck/reports/lens_sch_check.py"]').count()) === 1, tag + ': the script box offers lens_sch_check.py');
  const over = await pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); ok(over <= 0, `${tag}: no horizontal page scroll (${over} px)`);
  if (y) {   // what the widgets show the Young Learner, after the driving (text, labels read aloud, hover titles), outside closed folds
    const seen = await pg.locator('[data-widget]').evaluateAll(es => es.flatMap(e => { const out = []; const vis = el => !el.closest('details:not([open])') || !!el.closest('summary');
      const tw = document.createTreeWalker(e, NodeFilter.SHOW_TEXT); for (let x = tw.nextNode(); x; x = tw.nextNode()) { const el = x.parentElement; if (el && vis(el) && !el.closest('style,script,code') && el.getClientRects().length) out.push(x.nodeValue); }
      for (const el of e.querySelectorAll('[aria-label],[title],svg title')) if (vis(el)) out.push(el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent || ''); return out.map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean); }));
    const hits = seen.filter(s => SYMBOLS.test(clean(s)) || JARGON.test(clean(s)));
    ok(hits.length === 0, `${tag}: the widgets show the Young Learner no formula and no technical word (${seen.length} strings): ` + hits.slice(0, 5).join(' | '));
  }
  ok(errs.length === 0, `${tag}: no page error: ` + errs.slice(0, 3).join(' | '));
  await ctx.close();
}
await b.close();
console.log(`${n} checks, ${bad} failed`); console.log(bad ? `${bad} FAILURES` : 'ALL SCHULLER WIDGET UI TESTS PASS'); process.exit(bad ? 1 : 0);
