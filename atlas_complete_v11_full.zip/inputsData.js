// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// What each tab needs and what it takes from outside the bit rule (the "needs and inputs" strip, NeedsStrip.jsx). Key: tab id ('maxwell/<tab>' for the three Maxwell tabs).
//   needs:  tab ids (or the page words 'conventions', 'maxwell') to read first; StoryShell resolves them to links.
//   inputs: [kind, text]; kind is a key of KINDS; every text is a statement tagged `input` (INPUT_FLAGS), never `standard`, never `checked`.
//   yl:     the plain line for the Young Learner (no formula, no jargon: test_yl_ui.mjs lists).
//   none:   true on a tab that takes nothing from outside the bit rule.
// The input lines are also the rows INP-001 to INP-0NN of the claims table (claimsLocators_inp.json points at them in this order).
export const KINDS = {
  chart: 'chart and ∇', grade: 'grade of a field', representation: 'representation of a field', time: 'time direction', complex: 'complex structure', involution: 'involution',
  postulate: 'postulated equation', solution: 'borrowed solution', data: 'imported data', convention: 'sign convention',
};
export const NEEDS = {
  // ---- page "maxwell" (Calibration 1), three tabs
  'maxwell/views': { needs: ['conventions', 'clock'], inputs: [
    ['postulate', 'The equation ∇F = J itself (Hestenes’ form of Maxwell’s equations). The page checks that the bit rule reproduces it term by term; it does not derive it.'],
    ['chart', 'A flat chart with the vector derivative ∇ = Σ e^μ ∂_μ, in the orthonormal frame that the labels already give.'],
    ['grade', 'F is a bivector (grade 2) and J a vector (grade 1): the grades are assigned, not found.'],
    ['convention', 'Which generators count as time, and the overall sign of J: see the Conventions page.']],
    yl: 'We took the rule for light from books and checked that the boxes give the same answer. We also chose by hand which pieces are the electric and the magnetic part.' },
  'maxwell/charges': { needs: ['conventions'], inputs: [
    ['postulate', 'The Lorentz force as the grade-1 part of F u: a postulated force law, not derived from ∇F = J.'],
    ['data', 'Charge, mass, start position and start speed are chosen by hand in each of the six situations.'],
    ['time', 'The observer’s time direction γ₀ splits F into E and B; another γ₀ splits the same F differently.'],
    ['solution', 'The Coulomb field of a point charge and the plane wave f(t − z) are put in as given fields; the page checks that they solve ∇F = J away from the charge (J = 0), it does not solve for them.']],
    yl: 'The push on a charge comes from a rule taken from books. The size of the charge, its weight and its first speed are ours to choose.' },
  'maxwell/ladders': { needs: ['clock', 'conventions'], inputs: [
    ['convention', 'Which sign is called time (the minority sign), and Cl(k,d) versus its mirror Cl(d,k), are conventions; only a Lorentzian split gives a hyperbolic wave operator (T18).'],
    ['time', 'Extra time generators are a mathematical exercise here: one time direction is what makes the wave operator hyperbolic (T18(f); stated on the Conventions page).']],
    yl: 'Which direction counts as time is a choice of words. The boxes do not decide it.' },
  // ---- page "shapes"
  orth: { needs: [], inputs: [
    ['complex', 'The Fock reading splits the 2n null vectors into n pairs and picks a vacuum: a choice of Witt split, not given by the labels.'],
    ['data', 'The charge formulas Y = a/2 − b/3 and B − L = 1 − 2b/3 at n = 5 are Baez, Bokor and Boyle’s; the page checks the bit counts and the vanishing sums, not the formulas.']],
    yl: 'Pairing the two poles of each line into a switch is a choice we make; the boxes alone do not say which poles go together. Some counts for the particles come from a paper.' },
  demi: { needs: [], inputs: [
    ['data', 'The Furey box uses her 16-dimensional model as imported on the Furey page; the page checks the bijection and the axes only.']],
    yl: 'One box is about her model of particles; we take her model as she gives it and check only that the shapes match.' },
  gosset: { needs: ['orth', 'demi'], inputs: [
    ['data', 'The Cartan matrices of E6, E7 and E8 are imported; the Lie bracket of E8 is not built (it needs a cocycle choice).']],
    yl: 'The big shape comes from a table of numbers taken from books.' },
  // ---- the clock and the equations page
  clock: { needs: [], inputs: [
    ['convention', 'The clock c = p − q mod 8 assumes that p counts the generators that square to +1; the mirror convention gives −c.'],
    ['convention', 'A null generator (square 0) adds weight 0 to the exponent of the clock sum, so each one multiplies the Gauss sum by 2: a convention of the page (checked for one and two null generators, core·B3).']],
    yl: 'The clock counts in the direction we picked. The mirror picture counts the other way round. Pieces that switch nothing add nothing to the count.' },
  comm: { needs: [], inputs: [], none: true, yl: 'Nothing is brought in from outside here.' },
  mirrors: { needs: ['comm'], inputs: [
    ['convention', 'The reflection formula x ↦ −a x a⁻¹ fixes one of two sign conventions for mirrors (Pin versus its twin).'],
    ['involution', 'The Dirac line uses the reversion ψ̃ (a blade of grade k gets the sign (−1)^{k(k−1)/2}) in ψγ₀ψ̃ and ψψ̃; the rule defines it, and using it rather than Clifford conjugation is a choice.'],
    ['time', 'The time direction (e_t, called γ₀ in the Dirac line) enters the time-reversal mirror x ↦ −e_t x e_t and the current ψγ₀ψ̃.']],
    yl: 'A mirror can be written in two equally good ways. We picked one.' },
  dirac: { needs: ['conventions', 'clock', 'demi'], inputs: [
    ['postulate', 'The equation ∇ψJ = mψγ₀ (Hestenes’ form of the Dirac equation). Checked: its incidences, determinant and covariance; not derived.'],
    ['grade', 'ψ is an even multivector (8 components in Cl(1,3)): the grade of the field is assigned.'],
    ['time', 'γ₀, the observer’s time direction, enters the mass term and the current ψγ₀ψ̃.'],
    ['complex', 'J = γ₂γ₁ plays the part of the Dirac i: a complex structure chosen in the algebra, not given by it.'],
    ['convention', 'Cl(1,3) with γ₀² = +1 is used; Cl(3,1) reads the same system with the signs swapped.'],
    ['chart', 'A flat chart with the vector derivative ∇ = Σ e^μ ∂_μ: the derivative term of ∇ψJ is part of the postulated equation.'],
    ['involution', 'The current ψγ₀ψ̃ and the norm ψψ̃ use the reversion (a blade of grade k gets the sign (−1)^{k(k−1)/2}). The rule defines it; that the page uses it, rather than Clifford conjugation or a dagger, is a choice.']],
    yl: 'The electron’s rule is taken from books. We choose which direction counts as time, and which turn plays the part of the number i.' },
  coupling: { needs: ['maxwell', 'dirac'], inputs: [
    ['postulate', 'The coupled system ∇F = eX with the current X = ψγ₀ψ̃ and the replacement ∇ → ∇ − eA, taken from the Dirac–Maxwell form; no action is built.'],
    ['data', 'The coupling constant e and the sign of the source term are free constants.'],
    ['grade', 'The potential A is a vector (grade 1) and the current X a vector: assigned.'],
    ['time', 'γ₀ of the Dirac step, the observer’s time direction, enters the current X = ψγ₀ψ̃.'],
    ['complex', 'J = γ₂γ₁ of the Dirac step is the complex structure of ∇ψJ and of the charged form, which exists from n = 3; it is chosen in the algebra, not given by it.'],
    ['chart', 'The potential A is a vector-valued 1-form on a flat chart, and the replacement ∇ → ∇ − eA uses the same derivative.'],
    ['involution', 'The current X = ψγ₀ψ̃ uses the reversion; Clifford conjugation or a dagger would give another current. The rule defines the reversion; choosing it is an input.']],
    yl: 'How light pushes the electron and how the electron makes light is taken from books. How strong the push is, is a number we put in.' },
  ym: { needs: ['comm'], inputs: [
    ['postulate', 'The Yang–Mills equations D^μF_{μν} = J_ν for a gauge algebra so(m): their structure is rebuilt and the identities checked; they are not derived from an action.'],
    ['postulate', 'so(m) as the gauge algebra is one choice; the Standard Model algebra is not an so(m) for any m.'],
    ['data', 'The gauge coupling g is a free constant.'],
    ['chart', 'The covariant derivative D^μ = ∂^μ + gA^μ takes the potential A as a vector-valued 1-form on a flat chart.']],
    yl: 'The rule for forces with many charges is taken from books. Which family of turns carries the charge is our choice.' },
  matter: { needs: ['dirac', 'ym'], inputs: [
    ['postulate', 'The Dirac field Ψ in a representation of the gauge group, with the Noether current of each generator: standard; the page rebuilds it and checks the conservation.'],
    ['grade', 'Ψ = Σ Ψ_{S,T} is even in the space-time part and carries an internal blade T of Cl(0,m); the generators act on T: assigned.'],
    ['representation', 'The representation of the gauge algebra on Ψ is a choice: left multiplication on Cl(0,m), the spinor-type one; tensor-type ones and chiral doublets are not drawn.'],
    ['data', 'The coupling κ in D^μF_{μν} = κ j_ν: no action fixes it.'],
    ['chart', 'The covariant derivative D = ∂ + gA^aB_a acts on a flat chart: the chart and ∂ are those of the Dirac step.'],
    ['complex', 'J = γ₂γ₁ of the Dirac step, acting from the right, is the complex structure of the matter equation; the J-generator gives the coupling step.'],
    ['time', 'γ₀ of the Dirac step (label 1) enters the mass term and the current of each generator.'],
    ['involution', 'The current of each generator is built like X = ψγ₀ψ̃ of the Dirac step, with the reversion ψ̃; using it rather than Clifford conjugation is a choice.']],
    yl: 'Matter that feels these forces is built the way books build it. How strongly it feels them is a number we put in.' },
  grav1: { needs: ['comm', 'conventions'], inputs: [
    ['postulate', 'First-order (Cartan) gravity: the structure equations R = dω + ¼[ω,ω] and T = de + ωe are taken as given. Checked: Bianchi identities and counts.'],
    ['chart', 'A tetrad e on a chart: grade 1 is identified with tangent vectors by a choice of frame.'],
    ['grade', 'ω is a bivector-valued 1-form and e a vector-valued 1-form: assigned.'],
    ['convention', 'The frame algebra is Cl(1, n−1): one generator squares +1 (time) and the n−1 others square −1; the other convention swaps the two signs of the squares (see Conventions).']],
    yl: 'Gravity as bending space is taken from books. We pick the frame that measures the bending.' },
  grav2: { needs: ['grav1'], inputs: [
    ['postulate', 'The Einstein form E_a with the cosmological term (Einstein–Cartan with the MacDowell–Mansouri embedding) is taken from the literature; no action is built.'],
    ['convention', 'The sign of the cosmological term is minus the sign of the square of the extra generator (k = −s); that rests on the signature convention. Invariant: an extra spatial generator gives de Sitter.'],
    ['data', 'The coupling κ and the sign of the source are free constants.']],
    yl: 'Einstein’s equation is taken from books, in a form our boxes can draw. How strongly matter bends space is a number we put in.' },
  projective: { needs: ['mirrors', 'grav2'], inputs: [
    ['convention', 'PGA is Cl(n,0,1) when space squares +1 (Dorst and De Keninck) and Cl(0,n,1) when space squares −1 (the convention used here).'],
    ['data', 'The three plane-based geometries and the extension to spheres are taken from Dorst and De Keninck’s tables.'],
    ['data', 'Conformal invariance of Maxwell, Yang–Mills and the massless Dirac equation is cited from the literature and not rebuilt; the algebra itself needs no postulated equation.']],
    yl: 'Flat, round and saddle-shaped geometries come from one extra direction, as in a paper we read. Which sign each gets is a matter of convention.' },
  gauge: { needs: ['grav1', 'grav2', 'projective', 'conventions'], inputs: [
    ['solution', 'The Schwarzschild metric (a point mass) is borrowed (Lasenby, Doran and Gull): the page rebuilds it as a shear of the frame and checks it; it does not solve for it.'],
    ['chart', 'A frame: the shear h̄ and the static time direction e_t are chosen; the same metric has other frames.'],
    ['postulate', 'The field equations of the theory are not used: the metric is put in, not derived.'],
    ['convention', 'Time squares +1; with the other convention the two signs of the squares swap and the 0 does not (see Conventions).']],
    yl: 'The shape of space around a heavy ball is taken from books. We rebuild it from simple bends of the frame and check that the pieces fit.' },
  nullsurf: { needs: ['gauge', 'projective'], inputs: [
    ['solution', 'The metrics (Schwarzschild, Kerr, the Ellis wormhole) are borrowed; the page rebuilds the null-surface statements on them and checks them.'],
    ['chart', 'A static Killing vector ξ and the covector n = dx: the null normal exists once the chart and the time direction are chosen.'],
    ['data', 'The four claims of the paper (Hsu, Barker, Hobson and Lasenby) are taken as given; its Eq. (12) is not rebuilt.']],
    yl: 'Surfaces of light that stand still are studied on shapes of space taken from books.' },
  forque: { needs: ['mirrors', 'projective'], inputs: [
    ['postulate', 'The Newton–Euler equations Ṗ = F, Ḃ = I⁻¹[B × I[B] + F], Ṁ = −½MB of Dorst and De Keninck are taken as given: 27 of 41 rows agree exactly, 9 after a small adjustment.'],
    ['data', 'The inertia map I and the forces are the paper’s examples.'],
    ['convention', 'With space squaring −1 the kinetic term changes sign (mainly-minus mechanics): a convention of the metric.'],
    ['chart', 'The time derivative along the motor path: the only chart is the time parameter t.'],
    ['involution', 'The motor is normalised by M M̃ = 1 with the reversion; the rule defines the reversion, and using it rather than Clifford conjugation is a choice.']],
    yl: 'Push and spin as one line comes from a paper we read. The weights and pushes in the examples are the paper’s.' },
  spin: { needs: ['dirac', 'clock'], inputs: [
    ['postulate', 'The pointor and spinor equations are the authors’ and the lecturer’s (Roelfs, Eelbode, De Keninck; Eelbode’s lecture): 22 of 30 rows agree exactly.'],
    ['complex', 'Which kind of i plays the complex unit (the central I, a bivector J, or the lecture’s B + i) is a choice of complex structure.'],
    ['grade', 'The pointor ψ lives in the even subalgebra; the chirality map ψ ↦ IψJ uses the chosen J.'],
    ['chart', 'The Dirac step is reused with its chart and ∇: its free plane waves solve that postulated equation.'],
    ['involution', 'The pointors ψψ̃ use the reversion; that the scalar part is a state holds for the dagger involution (T15), and the reversion’s scalar part is indefinite in Cl(1,3). Which involution a page uses is a choice.'],
    ['time', 'γ₀ of the Dirac step, the observer’s time direction, defines the energy of a plane wave: β = 0 for positive and β = π for negative energy.']],
    yl: 'Things that turn twice are described as in a paper and a lecture. Which turn plays the part of the number i is our choice.' },
  spring: { needs: ['comm', 'spin'], inputs: [
    ['postulate', 'Hooke’s law x″ = −Lx on the cube’s graph, with one scalar displacement per vertex, is a postulated force law.'],
    ['convention', 'The sign s of the generator (−1, 0, +1) is a parameter you choose. The matrix D = Σ e_i is built from the generators and checked (D² = n·I); that it is the signed matrix of Huang (2019) is standard.'],
    ['involution', 'The rotor sandwich R s R̃ uses the reversion; using it rather than Clifford conjugation is a choice.'],
    ['chart', 'The time derivative along the flow: the only chart is the time parameter t.']],
    yl: 'A spring on the cube follows the law of springs from books. We choose the weights and the stiffness.' },
  rigid: { needs: ['forque', 'spring'], inputs: [
    ['postulate', 'Euler’s equation, Hooke’s and Newton’s laws and Kepler’s problem are taken as given; the identities G1–G5 are checked exactly.'],
    ['data', 'The planets’ masses and positions are the example’s own printed table (JPL was not reached): six bodies, checked for plausibility only.'],
    ['chart', 'The time derivative along the motor path: the only chart is the time parameter t (the engine integrates numerically in t).'],
    ['involution', 'The versor condition M M̃ = 1 uses the reversion; using it rather than Clifford conjugation is a choice (the rule only defines it).']],
    yl: 'A solid body moves by the laws of books. The weights of the planets in the example are numbers copied from the paper.' },
  groups: { needs: ['clock'], inputs: [
    ['data', 'The uniqueness of the Golay code, the simplicity of the large groups, the orders of Co₁ and the Monster, and Monster ⊃ 2^{1+24}.Co₁ are quoted from the literature, not rebuilt.']],
    yl: 'Counting the ways to shuffle uses numbers that mathematicians have worked out; we quote the biggest ones.' },
  // ---- the lens chapters
  category: { needs: ['clock'], inputs: [
    ['convention', 'A label with a null bit gets weight 0 in the clock sum: a convention of the page, so the clock cannot see the null part.'],
    ['involution', 'States use the dagger involution (e_i† = ε_i e_i on the generators, null generators fixed; T15). Using it rather than the reversion or Clifford conjugation is a choice.'],
    ['data', 'The classical theorems that T4, T6 and T8 reduce to (Wall, Hurwitz, de la Peña) are recalled from the literature, not rebuilt.']],
    yl: 'The clock ignores the pieces that switch nothing; that is a rule we chose. A few famous results are quoted, not rebuilt.' },
  baez: { needs: ['groups'], inputs: [
    ['data', 'Baez’s octonion table and his embeddings of generations (E7, the Albert algebra) are imported; the multiplicities (a, b) are recalled from Loos.'],
    ['convention', 'The colour labels 3 and 3̄ depend on a sign convention for the weights.'],
    ['data', 'The periodic-table section fills subshells in the Madelung order (n + l, then n), a textbook rule taken as given and an approximation for real atoms; the page counts the rows it closes.']],
    yl: 'The seven papers are read as written, and so is the order in which electrons fill. Their names for the colours are a choice of words.' },
  schuller: { needs: ['maxwell', 'dirac', 'grav2'], inputs: [
    ['postulate', 'The matter action (Schuller’s stone 1) and his closure construction are imported; the page rebuilds the symbol and hyperbolicity (T18(f)), not the dynamics.'],
    ['convention', 'One Lorentzian class in two conventions, P ↔ −P: the quantum notes print Cl(3,1), the Atlas Cl(1,3).']],
    yl: 'The lectures are followed from the rule to how things move. We check the first steps and not the last.' },
  // ---- the Furey page, three tabs
  dictionary: { needs: ['clock'], inputs: [
    ['data', 'Furey’s octonion table and her nested flag ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆 in 𝕍 (real dimension 16) are imported: the octonion sign is not the rule’s cocycle.'],
    ['complex', 'The complex structure ω = L_{e₇} is imported.']],
    yl: 'The model of particles is her own idea. We rebuild it from her table and count what fits.' },
  earlier: { needs: ['dictionary'], inputs: [
    ['data', 'Her octonion table and the constructions of her papers (Roadmap I–III, Trialities, the 2026 paper) are taken as given; the page rebuilds the algebra from the octonion units and recomputes the quoted numbers.']],
    yl: 'Her older papers are her own ideas. We rebuild them from her table of numbers and count again what she quotes.' },
  findings: { needs: ['dictionary'], inputs: [
    ['data', 'The partition of the 16 axes into blocks is input: 616 of 18 480 candidate quadruple sets diagonalise the block projectors, and Witt pairing does not force it.'],
    ['complex', 'The complex structure ω = L_{e₇} of the Dictionary tab is hers; the page builds 𝕍 with it and computes the blocks.'],
    ['data', 'The formulas of Y and Q as sums of projectors (her eqs. 44, 45) are hers; the page computes their traces and their values on the blocks.']],
    yl: 'Which pieces go into which block is a choice she makes; the rule alone does not decide it. Her formulas for the charges are used as she gives them.' },
  threegen: { needs: ['dictionary', 'findings'], inputs: [
    ['data', 'The Standard Model labels on the edges of her Fig. 1 are imported; that one complete set fits is computed.']],
    yl: 'The labels of the particles are hers. That only one family fits in the board is something we counted.' },
  help: { needs: ['threegen'], inputs: [
    ['data', 'The labels of the 20 cells of her Fig. 1 are hers; the table to download repeats them with the irreps and charges computed on the Three generations tab.']],
    yl: 'The labels of the particles in her figure are hers. We list what we counted and what stays open.' },
};
export const INPUT_FLAGS = ['input'];

// The words of the strip (English in both languages) and of its line in the legend. `words` names a page when a need is a page and not a tab; `pages` is the page word in front of the label of a link to a tab.
export const NEEDS_COPY = {
  aria: 'Needs and inputs', script: 'Script', needs: 'Needs', inputs: 'Inputs', none: 'None beyond the bit rule.', nothing: 'Nothing outside this page.',
  words: { conventions: 'Conventions', maxwell: 'Maxwell' },
  pages: { conventions: 'Conventions', maxwell: 'Maxwell', shapes: 'Shapes', equations: 'Equations', furey: 'Furey', lenses: 'Lenses' },   // the page that a link to a tab names first ("Shapes · 2 · The demicube"): step numbers repeat from page to page
  help: 'The strip under the tabs says what a tab needs (read those first) and what it takes from outside the algebra: a postulated equation, a chart and derivative, the grade or the representation a field lives in, a time direction, a complex structure, an involution (the reversion used for norms and currents), a borrowed solution, imported data or a sign convention. Each such line is an input.',
  yl: { aria: 'Needs and what we brought in', script: 'The check', needs: 'Read first', words: { conventions: 'How we name things', maxwell: 'Light' }, pages: { conventions: 'Our words', maxwell: 'Light', shapes: 'Shapes', equations: 'Equations', furey: 'Furey', lenses: 'Lenses' },
    help: 'Under the tabs, a short bar says what to read first and what we had to bring in from outside the boxes.' },
};

// The label of a link to a tab names its page first ("Shapes · 2 · The demicube", "Equations · 2 · Commutators"), because the step numbers repeat from page to page.
// `t` is what the router resolves a need to ({ page, sub, label }), `w` the need, `pages` the page words of NEEDS_COPY (plain ones for the Young Learner).
// A need that is a page ('maxwell') keeps the name of the page; a tab whose label is the page word itself ('Conventions') is not named twice.
export const needLabel = (t, w, pages) => { const p = t.sub === w ? pages[t.page] : null; return p && t.label !== p ? p + ' · ' + t.label : t.label; };
