// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { fc } from './fureyCopy.js';
import { Head, Sec, Older } from './FureyKit.jsx';
import { Timeline, Checkpoints, Cascade, Spectra, Triality } from './FureyWidgets.jsx';

// Tab "Her papers": the six papers in the order they appeared, with the numbers of each that furey_papers_check.py rebuilds (the explicit algebra from the octonion
// table, the Roadmap's ladders, the spectra of one generation, the three spaces of Trialities). Every statement is an item of fureyCopy.js (earlier.secs).
const ORDER = [['timeline', Timeline], ['checkpoints', Checkpoints], ['cascade', Cascade], ['spectra', Spectra], ['triality', Triality], ['fit', null]];
export default function FureyEarlier({ lang = 'en', profile = 'Young Learner' }) {
  const L = lang === 'it' ? 'it' : 'en', c = fc(L).earlier, W = { lang: L, profile };
  return <section className="ln fy" id="earlier" aria-labelledby="earlier-h" data-tab="earlier"><Head lang={L} profile={profile} id="earlier" c={c} hid="earlier-h" />
    {ORDER.map(([k, Wd]) => <Sec key={k} lang={L} profile={profile} id={'fy-' + k} s={c.secs[k]}>{Wd ? <Wd {...W} /> : null}</Sec>)}
    <Older lang={L} profile={profile} secs={ORDER.map(([k]) => [k, c.secs[k]])} />
  </section>;
}
