// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { Fold, Intro, level } from './Fold.jsx';
import K from './nullData.js';
import { NULL_PY } from './nullSelfcheckSource.js';
import { STORY } from './storyCopy.js';
import COPY from './nullCopy.js';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';
import { ConeWidget, NeckWidget, CriterionWidget, KerrWidget, LadderWidget } from './NullWidgets.jsx';
import { Formal, isLearner } from './Formal.jsx';
import PLAIN from './plainStepsCopy.js';
import { PlainStory, PlainHedges } from './PlainBits.jsx';
import { Tags } from './StatusBadge.jsx';

// Step 13 of the equations page: null surfaces. Four results, each drawn live in several lenses (the same state seen through another one).
// Every number comes from selfcheck/null_selfcheck.py (exact arithmetic, standard library); nullEngine.js holds the formulas the figures draw and test_null.mjs
// recomputes them against selfcheck/null.json. test_null_ui.mjs drives the page. The full analysis, with every calculation, is not on this page.
const download = (name, text, type) => { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } };

const STYLE = `.nl-res{border-top:2px solid rgba(128,128,128,.3);margin-top:28px;padding-top:6px}.nl-fig{font-size:.78em;letter-spacing:.06em;text-transform:uppercase;opacity:.7;margin:.9em 0 0}
.nl-lens{margin:6px 0}.nl-slider{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:6px 0}.nl-slider>span{min-width:170px;font-size:.9em}.nl-range{flex:1;min-width:150px}.nl-val{font-variant-numeric:tabular-nums}
.nl-zero{margin:0}.nl-svg{max-width:100%}.nl-readouts{margin-top:6px}.nl-line{margin:.25em 0;font-size:.86em;overflow-wrap:anywhere}.nl-card .eq-cap{margin:.5em 0 0}.nl-sum{margin:.4em 0}`;

export default function NullSection({ lang = 'en', profile = 'Young Learner' }) {
  const lv = level(profile), l = COPY[lang] ? lang : 'en', t = COPY[l], yl = isLearner(profile), P = PLAIN[l].nullsurf;
  const Fig = ({ k, children }) => <><p className="nl-fig" data-fig={k}>{t.fig} {k}</p>{children}</>;
  return <section className="eq" id="eq-nullsurf" aria-labelledby="eq-nl-h"><style>{STYLE}</style><p className="eyebrow"><Tx>{stepEyebrow(l, 'eq', 'nullsurf')}</Tx></p><h2 id="eq-nl-h"><Tx>{yl ? P.title : t.title}</Tx></h2><Intro lang={l} profile={profile} id="nullsurf" lede={t.lede} />
    <div><Tags kinds={['checked', 'standard', 'ours', 'open']} lang={l} /></div>
    {yl && <><PlainStory paras={P.story} /><h3><Tx>{P.tryH}</Tx></h3><p className="eq-cap"><Tx>{P.try}</Tx></p><ConeWidget t={t} plain={P} /></>}
    <Formal profile={profile} lang={l}>
    <p className="eq-cap nl-sum" data-passed={K.portal.summary.passed} data-computed={K.portal.summary.computed} data-readings={K.portal.summary.readings}><Tx>{t.summary}</Tx></p>
    {t.cards.map((c, i) => <div key={i} className="nl-res" id={'nl-res-' + (i + 1)} data-result={i + 1}>
      <h3><Tx>{i + 1}</Tx>. <Tx>{c.h}</Tx></h3><div><Tags kinds={c.tags} lang={l} /></div>
      {c.text.map((x, j) => <p key={j}><Tx>{x}</Tx></p>)}
      {i === 0 && !yl && <Fig k={1}><ConeWidget t={t} /></Fig>}
      {i === 1 && <Fig k={2}><NeckWidget t={t} /></Fig>}
      {i === 2 && <><h4><Tx>{t.critH}</Tx></h4><p><Tx>{t.critText}</Tx></p><Fig k={3}><CriterionWidget t={t} /></Fig>
        <h4><Tx>{t.kerrH}</Tx></h4><p><Tx>{t.kerrText}</Tx></p><Fig k={4}><KerrWidget t={t} /></Fig></>}
      {i === 3 && <Fig k={5}><LadderWidget t={t} /></Fig>}
    </div>)}
    <h3><Tx>{t.limitsH}</Tx></h3>
    <div>{t.limits.map(([k, txt], i) => <div key={i} className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={[k]} lang={l} /></div><p><Tx>{txt}</Tx></p></div>)}</div>
    <Fold title={t.linksH} open={lv >= 2}>{t.links.map(([ks, h, txt], i) => <div key={i} className="eq-xr"><h4><Tx>{h}</Tx> <Tags kinds={ks} lang={l} /></h4><p><Tx>{txt}</Tx></p></div>)}</Fold>
    <Fold title={t.dl.h} open={lv >= 2}><p><Tx>{t.dl.text}</Tx></p><div><button className="eq-btn" onClick={() => download('null_selfcheck.py', NULL_PY, 'text/x-python')}><Tx>{t.dl.py}</Tx></button><button className="eq-btn" onClick={() => download('null.json', JSON.stringify(K, null, 1), 'application/json')}><Tx>{t.dl.json}</Tx></button></div><p className="eq-mono eq-cap"><Tx>{t.dl.cmd}</Tx></p></Fold></Formal>
    {yl && <PlainHedges lang={l} title={PLAIN[l].hedgesH} items={P.hedges} />}</section>;
}
