// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Copy of the Conventions tab: the choices of words the Atlas makes (which generators are called space or time, what the mirror flips, what a cell is without
// a frame), the statements that hold in every convention, the primordial ideas and readings with what is proved and what would settle them, and the glossary.
// One English text serves both language slots (v11: new text is English in the Italian slots too). Status words: checked, standard, ours, open, input (storyCopy.js).
// Every row names the places of the Atlas that use it (files, not line numbers), the status of its statement, and the checks it stands on (ids of the core table).
import { stepNo, groupOfStep } from './steps.js';

// the step number of a tab, whatever page holds it: the clock (Conventions page), gauge gravity (equations page), finite groups (lenses page)
const E = id => stepNo('eq', id), L = id => stepNo(groupOfStep(id), id);

// the checks the rows may name: core·B1 to core·B17 (selfcheck/core.json); test_conventions.mjs reads them from there when the file is present
export const CORE_IDS = ['B1', 'B2', 'B3', 'B4', 'B4b', 'B5', 'B5b', 'B5c', 'B6', 'B6b', 'B6c', 'B7', 'B7b', 'B8', 'B9', 'B10', 'B10b', 'B10c', 'B11', 'B12', 'B13', 'B14', 'B15', 'B16', 'B17'].map(x => 'core·' + x);

const EN = {
  eyebrow: 'CONVENTIONS AND INVARIANTS',
  eyebrowY: 'WHICH WORDS WE USE',
  h: 'Conventions and invariants',
  lede: [
    'Several words of the Atlas are choices, not results: which generators are called space and which time, which sign a mirror flips, what “label” and “null” mean. This tab states each choice once, says where the Atlas uses it, and says whether the statement is checked, standard, ours, open or an input. The second list holds the primordial ideas and readings of the Atlas, each with what is proved so far and what would settle it. The glossary comes last.',
    'A convention is a choice of words; an invariant is a statement that holds in every convention; a reading is ours. Naming a generator time or space chooses between Cl(p,q) and Cl(q,p). These are in general different algebras (Cl(3,1) = M₄(ℝ), Cl(1,3) = M₂(ℍ)); they have isomorphic even parts and the same bivector squares, and the mirror between them is a change of names, not a dynamical operation.',
  ],
  ledeM: [
    'The cell is the triple (V, Q, π): the 𝔽₂ form Q on the addresses (which blades square to −1) with the parity π of the address. The clock is the Brown invariant of (V, w), w = π + 2Q mod 4; the mirror is Q → Q + π. The three conventions S, T and D read the same algebras with the signs named differently (rows 2 to 4); the invariants (rows 6 to 9, 13, 14, 16) hold in all of them. The second list is the Atlas’s own account of its ideas; the first table holds the statements it stands on.',
  ],
  ledeY: [
    'Which switch counts as space and which as time is a choice of words; the boxes do not decide it.',
    'We say which words a page uses at the top of the page.',
  ],
  where: 'Used in', checks: 'Checks',
  rowsH: 'The statements',
  rows: [
    { n: 1, title: 'The Atlas convention.',
      text: 'A cell Cl(p,q,r) has p generators that square to +1, q that square to −1 and r that square to 0 (n = p + q + r). Its place in the lattice of cells is [p + q, p − q]; the pages show it as n = p + q and c = p − q.',
      where: ['researchersData.js (T1)', 'categoryCopy.js (definitions)', 'genesis_audit_v3.js (the place in the lattice)', 'labelsCopy.js (the clock tab)', 'App.jsx (the lattice of cells)'],
      tags: ['ours'], note: 'a choice of words' },
    { n: 2, title: 'Convention S (plus = space).',
      text: 'Generators that square to +1 are called space and the single odd one, −1, time: spacetime is Cl(3,1) = M₄(ℝ), clock 2.',
      where: ['App.jsx (the toggle “Space +”, the cell cards)', 'storyCopy.js (Reading 1)', 'genesis_audit_v3.js (node and cell texts)', 'schullerCopy.js (the signature the quantum notes print for Dirac)'],
      tags: ['ours', 'checked'], ids: [], scripts: ['labels_check.py'], note: 'the naming is ours; the algebra Cl(3,1) = M₄(ℝ) is checked (the clock table, labels_check.py)' },
    { n: 3, title: 'Convention T (plus = time).',
      text: 'Generators that square to +1 are called time and those that square to −1 are called space; with one time generator spacetime is Cl(1,3) = M₂(ℍ), clock 6 (Hestenes’ spacetime algebra; Lasenby, Doran and Gull). The Maxwell, Dirac, coupling, gravity, gauge-gravity and projective (Lorentz base) steps use it.',
      where: ['mapCopy.js (the rule node)', 'equationsCopy.js (Dirac, coupling)', 'gravityCopy.js (the frame algebra Cl(1,n−1))', 'labelsCopy.js (the gauge tab)', 'MaxwellSection.jsx (exactly two sign choices reproduce the standard equations, and they differ by an overall sign)', 'projective_selfcheck.py (the base square)', 'check_T18.py (the time-positive convention)'],
      tags: ['standard', 'checked'], scripts: ['projective_selfcheck.py', 'check_T18.py'], note: 'the naming is Hestenes’ Cl(1,3), cited by the Atlas (a pointer; its sources are not read here); the use is checked where the step scripts run it' },
    { n: 4, title: 'Convention D (plus base).',
      text: 'The base of the projective algebra squares to +1 and the null generator to 0: Cl(n,0,1) (Dorst and De Keninck; Roelfs and De Keninck).',
      where: ['forqueCopy.js (the Atlas rule gives space axes the square −1, the paper’s base has +1; the energy is not computed with squares −1 here)', 'rigidCopy.js', 'pgadyn_selfcheck.py', 'gtg_check.py (part R)', 'categoryCopy.js and baezCopy.js (the PGA rows)'],
      tags: ['checked', 'standard'], scripts: ['pgadyn_selfcheck.py', 'gtg_check.py'], note: 'checked by the scripts of the chapters; the convention is the one of the cited papers' },
    { n: 5, title: 'Which convention each step uses.',
      text: `The cell cards use S (Reading 1) or its mirror reading T (Reading 2 of the toggle). Maxwell, Dirac (step ${E('dirac')}), coupling (step ${E('coupling')}), gravity (steps ${E('grav1')} and ${E('grav2')}), gauge gravity (step ${L('gauge')}), null surfaces (step ${E('nullsurf')}) and projective with a Lorentz base (step ${E('projective')}) use T. The spin step (step ${E('spin')}) uses T for its spacetime algebra Cl(1,3). Forque (step ${E('forque')}) and the rigid body (step ${E('rigid')}) use D. The clock tab, the commutator step (${E('comm')}), the mirrors step (${E('mirrors')}), Yang–Mills with Cl(0,m) (step ${E('ym')}), matter (step ${E('matter')}) and the spring network (step ${E('spring')}) state nothing that depends on the convention. Projective with a space base squaring −1 is Cl(0,n,1).`,
      where: ['the step pages', 'mapCopy.js (the rule node)'],
      tags: ['ours'], note: 'our bookkeeping of the pages' },
    { n: 6, title: 'Time is the single generator of the minority sign.',
      text: 'A quadratic principal polynomial is hyperbolic exactly when its signature is Lorentzian (one generator of one sign, the others of the other sign); for Cl(k,d) with k, d ≥ 2 the wave operator is ultrahyperbolic and no direction supports a well-posed initial-value problem.',
      where: ['researchersData.js (T18)', 'check_T18.py', 'MaxwellSection.jsx (the note on the type of the wave operator)', 'schullerCopy.js (the T18 line)', 'LabelsTabs.jsx'],
      tags: ['checked', 'standard'], scripts: ['check_T18.py'], note: 'hyperbolic exactly for Lorentzian signature is checked (T18); the well-posedness statement is standard and is not proved here' },
    { n: 7, title: 'The mirror.',
      text: 'Replacing every square ε by −ε changes Cl(p,q) to Cl(q,p). On the addresses it changes Q to Q + π and w to −w, so the clock goes to −c. It is a change of naming: nothing runs backwards and no dynamics follow.',
      where: ['genesis_audit_v3.js (the Temporal reading)', 'schullerCopy.js (the mirror in the Brauer–Wall group)', 'storyCopy.js (the toggle, Reading 2)'],
      tags: ['checked', 'ours'], ids: ['core·B4', 'core·B4b'], note: 'the statement on the addresses is checked; the sentence that no dynamics follow is ours' },
    { n: 8, title: 'Mirror invariants.',
      text: 'A blade keeps its square under the mirror exactly when its grade is even: the squares of bivectors, of 4-blades and the even part of the algebra (Cl⁰(p,q) ≅ Cl⁰(q,p)) are the same in both conventions; vector squares and trivector squares change sign. Rotation, boost and translation as the squares −1, +1, 0 of a simple bivector are therefore convention-free; the sign of a vector (a horizon gradient, a velocity) is not.',
      where: ['labelsCopy.js (the clock tab, the trinity)', 'springCopy.js', 'nullCopy.js'],
      tags: ['checked'], ids: ['core·B5', 'core·B5b', 'core·B5c'], note: 'checked for n ≤ 6 (core·B5 and core·B5c for r = 0; core·B5b also with r = 1, 2 null generators)' },
    { n: 9, title: 'Bivector squares.',
      text: '(e_{i}e_{j})² = −ε_{i}ε_{j}: −1 for two generators of the same sign (rotation), +1 for one of each (boost), 0 if either is null (translation or a totally null plane).',
      where: ['labelsCopy.js (the clock tab: X² = −1, +1, 0)', 'labels_check.py (section 9)'],
      tags: ['checked'], ids: ['core·B5b'], scripts: ['labels_check.py'], note: 'checked for every signature with n ≤ 6, with r = 0, 1, 2 null generators' },
    { n: 10, title: 'De Sitter and anti-de Sitter.',
      text: 'An extra generator with spatial signature gives de Sitter space; with the opposite signature, anti-de Sitter space. In convention T the sign k = −s of the cosmological term says the same.',
      where: ['gravityCopy.js (the second gravity step)', 'projectiveCopy.js'],
      tags: ['standard'], note: 'the ambient signatures ℝ^{n,1} against ℝ^{n−1,2}; a pointer, the source is not read here' },
    { n: 11, title: 'The PGA label.',
      text: 'A space base squaring −1 with a null generator is Cl(0,n,1); a Lorentz base is Cl(1,n−1,1); a Euclidean (+1) base is Cl(n,0,1).',
      where: ['projectiveCopy.js', 'projective_selfcheck.py (the −1 base and the Lorentz base)', 'pgadyn_selfcheck.py (the +1 base)'],
      tags: ['checked', 'standard'], scripts: ['projective_selfcheck.py', 'pgadyn_selfcheck.py'], note: 'the labels Cl(0,n,1) and Cl(1,n−1,1) are checked by projective_selfcheck.py (its −1 base and its Lorentz base); the label Cl(n,0,1) for a +1 base is the naming of Dorst and De Keninck, run in pgadyn_selfcheck.py (a pointer, the source is not read here)' },
    { n: 12, title: 'Spin and Pin.',
      text: 'The even part Cl⁰ is the same algebra in both conventions; the Pin groups are not (Pin⁺ and Pin⁻ swap). The Atlas does not treat this.',
      where: [],
      tags: ['open'], note: 'a pointer: Berg, DeWitt-Morette, Gwo and Kramer, “The Pin groups in physics” (2001); the source is not read here' },
    { n: 13, title: 'The cell, without a frame.',
      text: 'The cell is the triple (V, Q, π): the 𝔽₂ form Q on the addresses (which blades square to −1) with the parity π of the address. Different frames give the same triple, so the triple is frame-free; the pair (p, q) is one frame-dependent presentation of it, and so is the bit rule. Two cells have isomorphic triples exactly when n and p − q mod 8 agree; Q alone fixes only the type, up to c ↔ 2 − c.',
      where: ['labelsCopy.js (the clock and the finite-groups tabs)', 'categoryCopy.js (the label form)'],
      tags: ['checked'], ids: ['core·B6', 'core·B6b', 'core·B6c'], note: 'checked for n ≤ 5' },
    { n: 14, title: 'The null part.',
      text: 'Null generators split off: Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^{r}). The product of two addresses is 0 when they share a null bit; otherwise it is ±(their sum). The only universal label-grading group is ℤ₂^{p+q} × ℤ^{r}, a ℤ-grading by the number of null bits. Every positive hermitian functional vanishes on the addresses with a null bit, so the states of Cl(p,q,r) are those of Cl(p,q) (T15, on the researchers page; over ℝ the word hermitian cannot be dropped).',
      where: ['researchersData.js (T2, T15)', 'categoryCopy.js (the null part)', 'nullCopy.js', 'check_T2.py', 'check_T15.py'],
      tags: ['checked'], ids: ['core·B7', 'core·B7b', 'core·B8', 'core·B9'], scripts: ['check_T2.py', 'check_T15.py'], note: 'checked for every choice of squares with n ≤ 4, and for n ≤ 5 in the tensor-product form' },
    { n: 15, title: 'Choices the algebra does not make.',
      text: 'A complex structure J (an element with J² = −1 acting on the field space), a time direction γ₀, a Witt split with a vacuum: the coupling step (J), the Spin step, Furey’s ω and her octonion flag, Schuller’s Witt pairs and the Fock vacuum each use one. The table of the four kinds of i of the Spin step classifies where an element of square −1, +1 or 0 can sit; it is not one of these choices.',
      where: ['couplingCopy.js', 'spinCopy.js', 'fureyCopy.js', 'schullerCopy.js', 'shapesCopy.js'],
      tags: ['input'], note: 'inputs of the pages that use them' },
    { n: 16, title: 'Doubling.',
      text: 'A non-degenerate Clifford algebra A = Cl(p,q) (r = 0) acts on itself by left and twisted right multiplication; the two actions generate Cl(n,n) = End(A); the blade addresses are the spinor weights. For r ≥ 1 the two actions of a null generator multiply to 0, so they generate only a proper subalgebra of End(A), and the statement is not made there.',
      where: ['schullerCopy.js (the left and right actions)', 'gossetCopy.js'],
      tags: ['checked'], ids: ['core·B10', 'core·B10b', 'core·B10c'], note: 'checked for every non-degenerate signature (r = 0) with n ≤ 4, and for n = 8 in Cl(8,0)' },
    { n: 17, title: 'The carrier.',
      text: 'The addresses are the group (ℤ/2)ⁿ. Three structures on it are drawn: the group law (the cube), the order by inclusion (the simplex) and an encoding by numbers (primes, notation only). None of them knows the squares of the generators; the Clifford view does.',
      where: ['App.jsx (the four views)', 'genesis_audit_v3.js (the three notations)', 'dictionaryData.js'],
      tags: ['ours'], note: 'our statement of what the pictures draw; that the three notations depend on n only is tested in test_story.mjs' },
    { n: 18, title: 'The finite shadow.',
      text: `The triple (V, Q, π) over 𝔽₂, with its groups: see the finite-groups tab (step ${L('groups')}) and the category chapter. No new statement.`,
      where: ['labelsCopy.js (the groups tab)', 'categoryCopy.js (the finite shadow)', 'check_T9.py'],
      tags: ['checked'], scripts: ['check_T9.py'], note: 'checked (T9, and the finite-shadow row of the category script)' },
  ],
  ideasH: 'The primordial ideas and readings',
  ideasLede: 'Each idea is ours. The second line says what is proved so far, the third what would prove the idea, the fourth what would refute it; a refutation already in hand is said as such.',
  ideaCols: { idea: 'The idea, as the Atlas states it', proved: 'Proved so far', would: 'Would prove it', refute: 'Would refute it' },
  ideas: [
    { id: 'H1', idea: 'A null seed and polarisation generate the ladder of algebras (Genesis ideas A and B).', proved: 'Tian’s chain truncated to k generators is Cl(m,m) for k = 2m and Cl(m−1,m−1,1) for k = 2m − 1, so the ladder reaches the neutral cells with at most one spare null (T7, check_T7.py, k ≤ 12; more spare nulls are the construction of ideas A and B, not a theorem); polarisation is an extra datum (the spine of the audit; hyperbolic basis, T7).', would: 'A selection principle for non-neutral signature.', refute: 'Insufficient already for any physical cell: Cl(3,1), Cl(1,3), … are not neutral.', tags: ['checked'] },
    { id: 'H2', idea: 'A budget of 8 (Genesis idea C).', proved: 'The period 8 of the type table is a theorem (T4, check_T4.py); the stop at E8 is not caused by it.', would: 'Nothing is needed: the budget is the scope of the first tour.', refute: 'Refuted as a universal statement by cells of the Atlas itself: Cl(0,10), Cl(5,5), Cl(1,9), Cl(16,0).', tags: ['checked'] },
    { id: 'H3', idea: 'The labels, not the matrix algebra, are the object.', proved: '(V, Q, π) fixes the cell (n and p − q mod 8); Q alone does not (core·B6c).', would: 'A statement that the frame-free triple loses nothing.', refute: 'None known.', tags: ['checked'] },
    { id: 'H4', idea: 'Four views are four coordinates of one object.', proved: 'Not as stated: the simplex, the cube and the prime view depend on n only; the Clifford view alone sees the squares.', would: '—', refute: 'Shown: the three notations return the same text for every signature with the same n (genesis_audit_v3.js; tested in test_story.mjs).', tags: [] },
    { id: 'H5', idea: 'A horizon is the label 0.', proved: 'Two distinct null statements: a paired null of the non-degenerate Cl(1,1) (the radial gradient; cat_check.py M2) and the radical of the tangent algebra Cl(0,n−2,1) (T18).', would: 'One object that covers both.', refute: 'Covered: the two are two objects, not one.', tags: ['checked'] },
    { id: 'H6', idea: 'One trio −1, 0, +1 everywhere.', proved: 'It splits into the square of a generator (a parameter of the algebra) and the square of an element (an orbit type); what they share is ℝ^{×}/ℝ^{×2} ∪ {0}; bivector squares are mirror-invariant (core·B5b).', would: 'A single definition on one-parameter subgroups, checked on the springs, Kepler, the projective step and the horizons.', refute: 'A case where the generator-level signs clash (Kepler against the projective step may).', tags: ['checked'] },
    { id: 'H7', idea: 'A base/fibre reading of cells.', proved: 'Three different meanings occur in the Atlas (see the glossary).', would: 'One convention.', refute: '—', tags: [] },
    { id: 'H8', idea: 'The cell role names (Leptonic Current Frame, …).', proved: 'None: the Atlas page marks every role name as a reading we propose, not a result.', would: 'A map from irreps and fields to cells.', refute: '—', tags: [] },
    { id: 'H9', idea: 'Three generations from 5-bit labels, or from the 3 of E8.', proved: 'Nothing in the address group (ℤ/2)ⁿ has order 3; order-3 symmetries of the labels exist when three generators share a sign (core·B12).', would: 'An order-3 automorphism or a triality acting compatibly on Furey’s or Baez’s data.', refute: 'The Furey family test already excludes the gauge commutant.', tags: ['checked'] },
    { id: 'H10', idea: 'Physics “from the bit rule alone”.', proved: 'The squares and the volume element enter; ∇, grades, γ₀, J and the equations are inputs.', would: '—', refute: 'Refuted as worded: the pages say what they take from outside.', tags: [] },
    { id: 'H11', idea: '4/17 against sin²θ_W; the number 210.', proved: 'Arithmetic only.', would: 'A derivation.', refute: '—', tags: [] },
  ],
  ideasFurther: 'Further readings of this band keep their own tags and make no new claim: the cell role names, the Λ-like term k = −s in gravity (bound to the convention), the real-10 against complex-10 reading of the (1,9) cell in the Baez chapter, and the wording “our model” for Furey’s model.',
  glossH: 'Glossary',
  glossLede: 'Words that have more than one use in the Atlas, with the use each page keeps. Where a chapter uses a different word for the same thing it adds the gloss at first use.',
  gloss: [
    ['address', 'A pattern of switches, an element of 𝔽₂ⁿ. It says which generators a blade contains. (Elsewhere called “label”.) The “lattice address” [p + q, p − q] of a cell is something else: the place of the cell in the lattice of cells.'],
    ['label −1, +1, 0', 'The square of a generator. Say “the square of a generator is −1, +1 or 0”.'],
    ['label 0', 'A generator whose square is 0 (a null generator, the radical). It is not the empty address (the unit 1) and it is not a paired null of a non-degenerate algebra.'],
    ['form', 'The 𝔽₂ form Q on addresses: Q(a) = 1 when the blade e_{a} squares to −1. With the parity of the address it fixes the cell (row 13).'],
    ['state label', `A character of a maximal set of commuting blades (the Fock and Walsh bases, steps ${E('spin')} and ${E('spring')}).`],
    ['mode', 'A Walsh mode: the same, for the spring on the cube.'],
    ['vertex', 'A corner of a body in the rigid-body chapter, identified with an address by choosing a base corner.'],
    ['prime name', 'The prime that the Prime view assigns to a face. Notation only.'],
    ['clock value', 'c = p − q mod 8: the Brown invariant of the addresses with their Z_{4}-form (row 13). “Phase” is the word for a U(1) phase.'],
    ['base / fibre', 'Three uses. (1) The two actions of an algebra on itself: the left action is called the base and the twisted right action the fibre (our naming, in the Schuller chapter). (2) The two factors of a graded tensor product, base Cl(1,3) and fibre Cl(0,3), or an algebra and its commutant, as in Schuller’s lectures. (3) On the cell cards and in the coordinates B+F and B−F: the plus generators are the base and the minus generators the fibre (B = p, F = q), a reading of ours; the count is also said “plus and minus”.'],
    ['bit rule', 'The Clifford rule s_{ε} with squares ε. Any other sign function is called a sign function on the addresses.'],
    ['mirror', `ε → −ε: every square changes sign (the mirror cell Cl(q,p)). The reflection of step ${E('mirrors')} is called a reflection in a hyperplane.`],
    ['null', 'Three objects share the word. (1) A null generator: label 0, unpaired, the radical. (2) A null vector of a non-degenerate algebra, such as e_{t} − e_{r} in Cl(1,1): it has a partner and spans a hyperbolic plane with it. (3) An element of square 0 in a non-degenerate cell: a translation in the projective picture, a null rotation in the cell itself (T = 1 − a n_{∞}/2, gtg_check.py part R).'],
    ['trio', 'The trinity of step 1 and the −1, 0, +1 of generator squares are two different things. (A) The square of a generator, e_{i}² in {−1, 0, +1}: a parameter of the algebra that makes the cell; as a family it is a deformation and 0 is the contraction; it changes under the mirror (−1 and +1 swap, 0 stays). (B) The square of an element x² (a vector or a bivector): the orbit type of exp(tx), elliptic for x² < 0 (rotation), parabolic for x² = 0 (translation or null rotation), hyperbolic for x² > 0 (boost); for a bivector (e_{i}e_{j})² = −ε_{i}ε_{j}, which does not change under the mirror, while for a vector it does. Both sort a real square by its sign, ℝ^{×}/ℝ^{×2} ∪ {0}; reading the two as one trio is ours.'],
    ['calibration', 'A run on something whose answer is known, to show which inputs the method needs; it is not a test of a new theory.'],
  ],
  wordsLink: 'Words and conventions: see the glossary',
  wordsLinkY: 'Which words mean what: see the page of words',
};
// the number of the step a row speaks of is read from steps.js, so that it cannot go stale
EN.gloss[13][1] = EN.gloss[13][1].replace('step 1', `step ${L('clock')}`);

export const CONV = { en: EN, it: EN };

// ---- the frame of the Conventions page: heading, what it does, what came before and after, the tags strip.
// One English text serves both language slots. The tab bar names the two tabs: the Conventions tab and step 1, the clock.
const PAGE_EN = {
  h: 'Conventions and the clock',
  does: 'Some words of the Atlas are choices, not results: which generators are called space and which time, what the mirror flips, what a label is. The Conventions tab states each choice once, with the statements that hold in every convention, the primordial ideas with what is proved so far, and a glossary. Step 1 is the clock: every cell has a class on the Z_{8} clock, c = p − q mod 8, which fixes what the cell is, and the signs −1, +1, 0 of a square sort the elements into rotations, boosts and translations. Every later page uses both. Every picture here is computed in your browser from the bit rule, and the scripts that check the same numbers come with the package.',
  before: 'The atlas gave every cell an algebra and a place.',
  after: 'Two cells are rebuilt in depth as calibrations: the electromagnetic one first, because everything about it is known.',
  tags: [
    ['checked standard', 'the clock is rebuilt from the bit rule in your browser and by scripts: the class of each cell on the Z_{8} clock, its matrix type and size, the 72 isomorphisms of the rotor algebras (n ≤ 8), the trinity counts (squares of elements) and the roots at n = 4; the statements of the Conventions tab marked checked are confirmed by the core checks, labels_check.py and the scripts named in each row'],
    ['standard', 'the classification of Clifford algebras, the Bott clock, and the conventions of the literature that the Conventions tab names (Hestenes; Lasenby, Doran and Gull; Dorst and De Keninck) are published results, quoted'],
    ['checked standard ours', 'the signs −1, +1, 0 of a square as rotation, boost and translation for a vector or a simple bivector (the elliptic, hyperbolic and parabolic one-parameter subgroups; a simple bivector with square 0 is a translation, a null rotation or a totally null plane; from n = 4 they are no longer enough); the choices of words (which generators are called space or time, what the mirror flips) and the primordial ideas of the Conventions tab, each tagged where it stands'],
    ['checked open', 'the Pin groups are not treated, and the primordial ideas are not settled (each lists what would settle it); that translation inside a non-degenerate cell is a null rotation, T = 1 − a n_{∞}/2, is checked in gtg_check.py, part R'],
  ],
};
const PAGE_YL_EN = {
  h: 'Which words we use, and the clock',
  does: 'Some words in the atlas are choices, not discoveries: which switch counts as space and which as time. The first tab says each choice once. Then comes the first step: every box has a hand on a clock with eight places, and the place tells what the box is made of. Every picture here is worked out by your browser while you look.',
  before: 'The atlas set 25 cards side by side.',
  after: 'Two boxes are worked through closely: first the one for light, because everything about light is known.',
  tags: [
    ['checked standard', 'every number and picture of the clock is worked out again by your browser from the switch rule, and scripts check the same numbers'],
    ['standard', 'the list of all kinds of box and the clock that sorts them are known maths from books'],
    ['checked standard ours', 'a turn, a push and a slide are what the three signs do to one arrow, which is known and checked; which switch we call space and which we call time is a choice of words, ours'],
    ['checked open', 'our own ideas about why the boxes are the way they are are not settled (each says what would settle it); inside the plain boxes the slide is a special kind of turn, and that is checked'],
  ],
};
export const PAGE = { en: PAGE_EN, it: PAGE_EN };
export const PAGE_YL = { en: PAGE_YL_EN, it: PAGE_YL_EN };
// short readings for the Young Learner and the Physicist (audienceCopy.js SHORT.page_conventions)
const SHORT_EN = [
  'Which words we use, and a clock. Some words are our choices: which switch counts as space and which as time. Then a clock with eight places tells what each box is made of. Everything on the page is worked out in your browser.',
  'The conventions of the Atlas (S, T and D: which generators are called space or time; the mirror; what a cell is without a frame), the statements that hold in every convention, the primordial ideas with what is proved, and a glossary. Step 1: the Z_{8} clock, rotor algebras, the trinity X^{2} = −1, +1, 0 and bivectors at n = 4. All computed live; the checks are named.',
];
export const SHORT = { en: SHORT_EN, it: SHORT_EN };
// the tab-bar label of the page, read aloud by a screen reader to the Young Learner too (test_yl_ui.mjs scans aria-labels for jargon)
export const TABS_LBL = { en: 'The conventions, and step 1: the clock', it: 'The conventions, and step 1: the clock' };
export const ROWS = EN.rows, IDEAS = EN.ideas, GLOSSARY = EN.gloss;
// the status line of the tab, written from the rows so that the list of rows of each kind cannot go stale
const kindRows = k => { const ns = ROWS.filter(r => r.tags.includes(k)).map(r => r.n); return (ns.length === 1 ? 'row ' : 'rows ') + ns.join(', '); };
EN.glance = {
  tags: [
    ['checked', `what the checks prove: ${kindRows('checked')} (core·B4 to B10c, check_T2.py, check_T9.py, check_T15.py, check_T18.py, labels_check.py, gtg_check.py, pgadyn_selfcheck.py, projective_selfcheck.py)`],
    ['standard', `named in the literature and quoted by the Atlas: ${kindRows('standard')} (Hestenes, Lasenby–Doran–Gull, Dorst–De Keninck, the de Sitter signatures)`],
    ['ours', `choices and readings of the Atlas: ${kindRows('ours')}, and every idea of the second list`],
    ['open', `${kindRows('open')}: the Pin groups are not treated`],
    ['input', `${kindRows('input')}: the complex structure, the time direction and the Witt split are chosen, not supplied by the algebra`],
  ],
  est: 'Established here: the label and mirror statements of the checked rows, by the core checks. The naming of time and space is a choice of words; nothing in the algebra decides it.',
  script: 'core_check.py (core·B1 to B17) · labels_check.py · check_T18.py',
};
