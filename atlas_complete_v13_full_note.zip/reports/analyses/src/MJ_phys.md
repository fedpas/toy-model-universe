# Lane MP (physics: string theory, solid state, field theory): the Majkić paper against the Atlas

Paper: arXiv:2403.19689 v3 ("General Categorial Geometry and Algebraic Topology"), items M1–M20 of `pack/majkic/INVENTORY.md`. Lens languages: `str`, `sol`, `fld`. Check family `bd·mjp·n`, 38 checks and 2 info lines in six scripts `selfcheck/bridges/mjp_*.py` of the clone `mj_MP`; copies with logs in `out/MP_code/`. Nothing here is a claim about nature: the physical words name structures and models, and the paper's table (2.53) is read as a dictionary of analogies, in the same way as the Atlas's calibrations.

## 0. Summary

1. **Fits (§2, §3 U1–U3).** On the labels the paper's category is the *creation category* of $n$ fermionic modes: an arrow $S\to T$ is a creation process, the undefined $a\oplus b$ is Pauli exclusion, the weight is the particle-number change, the bit-rule sign is the Jordan–Wigner string, and the arrow is the matrix unit $|T\rangle\langle S|=s(T\setminus S,S)\,C^+_{T\setminus S}P_S$. Creation operators and number projectors generate exactly these $3^n$ units, the Borel part of $Cl(n,n)=M_{2^n}(\mathbb R)$ ($4^n$) (bd·mjp·1–5).
2. **Generic, not findings (§6).** The Borel algebra is sign-blind (200/200 random sign tables; bd·mjp·6). The data is the face flux $-1$ (bd·mjp·7); the mode order is a gauge (bd·mjp·8).
3. **(9) physically (§3 U2).** Weights additive on the labels' partial sum are the $n$ charges $\sum q_in_i$, the free energies (bd·mjp·9). Weights additive on composition are the $2^n-1$ energy differences $E(T)-E(S)$, because $B_n$ has a minimum (the vacuum); random posets with $b_1>0$ break this (bd·mjp·10). An interaction is the defect of (9).
4. **Discovery (§9 X1).** The clock form is a $\mathbb Z_4$ charge: $w(a)=\sum_{i\in a}\varepsilon_i\bmod4$ adds on $\oplus$ ($Q$ does not), and the Gauss sum is $\prod_i(1+i^{\varepsilon_i})$, the grand partition function at fugacity $i$, with null bits as zero modes (bd·mjp·31). The paper's integer weights mod 4 give a cell iff no $q_i\equiv2$ (bd·mjp·32).
5. **Breaks (§7), each decided by a computation.** B1, minimal action ↔ limit cone: only "limit ⟹ least leg weight" holds; the bowtie has a least cone and no limit (bd·mjp·18). B2, Lagrangian density ↔ unit: in $B_n$ the unit is the identity, so the adjunction moves nothing (bd·mjp·17). B3: an additive weight is an absolute time; proper time is super-additive (bd·mjp·23), and only $dt$ is boost-invariant (bd·mjp·25). B4, Königsberg with bridges as objects: all bridges once is possible unless the objects carry the side (bd·mjp·15). B5: (9) and (13) are exclusive in the label-vector reading (bd·mjp·13). B6, the word "Galilean boost". B7, $e_3$ unit or null: clock 3 or 2.
6. **Clock (§3 U7, §4 D0).** The paper's relations give Cl(3,0), Cl(2,0) and Cl(2,0,1), with clocks 3, 2, 2. The data fix nothing more: the Gram of (10) is $(2,0)$ in 200/200 random categories (bd·mjp·30).
7. **Meeting (§5).** U2 = D3 for all 364 $\varepsilon$ (bd·mjp·36), given a frame. The frame is unique up to $S_p\times S_q$ for $n\le3$; there are two for Cl(1,3), Cl(2,2) and Cl(3,1) (bd·mjp·38). The integer weight is a grading only below the squares (bd·mjp·37) and needs a Witt pairing above them ($n!\,2^n$ number operators, one parity; bd·mjp·11).
8. **Places (§8).** Category lens (cat·K1a), T20, conventions (clock), null surfaces/T17, the equations tally. No new step. 12 MJ rows; D03 changed, D17 and D38 confirmed.

**Five most important:** (i) the creation category and Borel part, with sign = gauge and flux = data (§2, §3 U3, §6); (ii) $w$ as a $\mathbb Z_4$ charge and the Gauss sum as a partition function (§9 X1); (iii) the two additivities, charges against energy differences (§3 U2); (iv) B1 and B2 on table (2.53) (§7); (v) the frame and the integer weight separate the ladders (§5).

## 1. How I read the paper and the Atlas

**The paper, from the physics side.** Four pieces of the paper speak physics.
- (M7) The table (2.53) of the author's book [13] pairs six physics notions with categorical ones: space-time with points; scalar field of type $J$; Lagrangian density; action; principle of minimal action; Euler–Lagrange equation. The paper itself calls this an "analogy" and a "mathematical intuition", and adds that the transformations are Galilean, with absolute time, not Lorentz boosts. The A-space is flat without adjunctions and is "curved" by them, which "changes the mapping $P$".
- (M8, M11) The norm $\|f\|$ is the time to cross the path at speed 1 (footnote 7: not the planar length). In Example 1 (Königsberg) the total time, cost or energy of a path is $\sum_i\alpha_i\|f_i\|$.
- (M10, M12) The norm is additive on composition, (9). There are no inverses and only positive scalars.
- (M15–M18) The inner product (10), the wedge (12), $f^2=\|f\|^2$ (13), and Corollary 1 (the relations of Cl(3,0)).

The author's related preprint [14] (arXiv:2406.16884, read through extracts, §12) adds three things:
- adjunctions are "scalar fields" ("adjunctions-as-fields"), whose unit and counit act as "forces" that displace objects;
- the levels $C_{n+1}=C_n\downarrow C_n$ are "Galilean reference frames", and comma-propagation is a "Galilean boost";
- universal arrows are "a kind of Lagrangian".

**The Atlas, from the physics side.**
- The labels as a Fock space: T20, D38, baez·H3a.
- The cube category $kB_n$ with the Jordan–Wigner sign on its edges: cat·K1a, cat·K1b, LNC claims, D43.
- The Majorana reading of the cell: bd·sol·1 (Hermitian iff $Q=0$, fermion-odd iff $\pi=1$).
- The clock as the Fidkowski–Kitaev edge invariant (bd·sol·2) and as a KO-degree (bd·str·2).
- The null part as creation operators or Grassmann directions: D17, bd·sol·12, bd·str·23.
- The null rotation and the Carroll kernel: T17, T18, D33, bd·phy·6.
- The action input lines of the equations pages (`pack/needs_inputs.md`): the Maxwell and Dirac actions, whose Euler–Lagrange equations are bd·phy·18 and bd·phy·19.
- The Kepler trio through Fock's projection (`disc_KEP_result.md`, bd·kep·1–6), where hodographs are geodesics: the Atlas's one computed instance of a geodesic (stationary-length) principle.

**The reading.** The objects of the paper's category are the labels $S\in\mathbb F_2^n$, read as occupation patterns of $n$ modes. An arrow $S\to T$ ($S\subseteq T$) creates the particles $T\setminus S$, and its weight is any additive function of the arrow. The paper's planar vectors $D(f)=P(\mathrm{cod}f)-P(\mathrm{dom}f)$ and its weights are read as the space and time components of an event displacement (§3 U4).

Every row below is computed on the labels and then tested against noise: random sign tables, random posets, random functions, random positions, weights and Gram matrices. A statement that every control also satisfies is called generic.

## 2. Dictionary

| Paper object (M-ids) | Atlas object (ids) | object in my field | match | evidence | flag |
|---|---|---|---|---|---|
| object $a\in\mathrm{Ob}\,C$ as a point (M1, M5) | label $S\in\mathbb F_2^n$ (D01) | `sol` occupation pattern, Fock basis state $\lvert S\rangle$ | exact with convention (objects = labels) | bd·mjp·33 | checked (counts), ours (reading) |
| non-identity morphism $f$ (M1, M8) | arrow $S\subsetneq T$ of $B_n$ (cat·K1a, T8) | `sol` creation process; the matrix unit $\lvert T\rangle\langle S\rvert=s(T\setminus S,S)\,C^+_{T\setminus S}P_S$ | exact | bd·mjp·5 | checked |
| partial sum $\oplus$ = composition (M10, (8)) | composition in $B_n$; on labels the disjoint union (S1) | `sol` successive creation; undefined $\Leftrightarrow C^+_aC^+_b=0$ (Pauli exclusion) | exact | bd·mjp·2, bd·mjp·33 | checked |
| norm additive on composition (9) (M10, M12) | popcount $\lvert T\setminus S\rvert$; number operator (T20(c)) | `sol` $[N,A(S\to T)]=\lvert T\setminus S\rvert\,A$; in general an energy difference $E(T)-E(S)$ | exact for popcount; a $(2^n-1)$-dimensional space in general | bd·mjp·5, bd·mjp·10 | checked |
| (9) read on the labels' partial sum (S10) | charges on $(\mathbb F_2^n,\oplus)$ | `sol` one-body charges $\sum q_in_i$ (free energies); `str` $2h=\lvert\alpha\rvert^2$ of $\mathbb Z^n$ vertex operators on 0/1 vectors | exact ($n$-dimensional) | bd·mjp·9, bd·mjp·28 | checked |
| time, cost, energy (M8, M11) | input kinds `time`, `action` (needs_inputs) | `fld` absolute (Galilean) time $dt$; not proper time | partial | bd·mjp·23, bd·mjp·25 | checked, ours |
| no inverse, positive scalars (M11, M12) | Borel part ($3^n$) of $Cl(n,n)$ (core·B Witt pairs, T20) | `sol` creation only; the annihilation operators are the missing inverses | exact with convention | bd·mjp·3, bd·mjp·4 | checked |
| inner product (10) (M15) | the form $Q$ of a cell (D04, D11) | `fld` a positive metric on the plane $Z_0$: Gram $(2,0)$ always | partial | bd·mjp·30 | checked |
| wedge $f\wedge g=-g\wedge f$ (M16) | the sign on disjoint labels (T6, D03) | `sol` Jordan–Wigner exchange sign, flux $-1$ (π) through every face; `str` lattice cocycle of $V_{\mathbb Z^n}$ | exact on labels | bd·mjp·1, bd·mjp·7, bd·mjp·29 | checked |
| (9) together with (13) $f^2=\|f\|^2$ (M10, M17) | $\pi$ (grading) against $Q$ (squares) (D04, D05) | `fld` linear weight against squared norm (Pythagoras on orthogonal vectors) | none (exclusive in the label-vector reading) | bd·mjp·13 | checked |
| Corollary 1, $e_i^2=1$ (M18) | Cl(3,0), clock 3 | `sol` three T-even Majoranas (an odd count) | exact | bd·mjp·30, info bd·mjp·i2 | checked |
| zero vector $0=\|0\|e_3$ (M9) | null generator (D17); or the zero element | `sol` a zero mode: factor 2 in the Gauss product, no phase | partial (two readings) | bd·mjp·30, bd·mjp·31 | checked, ours |
| Galilean boosts, absolute time (M7) | null rotation of $Cl(d,0,1)$ (T17, translation kind) | `fld` Galilei boost on points, Carroll boost on vectors (inverse transpose) | partial ([14] uses the word for comma-propagation) | bd·mjp·25, bd·mjp·26 | checked, ours |
| table (2.53), six rows (M7) | §7 B1, B2 and the T10 table below | §3, §7 | analogy | bd·mjp·16–22 | ours (analogy) |
| Königsberg (M11) | none | free category on the multigraph | — | bd·mjp·14, bd·mjp·15 | checked |
| adjunctions curve the A-space and move $P$ (M7) | none (the Atlas has no positions) | `fld` the unit of $\Delta\dashv\lim$ as a displacement | none on $B_n$ (unit = identity) | bd·mjp·17 | checked, ours |

**The table (2.53) row by row (T10).** Each row is checked against the Atlas's counterpart and against what can be computed.

| row (physics ↔ category) | Atlas counterpart | computed here | match | status |
|---|---|---|---|---|
| continuous space-time with points ↔ category as a 3D space, objects as points | the `chart` input (flat chart, ∇); the labels are a basis, not points | the A-space read as Galilean space-time: $X(f)=(\|f\|,D(f))$ is additive, and the speed-1 cone is kept by composition (bd·mjp·27) | partial | ours (reading), checked (the cone) |
| scalar field of type $J$ ↔ adjunction $(\Delta,G,\varepsilon,\eta)$, $\Delta:C\to C^J$ | the `grade` input (a scalar is grade 0); no adjunction in the Atlas's physics pages | $\Delta\dashv\wedge$ on $B_n$: 74584 of 74584 hom comparisons (bd·mjp·17) | none (no shared computation) | input / analogy |
| Lagrangian density ↔ universal arrow $(\Delta(p_i),\eta(p_i))$ | the action lines of steps 2–16 (Maxwell, Dirac, coupling: bd·phy·18, bd·phy·19) | on $B_n$, $\eta_c=\mathrm{id}_c$ (weight 0) at every object (bd·mjp·17) | none | analogy; degenerate on posets (B2) |
| action $\int L$ ↔ set of displacements of each point (path integrals) | input kind `action` | the out-sum $\sum_{T\supseteq S}e^{-\beta w}$ equals $\prod_{i\notin S}(1+e^{-\beta q_i})$ for charge weights and fails 200 of 200 times for interacting ones (bd·mjp·22); path sums 1 / $n!$ / 0 (bd·mjp·21) | partial | checked (the sums), ours (the reading) |
| minimal action ↔ unique arrow to the limit cone | bd·kep·6 (hodographs are geodesics: a stationary-length principle) | limit ⟹ unique least-weight cone; the converse fails (bowtie) (bd·mjp·18); on thin categories every path minimises (bd·mjp·19) | partial (one direction) | checked; B1 |
| Euler–Lagrange ↔ commutative diagram of the adjunction | bd·phy·18, bd·phy·19 (Euler–Lagrange of the coupled action in Cl(1,3)) | the triangle identities on $B_n$ hold trivially (a poset) | none (no shared computation) | analogy |

## 3. The ladder up

Sizes are computed by enumeration in bd·mjp·33 ($n=0..6$), bd·mjp·9, bd·mjp·10, bd·mjp·34 and bd·mjp·35. The rows for $n=0..4$:

| rung | quantity | n=0 | 1 | 2 | 3 | 4 | check |
|---|---|---|---|---|---|---|---|
| U0 | labels (Fock states) $2^n$ | 1 | 2 | 4 | 8 | 16 | bd·mjp·33 |
| U1 | pairs with a defined $a\oplus b$ = non-zero $C^+_aC^+_b$, $3^n$ | 1 | 3 | 9 | 27 | 81 | bd·mjp·2, bd·mjp·33 |
| U2 | weights additive on $\oplus$ (charges), dimension $n$ | 0 | 1 | 2 | 3 | 4 | bd·mjp·9 |
| U3 | arrows $3^n$ / composable pairs $4^n$ | 1/1 | 3/4 | 9/16 | 27/64 | 81/256 | bd·mjp·33 |
| U3 | chains $S_0\subseteq S_1\subseteq S_2\subseteq S_3$ (3-simplices of the nerve) $5^n$ | 1 | 5 | 25 | 125 | 625 | bd·mjp·33 |
| U3 | composition-additive weights (potentials), $2^n-1$ | 0 | 1 | 3 | 7 | 15 | bd·mjp·10 |
| U3 | incidence (Borel) algebra $3^n$ | 1 | 3 | 9 | 27 | 81 | bd·mjp·4 |
| U4 | non-identity arrows carrying a planar vector, $3^n-2^n$ | 0 | 1 | 5 | 19 | 65 | arithmetic |
| U5 | $\Lambda(\mathbb R^n)$, dimension $2^n$; commutator space $2^{n-1}-1$ | 1; 0 | 2; 0 | 4; 1 | 8; 3 | 16; 7 | bd·mjp·34 |
| U5 | square faces $\binom n2 2^{n-2}$ (flux $-1$ on each) | 0 | 0 | 1 | 6 | 24 | bd·mjp·7 |
| U6 | cells $Cl(p,q,r)$, $(n+1)(n+2)/2$; isometry classes of the triple | 1; 1 | 3; 2 | 6; 4 | 10; 8 | 15; – | bd·mjp·35 |
| U6 | the CAR algebra $Cl(n,n)$ with Witt pairs, $4^n$ | 1 | 4 | 16 | 64 | 256 | bd·mjp·3, bd·mjp·4 |
| U7 | modulus of the Gauss sum $2^{n/2}$ (r = 0); 8 clock values | 1 | $\sqrt2$ | 2 | $2\sqrt2$ | 4 | bd·mjp·30, bd·mjp·31 |

**U0, bare points.** The $2^n$ labels are noise: a set with no operation.
- Paper: the objects (M1) and the discrete space $\mathrm{Im}(P)$ before any arrow (M4, M5).
- Atlas: D01 as a bare set.
- Lens rows:
  - `sol`: "occupation patterns; the Fock basis of $n$ modes". Match exact as a set. Flag ours. Check bd·mjp·33.
  - `fld`: "configurations of $n$ fermionic modes". Exact as a set; ours.
  - `str`: "Ramond zero-mode occupations" (the $2^n$ weights of a spinor). Partial: the bare set does not carry the weights $\pm\frac12$. Ours; pointer, source unread.
- Forces: nothing.

**U1, the partial sum $a\oplus b$ ($a\wedge b=0$), unit 0.**
- Paper: M10's (8) on the labels, M13's partial commutative monoid, and the undefinedness rule.
- Atlas: the bit rule restricted to disjoint labels, which is the exterior product for every $\varepsilon$ (bd·mjp·36).
- Physical reading: $a\oplus b$ is defined exactly when $C^+_aC^+_b\neq0$. Over $n=1..5$, the 363 disjoint pairs give products $s(a,b)C^+_{a\oplus b}$, and the 1001 overlapping pairs give 0 (bd·mjp·2). **The paper's "undefined" is Pauli exclusion.**
- Lens rows:
  - `sol`: "Pauli exclusion; $C^+_aC^+_b=0$ iff $a\wedge b\ne0$". Exact; checked; bd·mjp·2.
  - `fld`: "adding particles to empty modes". Exact; ours.
  - `str`: "OPE of distinct fermions $e^{iX_j}$ without contraction". Partial, because the OPE exponent $\alpha_a\cdot\alpha_b=|a\wedge b|$ vanishes exactly on the disjoint pairs (bd·mjp·28). Checked for the exponent, ours for the reading.
- Sabotage of bd·mjp·33: with the sum defined on every pair (XOR, a group), the count becomes $4^n$.
- Forces: a weight additive on $\oplus$ can now be asked for (U2).

**U2, the weight $\|a\|=$ popcount (primary rung).**
- Paper: M8 (the norm), (9), M11 (time, cost, energy), M12 (non-negative).
- Atlas: the grading $\pi$ is its value mod 2. The number operator has eigenvalue popcount on $|S\rangle$ (T20(c)).

Computed (bd·mjp·9):
- The weights $h$ on the labels with $h(a\oplus b)=h(a)+h(b)$ on all disjoint pairs form a space of dimension exactly $n$ ($n=0..6$). These are $h_q(a)=\sum_{i\in a}q_i$, the diagonal of $\sum_iq_in_i$. They are **charges**: a free one-body energy, the particle number ($q=1$), or any $U(1)$ charge.
- The paper's positivity ($\|f\|>0$ off the identities) is $q_i>0$ for every mode: adding any particle costs. The vacuum is then the ground state, with no Fermi sea.
- An interaction $Un_0n_1$ breaks (9) on $(\{0\},\{1\})$ by exactly $U$.
- 200 random functions are additive in 0 of 200.
- Sabotage: with the sum defined on all pairs (a group), the space is $\{0\}$ for every $n$. A real-valued additive weight needs the partiality, which is the paper's "no inverse".

**The finding:** the label weights that satisfy (9) for the partial sum are exactly the non-interacting charges. This is not generic.

Lens rows:
- `sol`: "particle number; one-body charges $\sum q_in_i$, free energies". Exact; checked; bd·mjp·9, bd·mjp·5.
- `fld`: "$U(1)$ charge; additive quantum number". Exact; checked; bd·mjp·9.
- `str`: "conformal weight $h=|\alpha|^2/2$ of the $\mathbb Z^n$ vertex operator $e^{i\alpha\cdot X}$ on 0/1 vectors". Exact on the labels, because $h(\alpha_a+\alpha_b)=h(\alpha_a)+h(\alpha_b)+|a\wedge b|$ is additive exactly on disjoint pairs (bd·mjp·28; $n\le6$). It is not additive under fusion in general: 27 of 200 random $\mathbb Z^4$ pairs, exactly the orthogonal ones. Checked; $h=|\alpha|^2/2$ is a pointer (standard, unread here).

Forces: an order (U3), because "$a$ then add $c$" is the arrow $a\to a\oplus c$.

**U3, the order and the arrows $S\to T$; composition = chains; weight $|T\setminus S|$.**
- Paper: M1 and M2 (the category), M10 (the sum read as composition), M14 ($d(f,g)=\|f\ominus g\|$ is the weight of the third side).
- Atlas: the cube category $kB_n$ (T8, D43); the Jordan–Wigner edge signs (cat·K1a).

Computed:
- The arrow functor $A(S\to T)=s(T\setminus S,S)\,C^+_{T\setminus S}P_S$ equals $|T\rangle\langle S|$ on all 363 arrows ($n\le5$). It keeps all 1364 compositions and satisfies $[N,A]=|T\setminus S|\,A$ (bd·mjp·5).
- Creation operators and number projectors generate exactly the $3^n$ matrix units with $S\subseteq T$ ($n\le5$). With the annihilation operators the algebra is $4^n$ ($n\le4$) (bd·mjp·4).
- The order of $B_n$ is the **mode-wise** order of occupations, not the order of the total charge. The non-negative-charge part of $M_{2^n}(\mathbb R)$ has dimension $(4^n+\binom{2n}{n})/2$: 3, 11, 42, 163, 638, 2510, against the Borel 3, 9, 27, 81, 243, 729 (bd·mjp·12). The difference is the hopping $c_i^+c_j$.
- The weights additive on composition are the potentials $E(T)-E(S)$, a space of dimension $2^n-1$ (bd·mjp·10). This holds because $B_n$ has a minimum (the vacuum). In random posets the dimension is (elements − components + $b_1$) in 200 of 200, and only the 146 posets with $b_1=0$ have potentials only.
- Physical reading: on the labels, the paper's (9) on composition says that energy is an energy difference. Interactions are allowed, and the time of a path is the telescoping sum.
- Every path $0\to[n]$ has the same weight (bd·mjp·19). A "minimal action" principle therefore selects nothing on $B_n$ (§7 B1).

Lens rows:
- `sol`: "creation category; the Borel (upper triangular) part of the CAR algebra". Exact; checked; bd·mjp·4, bd·mjp·5.
- `fld`: "energy differences; the vacuum as the minimum". Exact; checked; bd·mjp·10.
- `str`: no counterpart. The open-string category (boundary conditions and open strings) would be a candidate. Its weights are conformal weights, which are not additive under joining, and no computation here supports a match.

Forces: the paper's next step, positions (U4).

**U4, positions $P$ and planar vectors $D(f)$ (the paper's O-space and Cat-arrows).**
- Paper: M5, M6, M8, M15.
- Atlas: **no rung.** The Atlas's labels carry no positions; the cube coordinates of the shapes page are the label vectors $\alpha_a\in\{0,1\}^n$ of bd·mjp·13.
- Computed: read the paper's arrow as a Galilean event displacement $X(f)=(\|f\|,D(f))\in\mathbb R\times\mathbb R^2$. At speed 1 the time to cross a path is at least its planar chord, and strictly more when the interior is off $Z_0$: $\|f\|>|D(f)|$. Composition keeps this cone: 200 of 200 random weighted $B_3$ with random positions (bd·mjp·27).
- Lens rows:
  - `fld`: "events of a Galilean space-time with a speed limit". Partial; checked; bd·mjp·27.
  - `sol`: "weight diagram, $P(S)=\sum_{i\in S}q_i$ with $q_i\in\mathbb R^2$". Partial; ours. No check: a reading only.
  - `str`: no counterpart.

**U5, the sign $s(a,b)$ (the wedge).**
- Paper: M16 ($f\wedge g=-g\wedge f$) and M18 (orthogonal vectors anticommute).
- Atlas: T6 (unique up to gauge), D03, cat·K1a and cat·K1b.

Computed:
- Jordan–Wigner $c_i^+$ equals left multiplication by $e_i$ in $\Lambda(\mathbb R^n)$, entry by entry ($n\le5$; bd·mjp·1).
- The bit rule has flux $-1$ on all $\binom n2 2^{n-2}$ faces ($n=2..6$).
- Random edge-sign tables anticommute in 8 of 200 ($n=3$) and 0 of 200 ($n=4$), exactly the tables with every flux $-1$ (bd·mjp·7).
- For 60 random orderings of the modes, the ordering changes the table by a coboundary and leaves the fluxes alone (bd·mjp·8).
- What the sign adds (bd·mjp·34). The algebra of the paper's partial sum on the labels is $e_ae_b=e_{a\oplus b}$ for disjoint labels and 0 otherwise: the commutative zeon or hard-core boson algebra. Its left multiplications are $\sigma_i^+$ without a string. $\Lambda(\mathbb R^n)$ has the same dimension, zero pattern and grading, a commutator space of dimension $2^{n-1}-1$ (0, 1, 3, 7, 15 for $n=1..5$), and the Jordan–Wigner $c_i^+$. **The sign turns hard-core bosons into fermions.**

Lens rows:
- `sol`: "Jordan–Wigner string; flux π through every face". Exact; checked; bd·mjp·1, bd·mjp·7, bd·mjp·8.
- `fld`: "fermionic exchange sign". Exact; standard, checked.
- `str`: "cocycle of the lattice vertex superalgebra $V_{\mathbb Z^n}$". Exact for (4.2) of Bakalov–Kac. The sign is bimultiplicative for every $\varepsilon\in\{\pm1\}^n$ and has the commutator $(-1)^{\alpha\cdot\beta+\alpha^2\beta^2}$; for $\varepsilon=+1$ it is $(-1)^{\sum_{i>j}a_ib_j}$ (bd·mjp·29). Checked; standard (§12).

**U6, the squares $\varepsilon$ (primary rung).**
- Paper: M15 (inner product), M17 ($f^2=\|f\|^2$), M18 (Corollary 1: Cl(3,0)).
- Atlas: the cell $(V,Q,\pi)$ (D11) and the quadruple for $r\ge1$ (D13).

Computed:
- **What the paper's relations give** (bd·mjp·30), computed as exact Gauss sums: Cl(3,0) from Corollary 1, Gauss sum $-2+2i$; Cl(2,0) for the plane $Z_0$ of the arrows, $2i$; Cl(2,0,1) when $e_3$ is read as a null direction (M9), $4i$.
- **What the paper's data give:** nothing beyond the rank. For 200 random categories with random positions and weights, the Gram matrix $\|f\|\|g\|\cos\theta$ of (10) is positive semidefinite of signature $(2,0)$. This holds by construction, since it is the Euclidean Gram of the rescaled vectors $\|f\|\hat u_f$. It is a generic statement.
- **The squares against the integer weight.** In the label-vector reading $\alpha_a=\sum_{i\in a}e_i$ (grade 1, bit rule), $\alpha_a^2=|a|$ in Cl(n,0). Disjoint labels anticommute (Corollary 1, point 2) and satisfy Pythagoras on all 602 pairs at $n=6$ (bd·mjp·13). So (9) holds with $\|a\|=\alpha_a^2$, and then (13) fails for $|a|\ge2$. With $\|a\|=|\alpha_a|$, (13) holds and (9) fails on every disjoint pair of non-zero labels.
- In Cl(1,3), $\alpha_a^2\le0$ on 14 of 15 labels (3 null): a positive weight of this kind needs all squares $+1$.
- **The squares destroy the integer grading** (bd·mjp·37). The popcount is additive on every non-zero product only for $\varepsilon=0$. For $\varepsilon\in\{\pm1\}^n$ the $4^n-3^n$ overlapping products (1, 7, 37, 175) break it, and only the parity survives.
- **The Witt pairs** (bd·mjp·3). $a_i^\pm=(g_i\pm g_{n+i})/2$ satisfy the CAR inside the 256-dimensional bit-rule $Cl(4,4)$. The ideal $Cl(n,n)P_0$ has dimension $2^n$, and $a_i^+$ acts on it exactly as Jordan–Wigner $c_i^+$.

Lens rows:
- `sol`: "T-even/T-odd Majoranas: Hermitian iff $Q=0$, odd iff $\pi=1$". Exact; checked; bd·sol·1 (D04).
- `sol`: "Witt pairs → creation and annihilation; particle number needs the pairing". Exact; checked; bd·mjp·3, bd·mjp·11.
- `fld`: "gamma matrices of a metric; positive weight needs Euclidean squares". Exact; checked; D02, bd·mjp·13.
- `str`: "the square condition (4.1) of the $V_{\mathbb Z^n}$ cocycle, $\varepsilon(\alpha,\alpha)=(-1)^{k(k+1)/2}$". It holds exactly for all squares $-1$, Cl(0,n), and fails on the 16 odd labels at $n=5$ for all squares $+1$ (bd·mjp·29). Partial; checked.
- `str`, no counterpart: Hull's signature lists (bd·str·7), the Majorana–Weyl table (bd·str·6) and the worldsheet algebra $\mathrm{Witt}\otimes A_\varepsilon$ (bd·str·14). The reason: the paper's cells have $n\le3$ and no indefinite signature, so none of these statements has an object to apply to.

**U7, the clock $w=\pi+2Q$ (primary rung, Atlas only).** The paper has no counterpart.

Computed:
- **$w$ is a $\mathbb Z_4$-valued charge** (bd·mjp·31). For every $\varepsilon\in\{\pm1\}^n$ ($n\le6$), $w(a)=\sum_{i\in a}\varepsilon_i\bmod4$. So $w(a\oplus b)=w(a)+w(b)$ on every disjoint pair, which is the paper's (9) mod 4, while $Q$ fails on 376 such pairs by the twist $\pi(a)\pi(b)$.
- The Gauss sum is $\sum_ai^{w(a)}=\prod_i(1+i^{\varepsilon_i})$, for every $\varepsilon\in\{+1,-1,0\}^n$, with $w_D$ when there are null bits. This is the out-sum of bd·mjp·22 at $S=\varnothing$ with fugacity $e^{-\beta}=i$. **The clock is the phase of the grand partition function of the modes with charges $\varepsilon_i$ at fugacity $i$**, and a null generator is a zero mode: a factor 2 and no phase.
- 200 random $\mathbb Z_4$ functions are additive in 0 of 200.
- The paper's positive integer weights $q_i$, reduced mod 4, are the form $w_D$ of the bit-rule cell with $e_i^2=+1,-1,0$ for $q_i\equiv1,3,0$. When some $q_i\equiv2\bmod 4$ they are the form of no cell. The clock is $\#\{q\equiv1\}-\#\{q\equiv3\}\bmod 8$. This was checked on 884 weight vectors (bd·mjp·32).

Lens rows:
- `sol`: "Fidkowski–Kitaev index; the Gauss sum as $Z$ at fugacity $i$". Exact for the index (bd·sol·2, D08). The fugacity reading is ours, the identity checked (bd·mjp·31).
- `fld`: "Kitaev's eight real classes" (D08). Exact; standard, checked; bd·sol·2.
- `str`: "KO-degree (ABS), Arf–Brown of a Pin⁻ surface" (D07, D08). Exact; checked; bd·str·1, bd·str·2. The paper's two clocks sit at $KO^{-6}(\mathrm{pt})=KO^{-5}(\mathrm{pt})=0$ (info bd·mjp·i1, a read-off).

**What each rung forces.**
- U1 makes U2 meaningful. The order of U3 is definable from U1 ($S\le T$ iff $S\oplus c=T$; bd·mjp·36).
- U4 is a free choice: the Atlas has no rung for it.
- U5 is forced by nothing in the paper. The paper's $\oplus$ is commutative (M10), so its algebra is the zeon algebra; the wedge (M16) adds the sign by hand.
- U6 forces the loss of the integer grading (bd·mjp·37). It also needs the pairing to recover particle number (bd·mjp·11).
- U7 needs the squares to be read mod 4 (bd·mjp·31, bd·mjp·32).

## 4. The ladder down

My reading of D1, stated so that it can be checked: "forget the pairing of $w$" means forgetting both (a) the null part $N$ of the quadruple and (b) the Witt pairing. The Witt pairing is the choice of which generator of square $+1$ is paired with which of square $-1$ to form creation and annihilation operators, and with it the vacuum. The `needs_inputs` entry of the orthoplex tab says the same: "The Fock reading pairs the 2n null vectors and picks a vacuum: a Witt split, not given by the labels". What is kept is the triple $(V,Q,\pi)$.

| rung | quantity | n=0 | 1 | 2 | 3 | 4 | check |
|---|---|---|---|---|---|---|---|
| D0 | cells $Cl(p,q,r)$ = classes of $(n,r,p-q \bmod 8)$ | 1 | 3 | 6 | 10 | 15 | bd·mjp·35 (n ≤ 3), D13 |
| D0 | Witt pairings of $Cl(n,n)$ from fixed generators, $n!\,2^n$ = distinct number operators | 1 | 2 | 8 | 48 | – | bd·mjp·11 (n = 2, 3) |
| D1 | isometry classes of $(V,Q,\pi)$ | 1 | 2 | 4 | 8 | – | bd·mjp·35 |
| D1 | parity operators up to sign | 1 | 1 | 1 | 1 | – | bd·mjp·11 |
| D2 | $\Lambda(\mathbb R^n)=Cl(0,0,n)$: one algebra, dimension $2^n$, $\mathbb Z$-graded | 1 | 2 | 4 | 8 | 16 | bd·mjp·37 |
| D3 | zeon algebra (sign forgotten), commutative, dimension $2^n$ | 1 | 2 | 4 | 8 | 16 | bd·mjp·34 |
| D3 | partial sums with the same form $w$ (frames up to $S_p\times S_q$), $n=4$: Cl(1,3), Cl(2,2), Cl(3,1) | – | 1 | 1 | 1 | 2 | bd·mjp·38 |
| D4 | arrows / composable pairs of the poset | 1/1 | 3/4 | 9/16 | 27/64 | 81/256 | bd·mjp·33 |
| D5 | points | 1 | 2 | 4 | 8 | 16 | bd·mjp·33 |

**D0, the full cell with the clock and the null part (primary rung).** The Atlas's $Cl(p,q,r)$ with the quadruple $(V,Q,\pi,N)$, the form $w_D$ and its clock, which is the clock of the quotient $Cl(p,q)$ and of the mother cell $Cl(p+r,q+r)$ (bd·cat·3, bd·cat·4, bd·sol·12). In the solid-state lens, D0 is a Fidkowski–Kitaev edge with T and P (bd·sol·2) plus zero modes. A null generator contributes a factor 2 to the Gauss product and no phase (bd·mjp·31). In the *-closure (bd·sol·12) it is a creation operator whose partner has been cut off.
- Paper items present: M9 (the auxiliary zero $0=\|0\|e_3$ off the plane, read as a null direction gives Cl(2,0,1), clock 2) and M18 (Cl(3,0), clock 3).
- Atlas statements that live here: D05–D10, D13, D17, D33, T17 (the translation kind), bd·mjp·26.
- `fld`: the null rotation $1+\frac v2e_0e_1$ of Cl(2,0,1) acts on vectors as the Carroll boost $t\mapsto t+vx$ and on bivectors (points, by the complement duality) as the Galilei boost $x\mapsto x-vt$. The two matrices are inverse transposes. The bivectors $e_{12},e_{01},e_{02}$ have the brackets of the homogeneous Galilei algebra of the plane ($J=e_{12}/2$, $K_i=e_0e_i$, $K_i^2=0$). Exact at $v=1/3,2,-5/7$ (bd·mjp·26).
- Only Galilei keeps a linear weight: the boost-invariant covectors of rotations and boosts on $\mathbb R^{1+d}$ ($d=2,3$) number 1 for Galilei ($dt$), 0 for Lorentz and 0 for Carroll, and the invariant vectors 0, 0, 1 ($\partial_t$) (bd·mjp·25).
- **Reading (ours):** an absolute time is the null generator read as a covector (the plane-based reading), and the paper's "frozen time" is the null direction of the Carroll-dual picture.
- Lens rows:
  - `sol`: "FK edge with zero modes; creation operator without its partner". Exact; checked; bd·sol·2, bd·sol·12, bd·mjp·31.
  - `fld`: "Carroll kernel on vectors, Galilean clock form on covectors". Exact for the matrices (checked, bd·mjp·26); the time reading is ours.
  - `str`: "Grassmann directions; the superpoint $\mathbb R^{0|r}$" (D17). Exact; checked; bd·str·23.

**D1, forget the pairing, keep $(V,Q,\pi)$ (primary rung).** What is lost is computed.
- (a) **The null part.** For $n=1,2,3$ the triples fall into 2, 4, 8 isometry classes against 3, 6, 10 cells. Cl(1,0) and Cl(0,0,1) share a triple (bd·mjp·35, bd·cat·1): a Majorana ($\gamma^2=1$) and a creation operator ($c^{+2}=0$) have the same $Q$ and $\pi$.
- (b) **The particle number.** From the same orthonormal generators of the bit-rule $Cl(n,n)$, the $n!\,2^n$ Witt pairings give $n!\,2^n$ distinct number operators $N$ (8 at $n=2$, 48 at $n=3$) and one parity operator up to sign, $\pm g_1\cdots g_{2n}$ (bd·mjp·11). **$(V,Q,\pi)$ fixes the fermion parity, not the particle number.** A particle–hole relabelling of one mode is invisible at D1 and changes $N$.
- (c) For $r=0$ the clock is still a function of the isometry class of the triple (D11, bd·mat·5), so what is lost is not the clock's value but its physical carrier: the vacuum and the pairing.
- Paper items: the relations M15–M18 (squares and anticommutation) live here; Corollary 1 is a triple statement.
- Lens rows:
  - `sol`: "Majoranas with T: Hermiticity and parity, no vacuum". Exact; checked; bd·sol·1, bd·mjp·11.
  - `fld`: "gamma matrices without a chosen spinor vacuum". Exact; checked; D02, bd·mjp·11.
  - `str`: "worldsheet spin structure as a $\mathbb Z_4$ refinement" (bd·str·1, D05; for $r=0$ the triple fixes it). Exact; checked; bd·str·1.

**D2, forget $Q$: the exterior algebra $\Lambda(\mathbb R^n)=Cl(0,0,n)$.**
- Lost: every square (all $3^n$ choices of $\varepsilon$ collapse to one algebra) and the clock (the Gauss sum of $w_D$ is $2^n$, phase 0).
- **Gained:** the popcount becomes an algebra grading. It is additive on every non-zero product exactly when $\varepsilon=0$ (bd·mjp·37).
- Paper items: M16 (the wedge), M12 ("no inverse"), and the creation-only category of U3. The products of creation operators are the exterior algebra in the Jordan–Wigner basis (bd·mjp·1, bd·mjp·2).
- Lens rows:
  - `sol`: "the algebra of creation operators". Exact; checked; bd·mjp·1, bd·mjp·2.
  - `fld`: "Grassmann (fermionic) creation part". Exact; standard.
  - `str`: "superpoint $\mathbb R^{0|n}$" (D17). Exact; checked; bd·str·23.

**D3, forget the sign, keep $\oplus$ on disjoint labels and the weight.**
- Computed: the zeon (hard-core boson) algebra, commutative, of dimension $2^n$, with $\sigma_i^+$ in place of $c_i^+$ (bd·mjp·34).
- Lost: the anticommutation (the commutator space drops from $2^{n-1}-1$ to 0) and the Jordan–Wigner string.
- **Needed: a frame.** The partial sum is a property of the label basis. The automorphisms of $(\text{labels},\oplus)$ are exactly the $n!$ permutations of the generators (brute force, $n\le3$; bd·mjp·38). The isometry group $O(V,w)$ is $p!\,q!$ times the number of partial sums compatible with the same form $w$: 1 for every cell with $n\le3$ and for Cl(4,0) and Cl(0,4), and 2 for Cl(1,3), Cl(2,2) and Cl(3,1) ($|O|=12, 8, 12$).
- Paper items: M10 and M13. The paper's $\oplus$ is commutative, so **the algebra of the paper's partial sum on the labels is the zeon algebra**, and (9) lives here.
- Lens rows:
  - `sol`: "hard-core bosons; $\sigma^+$ without a string". Exact; checked; bd·mjp·34.
  - `fld`: "classical occupation numbers". Exact; ours.
  - `str`: no counterpart.

**D4, forget the partial sum, keep the order.**
- The poset $B_n$: $3^n$ arrows, $4^n$ composable pairs.
- Lost: the label $T\setminus S$ of an arrow as something that can be added elsewhere. Translation-invariant weights (charges, dimension $n$) become potentials (dimension $2^n-1$) (bd·mjp·10). For the Boolean lattice the partial sum can be rebuilt (the join of two elements whose meet is 0), but for random posets it cannot: pairs have a limit in only 56% of cases (bd·mjp·16).
- Paper items: M1, M2, M14, the table rows on limits (§7 B1, B2), and Example 1 (bd·mjp·14, bd·mjp·15).
- Lens rows:
  - `sol`: "configuration poset, mode-wise occupation order". Exact; checked; bd·mjp·12.
  - `fld`: "causal order (the speed-1 cone of U4)". Partial; checked (the cone) / ours; bd·mjp·27.
  - `str`: no counterpart.

**D5, forget the order: $2^n$ points.** Everything is lost; this is the same object as U0.

## 5. Where they meet

**U2 = D3, computed.** Two constructions of the partial monoid with its weight are compared.
- Upward: take $\mathbb F_2^n$, the partial sum on disjoint labels and the popcount.
- Downward: take the bit rule of any cell, keep only the products of disjoint labels (forget $Q$), then drop the sign.

They give the same table for all 364 choices $\varepsilon\in\{+1,-1,0\}^n$, $n=0..5$, and the sign on disjoint pairs never depends on $\varepsilon$ (bd·mjp·36). The order defined by the partial sum ($S\le T$ iff $S\oplus c=T$ for some $c$) is inclusion. So the two orders of entering the structure give the same object at every $n$ computed. **The proviso is the frame.**

**What is the same and what differs.**
1. **The frame.** The up ladder starts from the labels as a basis, so the frame is there from U0. The down ladder is frame-free at D0, D1 and D2: cells up to isomorphism, $\Lambda(\mathbb R^n)$ up to $GL_n$. It must choose a frame to reach D3, because the partial sum is frame data. The automorphisms of $(\text{labels},\oplus)$ are only the $n!$ generator permutations, while the isometries of $(V,w)$ can be more: for Cl(1,3), Cl(2,2) and Cl(3,1) two partial sums carry the same form $w$ (bd·mjp·38). This is the `chart`/frame input of the Atlas (the frame is gauge under Pin; bd·tor·6; bd·phy·4: "the frame is data beyond the triple").
2. **The integer weight.**
   - Up, the integer weight enters at U2, before the squares.
   - Down, it is an algebra grading only at D2 and D3. The popcount is additive on all non-zero products exactly for $\varepsilon=0$ (bd·mjp·37).
   - At D0 it exists only through a Witt pairing, and the choice matters: $n!\,2^n$ pairings give $n!\,2^n$ number operators (bd·mjp·11). At D1 only its parity survives.
   - **So the up ladder's U2 has no rung in the down ladder between D0 and D2.** This is a discovery (§9 X3): entering the squares (U6) demotes the weight from a grading to a filtration plus a parity, and a Witt pairing promotes it back.
3. **Positions.** U4 (positions $P$ and the planar vectors $D(f)$) has no rung in the down ladder. The Atlas carries no positions of labels. The nearest object is the label vectors $\alpha_a\in\{0,1\}^n$ of bd·mjp·13, which live in $\mathbb R^n$, not in a plane. The paper's plane $Z_0$ makes the inner product (10) rank 2 for every category (bd·mjp·30).
4. **The clock.** U7 and D0 agree: the clock is the Brown invariant of $w$, or of $w_D$ with null bits. The charge reading adds that $w$ (for $r=0$) and $w_D$ (for $r\ge1$) are additive on the partial sum. The form $\pi+2Q$ on all of $V$ is not additive when null bits are present (87 of 90 cells; bd·mjp·31). The paper's partial sum therefore singles out the same form ($w_D$) that the Atlas chose for the null part, for an independent reason: zero modes carry charge 0.
5. **The order of entry.** Up enters the order (U3) after the weight. Down keeps the order (D4) after dropping the partial sum. Since the order of $B_n$ determines the partial sum (join of elements with meet 0), U1 and U3 carry the same information on the labels. On noise they do not: only 56% of the pairs of a random 8-element poset have a meet (bd·mjp·16).

## 6. Controls

| control (seed) | statement tested | result | verdict |
|---|---|---|---|
| 200 random edge-sign tables, $n=3,4$ (6) | the algebra of creation operators and number projectors has dimension $3^n$ | 200/200, 200/200 | **generic**: the Borel algebra is sign-blind |
| 200 random edge-sign tables (7) | the creation operators anticommute | 8/200 ($n=3$), 0/200 ($n=4$), exactly the tables with all fluxes $-1$; the bit rule has all fluxes $-1$ for $n=2..6$ | **finding**: the bit-rule sign is the flux $-1$ class |
| 60 random mode orderings (8) | JW in another order is the bit rule up to a diagonal gauge | 60/60 | the ordering is gauge (what is gauge: the vertex signs $g(S)$; what is data: the face fluxes) |
| 200 random functions on labels (9) | additive on the partial sum | 0/200 | **finding**: additive = charge vector |
| 200 random posets of 8 and 16 elements (10) | additive weights = potentials | 146/200; dimension = elements − components + $b_1$ in 200/200 | the vacuum (a minimum) makes every additive weight an energy difference on $B_n$: **finding** for the labels; the cocycle count is generic |
| 200 random posets of 8 (16) | every pair has a limit | 3115/5600 pairs (56%) | **finding**: $B_n$ has all limits |
| 200 random posets of 8 (18) | limit ⟹ unique least-weight cone | 2928/2928 | **generic** (a theorem: every cone factors through the limit); converse fails on 80 pairs |
| 20 random potentials on $B_n$ (19) | all maximal paths have the same weight | 20/20 | **generic** for thin categories (not about the labels) |
| generic edge weights on the free Hasse category (20) | tropical limit, unique minimiser | $n=3..6$ all | **generic** (shortest paths in a DAG) |
| 200 random sign tables, $n=2,3,4$ (21) | the sum over maximal chains is 0 | 90, 46, 63 of 200 | the bit rule gives 0 for every $n$, and so does every all-flux-$(-1)$ table; random tables only sometimes |
| 200 random interacting energies (22) | the out-sum factorises as $\prod(1+e^{-\beta q_i})$ | 0/200 (fails 200/200) | **finding**: factorisation = charges (free) |
| 200 random timelike pairs in Cl(1,3), Cl(3,1) (23) | proper time additive | 0/200; super-additive 200/200 | **generic** (reverse Cauchy–Schwarz): no additive Lorentzian interval |
| 200 random weighted $B_3$ with positions (27) | speed-1 cone kept by composition; Galilei boost keeps it | 200/200; 0/200 | the first is generic (a convex cone); the second is a finding about the pair (dt, cone) |
| random Gram matrices, A_n roots, random $\mathbb Z^4$ vectors (28) | conformal weight additive on disjoint labels | iff the Gram is diagonal (200/200); A_n fails on 2, 10, 40, 144, 490 pairs; fusion additive only on the 27 orthogonal pairs | **finding**: the $\mathbb Z^n$ lattice (orthonormal frame) |
| 200 random sign tables (29) | bimultiplicative | 0/200 | **finding** (the bit rule is a bicharacter) |
| 200 random categories, positions, weights (30) | Gram of (10) is $(2,0)$ | 200/200 | **generic by construction**: the paper's data determine nothing of the clock |
| 200 random $\mathbb Z_4$ functions (31) | additive on the partial sum | 0/200 | **finding**: $w$ is a $\mathbb Z_4$ charge |
| 884 integer weight vectors (32) | mod 4 = the form of a cell iff no $q_i\equiv2$ | 884/884 | reading of the paper's weights (ours) |

**Generic statements (not findings):**
- the Borel dimension $3^n$ under any signs;
- limit ⟹ least cone;
- path-independence of additive weights on thin categories;
- the tropical limit;
- super-additivity of proper time;
- the convexity of the speed-1 cone;
- the Gram signature $(2,0)$ of (10);
- the counts $2^n$, $3^n$, $4^n$, $(k+2)^n$ (these are properties of $B_n$ as a product of $n$ two-element chains).

**Findings (hold for the labels, fail for the controls):**
- the flux $-1$ class of the sign;
- additive label weights are charges, and additive arrow weights are energy differences because of the vacuum;
- every diagram has a limit;
- factorisation of the out-sum for charges;
- additivity of the conformal weight on disjoint labels for the orthonormal lattice;
- bimultiplicativity;
- $w$ as a $\mathbb Z_4$ charge (and $w_D$ rather than $w$ with null bits);
- the frame count of bd·mjp·38.

## 7. Breaks and patches

Every row is decided by a computation of this lane. "Printed" quotes the paper as it stands in `paper.txt`. None of these says the paper is wrong as a whole. Each names the reading in which the printed sentence holds.

| B | ids | what the paper says (verbatim) | what the computation gives | reading(s) in which the printed statement holds, with the input | kind | natural patch (exact wording) |
|---|---|---|---|---|---|---|
| B1 | bd·mjp·16, bd·mjp·18, bd·mjp·19 | Table (2.53): "Principle of minimal action \| Property that for each cone of a diagram d′ in CJ there is a unique arrow to the limit cone" | With any positive additive weight, a limit cone is the unique cone of least total leg weight $\sum_j w(c\to d_j)$ (25100/25100 diagrams of $B_n$; 2928/2928 pairs with a limit in random posets). The converse fails: the bowtie $c_1,c_2<a,b$ has no limit of $\{a,b\}$ and a unique least cone ($c_2$, weight 2 against 4), and 80 such pairs occur in random posets. On thin categories every path has the same weight, so a principle of least weight selects no path (bd·mjp·19). | One direction: "limit ⟹ least action", for the action = total leg weight and any weight that is positive and additive (input: the weight). The equivalence holds in lattices (such as $B_n$), where every diagram has a limit. | DICTIONARY | "For every positive additive weight, the limit cone of a diagram, when it exists, is the unique cone of least total leg weight; a cone of least weight need not be a limit." |
| B2 | bd·mjp·17 | "Lagrangian density L(Ψ, pi) \| Universal arrow (△(pi), η(pi)) at a point pi"; "this 3D space curvature changes the point positions of the objects, that is, changes the mapping P" | In $B_n$ every discrete diagram has a limit (the AND) and $\Delta\dashv\wedge$ holds on all 74584 hom pairs ($n\le4$), but the unit $\eta_c:c\to\wedge(c,\dots,c)=c$ is the identity at every object. The displacement $D(\eta_c)=P(\lim\Delta c)-P(c)$ is 0 for every position map. The adjunction is present and moves nothing. | In a category where $\lim\Delta c=c^J\ne c$ (a product of an object with itself that is not the object, e.g. finite sets), the unit is the diagonal, a non-identity arrow, and can carry a displacement. Input: a category that is not a preorder. | SCOPE | "In a preorder the unit of Δ ⊣ lim is the identity, so the adjunction displaces no object; the displacement of P by an adjunction needs a category in which c ≠ c^J." |
| B3 | bd·mjp·23, bd·mjp·25, bd·mjp·27 | "‖f‖ equal to the time necessary to cross its path by recommended speed v0"; (9) "‖f ⊕ g‖ ≡ ‖f‖ + ‖g‖"; "this 3D A-space is a curved GR space"; "it is absolute time and space as conceived by […] Newton that provides their domain of definition" | An additive weight is not a Lorentzian interval: $g_0$ and $\frac54g_0+\frac34g_1$ have proper time 1 each, and their sum has $\tau^2=9/2>4$. Proper time is strictly super-additive on 200/200 random timelike pairs, and the squared interval is additive on none. The time component (coordinate time) is additive on 200/200. Among rotations with boosts, only Galilei keeps a linear form ($dt$; Lorentz and Carroll keep none). | The printed choice of Galilean boosts and absolute time is the reading in which (9) holds for a time. Input: absolute time. The phrase "curved GR space" holds for the 3-space at a fixed time only (the paper's "time is frozen"), not for a Lorentzian space-time. | SCOPE | "The weight is an absolute (Galilean) time: additive along paths and kept by Galilean boosts; a Lorentzian proper time is super-additive and is not a weight in the sense of (9)." |
| B4 | bd·mjp·14, bd·mjp·15 | Example 1: "each bridge is an object of category C and the paths between them are represented by the morphisms … (Euler demonstrated that at least for one bridge we have by this path pass two times)" | With bridges as objects and a morphism whenever two bridges share a land mass, a path through all seven bridges once exists (a Hamiltonian path of the line graph). With oriented crossings as objects (the next bridge leaves from the side where the last one arrived) none exists, and the shortest covering path has 8 crossings. In the standard graph (land masses as objects, bridges as arrows; degrees 5, 3, 3, 3) no walk crosses each bridge once, and the shortest covering walk has 8 crossings: exactly one bridge twice. | The parenthesis holds when the objects are the land masses or the oriented crossings. Input: the side of each crossing. | DICTIONARY | "…where each crossing of a bridge, with its direction, is an object (or each land mass is an object and each bridge an arrow); then every path that crosses all seven bridges crosses one of them twice, and the shortest such path has eight crossings." |
| B5 | bd·mjp·13 | (9) "‖f ⊕ g‖ ≡ ‖f‖ + ‖g‖" and (13) "f² = ff = f · f = ‖f‖² ≥ 0" | Read on the labels with vectors $\alpha_a=\sum_{i\in a}e_i$ in Cl(n,0): disjoint labels are orthogonal and anticommute, as in Corollary 1. (9) holds with $\|a\|=\alpha_a^2$ (602/602 pairs at $n=6$) and then (13) fails for every $\lvert a\rvert\ge2$. With $\|a\|=\lvert\alpha_a\rvert$, (13) holds on all labels and (9) fails on every disjoint pair of non-zero labels. | Both hold when $\|f\|$ is an independent weight and $f\cdot f$ is defined by (10) with $\theta=0$, not as the square of a Clifford vector. They also both hold when every arrow has weight 0 or 1 (single generators). Input: which product (13) refers to. | DICTIONARY | "(9) is a statement about the weight; (13) defines f·f from the weight by (10); f² in (13) is not the Clifford square of the planar vector of f." |
| B6 | bd·mjp·25, bd·mjp·26; [14] read | "another transformation from one to another reference frame with the constant velocity v between them ("Galilean boosts")" | In [14] (read through extracts) the levels $C_n$ are "Galilean reference frames" and comma-propagation is the "Galilean boost". In the Atlas a Galilei boost is the linear map $x\mapsto x+vt$, the null rotation of $Cl(d,0,1)$ acting on points (the inverse transpose of the Carroll boost on vectors). | Both, as long as the word is kept per paper. Input: which of the two is meant in (2.53). | DICTIONARY | "Galilean boost (in the sense of [14]: the comma-propagation C_n → C_n ↓ C_n)" or "(in the sense of R^{1+2}: x ↦ x + vt)". |
| B7 | bd·mjp·30, bd·mjp·31 | Corollary 1: "For each base vector ei ∈ V for 1 ≤ i ≤ 3, e²i = 1"; Def. 2 (2): "auxiliary zero vector in V, denoted by 0 = ‖0‖e3 … with ‖0‖ = 0" | Two cells, two clocks: with $e_3^2=1$ (Corollary 1) the algebra is Cl(3,0) (clock 3); reading the auxiliary direction as null gives Cl(2,0,1) (clock 2 = that of Cl(2,0)). The data (positions, weights, (10)) give Cl(2,0) for every category. | Cl(3,0) when $e_3$ is a unit vector; Cl(2,0,1) when the direction of the auxiliary zero is null. Input: $e_3^2\in\{1,0\}$. | GAP | "e₃ is a unit vector orthogonal to Z₀ (e₃² = 1) and is the vector of no morphism; the zero vector is 0·e₃." |

## 8. Places in the Atlas

All statements below are about the Atlas's structures, not about the paper. **No new step is proposed.** The occupation-number reading belongs to T20 and the category lens, and the charge reading of $w$ to the conventions page. None of them changes the story's order.

| where | wording (Atlas form) | flag | check id | new step? |
|---|---|---|---|---|
| Category lens (step 18), after the cat·K1a paragraph on the cube category | Read as occupation patterns, the labels make the cube category a category of creation processes. The arrow S → T is the matrix unit \|T⟩⟨S\| = s(T∖S, S) C⁺_{T∖S} P_S, composition is the matrix product, and the weight \|T∖S\| is the change of the number operator: [N, A] = \|T∖S\| A. Creation operators and number projectors generate exactly these 3ⁿ matrix units, the upper triangular part of End Λ(ℝⁿ) = Cl(n,n); with the annihilation operators the algebra is all 4ⁿ. | standard, checked | bd·mjp·4, bd·mjp·5 | no |
| Same paragraph (gauge and data) | The upper triangular algebra does not see the signs: any signs on the edges give the same 3ⁿ-dimensional algebra (200 random tables). The creation operators see them: they anticommute exactly when every square face has flux −1, and a change of the order of the modes changes the signs by a coboundary only. | checked | bd·mjp·6, bd·mjp·7, bd·mjp·8 | no |
| T20, remark (c) | The number operator needs the Witt pairing. From the same generators of the bit-rule Cl(n,n), the n!·2ⁿ pairings give n!·2ⁿ different number operators and one parity operator up to sign (± the top blade). The popcount is an algebra grading only when every square is 0 (Λ(ℝⁿ)); with squares ±1 the 4ⁿ − 3ⁿ products of overlapping labels break it, and only the parity π remains. | checked | bd·mjp·11, bd·mjp·37 | no |
| Labels page / glossary "weight" | A weight on the labels that adds on disjoint labels is a charge vector, h(a) = Σ_{i∈a} q_i: a space of dimension n, the one-body (free) energies; an interaction U nᵢnⱼ is exactly the defect of this additivity. A weight on the arrows of the cube category that adds under composition is an energy difference E(T) − E(S), a space of dimension 2ⁿ − 1, because the cube has a minimum (the vacuum). | checked | bd·mjp·9, bd·mjp·10 | no |
| Conventions page (step 1, the clock), after core·B1 | For squares ±1 the form is w(a) = Σ_{i∈a} εᵢ mod 4, so w adds on disjoint labels (Q does not; it fails by π(a)π(b)). The Gauss sum factorises as Πᵢ (1 + i^{εᵢ}), and a null generator gives the factor 2 and no phase: the Gauss sum 2^r (1+i)^p (1−i)^q of w_D. The form π + 2Q on all of V gives a null generator the charge 1 and does not add on disjoint labels (87 of the 90 cells with r ≥ 1, n ≤ 4). | checked | bd·mjp·31 | no |
| Same place, a second line | Read as the grand partition function of n modes with charges εᵢ at fugacity i, the Gauss sum is Z and the clock is its phase; null generators are zero modes. | ours | bd·mjp·31, bd·mjp·22 | no |
| Null-surfaces page (step 13), with T17 (translation kind) | In Cl(d,0,1) the null rotation 1 + (v/2) e₀e₁ is a Carroll boost t ↦ t + vx on vectors and a Galilei boost x ↦ x − vt on points (the bivectors, by the complement); the two matrices are inverse transposes. The bivectors e₁₂, e₀₁, e₀₂ have the brackets of the homogeneous Galilei algebra of the plane. Among rotations with boosts on ℝ^{1+d}, only the Galilean ones keep a linear form (dt); Lorentz and Carroll keep none. | checked | bd·mjp·25, bd·mjp·26 | no |
| Same place, a second line | An absolute time is the null generator read as a covector: the clock form of the Galilean structure is the null vector of the plane-based reading, and its Carroll dual is the null direction of the vector reading. | ours | bd·mjp·26 | no |
| Equations tally / needs_inputs (kinds `time`, `action`) | A proper time is not an additive weight: g₀ and (5/4)g₀ + (3/4)g₁ have proper time 1 each and their sum has proper time (9/2)^{1/2} > 2. Along future-timelike chains the proper time is super-additive and the time component is additive. | checked | bd·mjp·23, bd·mjp·24 | no |
| Category lens (step 18), limits | In the label category every finite discrete diagram has a limit (the AND) and a colimit (the OR), and Δ ⊣ ∧ with the identity as unit. For any positive additive weight the limit cone is the unique cone of least total leg weight. The converse fails: a bowtie poset has a least cone and no limit. | checked | bd·mjp·16, bd·mjp·17, bd·mjp·18 | no |
| Lens dictionary D03 (str and sol terms) | The bit-rule sign is a bimultiplicative cocycle on the labels with commutator (−1)^{α·β+α²β²}: the condition (4.2) of the lattice vertex superalgebra V_{ℤⁿ} (Bakalov–Kac). With all squares −1 it also satisfies the square condition (4.1). | standard, checked | bd·mjp·29 | no |
| Shapes or labels page, frame (with bd·phy·4) | The partial sum of disjoint labels is frame data. Its automorphisms are the n! permutations of the generators, while the isometries of (V, w) can be more: one partial sum per form w (up to S_p × S_q) for every cell with n ≤ 3, two for Cl(1,3), Cl(2,2) and Cl(3,1). | checked | bd·mjp·38 | no |

**Dictionary rows (proposed, JSON form of `pack/lens_dictionary.json`).** Existing rows are touched as follows:
- **D38 (labels as Fock space): confirmed**, with a `sol` term proposed ("creation category; Borel part of the CAR algebra"; checks bd·mjp·4, bd·mjp·5).
- **D03 (sign up to gauge): changed**, with `sol` and `str` terms (MJ06).
- **D17 (null generator): confirmed** for `sol`, by the zero-mode factor 2 (bd·mjp·31).
- **D08 (clock as a physical ℤ₈): confirmed.**
- **D34 (squares −1/0/+1): unchanged.**

```json
[
 {"id": "MJ01", "atlas": "arrow S → T of the label category", "where": ["T20", "cat·K1a", "D43"],
  "terms": {"sol": "creation process; the matrix unit |T⟩⟨S| = s(T∖S,S) C⁺_{T∖S} P_S", "fld": "fermionic creation amplitude; weight = particle-number change"},
  "match": "exact", "flags": ["standard", "checked"], "checks": ["bd·mjp·1", "bd·mjp·2", "bd·mjp·5"]},
 {"id": "MJ02", "atlas": "category algebra of B_n (3ⁿ)", "where": ["T8", "T20", "D43"],
  "terms": {"sol": "Borel part of the CAR algebra; creation operators and number projectors", "fld": "upper triangular part of End Λ(ℝⁿ) = Cl(n,n)"},
  "match": "exact", "flags": ["checked"], "checks": ["bd·mjp·4", "bd·mjp·6", "bd·mjp·12"]},
 {"id": "MJ03", "atlas": "partial sum a ⊕ b (a ∧ b = 0)", "where": ["S1", "D38"],
  "terms": {"sol": "Pauli exclusion; C⁺_a C⁺_b = 0 iff a ∧ b ≠ 0", "str": "OPE of distinct free fermions; no contraction iff disjoint"},
  "match": "exact", "flags": ["checked"], "checks": ["bd·mjp·2", "bd·mjp·28", "bd·mjp·33"]},
 {"id": "MJ04", "atlas": "weight additive on ⊕ of labels", "where": ["core·B1", "D04"],
  "terms": {"sol": "one-body charge Σ qᵢnᵢ; free energies, an interaction is the defect", "fld": "U(1) charge; particle number", "str": "conformal weight |α|²/2 of ℤⁿ vertex operators on 0/1 vectors"},
  "match": "exact", "flags": ["checked"], "checks": ["bd·mjp·9", "bd·mjp·28"]},
 {"id": "MJ05", "atlas": "weight additive on composition in B_n", "where": ["T8"],
  "terms": {"sol": "energy difference E(T) − E(S); interactions allowed", "fld": "potential; the vacuum as minimum"},
  "match": "exact", "flags": ["checked"], "checks": ["bd·mjp·10"], "scope": "posets with b₁ = 0"},
 {"id": "MJ06", "atlas": "sign up to gauge (D03): flux −1 on every face", "where": ["T6", "cat·K1a", "cat·K1b"],
  "terms": {"sol": "Jordan–Wigner string; the mode order is a gauge, the face flux π is the data", "str": "cocycle of V_{ℤⁿ}; (4.2) for every ε, (4.1) for squares −1"},
  "match": "exact", "flags": ["standard", "checked"], "checks": ["bd·mjp·7", "bd·mjp·8", "bd·mjp·29"]},
 {"id": "MJ07", "atlas": "form w as a ℤ₄ charge", "where": ["core·B1", "core·B3", "D05", "D10"],
  "terms": {"sol": "w(a) = Σ εᵢ mod 4; Gauss sum = Πᵢ(1 + i^{εᵢ}), the grand partition function at fugacity i; null bits are zero modes", "str": "Brown phase of ℤⁿ/2ℤⁿ (bd·str·16) as a product of one-mode factors"},
  "match": "exact", "flags": ["checked", "ours"], "checks": ["bd·mjp·31", "bd·mjp·32"]},
 {"id": "MJ08", "atlas": "a time as a weight on arrows", "where": ["needs_inputs: time, action"],
  "terms": {"fld": "absolute (Galilean) time dt; proper time is super-additive, no Lorentz-invariant linear weight"},
  "match": "partial", "flags": ["checked", "input"], "checks": ["bd·mjp·23", "bd·mjp·25"]},
 {"id": "MJ09", "atlas": "null rotation of Cl(d,0,1)", "where": ["T17", "nullsurf", "D33"],
  "terms": {"fld": "Carroll boost on vectors, Galilei boost on points (inverse transpose); homogeneous Galilei algebra of the plane"},
  "match": "exact", "flags": ["checked", "ours"], "checks": ["bd·mjp·26"]},
 {"id": "MJ10", "atlas": "limit of a discrete diagram in B_n (AND)", "where": ["lenses: category"],
  "terms": {"fld": "'least action' cone: limit ⟹ least total leg weight, not conversely"},
  "match": "partial", "flags": ["checked"], "checks": ["bd·mjp·16", "bd·mjp·18"]},
 {"id": "MJ11", "atlas": "sum over the maximal chains 0 → [n]", "where": ["T20"],
  "terms": {"sol": "fermionic amplitude Σ_σ sign(σ) = 0; hard-core bosons n!", "fld": "tropical limit = least weight; degenerate on thin categories"},
  "match": "exact", "flags": ["standard", "checked"], "checks": ["bd·mjp·19", "bd·mjp·20", "bd·mjp·21"]},
 {"id": "MJ12", "atlas": "the integer weight as a grading", "where": ["T20", "LAB-019"],
  "terms": {"sol": "particle number: conserved by creation-only algebras or after a Witt split; Majorana cells keep the parity only"},
  "match": "exact", "flags": ["checked", "input"], "checks": ["bd·mjp·11", "bd·mjp·37"], "scope": "pairing: input"}
]
```

## 9. Discoveries to explore

**X1. The clock form is a $\mathbb Z_4$-valued charge.** The relevant checks are bd·mjp·31, bd·mjp·32 and bd·mjp·22.
- *Question.* The Atlas's clock is the Brown invariant of $w=\pi+2Q$. On the labels, $w(a)=\sum_{i\in a}\varepsilon_i\bmod4$ adds on the paper's partial sum, and its Gauss sum is $\prod_i(1+i^{\varepsilon_i})$: the free-fermion grand partition function of bd·mjp·22 at fugacity $i$. Is this the right physical home of the clock? That is, is the clock the phase of a partition function that the paper's own weights (times, energies) reach by continuing $\beta$ to $-i\pi/2$?
- *Why it does not fit the paper.* The paper's scalars are positive reals, with no complex fugacity, and its weights carry no squares. Still, the residues mod 4 of positive *integer* weights give a cell exactly when no $q_i\equiv2$, with $e_i^2=+1,-1,0$ for $q_i\equiv1,3,0$ (884/884). So the sign of a square is not the sign of a weight: a weight 3 is a square $-1$.
- *Smallest decisive computation.* Three steps:
  - the stacking law: under disjoint union of mode sets, $Z$ multiplies and the clock adds. This holds by the product formula, and its check against Brauer–Wall stacking is bd·cat·12;
  - for a cell with null bits: whether the $w$ on all of $V$ or $w_D$ is additive. Done: only $w_D$ is, in 87 of 90 cells;
  - whether the frame-independence of the clock (under $O(V,w)$, which mixes labels) survives in the charge picture, which is frame data (X2).
- *Outcomes.* If the frame-changing isometries of X2 keep the charge vector's residues up to permutation, the charge reading is frame-free and can sit on the conventions page as a lemma. If not, it is a statement about the frame (as the paper's partial sum is).
- *First computation done.* bd·mjp·31 and bd·mjp·32. The second frame of Cl(1,3) (X2) carries the same residues (1; 3, 3, 3) on its generators, since it is an isometry of $w$. The algebraic statement is the D05 identity $w=x\cdot x\bmod4$; what is new is additivity on $\oplus$ and the partition-function form.

**X2. The partial sum is frame data, and two frames exist from $n=4$.** The relevant check is bd·mjp·38.
- *Question.* For Cl(1,3), Cl(2,2) and Cl(3,1), two partial sums of labels carry the same form $w$. A direct listing (an ad hoc script, not a check) gives them:
  - Cl(1,3): the generators $\{e_0;e_1,e_2,e_3\}$, or the grade-3 blades $\{e_{123};e_{023},e_{013},e_{012}\}$;
  - Cl(2,2) and Cl(3,1): the same pattern, generators against grade-3 blades.

  The second frame is the pseudoscalar twist $e_i\mapsto e_iI$. Which frame is "the" particle basis of the paper's category on these cells?
- *Why it does not fit.* The paper's sum is defined on morphisms, which form one fixed frame. The Atlas's cell is frame-free (bd·phy·4: "the frame is data beyond the triple").
- *Smallest decisive computation.* Two steps:
  - Check whether the two partial sums give isomorphic creation categories with isomorphic weight data (the charge residues). For Cl(1,3), the second frame has the $+1$ generator $e_{123}$, of grade 3.
  - Check whether a physically natural additional datum (a time orientation, or the T of bd·sol·1) prefers one frame.
- *Outcomes.* "Isomorphic with the same charges" means the frame is gauge. "Distinguished by T" means the frame is data, and the paper's category picks a Lorentzian frame.
- *First computation done.* The counts (bd·mjp·38) and the explicit frames (direct listing).

**X3. The integer weight has no rung in the down ladder above D2.** The relevant checks are bd·mjp·11 and bd·mjp·37.
- *Question.* The paper's weight is an integer grading on the labels: (9) on $\oplus$. The cells with squares $\pm1$ carry only the parity, and the integer weight comes back only through a Witt pairing, of which there are $n!\,2^n$ for fixed generators. Is the number of independent number operators that a cell $Cl(p,q)$ admits its Witt index $\min(p,q)$, and is that the place of the paper's weight in the down ladder?
- *Why it does not fit.* The up ladder enters the weight (U2) before the squares (U6). The down ladder has the weight as a grading only below D1.
- *Smallest decisive computation.* For $p+q\le6$, the maximal number of commuting operators $a_i^+a_i$ built from null pairs of $Cl(p,q)$; the expected answer is $\min(p,q)$ (standard, Witt index; pointer).
- *Outcomes.* If it is the Witt index, the paper's weight lives on the hyperbolic part $Cl(k,k)$ of a cell, and the remaining $Cl(p-k,q-k)$ (whose clock is the clock of the cell) carries no particle number. The clock and the weight then live on complementary parts of the cell.
- *First computation done.* bd·mjp·11 ($n=2,3$) and bd·mjp·37.

**X4. The paper's data as events with a speed limit.** The relevant check is bd·mjp·27.
- *Question.* Read each arrow as the event displacement $(\|f\|,D(f))$. At speed 1, $\|f\|>|D(f)|$ (footnote 7, path length over chord), and composition keeps this cone. Galilean boosts keep $\|f\|$ and break the cone; Lorentz boosts keep the cone and change $\|f\|$. The linear maps that keep both form $so(2)$. So the paper's three claims (frozen time, Galilean boosts, speed 1) leave the rotations of $Z_0$ as the only symmetry. Is the speed-1 condition meant to hold in every frame?
- *Why it does not fit.* The paper names Galilean boosts. In the Atlas the Lorentzian cone is a separate structure (step 13, T18).
- *Smallest decisive computation.* Done (dimension 1). The open part is whether a category with a coboundary weight ($t:\mathrm{Ob}\to\mathbb R$) embeds faithfully as a causal set: comparable ⟺ timelike. For $B_n$ with $t=$ popcount and $P(S)=\sum q_i$, count the incomparable pairs sent to timelike separations.
- *Outcomes.* Faithful for some $q$: $B_n$ is a causal set in $\mathbb R^{1,2}$ for small $n$. Never faithful: the order dimension $n$ of $B_n$ forbids it (pointer).
- *First computation done.* bd·mjp·27.

**X5. Three path sums.** The relevant checks are bd·mjp·19, bd·mjp·20 and bd·mjp·21.
- *Question.* The table's "action ↔ path integrals" row needs an algebra in which paths are summed. There are three readings, with three answers for $0\to[n]$:
  - in the category $B_n$ there is one arrow;
  - in the free category on the Hasse diagram there are $n!$ arrows (tropical limit, unique minimiser for generic weights);
  - in the fermionic (CAR) algebra the sum is 0 for $n\ge2$.

  Which reading does the row intend?
- *Why it does not fit.* The paper's composition is that of a category, so the first reading, in which the sum over paths is trivial.
- *Smallest decisive computation.* Done. The question goes to the author (§10, Q9).
- *Outcomes.* Category: the row is degenerate on posets. Free category: the row is the tropical semiring (shortest paths; pointer). Fermions: the sign of the Atlas makes the path sum cancel, and the row then belongs to T20.

## 10. Concrete questions for the author

Drafts for the user, without address or contact. Each can be answered in one or two sentences.

1. **Table (2.53), "Principle of minimal action ↔ unique arrow to the limit cone".** Which quantity is minimised: the total weight $\sum_j\|c\to d_j\|$ of the legs of a cone? With any positive additive weight, a limit cone is the unique cone of least leg weight. But in the poset $c_1,c_2<a,b$ the pair $\{a,b\}$ has a cone of least weight and no limit. Is the row meant as "limit ⟹ least action" only?
2. **"Lagrangian density ↔ universal arrow $(\Delta(p_i),\eta(p_i))$".** In a poset with meets, such as the subsets of a finite set under inclusion, the unit $\eta_c:c\to\lim\Delta c$ is the identity at every object. Is the Lagrangian density then zero there, although every limit exists?
3. **"this 3D space curvature changes the point positions of the objects, that is, changes the mapping P".** Is the displacement of $P(c)$ given by the planar vector of the unit, $P(\lim\Delta c)-P(c)$, or by another formula?
4. **"Galilean boosts".** In arXiv:2406.16884 the levels $C_n$ are Galilean reference frames and comma-propagation is the Galilean boost. In the present paper, is the boost the same level shift, or a linear map $x\mapsto x+vt$ of the plane $Z_0$ with $t$ the weight?
5. **Def. 2 (1), "‖f‖ equal to the time necessary to cross its path by recommended speed v0".** At speed 1 a path whose interior is off $Z_0$ has $\|f\|>|D(f)|$. Is this inequality part of the definition? (Under $x\mapsto x+vt$ some arrows leave it; under Lorentz boosts $\|f\|$ changes.)
6. **(9) "‖f ⊕ g‖ ≡ ‖f‖ + ‖g‖" with "a curved GR space".** An additive time is an absolute (coordinate) time; a Lorentzian proper time is super-additive, e.g. $1+1<\sqrt{9/2}$ for $\gamma_0$ and $\frac54\gamma_0+\frac34\gamma_1$. Is the weight meant as absolute time in every reading of the paper?
7. **Example 1, "each bridge is an object of category C".** If a morphism joins two bridges whenever they share a bank, a path through all seven bridges once exists. Should a morphism leave a bridge on the side where the previous one arrived, or are the land masses the objects?
8. **Def. 2 and (9), M11 "the total cost or total energy".** Is an energy meant to add only along composition, as energy differences do, or also over independent parts that are not composed? On the subsets of $n$ modes only the second makes it a sum of one-mode energies, with no interaction.
9. **Table (2.53), "Action ↔ set of displacements of each point (path-integrals)".** Is the path integral a weighted sum over all arrows with domain $p_i$, e.g. $\sum e^{-\beta\|f\|}$? If so, should different composites with the same endpoints count once (category) or separately (paths)?
10. **(13) "f² = ff = f · f = ‖f‖² ≥ 0".** Is $f^2$ here the square in a Clifford algebra of the planar vector $D(f)$, or the inner product (10) with $\theta=0$? On subsets read as vectors $\alpha_a=\sum_{i\in a}e_i$, the additive norm (9) is $\alpha_a^2$, and then $f^2=\|f\|$ rather than $\|f\|^2$.
11. **Corollary 1, "e²i = 1" for $i=3$, and Def. 2 (2), "0 = ‖0‖e3".** Is $e_3$ a unit vector, which gives Cl(3,0), or is the auxiliary direction meant to be null, which gives Cl(2,0,1)? The two differ in their invariants (3 against 2 in the Brown invariant).
12. **"partial covering with Clifford algebra" (the author's reply).** On the subsets of $n$ modes, the arrows $S\subseteq T$ with "no inverse, positive scalars only" span exactly the upper triangular part ($3^n$) of $Cl(n,n)=M_{2^n}(\mathbb R)$ ($4^n$), and the missing part is the reversed arrows. Is this the covering meant, or a covering of Cl(3,0)?

## 11. Code

Scripts in `mj_MP/selfcheck/bridges/`, copies with their logs (`*.log` and `*_sabotage.log`) and the run table `RUNS.txt` in `out/MP_code/`.
- Each script has the 4-line licence header of `cat_cell.py` and a docstring with one entry per id.
- Each prints one line per check, `ok   bd·mjp·n …` (or `FAIL`), and the verdict line, and exits 1 on a failure.
- With `--sabotage`, each check runs on a deliberately broken input and prints `CAUGHT`/`MISSED`.
- Standard library and numpy only (scipy and sympy are not used). Fixed seeds; no file read or written; no network; the scripts run from any folder (all runs below are from `/tmp` with `python3 -I`, one core, `OMP_NUM_THREADS=1`).

| script | ids | command | seconds (run / sabotage) | result line |
|---|---|---|---|---|
| `mjp_fock.py` | bd·mjp·1–8 | `python3 -I selfcheck/bridges/mjp_fock.py [--sabotage]` | 3.8 / 3.8 | `8/8 bridge checks hold.  ALL BRIDGE CHECKS PASS` / `ALL CAUGHT` |
| `mjp_charges.py` | bd·mjp·9–15 | same form | 0.6 / 0.5 | `7/7 …  ALL BRIDGE CHECKS PASS` / `ALL CAUGHT` |
| `mjp_action.py` | bd·mjp·16–22 | same form | 0.7 / 0.6 | `7/7 …  ALL BRIDGE CHECKS PASS` / `ALL CAUGHT` |
| `mjp_time.py` | bd·mjp·23–27 | same form | 0.3 / 0.3 | `5/5 …  ALL BRIDGE CHECKS PASS` / `ALL CAUGHT` |
| `mjp_clock.py` | bd·mjp·28–32, info bd·mjp·i1, i2 | same form | 2.3 / 2.3 | `5/5 …  ALL BRIDGE CHECKS PASS` / `ALL CAUGHT` |
| `mjp_ladder.py` | bd·mjp·33–38 | same form | 5.3 / 5.7 | `6/6 …  ALL BRIDGE CHECKS PASS` / `ALL CAUGHT` |

**Totals.** 38 checks and 2 info lines. All 38 sabotages are caught.

**Sabotages that show the machinery seeing a non-zero or non-matching answer.** Examples:
- bd·mjp·1: the Jordan–Wigner string on the modes above $i$ differs in 64 entries.
- bd·mjp·3: a wrong Witt partner gives $\{a_1,a_1^+\}=0.5$.
- bd·mjp·4: one annihilation operator gives dimension $4\cdot3^{n-1}$ (12, 36, 108, 324).
- bd·mjp·5: dropping the sign leaves 265 of 363 arrows and 1077 of 1364 compositions.
- bd·mjp·9: the sum on all pairs gives the space $\{0\}$.
- bd·mjp·14: an eighth bridge B–C makes an Euler walk exist.
- bd·mjp·21: dropping the sign gives $n!$ instead of 0.
- bd·mjp·22: counting every label gives a deviation of $2.7\cdot10^{7}$.
- bd·mjp·23: collinear pairs are additive, so super-additivity is 0/200.
- bd·mjp·26: the rotation bivector in place of the null one gives no Carroll or Galilei matrix.
- bd·mjp·30: Cl(2,1) in place of Cl(3,0) gives clock 1.
- bd·mjp·32: 429/884.
- bd·mjp·38: no cell with two frames.

**Output lines quoted in this report** (from the logs):
- `ok   bd·mjp·2  C_a^+ C_b^+ = s(a,b) C_(a xor b)^+ on 363 disjoint pairs (= sum 3^n, n = 1..5): 0 failures; C_a^+ C_b^+ = 0 on the 1001 overlapping pairs (Pauli exclusion = the undefined a + b of the paper): 0 failures; C_a^+|0> = |a>: 0 failures`
- `ok   bd·mjp·7  bit rule: flux -1 on all faces for n = 2..6 (1, 6, 24, 80, 240 faces): True; random tables (seed 7): n=3: anticommuting in k = 8/200, every face flux -1 in 8/200, the two agree on 200/200; n=4: anticommuting in k = 0/200, …`
- `ok   bd·mjp·18  B_n (n = 1..4, 5 energies each): the meet is the unique minimal-weight cone in 25100/25100 diagrams; random posets: limit = unique minimal cone in 2928/2928 pairs with a limit, 80 pairs with cones but no limit (a minimal cone exists there); bowtie: no limit, unique minimal cone c2 of weight 2 (c1: 4): True`
- `ok   bd·mjp·23  u = g0, v = (5/4)g0 + (3/4)g1: u^2 = 1, v^2 = 1, (u+v)^2 = 9/2 against (tau_u + tau_v)^2 = 4; random future-timelike pairs (seed 23): super-additive 200/200, squared interval additive 0/200, time component additive 200/200; …`
- `ok   bd·mjp·31  every eps in {+1,-1,0}^n, n <= 6: w(a) = sum eps_i mod 4 (eps non-zero) True; w (w_D with null bits) additive on disjoint pairs (n <= 4) True; Q additive there: fails on 376 pairs (the twist pi(a)pi(b)); Gauss sum = prod (1 + i^eps_i) True; with null bits, w on all of V (not w_D) is not additive on disjoint labels in 87/90 cells (n <= 4), additive only for eps = [[0], [-1, 0], [0, -1]]; random Z_4 functions additive in 0/200`
- `ok   bd·mjp·38  automorphisms of (labels, +): [1, 2, 6] = n! (n = 1..3); |O(V, w)| and the number of partial sums … Cl(1,3): 12, 2, Cl(2,2): 8, 2, Cl(3,1): 12, 2, Cl(4,0): 24, 1; cells with more than one partial sum: 3`

The clone's `README.md` and `bridges_phys.json` are not updated: the scripts are not yet part of `regen_bridges_phys.sh`, and adding the 38 rows there is a merge step.

## 12. Sources

- **Majkić, "General Categorial Geometry and Algebraic Topology"**, arXiv:2403.19689 v3: *read* (`pack/majkic/paper.txt`, every page). Quotations in §7 are verbatim from that text.
- **Majkić, "Category Theory: Symmetry Group of Comma-propagation Transformations"**, arXiv:2406.16884: *read through the fetch tool's extracts* (abstract, Definition 1, §3 and the conclusions as extracted), not the full text. The statements used are:
  - adjunctions as "scalar fields" ("adjunctions-as-fields"), with unit and counit as "forces" that displace objects;
  - the levels $C_{n+1}=C_n\downarrow C_n$ and the Peano-like axioms;
  - the levels as "Galilean reference frames" and comma-propagation as a "Galilean boost";
  - universal arrows as "a kind of Lagrangian".
- **Majkić, *Category Theory: Invariances and Symmetries in Computer Science*** (De Gruyter 2023), §2.5.1, table (2.53): *pointer, source unread*. Used only through its reproduction in the paper.
- **Majkić, the three volumes on the completion of QM** (paper refs [17]–[19]): *pointer, source unread*; not used.
- **Bakalov, Kac, "Twisted modules over lattice vertex algebras"**, arXiv:math/0402315, §4.1, eqs. (4.1)–(4.3) (the cocycle $\varepsilon$, its square condition and commutator, the twisted group algebra): *read through extracts*. The conformal weight $|\alpha|^2/2$ is not stated there; it is used as standard (*pointer*).
- **Duval, Gibbons, Horvathy, Zhang, "Carroll versus Newton and Galilei: two dual non-Einsteinian concepts of time"**, arXiv:1402.0657: abstract and introduction *read through extracts*. Used: the Galilei and Carroll groups are related by a "duality", "associated with two different non-Minkowskian notions of time". Section III (the definitions) is *unread*; the explicit inverse-transpose form is computed here (bd·mjp·26), not taken from the source.
- **Jordan–Wigner, the CAR, Fock space**: *standard*, as recorded and proved in the Atlas (T20; cat·K1a, cat·K1b; baez·H3a).
- **Fidkowski–Kitaev, Atiyah–Bott–Shapiro, Arf–Brown**: through the Atlas's checks bd·sol·2, bd·str·1, bd·str·2 and their sources; not re-read here.
- **Lawvere metric spaces; the tropical (min, +) semiring and its zero-temperature limit; the Witt index; Lévy-Leblond's Carroll group; the order dimension of the Boolean lattice; causal sets**: *pointers, sources unread*. No statement rests on them.
- **Euler's Königsberg problem** (degrees 5, 3, 3, 3 of the standard layout): standard. The layout used (island with five bridges: two to each bank and one to the east land mass; one bridge from each bank to the east) is the usual one, and the computation uses only this multigraph.
- **Atlas sources (internal)**: `pack/claims_en.md`, `pack/theorems_questions_sources.md` (T6, T8, T17, T18, T20), `pack/needs_inputs.md`, `pack/lens_dictionary.json`, `pack/findings/disc_KEP_result.md`, `pack/copy_en/categoryCopy.txt`, `selfcheck/bridges/README.md`, `str_dualities.py`, `sol_fk_clock.py`, `str_clock.py`, `cat_cell.py`.

## 13. Limits

- **Ranges.** Every statement is checked for small $n$ only:
  - the Fock checks for $n\le5$ (Witt-pair algebra $n\le4$);
  - the closure of the full algebra for $n\le4$;
  - the isometry classes for $n\le3$ (frames for $n\le4$);
  - the charge statements for $n\le6$.

  Statements "for all $n$" rest on the obvious algebra (product formulas, Vandermonde), not on the range.
- **Floating point.** Some checks use floating point: the algebra closures by Gram–Schmidt (the matrices are integer, so the tolerances are generous), the random posets, the tropical limit and the event cones. The Lorentzian, clock and Gauss-sum checks are exact (fractions and Gaussian integers).
- **Readings.** The physical readings are mine and are flagged *ours*:
  - occupation patterns;
  - charges and energy differences;
  - the Gauss sum as a partition function at fugacity $i$;
  - absolute time as the plane-based null generator;
  - the paper's arrows as Galilean events.

  None is a claim about nature.
- **Not done.**
  - The `str` lens is thin: no computation supports a category of boundary conditions (open strings), so U3, U4, D3 and D4 have no `str` counterpart.
  - Odd numbers of Majoranas (Cl(3,0)) are outside the Fidkowski–Kitaev range of the Atlas (info bd·mjp·i2).
  - The comma-propagation levels of [14] (S7) and the nerve cohomology (S5) are not computed in this lane.
  - The Witt-index statement of X3 is not computed beyond $n=3$.
- **Things I am unsure of.**
  - My reading of D1 ("forget the pairing of $w$") as forgetting both the null part and the Witt pairing is a choice; §4 states it.
  - The identification of the paper's "Galilean boosts" with a linear boost rests on the paper's sentence about a constant velocity $\vec v$. [14] uses the word for comma-propagation; the book [13] is unread.
  - The Königsberg land-mass layout is the standard one; the paper does not draw it.
- **Not touched.** The clone's README and json, the Atlas pages, and `mrg3`. No person was contacted, and no address or contact appears in this report or the code.
