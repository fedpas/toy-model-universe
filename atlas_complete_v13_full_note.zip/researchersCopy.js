// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The words of the "For researchers" page (ResearchersSection.jsx), English and Italian with the same keys. The data it shows (the statements,
// the theorems, questions, sources, reports, analyses and scripts) is English where no Italian text exists: those blocks carry lang="en" and the Italian
// page says so in one line (enNote, claimsNote). The Young Learner reads only `pointer`.
export const VERSION = 'v13';
export const RS = {
  en: {
    tocLbl: 'On this page',
    toc: { status: 'Status', claims: 'Claims', matrix: 'Matrix', theorems: 'Theorems', questions: 'Questions', sources: 'Sources', reports: 'Reports', analyses: 'Analyses', run: 'Run the checks', genesis: 'Genesis story' },
    pointer: 'This page is for grown-up researchers: it lists, one by one, what we looked up, what we checked with a program and what is only our way of reading. Everything here is also written in the pages.',
    enNote: 'This section is in English.',
    claimsNote: 'Statements without an Italian text are in English, as are the citations and the script names.',
    status: {
      h: 'Where the audit stands',
      intro: 'Counted from the claims table below, so the numbers and the table cannot disagree.',
      total: 'statements in the audit, each listed once',
      known: 'known ground: standard and checked, neither ours, open nor input',
      flag: 'statements carry this flag',
      several: 'A statement can carry several flags, so the five flag counts add up to more than the total.',
      version: 'version of the atlas',
      date: 'date of the claims table',
      run: 'scripts you can rerun (section “Run the checks”)',
      theorems: 'theorems written for the atlas, each with its own check script',
      matrix: (rows, cols) => `${rows} × ${cols}`,
      matrixLbl: 'translation matrix: items of three sets of sources against the parts of the atlas'
    },
    claims: {
      h: 'Every statement, with its flags',
      intro: 'One row per statement of the atlas. A statement that mixes a theorem and a reading is split: the theorem line first, the reading line second, each with its own flags. Known ground means standard and checked, and neither ours, open nor input; a line that is only standard is a citation without a check of ours.',
      legendH: 'The five flags',
      flagsLbl: 'Flags',
      modeLbl: 'Match',
      mode: { all: 'all chosen flags', any: 'any chosen flag' },
      groundLbl: 'Known ground',
      ground: { all: 'Show all', known: 'Known ground only', hide: 'Everything except known ground', 'hide+std': 'Also hide plain citations' },
      groundNote: n => `“Everything except known ground” hides what the reader filter hides; the ${n} rows of the tally of the equations page are navigation and are never hidden.`,
      groupLbl: 'Group',
      allGroups: 'All groups',
      searchLbl: 'Search text and id',
      searchPh: 'e.g. Cl(3,1), ATL-007, check_T4',
      clear: 'Clear the filters',
      shown: (n, N) => `${n} of ${N} statements shown`,
      among: 'among them',
      cols: { id: 'Id', where: 'Where', lines: 'Statement and flags', cited: 'Cited', checked: 'Checked by' },
      label: { theorem: 'theorem', reading: 'reading', line: '' },
      frozen: 'audit statement',
      frozenHelp: 'a Genesis node: this is the audit statement of the node; the page tells the story in its own words',
      tally: 'navigation row',
      tallyHelp: 'a row of the tally of the equations page: it summarises a step and is never hidden by the reader filter',
      known: 'known ground',
      noFlag: 'no flag',
      none: 'No statement matches these filters.',
      go: 'Open the page where it is shown',
      tableLbl: 'Statements of the atlas with their flags'
    },
    groups: {},
    matrix: {
      h: 'Translation matrix: three sets of sources against the atlas',
      intro: 'Each row is one item of a source (a lecture chapter, a paper, a notion of the category lens); each column is a part of the atlas. A cell grades how the item meets that part: E exact counterpart (checked in a script), S structural (the same structure in another generality, or a standard fact), A analogy (our reading; nothing computes it). The colours are those of the flags: E checked, S standard, A ours. An empty cell is a gap; a row with no cell is an item the atlas does not reach.',
      grade: { E: 'exact', S: 'structural', A: 'analogy', gap: 'gap' },
      srcLbl: 'Source', allSrc: 'All three',
      colLbl: 'Column', allCols: 'All columns',
      gradeLbl: 'Grade',
      shown: (n, N) => `${n} of ${N} rows shown`,
      help: 'Choose an id for the notes of its cells, or a column name for its counts.',
      item: 'Item',
      countRow: g => `${g}: cells per column`,
      close: 'Close',
      noCells: 'No cell: the atlas does not reach this item.',
      colCounts: (E, S, A) => `${E} exact, ${S} structural, ${A} analogy`,
      withCell: 'Rows with a cell here',
      noneIn: c => `None in “${c}”`,
      noneInEmpty: 'every shown row has a cell here',
      go: 'Open this part of the atlas',
      tableLbl: 'Translation matrix: rows are items of the sources, columns are parts of the atlas',
      cellLbl: (col, g) => `${col}: ${g}`,
      sources: {},
      cols: {}
    },
    theorems: {
      h: 'Theorems proved for the atlas',
      intro: 'Each theorem has a written proof, a script that checks it on the bit rule, and the verdict of an independent verifier who re-derived it. The statements that a theorem backs are linked to the claims table.',
      caption: 'proved here = derived and independently re-derived once by a second reader; no specialist has reviewed it yet',
      status: { proved: 'proved here', reduced: 'by reduction', range: 'range checked', open: 'open' },
      statusHelp: { proved: 'derived and independently re-derived once by a second reader; no specialist has reviewed it yet', reduced: 'proved from a recalled standard theorem, which is not re-proved here', range: 'an exhaustive computation over the stated range only, not a proof for every n', open: 'a part of the statement is not settled' },
      verifier: { verified: 'verified', gaps: 'verified with gaps' },
      kv: { status: 'Status', verifier: 'Independent verifier', script: 'Script', checks: 'What it asserts', usedFor: 'Backs', limits: 'Limits of the check', remarks: 'Remarks' },
      usedForHelp: 'show this statement in the claims table'
    },
    questions: {
      h: 'Questions for specialists',
      intro: 'What we would ask someone who knows the field, with what we checked and what we did not.',
      kv: { whom: 'Who could answer', checked: 'Checked', notChecked: 'Not checked', answer: 'Answer' }
    },
    sources: {
      h: 'Sources, verdicts and dead ends',
      intro: 'The papers and lectures the atlas was compared with: what each says, what we computed, and the verdict. Dead ends stay on the list.',
      deadEnd: 'dead end',
      kv: { itSays: 'What it says', weComputed: 'What we computed', atlasTerms: 'In the atlas\'s terms', verdict: 'Verdict' }
    },
    reports: {
      h: 'Reports',
      intro: 'Six reports ship with the atlas. Each is one self-contained page that works offline, with its check scripts and its test suite in the folder reports/ of the package. They state their results as they stand, each statement with its tags and the id of its check.',
      open: 'Open the report',
      file: 'File',
      script: 'Check script',
      checks: 'checks',
      suite: 'Test suite',
      onPage: 'On the atlas page',
      listLbl: 'The six reports'
    },
    analyses: {
      h: 'Analyses',
      intro: 'Analyses of the atlas, each shipped as it was generated. Among them: three physicists and four mathematicians each read the whole atlas and wrote a reading; one report joins the three readings of physics, one the four of mathematics; an analysis sets the two reports side by side; seven discovery runs answer questions the readings raised; one joint report and four readings take a published paper on a space of arrows (arXiv:2403.19689) into the atlas, rung by rung, with questions for its author. Each page shows its markdown source as it is, with the formulas typeset, and the source and the code it ran can be downloaded. The texts name a check by the id of the script that ran it (rv·P_str·5, disc·HH3); under each analysis the same checks carry their ids in the package (bd·str·5 and bd·hh·3 in selfcheck/bridges/, core·B3 in selfcheck/core_check.py).',
      open: 'Open',
      page: 'Download page',
      source: 'Download source (md)',
      sources: 'Download sources (md)',
      code: 'Download code',
      checks: 'Checks it quotes',
      none: 'none',
      listLbl: 'The analyses'
    },
    run: {
      h: 'Run the checks yourself',
      intro: 'The scripts behind the flag “checked”, each with the command that reruns it from the package folder.',
      kv: { what: 'What it checks', checks: 'Checks', command: 'Command' }
    },
    genesis: { h: 'Genesis story' }
  },
  it: {
    tocLbl: 'In questa pagina',
    toc: { status: 'Stato', claims: 'Affermazioni', matrix: 'Matrice', theorems: 'Teoremi', questions: 'Domande', sources: 'Fonti', reports: 'Reports', analyses: 'Analyses', run: 'Rieseguire i controlli', genesis: 'Storia della Genesi' },
    pointer: 'Questa pagina è per i ricercatori adulti: elenca, uno per uno, che cosa abbiamo cercato nei libri, che cosa abbiamo controllato con un programma e che cosa è solo il nostro modo di leggere. Tutto ciò che c’è qui è scritto anche nelle pagine.',
    enNote: 'Questa sezione è in inglese.',
    claimsNote: 'Le affermazioni senza un testo italiano sono in inglese, come le citazioni e i nomi degli script.',
    status: {
      h: 'A che punto è la verifica',
      intro: 'Contati dalla tabella delle affermazioni qui sotto, così i numeri e la tabella non possono contraddirsi.',
      total: 'affermazioni nella verifica, ognuna elencata una volta',
      known: 'known ground: standard and checked, neither ours, open nor input',
      flag: 'affermazioni hanno questa etichetta',
      several: 'A statement can carry several flags, so the five flag counts add up to more than the total.',
      version: 'versione dell’atlante',
      date: 'date of the claims table',
      run: 'script che puoi rieseguire (sezione «Rieseguire i controlli»)',
      theorems: 'teoremi scritti per l’atlante, ognuno con il suo script di controllo',
      matrix: (rows, cols) => `${rows} × ${cols}`,
      matrixLbl: 'matrice di traduzione: elementi di tre gruppi di fonti a confronto con le parti dell’atlante'
    },
    claims: {
      h: 'Ogni affermazione, con le sue etichette',
      intro: 'One row per statement of the atlas. A statement that mixes a theorem and a reading is split: the theorem line first, the reading line second, each with its own flags. Known ground means standard and checked, and neither ours, open nor input; a line that is only standard is a citation without a check of ours.',
      legendH: 'The five flags',
      flagsLbl: 'Etichette',
      modeLbl: 'Corrispondenza',
      mode: { all: 'tutte le etichette scelte', any: 'almeno un’etichetta scelta' },
      groundLbl: 'Terreno noto',
      ground: { all: 'Mostra tutto', known: 'Solo il terreno noto', hide: 'Tutto tranne il terreno noto', 'hide+std': 'Nascondi anche le sole citazioni' },
      groundNote: n => `«Tutto tranne il terreno noto» nasconde ciò che nasconde il filtro del lettore; le ${n} righe del bilancio della pagina delle equazioni servono a navigare e non sono mai nascoste.`,
      groupLbl: 'Gruppo',
      allGroups: 'Tutti i gruppi',
      searchLbl: 'Cerca nel testo e negli id',
      searchPh: 'per esempio Cl(3,1), ATL-007, check_T4',
      clear: 'Togli i filtri',
      shown: (n, N) => `${n} affermazioni mostrate su ${N}`,
      among: 'tra queste',
      cols: { id: 'Id', where: 'Dove', lines: 'Affermazione ed etichette', cited: 'Citato', checked: 'Controllato da' },
      label: { theorem: 'teorema', reading: 'lettura', line: '' },
      frozen: 'audit statement',
      frozenHelp: 'a Genesis node: this is the audit statement of the node; the page tells the story in its own words',
      tally: 'riga di navigazione',
      tallyHelp: 'una riga del bilancio della pagina delle equazioni: riassume un passo e il filtro del lettore non la nasconde mai',
      known: 'terreno noto',
      noFlag: 'nessuna etichetta',
      none: 'Nessuna affermazione corrisponde a questi filtri.',
      go: 'Apri la pagina dove si trova',
      tableLbl: 'Affermazioni dell’atlante con le loro etichette'
    },
    // the group names of the claims table; the English page reads groupName from the claims file
    groups: { ATL: 'Celle dell’atlante', GEN: 'Genesis ladder (our starting ideas)', FUR: 'Risultati su Furey', PAG: 'Strisce di affermazioni delle pagine', LAB: 'Clock, gauge and groups strips', EQN: 'Equazioni: passo 2 e bilancio', SHP: 'Forme: ortoplesso', GOS: 'Forme: Gosset', CPL: 'Passo 6: accoppiamento', GRV: 'Passi 9–10: gravità', MAT: 'Passo 8: materia', MIR: 'Passo 3: specchi', PRJ: 'Passo 11: proiettivo', YM: 'Passo 7: Yang–Mills', NUL: 'Passo 13: superfici nulle', FRQ: 'Passo 14: forque', SPN: 'Passo 5: spin', SPR: 'Passo 15: molle', RIG: 'Passo 16: corpo rigido', MAP: 'Nodi della mappa', RSN: 'Note per i ricercatori', INP: 'Needs and inputs', LNP: 'Striscia della pagina delle lenti (passi 18–20)', LNC: 'Lente categoriale (passo 18)', LNB: 'Baez (passo 19)', LNS: 'Schuller (passo 20)', THM: 'Researchers page: theorem remarks', SRC: 'Researchers page: sources' },
    matrix: {
      h: 'Matrice di traduzione: tre gruppi di fonti a confronto con l’atlante',
      intro: 'Ogni riga è un elemento di una fonte (un capitolo delle lezioni, un articolo, una nozione della lente delle categorie); ogni colonna è una parte dell’atlante. Una cella dice come l’elemento incontra quella parte: E controparte esatta (controllata da uno script), S strutturale (la stessa struttura in un’altra generalità, o un fatto standard), A analogia (una nostra lettura; nulla la calcola). I colori sono quelli delle etichette: E verificato, S standard, A nostro. Una cella vuota è una lacuna; una riga senza celle è un elemento che l’atlante non raggiunge.',
      grade: { E: 'esatto', S: 'strutturale', A: 'analogia', gap: 'lacuna' },
      srcLbl: 'Fonte', allSrc: 'Tutte e tre',
      colLbl: 'Colonna', allCols: 'Tutte le colonne',
      gradeLbl: 'Grado',
      shown: (n, N) => `${n} righe mostrate su ${N}`,
      help: 'Scegli un id per le note delle sue celle, o il nome di una colonna per i suoi conteggi.',
      item: 'Elemento',
      countRow: g => `${g}: celle per colonna`,
      close: 'Chiudi',
      noCells: 'Nessuna cella: l’atlante non raggiunge questo elemento.',
      colCounts: (E, S, A) => `${E} esatte, ${S} strutturali, ${A} analogie`,
      withCell: 'Righe con una cella qui',
      noneIn: c => `Nessuna in «${c}»`,
      noneInEmpty: 'ogni riga mostrata ha una cella qui',
      go: 'Apri questa parte dell’atlante',
      tableLbl: 'Matrice di traduzione: le righe sono elementi delle fonti, le colonne sono parti dell’atlante',
      cellLbl: (col, g) => `${col}: ${g}`,
      // the names of the three sources and of the 22 columns (short, long); the English page reads them from the matrix file
      sources: { schuller: 'Lezioni di Schuller e chiusura gravitazionale', baez: 'Sette articoli di Baez', category: 'Lente delle categorie (note KTH sulle algebre di Clifford, Tenfold Way, Tian, Majkic, contesto)' },
      cols: {
        rule: ['Regola', 'La regola: etichette di bit, XOR, segni'], cells: ['Celle', 'L’atlante delle celle Cl(p,q), l’orologio'], maxwell: ['Maxwell', 'Calibration 1: Maxwell ∇F=J'], furey: ['Furey', 'Calibration 2: Furey, one generation in Cl(0,8)'],
        shapes: ['Forme', 'Ortoplesso, demicubo, serie di Gosset'], comm: ['2 Commut', 'Passo 2: commutatori dei bivettori'], dirac: ['4 Dirac', 'Passo 4: equazione di Dirac'], coupling: ['6 Accopp', 'Passo 6: accoppiamento'],
        ym: ['7 YM', 'Passo 7: Yang–Mills'], matter: ['8 Materia', 'Passo 8: materia carica'], grav1: ['9 Gravità', 'Passo 9: gravità, tetrade e curvatura'], grav2: ['10 Gravità', 'Passo 10: gravità, forma di Einstein'],
        mirrors: ['3 Specchi', 'Passo 3: specchi e versori'], projective: ['11 Proiett', 'Passo 11: proiettivo e conforme'], forque: ['14 Forque', 'Passo 14: dinamica del forque'], spin: ['5 Spin', 'Passo 5: spinori'],
        spring: ['15 Molle', 'Passo 15: molle'], rigid: ['16 Rigido', 'Passo 16: corpi rigidi'], null: ['13 Nulle', 'Passo 13: superfici nulle'], clock: ['1 Orologio', 'Passo 1: orologio e trinità'],
        gauge: ['12 Gauge', 'Passo 12: gravità di gauge'], groups: ['17 Gruppi', 'Passo 17: gruppi finiti']
      }
    },
    theorems: {
      h: 'Teoremi dimostrati per l’atlante',
      intro: 'Ogni teorema ha una dimostrazione scritta, uno script che lo controlla sulla regola dei bit e il giudizio di un verificatore indipendente che l’ha ricavato di nuovo. Le affermazioni che un teorema sostiene sono collegate alla tabella delle affermazioni.',
      caption: 'dimostrato qui = ricavato e poi ricavato di nuovo, in modo indipendente, da un secondo lettore; nessuno specialista l’ha ancora esaminato',
      status: { proved: 'dimostrato qui', reduced: 'per riduzione', range: 'controllato in un intervallo', open: 'aperto' },
      statusHelp: { proved: 'ricavato e poi ricavato di nuovo, in modo indipendente, da un secondo lettore; nessuno specialista l’ha ancora esaminato', reduced: 'dimostrato a partire da un teorema standard richiamato, che qui non è dimostrato di nuovo', range: 'un calcolo esaustivo solo nell’intervallo indicato, non una dimostrazione per ogni n', open: 'una parte dell’enunciato non è risolta' },
      verifier: { verified: 'confermato', gaps: 'confermato con lacune' },
      kv: { status: 'Stato', verifier: 'Verificatore indipendente', script: 'Script', checks: 'Che cosa controlla', usedFor: 'Sostiene', limits: 'Limits of the check', remarks: 'Remarks' },
      usedForHelp: 'mostra questa affermazione nella tabella'
    },
    questions: {
      h: 'Domande per gli specialisti',
      intro: 'Che cosa chiederemmo a chi conosce il campo, con ciò che abbiamo controllato e ciò che non abbiamo controllato.',
      kv: { whom: 'Chi potrebbe rispondere', checked: 'Controllato', notChecked: 'Non controllato', answer: 'Answer' }
    },
    sources: {
      h: 'Fonti, verdetti e vicoli ciechi',
      intro: 'Gli articoli e le lezioni con cui l’atlante è stato confrontato: che cosa dice ciascuno, che cosa abbiamo calcolato e il verdetto. I vicoli ciechi restano nell’elenco.',
      deadEnd: 'vicolo cieco',
      kv: { itSays: 'Che cosa dice', weComputed: 'Che cosa abbiamo calcolato', atlasTerms: 'In the atlas\'s terms', verdict: 'Verdetto' }
    },
    reports: {
      h: 'Reports',
      intro: 'Six reports ship with the atlas. Each is one self-contained page that works offline, with its check scripts and its test suite in the folder reports/ of the package. They state their results as they stand, each statement with its tags and the id of its check.',
      open: 'Open the report',
      file: 'File',
      script: 'Check script',
      checks: 'checks',
      suite: 'Test suite',
      onPage: 'On the atlas page',
      listLbl: 'The six reports'
    },
    analyses: {
      h: 'Analyses',
      intro: 'Analyses of the atlas, each shipped as it was generated. Among them: three physicists and four mathematicians each read the whole atlas and wrote a reading; one report joins the three readings of physics, one the four of mathematics; an analysis sets the two reports side by side; seven discovery runs answer questions the readings raised; one joint report and four readings take a published paper on a space of arrows (arXiv:2403.19689) into the atlas, rung by rung, with questions for its author. Each page shows its markdown source as it is, with the formulas typeset, and the source and the code it ran can be downloaded. The texts name a check by the id of the script that ran it (rv·P_str·5, disc·HH3); under each analysis the same checks carry their ids in the package (bd·str·5 and bd·hh·3 in selfcheck/bridges/, core·B3 in selfcheck/core_check.py).',
      open: 'Open',
      page: 'Download page',
      source: 'Download source (md)',
      sources: 'Download sources (md)',
      code: 'Download code',
      checks: 'Checks it quotes',
      none: 'none',
      listLbl: 'The analyses'
    },
    run: {
      h: 'Riesegui i controlli da solo',
      intro: 'Gli script dietro l’etichetta «verificato», ognuno con il comando che lo riesegue dalla cartella del pacchetto.',
      kv: { what: 'Che cosa controlla', checks: 'Controlli', command: 'Comando' }
    },
    genesis: { h: 'Storia della Genesi' }
  }
};
