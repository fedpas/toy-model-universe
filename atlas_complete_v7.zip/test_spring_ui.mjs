import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { setLang } from './ui_helpers.mjs';
import fs from 'fs';
const K=JSON.parse(fs.readFileSync('/home/claude/ui/selfcheck/spring.json','utf8'));
const b=await chromium.launch();const errs=[];
const THREADS=['oscillator','vertices','edges','faces','sign','labels'], THR={oscillator:4,vertices:6,edges:2,faces:4,sign:5,labels:1};
for(const lang of ['en','it']) for(const w of [1100,375]) for(const prof of ['Young Learner','Mathematician']){
 const tag=`${lang}${w}${prof[0]}`;
 const pg=await b.newPage({viewport:{width:w,height:800},acceptDownloads:true});
 pg.on('pageerror',e=>errs.push(`${tag}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${tag} console: ${m.text()}`));
 await pg.goto('file:///home/claude/ui/dist/app.html#equations/spring');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.locator(`[data-profile="${prof}"]`).click();await pg.waitForTimeout(200);
 const S='#eq-spring';
 const eb=await pg.locator(`${S} .eyebrow`).textContent(); if(eb!==(lang==='en'?'STEP 12 OF 13 · A SPRING ON THE CUBE: VERTICES, EDGES, FACES':'PASSO 12 DI 13 · UNA MOLLA SUL CUBO: VERTICI, SPIGOLI, FACCE'))errs.push(`${tag}: eyebrow ${eb}`);
 if(await pg.locator('.tabbar [role=tab]').count()!==14)errs.push(`${tag}: nav`);
 if(await pg.locator(`${S} .spr-th`).count()!==6)errs.push(`${tag}: threads`);
 if(await pg.locator(`${S} .spr-view`).count()!==18)errs.push(`${tag}: views`);
 if(await pg.locator(`${S} .sp-w`).count()!==5)errs.push(`${tag}: widgets`);
 if(await pg.locator(`${S} .spr-lens`).count()!==4)errs.push(`${tag}: lenses`);
 if(await pg.locator(`${S} .spr-row`).count()!==22)errs.push(`${tag}: rows`);
 for(const th of THREADS){ const n=await pg.locator(`${S} #spr-th-${th} .spr-jump`).count(); if(n!==THR[th])errs.push(`${tag}: thread ${th} rows ${n}`); }
 // table in numbers
 if(await pg.locator(`${S} .spr-numbers tbody tr`).count()!==4)errs.push(`${tag}: numbers table`);
 {const cells=await pg.locator(`${S} .spr-numbers tr[data-n="3"] td`).allTextContents(); if(cells[1]!=='8'||cells[2]!=='12'||cells[3]!=='6')errs.push(`${tag}: n=3 counts ${cells}`);}
 // filters and search
 for(const th of THREADS){ await pg.locator(`${S} .spr-flt[data-flt="${th}"]`).click(); const c=await pg.locator(`${S} .spr-row`).count(); if(c!==THR[th])errs.push(`${tag}: filter ${th} ${c}`); }
 await pg.locator(`${S} .spr-flt[data-flt="all"]`).click();
 await pg.locator(`${S} .spr-search`).fill('B5'); {const ids=await pg.locator(`${S} .spr-row`).evaluateAll(es=>es.map(e=>e.dataset.row)); if(!ids.includes('B5')||ids.length>2)errs.push(`${tag}: search B5 ${ids}`);}
 await pg.locator(`${S} .spr-search`).fill('Huang'); await pg.locator(`${S} .spr-search`).fill('zzzz'); if(await pg.locator(`${S} .spr-row`).count()!==0)errs.push(`${tag}: search none`);
 await pg.locator(`${S} .spr-search`).fill('');
 // rows open, command, copy
 await pg.locator(`${S} #spr-row-B5 .spr-row-h`).click(); if(await pg.locator(`${S} #spr-row-B5 .spr-cmd`).textContent()!=='python3 spring_selfcheck.py --row B5')errs.push(`${tag}: cmd`);
 if((await pg.locator(`${S} #spr-row-B5 .spr-inst`).textContent()).length<10)errs.push(`${tag}: inst`);
 await pg.locator(`${S} #spr-row-B5 .spr-row-h`).click(); if(await pg.locator(`${S} #spr-det-B5`).count()!==0)errs.push(`${tag}: did not close`);
 for(const id of ['A4','B8','C3']) if(await pg.locator(`${S} #spr-row-${id} .spr-ctrl`).count()!==1)errs.push(`${tag}: control tag ${id}`);
 await pg.locator(`${S} #spr-th-edges .spr-jump`).filter({hasText:'B1'}).click(); await pg.waitForTimeout(100); if(await pg.locator(`${S} #spr-det-B1`).count()!==1)errs.push(`${tag}: jump B1`);
 // widgets: oscillator
 {const W=`${S} .spr-w-osc`; const sig=async()=>pg.locator(`${W} .spr-sig`).textContent(); if(!(await sig()).includes('B² = −1'))errs.push(`${tag}: osc harmonic ${await sig()}`);
  const pos=async()=>pg.locator(`${W} .spr-dot`).getAttribute('cx');
  const p0=await pos(); await pg.locator(`${W} .spr-slider`).fill('20'); await pg.waitForTimeout(60); const p1=await pos(); if(p0===p1)errs.push(`${tag}: osc dot did not move`);
  if(await pg.locator(`${W} .spr-half .ok`).count()!==2||await pg.locator(`${W} .spr-half .bad`).count()!==0)errs.push(`${tag}: osc half angle mark`);
  if(await pg.locator(`${W} .spr-energy`).count()!==1)errs.push(`${tag}: osc energy line`);
  await pg.locator(`${W} .eq-chip`).nth(1).click(); if(!(await sig()).includes('B² = 1')||await pg.locator(`${W} .spr-energy`).count()!==0)errs.push(`${tag}: osc inverted ${await sig()}`);
  if(!(await pg.locator(`${W} .spr-law`).textContent()).includes('x″ = 1·x'))errs.push(`${tag}: inverted law`);
  await pg.locator(`${W} .eq-chip`).nth(2).click(); if(!(await sig()).includes('B² = 0'))errs.push(`${tag}: osc free ${await sig()}`);
  if(!(await pg.locator(`${W} .spr-law`).textContent()).includes('x″ = 0·x'))errs.push(`${tag}: free law`);
  if(await pg.locator(`${W} .spr-half .ok`).count()!==2||await pg.locator(`${W} .spr-half .bad`).count()!==0)errs.push(`${tag}: free half mark`);}
 // cube widget
 {const W=`${S} .spr-w-cube`; const info=async()=>pg.locator(`${W} .spr-modeinfo`).textContent();
  if(await pg.locator(`${W} .spr-vtx`).count()!==8)errs.push(`${tag}: cube vertices`);
  let i=await info(); if(!i.includes('2|s| = 2')||!/ 3 /.test(i))errs.push(`${tag}: mode info ${i}`);
  await pg.locator(`${W} .spr-bit`).nth(1).click(); i=await info(); if(!i.includes('2|s| = 4')||!/ 3 /.test(i))errs.push(`${tag}: mode info 2 ${i}`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 4'}).click(); if(await pg.locator(`${W} .spr-vtx`).count()!==16)errs.push(`${tag}: n=4 vertices`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 3'}).click();
  const y0=await pg.locator(`${W} .spr-vtx circle`).first().getAttribute('cy'); await pg.locator(`${W} .spr-slider`).fill('13'); await pg.waitForTimeout(60); const y1=await pg.locator(`${W} .spr-vtx circle`).first().getAttribute('cy'); if(y0===y1)errs.push(`${tag}: mode did not move`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:lang==='en'?'Pluck a vertex':'Pizzica un vertice'}).click();
  if(await pg.locator(`${W} .spr-econs .ok`).count()!==1)errs.push(`${tag}: energy mark`);
  if(await pg.locator(`${W} .spr-share tbody tr`).count()!==4)errs.push(`${tag}: share table`);
  await pg.locator(`${W} .spr-slider`).fill('57'); await pg.waitForTimeout(60); if(await pg.locator(`${W} .spr-econs .ok`).count()!==1)errs.push(`${tag}: energy mark later`);
  await pg.locator(`${W} .spr-vtx`).nth(6).locator('circle').click({force:true}); await pg.waitForTimeout(60); if(!(await pg.locator(`${W} .spr-pluckinfo`).textContent()).includes('110'))errs.push(`${tag}: pluck vertex 110`);
  const play=pg.locator(`${W} .spr-play`); await play.click(); await pg.waitForTimeout(260); const tt=await pg.locator(`${W} .spr-slider`).inputValue(); await play.click(); if(+tt<=0)errs.push(`${tag}: play did not advance`);}
 // spectra
 {const W=`${S} .spr-w-spec`; if(await pg.locator(`${W} .spr-level`).count()!==7)errs.push(`${tag}: spectra n=4 default`);}
 {const W=`${S} .spr-w-spec`; const cnt=async()=>pg.locator(`${W} .spr-level`).count();
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 3'}).click(); if(await cnt()!==6)errs.push(`${tag}: spectra n=3`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 5'}).click(); if(await cnt()!==8)errs.push(`${tag}: spectra n=5`);
  const m=await pg.locator(`${W} .spr-level`).evaluateAll(es=>es.map(e=>+e.dataset.mult)); if(m.join()!=='1,5,10,10,5,1,16,16')errs.push(`${tag}: spectra n=5 mults ${m}`);
  if(await pg.locator(`${W} .spr-trace .ok`).count()!==1)errs.push(`${tag}: trace mark`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 4'}).click(); const lv2=await pg.locator(`${W} .spr-lv2`).textContent(); if(!lv2.includes('2 ')||!lv2.includes('6')||!lv2.includes('8'))errs.push(`${tag}: signed n=4 ${lv2}`);}
 // faces
 {const W=`${S} .spr-w-face`; if(await pg.locator(`${W} .spr-face`).count()!==6)errs.push(`${tag}: faces n=3`);
  if(await pg.locator(`${W} .spr-face.z`).count()!==6||await pg.locator(`${W} .spr-verdict .ok`).count()!==1)errs.push(`${tag}: displacement closes`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:lang==='en'?'arbitrary':'arbitrario'}).click(); if(await pg.locator(`${W} .spr-face.nz`).count()<1||await pg.locator(`${W} .spr-verdict .ok`).count()!==1)errs.push(`${tag}: arbitrary does not close`);
  await pg.locator(`${W} .spr-new`).click();
  if(!(await pg.locator(`${W} .spr-flux`).textContent()).includes('−1')||await pg.locator(`${W} .spr-flux .ok`).count()!==1)errs.push(`${tag}: flux`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 4'}).click(); if(await pg.locator(`${W} .spr-face`).count()!==24)errs.push(`${tag}: faces n=4`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 2'}).click(); if(await pg.locator(`${W} .spr-face`).count()!==1)errs.push(`${tag}: faces n=2`);}
 // labels as modes
 {const W=`${S} .spr-w-labels`; if(await pg.locator(`${W} .spr-lbl-tab tbody tr`).count()!==16)errs.push(`${tag}: label rows`);
  if(await pg.locator(`${W} .spr-lbl-tab .ok`).count()!==16||await pg.locator(`${W} .spr-lbl-mode .ok`).count()!==1)errs.push(`${tag}: label marks`);
  await pg.locator(`${W} .spr-lbit`).nth(2).click(); const md=await pg.locator(`${W} .spr-lbl-mode`).textContent(); if(!/(complement|complemento)/.test(md)||!md.includes('ω² = 2'))errs.push(`${tag}: odd label ${md}`);
  if(await pg.locator(`${W} .spr-lbl-tab .ok`).count()!==16)errs.push(`${tag}: odd label marks`);
  await pg.locator(`${W} .eq-chip`).filter({hasText:'n = 3'}).click(); if(await pg.locator(`${W} .spr-lbl-tab tbody tr`).count()!==8)errs.push(`${tag}: label rows n=3`);}
 // downloads (the folds start closed for the learner)
 await pg.evaluate(()=>document.querySelectorAll('#eq-spring details.eq-fold').forEach(d=>{d.open=true;}));await pg.waitForTimeout(80);
 {const [dl]=await Promise.all([pg.waitForEvent('download'),pg.locator(`${S} .eq-btn`).filter({hasText:'spring_selfcheck.py'}).click()]); const py=fs.readFileSync(await dl.path(),'utf8'); if(!py.includes('ALL SPRING CHECKS PASS')||dl.suggestedFilename()!=='spring_selfcheck.py')errs.push(`${tag}: py download`);
  const [d2]=await Promise.all([pg.waitForEvent('download'),pg.locator(`${S} .eq-btn`).filter({hasText:'spring.json'}).click()]); const js=JSON.parse(fs.readFileSync(await d2.path(),'utf8')); if(js.summary.ok!==K.summary.ok||d2.suggestedFilename()!=='spring.json')errs.push(`${tag}: json download`);}
 // no raw latex, no horizontal overflow
 {const txt=await pg.locator(S).innerText(); if(/\\[a-zA-Z]{3,}|undefined|NaN|\[object/.test(txt))errs.push(`${tag}: raw markup or undefined in text`);
  const ov=await pg.evaluate(()=>document.documentElement.scrollWidth-innerWidth); if(ov>1)errs.push(`${tag}: horizontal overflow ${ov}`);}
 // the link to the map
 await pg.locator(`${S} .spr-maplink`).click(); await pg.waitForTimeout(150); if(!(await pg.evaluate(()=>location.hash)).includes('map')||await pg.locator('.map').count()!==1)errs.push(`${tag}: map link`);
 await pg.close();
}
await b.close();
console.log(errs.length?errs.join('\n')+`\n${errs.length} FAILURES`:'ALL SPRING UI TESTS PASS');process.exit(errs.length?1:0);
