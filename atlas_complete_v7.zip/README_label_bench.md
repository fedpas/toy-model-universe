# Label speed test (`label_bench.html`)

A single standalone page that **times**, in your own browser, whether the "bit-label" speed-ups claimed in the maths app give any gain on your machine.
It measures; it does not prove. A result is true of this browser, this machine, its power mode and the load it had at that moment, and of nothing else.

## Open it
Download `label_bench.html` and double-click it (Chrome, Firefox or Safari, `file://` is fine). It makes no network request, loads no library and no font, and sends nothing anywhere.
For a stable result: close other tabs, plug in the power, keep the tab in the foreground, do not resize the window while it runs. Press **Run** (the **Quick** preset is selected: 20 ms batches, 3 repetitions);
use **Careful** (200 ms batches, 15 repetitions) when a row is flagged noisy. **Stop** ends the run and keeps what has been timed.

The timing runs in a Web Worker built from a Blob URL of the same inlined source, so the page stays responsive. If a Worker cannot be started the page falls back to the main thread (chunked with `setTimeout`)
and says so under the buttons ("Mode: ..."). Adding `#main` to the address forces the fallback.

## The scenarios (each runs the correctness check first: all variants must give the same answers, otherwise nothing is timed)
| Scenario | What is timed, per call |
|---|---|
| **Vertices** | The 2^n world corners of an n-cube from a motor: *direct* (2^n sandwiches), *frame* (n+1 sandwiches then 2^n-1 additions), *frame with the odd half mirrored through the centre*, the *matrix route* (frame, then n^2 flops a corner), and the table step alone (doubling against n^2 a corner, frame given). Claim: frame against direct. |
| **Contact** | The deepest corner under a plane: *scan* of 2^n dot products against *n sign bits* of the frame, with the table or frame **given** and with its **building counted**. |
| **Outline** | The flat outline of the projected cube: *convex hull* of the 2^n points against the 2n-corner *zonogon* from the n projected edges, given and building counted. |
| **Product** (new in 1.1.0) | The dense product of two multivectors of the neutral algebra Cl(k,k), n = 2k = 2, 4, ..., 12 (14 optional and slow). *Bit rule*: 4^n terms, each sign worked out. *Sign table*: the same terms, signs read from a table built before the clock. *Matrix route*: Cl(k,k) = M(2^k, R), so the multivector becomes a 2^k x 2^k real matrix (a butterfly on each of the k sites, k 4^k additions), one matrix product (8^k multiplications), and back. *Matrix product alone*: the matrices already exist. *Period 8 blocks* (n >= 10): Cl(N+8) = M16(Cl(N)), the product as 16^3 = 4096 products in Cl(n-8) by the bit rule. Inputs are dense integers; the check compares the answers **exactly** (`===`) before any timing, and `selfcheck/matrixrep_check.py` proves the representation in exact Python integers (the page's tables are rebuilt in JavaScript and `test_product.mjs` compares them with its fixtures). Claim: the matrix route against the sign table, against the plain rule, the matrix product alone, and the period-8 blocks. The ratio should be below 1 at small n (the conversion costs more than it saves) and then grow roughly as 2^(n/2). Sparse multivectors (a few blades) are another case and are not timed. |
| **Many bodies** | B bodies (100, 1000, 10000), each with its own motor from a seeded generator (seed 12345, so the scene is reproducible). One scene step: build every body's corners (direct against frame); a contact query of every body against one plane (scan against sign bits, given and building counted); and the whole path (direct and scan against frame and sign bits). Reported as ms per scene step and bodies per second. Motors are fixed: integrating the dynamics is not counted. |
| **Warm-up and cold start** | Call 1, calls 1-10, 11-100, 101-1000 of one function against its steady state. Every repeat starts a **fresh worker** so the code is cold (in main-thread mode it cannot be, and the page says so). The set-up (algebra tables, motor) is outside the clock. Times below the timer step are shown as upper bounds, not as numbers. |
| **Allocation** | Plain `Array` against `Float64Array` for allocating 8, 16, 32 and 64 doubles, and for a small sandwich-like loop (with and without reused Float64Array buffers). Reproduces, or not, the finding that made the engine use plain arrays (node 22: a Float64Array of 16 or more doubles cost about 2.3 us against 0.06 us). Whatever your browser gives is shown. |

## How to read a row
* **Ratio** = baseline time / variant time (medians). "frame is 3.24x faster" means the frame took 1/3.24 of the direct time; "frame is 0.67x, i.e. slower" means it took 1/0.67 of it.
* **Spread** of a timing = (slowest batch - fastest batch) / median over the repetitions. Above 15% the row is flagged "noisy: repeat with Careful".
* **Verdict**: *about equal within noise* when |ratio - 1| is below the larger of 5% and the larger spread of the two timings; otherwise *faster* or *slower*. A rule of thumb for one run, not a statistical test.
* **Chart**: log scale, bars start at the 1x line (up: faster, down: slower), colour follows the verdict, and every bar carries its value as text (`*` = noisy). Hatched bars are the "building counted" series.
* **Timer step**: the smallest observable step of `performance.now()` is measured and shown. Above 5 us the page warns; batches of at least 20 ms make that irrelevant for the batch timings, but single-call times (warm-up) are then only indicative.

## Save, share, compare
**Download JSON** (settings, machine info, checks, rows), **Download CSV** (one row per timing and per ratio), **Copy as text** (a readable summary, also shown in the "Text summary" box).
To compare two machines, send the JSON; the other person opens the page, runs it, and loads your JSON under **Compare with another run** (or loads the embedded *reference run on one 2-core VM, node 22*).
The table shows the claimed ratio on each side and the ratio between the two. The product timings are in the JSON under `product` and in the CSV and the text summary; the comparison table covers the vertices, contact and outline scenarios only. The JSON `rows` have the same shape as `selfcheck/bench_labels.json`, so a file from `node selfcheck/bench_labels.mjs --write file.json` can be loaded as well.
Everything stays in your browser.

## Regenerate
```
node build_label_bench.mjs          # writes label_bench.html (about 143 KB, deterministic: same sources, same bytes)
node test_label_bench.mjs           # Playwright checks, prints LABEL BENCH OK
```
The build inlines the **real source** of `pgaEngine.js`, `benchKernels.js` and `productKernels.js`: only the `import` line and the `export` keywords are removed, mechanically.
The variants that the page times are not retyped: the 14 lambdas and the set-up line are cut out of `runBench` in `benchKernels.js` at build time (the build fails if that file changes shape), so the page cannot drift from the kernels the app uses.
The page-specific code is in `label_bench_src/` (`template.html`, `style.css`, `runners.js` for the scenarios and the worker side (the product job is there), `page.js` for the interface). `test_label_bench.mjs` needs Playwright (module path at the top of the file).

## What this does not show
Other machines, browsers, engines and languages are open; WebAssembly and SIMD were not tried; the kernels are small plain-JavaScript functions; the counts of operations are an arithmetic fact, the seconds are a measurement
with a spread. The worker's results are shown live, which costs the page a little work on another thread while the worker times; on a one-core machine that can add noise.
