import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { setLang } from './ui_helpers.mjs';
import fs from 'fs';
const K=JSON.parse(fs.readFileSync('/home/claude/ui/selfcheck/forque.json','utf8')), C=K.counts;
const b=await chromium.launch();const errs=[];
for(const lang of ['en','it']) for(const w of [1100,375]) for(const prof of ['Young Learner','Mathematician']){
 const tag=`${lang}${w}${prof[0]}`;
 const pg=await b.newPage({viewport:{width:w,height:800},acceptDownloads:true});
 pg.on('pageerror',e=>errs.push(`${tag}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${tag} console: ${m.text()}`));
 await pg.goto('file:///home/claude/ui/dist/app.html#equations/forque');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.locator(`[data-profile="${prof}"]`).click();await pg.waitForTimeout(200);
 const S='#eq-forque';
 const eb=await pg.locator(`${S} .eyebrow`).textContent(); if(eb!==(lang==='en'?'STEP 10 OF 13 · FORQUE: FORCE AND TORQUE AS ONE LINE':'PASSO 10 DI 13 · FORQUE: FORZA E COPPIA COME UNA SOLA RIGA'))errs.push(`${tag}: eyebrow ${eb}`);
 const rows=await pg.locator(`${S} .fq-row`).count(); if(rows!==41)errs.push(`${tag}: rows ${rows}`);
 // filters
 for(const [k,n] of [['ok',C.ok],['note',C.note],['nc',C.not_checked],['all',C.rows]]){ await pg.locator(`${S} .fq-flt[data-flt="${k}"]`).click(); const c=await pg.locator(`${S} .fq-row`).count(); if(c!==n)errs.push(`${tag}: filter ${k} shows ${c}, expected ${n}`); const st=await pg.locator(`${S} .fq-row`).evaluateAll(es=>[...new Set(es.map(e=>e.dataset.status))]); if(k!=='all'&&(st.length!==1||st[0]!==k))errs.push(`${tag}: filter ${k} statuses ${st}`); }
 // search
 await pg.locator(`${S} .fq-search`).fill('F20'); {const ids=await pg.locator(`${S} .fq-row`).evaluateAll(es=>es.map(e=>e.dataset.row)); if(!ids.includes('F20')||ids.length>3)errs.push(`${tag}: search F20 ${ids}`);}
 await pg.locator(`${S} .fq-search`).fill('zzzz-nothing'); if(await pg.locator(`${S} .fq-row`).count()!==0)errs.push(`${tag}: search none`);
 await pg.locator(`${S} .fq-search`).fill('(2.33)'); const n233=await pg.locator(`${S} .fq-row`).count(); if(n233<1)errs.push(`${tag}: search (2.33)`);
 await pg.locator(`${S} .fq-search`).fill('');
 // every row: equations present, no raw LaTeX
 const txt=await pg.locator(`${S} .fq-row-h`).allTextContents(); if(txt.some(x=>/\\[a-zA-Z]/.test(x)))errs.push(`${tag}: raw latex in a row`);
 for(const r of K.rows){ const t=await pg.locator(`${S} #fq-row-${r.id}`).textContent(); if(!t||t.length<30)errs.push(`${tag}: row ${r.id} empty`); }
 // open a row: worked instance, code, and the command to re-run it
 await pg.locator(`${S} #fq-row-F20 .fq-row-h`).click();
 const code=await pg.locator(`${S} #fq-row-F20 .fq-codeline`).textContent(); const f20=K.rows.find(r=>r.id==='F20'); if(code!==f20.code)errs.push(`${tag}: F20 code line`);
 const cmd=await pg.locator(`${S} #fq-row-F20 .fq-cmd`).textContent(); if(cmd!=='python3 forque_selfcheck.py --row F20')errs.push(`${tag}: cmd ${cmd}`);
 const wk=await pg.locator(`${S} #fq-row-F20 .fq-worked`).textContent(); if(!wk.includes(f20.worked.lhs)||!wk.includes('✓'))errs.push(`${tag}: worked ${wk}`);
 await pg.locator(`${S} #fq-row-F20 .fq-row-h`).click(); if(await pg.locator(`${S} #fq-det-F20`).count()!==0)errs.push(`${tag}: row did not close`);
 // the noted rows show their note
 await pg.locator(`${S} #fq-row-F30 .fq-row-h`).click(); const note=await pg.locator(`${S} #fq-row-F30 .fq-note`).textContent(); if(note.length<40)errs.push(`${tag}: F30 note`);
 if(lang==='it'&&/lacks a factor|looks like a dropped|With the rotor/.test(note))errs.push(`${tag}: English note in Italian`);
 // jump buttons from the four lines
 const lines=await pg.locator(`${S} .fq-line`).count(); if(lines!==4)errs.push(`${tag}: lines ${lines}`);
 await pg.locator(`${S} .fq-line .fq-jump`).filter({hasText:'F24'}).click(); await pg.waitForTimeout(100); if(await pg.locator(`${S} #fq-det-F24`).count()!==1)errs.push(`${tag}: jump to F24`);
 // findings
 const fn=await pg.locator(`${S} .fq-finding`).count(); if(fn!==K.findings.length)errs.push(`${tag}: findings ${fn}`);
 await pg.locator(`${S} .fq-finding .fq-jump`).first().click(); await pg.waitForTimeout(100);
 // the notes download
 const [dl]=await Promise.all([pg.waitForEvent('download'),pg.locator(`${S} .eq-btn`).filter({hasText:lang==='en'?'notes for the authors':'note per gli autori'}).click()]);
 const md=fs.readFileSync(await dl.path(),'utf8'); for(const f of K.findings) if(!md.includes(f.id))errs.push(`${tag}: notes file lacks ${f.id}`); if(dl.suggestedFilename()!=='forque_notes_for_authors.md')errs.push(`${tag}: notes filename`);
 // the racket demo
 const out0=await pg.locator(`${S} .fq-racket-out`).first().textContent(); if(!/0\.89/.test(out0))errs.push(`${tag}: racket default ${out0}`);
 const sl=pg.locator(`${S} .fq-slider`); await sl.nth(0).fill('3'); await sl.nth(1).fill('3'); await pg.waitForTimeout(100);
 const out1=await pg.locator(`${S} .fq-racket-out`).first().textContent(); if(!(lang==='en'?/Two inertias are equal/:/Due inerzie sono uguali/).test(out1))errs.push(`${tag}: racket symmetric ${out1}`);
 const pts=await pg.locator(`${S} .fq-plot polyline`).count(); if(pts!==3)errs.push(`${tag}: plot lines ${pts}`);
 // paper link and downloads exist
 const href=await pg.locator(`${S} .fq-paper-link`).getAttribute('href'); if(href!=='https://bivector.net')errs.push(`${tag}: link ${href}`);
 // language
 const h3=await pg.locator(`${S} h3`).allTextContents(); if(!h3.includes(lang==='en'?'The translation matrix':'La matrice di traduzione'))errs.push(`${tag}: h3 ${h3}`);
 // layout: nothing wider than the screen
 const sw=await pg.evaluate(()=>document.documentElement.scrollWidth); if(sw>w+1)errs.push(`${tag}: horizontal overflow ${sw}>${w}`);
 // audience: the learner reads the short text
 const short=await pg.locator(`${S} .eq-short`).count(); if((prof==='Young Learner')!==(short===1))errs.push(`${tag}: short reading ${short}`);
 await pg.close();}
await b.close();console.log(errs.length?errs:'FORQUE UI OK');process.exit(errs.length?1:0);
