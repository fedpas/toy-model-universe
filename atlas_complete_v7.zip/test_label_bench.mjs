// Checks of label_bench.html: build determinism, no external request, the page runs the real kernels, the correctness numbers equal node's, the scenarios run (worker and main thread),
// verdict words, the chart, export and compare, layout at 1100 and 375 px in light and dark, Stop. Prints LABEL BENCH OK or exits 1.   node test_label_bench.mjs
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const PAGE = path.join(here, 'label_bench.html'), URL_ = pathToFileURL(PAGE).href;
const SHOTS = process.env.LB_SHOTS || (fs.existsSync('/tmp/claude-0/-home-claude/74388214-b700-5a31-b3ee-04cbd8de9097/scratchpad') ? '/tmp/claude-0/-home-claude/74388214-b700-5a31-b3ee-04cbd8de9097/scratchpad' : os.tmpdir());
const fails = []; let nchecks = 0;
const check = (name, cond, detail = '') => { nchecks++; if (!cond) { fails.push(name + (detail ? ': ' + detail : '')); console.log('FAIL  ' + name + (detail ? ': ' + detail : '')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

// ---------------------------------------------------------------- 1. the build
execFileSync('node', [path.join(here, 'build_label_bench.mjs')], { stdio: 'pipe' });
const h1 = sha(PAGE); const size = fs.statSync(PAGE).size;
execFileSync('node', [path.join(here, 'build_label_bench.mjs')], { stdio: 'pipe' });
check('rebuilding gives an identical file (deterministic)', sha(PAGE) === h1);
check('size under 300 KB', size < 300 * 1024, size + ' bytes');
const html = fs.readFileSync(PAGE, 'utf8');
const urls = [...html.matchAll(/https?:\/\/[^\s'"<>)]+/g)].map(m => m[0]);
check('the only URL in the file is the SVG namespace', urls.every(u => u === 'http://www.w3.org/2000/svg'), urls.join(' '));
for (const bad of ['<script src', '<link', '@import', 'fetch(', 'XMLHttpRequest', 'sendBeacon', 'WebSocket', 'importScripts', 'eval(', 'new Function', 'localStorage']) check('no ' + bad + ' in the page', !html.includes(bad));
check('title is short', /<title>Label speed test<\/title>/.test(html));
// the kernels in the page are the source, line by line
for (const f of ['pgaEngine.js', 'benchKernels.js', 'productKernels.js']) {
  const lines = fs.readFileSync(path.join(here, f), 'utf8').split('\n').filter(l => !/^import\s/.test(l) && l.trim() !== '');
  const missing = lines.filter(l => !html.includes(l.replace(/^export\s+(?=(const|let|function|class)\b)/, '')));
  check('every line of ' + f + ' is in the page (only export/import removed)', missing.length === 0, missing.slice(0, 2).join(' | '));
}
// the variants the page times are the ones runBench times
const BK = await import(pathToFileURL(path.join(here, 'benchKernels.js')).href), E = await import(pathToFileURL(path.join(here, 'pgaEngine.js')).href);
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lb-')), tmpBk = path.join(tmpDir, 'bk.mjs');
fs.writeFileSync(tmpBk, fs.readFileSync(path.join(here, 'benchKernels.js'), 'utf8').replace("from './pgaEngine.js'", "from '" + pathToFileURL(path.join(here, 'pgaEngine.js')).href + "'") + '\nexport { setup };\n');
const BKX = await import(pathToFileURL(tmpBk).href);
const rb = BK.runBench({ ns: [2], minMs: 1, reps: 1 })[0].ns;
const nodeDetail = n => {
  const { A, s, M } = BKX.setup(n), fr = E.frame(A, M, s), D = E.verticesDirect(A, M, s), F = E.verticesFrame(A, M, s, fr); let sum = 0, err = 0;
  for (let v = 0; v < D.length; v++) for (let k = 0; k < n; k++) { sum += D[v][k]; err = Math.max(err, Math.abs(D[v][k] - F[v][k])); }
  return { ok: BK.checkAll(n), sum, maxErr: err };
};

const REF = JSON.parse(fs.readFileSync(path.join(here, 'selfcheck', 'bench_labels.json'), 'utf8')), r6 = REF.rows.find(r => r.n === 6).ns, rr6 = r6.direct.med / r6.frame.med, refRatio6 = rr6.toFixed(rr6 >= 10 ? 1 : 2) + 'x';
const PK = await import(pathToFileURL(path.join(here, 'productKernels.js')).href);

// ---------------------------------------------------------------- browser helpers
const browser = await chromium.launch({ headless: true });
const open = async (ctxOpts = {}, init = null, hash = '') => {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 }, acceptDownloads: true, ...ctxOpts }), page = await ctx.newPage(), errs = [], reqs = [];
  page.on('pageerror', e => errs.push('pageerror: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console.error: ' + m.text()); });
  page.on('request', r => reqs.push(r.url())); if (init) await page.addInitScript(init);
  await page.goto(URL_ + hash); return { ctx, page, errs, reqs };
};
const st = page => page.evaluate(() => { const s = window.__labelBench.state(); return JSON.parse(JSON.stringify({ mode: s.mode, modeNote: s.modeNote, stopped: s.stopped, error: s.error, timerStepMs: s.timerStepMs, cells: s.cells, checks: s.checks, warm: s.warm })); });
const finished = (page, ms = 240000) => page.waitForFunction(() => !document.getElementById('run').disabled, null, { timeout: ms });
const setOnly = async (page, ids) => { for (const id of ['vertices', 'contact', 'outline', 'product', 'bodies', 'warm', 'alloc']) await page.locator('#sc-' + id).setChecked(ids.includes(id)); };
const noOverflow = page => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
// the verdict rule, written again here independently of the page
const verdictOf = (base, cand) => { const r = base.med / cand.med, sp = Math.max((base.max - base.min) / base.med, (cand.max - cand.min) / cand.med), tol = Math.max(0.05, sp); return Math.abs(r - 1) < tol ? 'equal' : r > 1 ? 'faster' : 'slower'; };
const parseCSV = text => text.trim().split('\n').map(l => { const out = []; let cur = '', q = false; for (let i = 0; i < l.length; i++) { const c = l[i]; if (q) { if (c === '"' && l[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; } else if (c === '"') q = true; else if (c === ',') { out.push(cur); cur = ''; } else cur += c; } out.push(cur); return out; });

try {
  // ---------------------------------------------------------------- 2. the Quick preset on every scenario, in a Worker
  {
    const { ctx, page, errs, reqs } = await open();
    check('the page starts with the Quick preset', (await page.getAttribute('#p-quick', 'aria-pressed')) === 'true' && (await page.inputValue('#minMs')) === '20' && (await page.inputValue('#reps')) === '3');
    check('defaults: n from 1 to 8, B = 1000', (await page.inputValue('#nFrom')) === '1' && (await page.inputValue('#nTo')) === '8' && (await page.inputValue('#bodiesB')) === '1000');
    check('Stop is disabled before a run', await page.isDisabled('#stop'));
    check('export buttons disabled before a run', await page.isDisabled('#dl-json') && await page.isDisabled('#dl-csv') && await page.isDisabled('#cp-text'));
    await page.selectOption('#nTo', '4'); await page.selectOption('#prodN', '10');
    check('the product scenario is on by default, up to n = 12', (await page.isChecked('#sc-product')) && (await page.locator('#prodN option[selected]').getAttribute('value')) === '12');
    await page.click('#run');
    check('Run is disabled while running', await page.isDisabled('#run'));
    check('Stop is enabled while running', !(await page.isDisabled('#stop')));
    await finished(page);
    const s = await st(page);
    check('run finished without error', (await page.textContent('#now')).startsWith('Finished') && !s.error, await page.textContent('#now'));
    check('Worker mode ran', s.mode === 'worker' && (await page.textContent('#mode')).includes('Web Worker'), s.mode + ' ' + s.modeNote);
    check('the timer step was measured', typeof s.timerStepMs === 'number' && s.timerStepMs > 0, String(s.timerStepMs));
    for (const id of ['vertices', 'contact', 'outline', 'product', 'bodies', 'warm', 'alloc']) {
      check('section ' + id + ' is shown', await page.locator('#res-' + id).isVisible());
      check('section ' + id + ' has a timings table', (await page.locator('#res-' + id + ' table').count()) >= 1);
      check('section ' + id + ' correctness check passed', (await page.locator('#res-' + id + ' .check.ok').count()) === 1 && (await page.locator('#res-' + id + ' .check.fail').count()) === 0);
    }
    for (const id of ['vertices', 'contact', 'outline', 'product']) { check('SVG chart in ' + id, (await page.locator('#res-' + id + ' .chartbox svg').count()) === 1); check('chart bars carry value text in ' + id, (await page.locator('#res-' + id + ' .chartbox svg text.vl').count()) >= 3); }
    const chips = await page.locator('.chip').allTextContents();
    const allowed = new Set(['▲ faster', '▼ slower', '≈ about equal within noise']);
    check('verdict chips exist and use the plain words only', chips.length > 20 && chips.every(c => allowed.has(c)), [...new Set(chips)].join(' | '));
    check('the word "faster" appears as a verdict', chips.some(c => c.includes('faster')));
    check('the page never says it proved anything', !/proved/i.test((await page.innerText('body')).replace(/not proved/gi, '')));
    check('"timed, not proved" is on the page', /timed, not proved/i.test(await page.innerText('body')));
    check('the how-to-read box and the banner exist', await page.locator('#howto').isVisible());
    // the verdict rule, recomputed here
    const vrows = await page.evaluate(() => [...document.querySelectorAll('#res-vertices table.cmp tbody')][0].innerText);
    const direct = s.cells.vertices;
    const lines = (await page.locator('#res-vertices table.cmp tbody').first().locator('tr').allInnerTexts()).slice(1);
    let ruleOk = lines.length === 4; for (let i = 0; i < lines.length && ruleOk; i++) { const n = i + 1, v = verdictOf(direct[n].direct, direct[n].frame); const word = { faster: 'faster', slower: 'slower', equal: 'about equal within noise' }[v]; ruleOk = lines[i].includes(word); if (!ruleOk) console.log('verdict mismatch at n=' + n, v, lines[i]); }
    check('the page verdicts equal the rule recomputed in the test (frame against direct, n = 1..4)', ruleOk, vrows.slice(0, 80));
    check('spread is shown for every timing', (await page.locator('#res-vertices td .r').count()) > 20);
    check('noisy rows carry a visible warning when the spread exceeds 15%', await page.evaluate(() => { const s = window.__labelBench.state(); let need = 0; for (const n of Object.keys(s.cells.vertices)) for (const v of Object.values(s.cells.vertices[n])) if ((v.max - v.min) / v.med > 0.15) need++; return need === 0 || document.querySelectorAll('#res-vertices .noisy, #res-vertices td .r').length > 0 && document.body.innerText.includes('noisy'); }));
    check('machine panel shows the user agent, processors, mode and version', /HeadlessChrome|Chrome/.test(await page.innerText('#machine')) && /Logical processors/.test(await page.innerText('#machine')) && /Web Worker/.test(await page.innerText('#machine')) && /1\.1\.0/.test(await page.innerText('#machine')));
    check('timer note: coarse or fine, the timer is reported', /Timer step/.test(await page.innerText('#machine')));
    // correctness numbers: the page's (computed in the worker) against node's
    for (const n of [1, 2, 3, 4]) { const w = s.checks.vertices[n], nd = nodeDetail(n); check('worker check n=' + n + ' equals node checkAll', w && w.ok === true && nd.ok === true && Math.abs(w.sum - nd.sum) <= 1e-9 * Math.max(1, Math.abs(nd.sum)) && Math.abs(w.maxErr - nd.maxErr) <= 1e-12, JSON.stringify([w, nd])); }
    // all of n = 1..8 on the main thread of the page (the same code), against node
    const pageChecks = await page.evaluate(() => [1, 2, 3, 4, 5, 6, 7, 8].map(n => LBCORE.checkDetail(n)));
    for (const n of [1, 2, 3, 4, 5, 6, 7, 8]) { const p = pageChecks[n - 1], nd = nodeDetail(n); check('page check n=' + n + ' equals node checkAll (ok, vertex sum, |direct-frame|)', p.ok === nd.ok && p.ok === true && Math.abs(p.sum - nd.sum) <= 1e-9 * Math.max(1, Math.abs(nd.sum)) && Math.abs(p.maxErr - nd.maxErr) <= 1e-12, JSON.stringify([p, nd])); }
    check('the page times the same variants as runBench', JSON.stringify((await page.evaluate(() => LBCORE.VARIANT_KEYS)).slice().sort()) === JSON.stringify(Object.keys(rb).sort()));
    check('the page cell for direct n=4 is a positive time in ns', s.cells.vertices[4].direct.med > 0 && s.cells.vertices[4].direct.min <= s.cells.vertices[4].direct.med && s.cells.vertices[4].direct.med <= s.cells.vertices[4].direct.max);
    check('many-bodies cells: 7 variants', Object.keys(s.cells.bodies.scene).length === 7);
    check('warm-up: 6 targets, 3 cold runs each, a steady state each', Object.keys(s.warm.cold).length === 6 && Object.values(s.warm.cold).every(a => a.length === 3) && Object.keys(s.warm.steady).length === 6 && s.warm.fresh === true);
    check('allocation cells: 4 sizes and the loop', ['a8', 'a16', 'a32', 'a64', 'loop'].every(k => s.cells.alloc[k]));

    // export
    const [dj] = await Promise.all([page.waitForEvent('download'), page.click('#dl-json')]);
    const json = JSON.parse(fs.readFileSync(await dj.path(), 'utf8'));
    check('JSON: valid, with rows, settings, machine, mode, checks', Array.isArray(json.rows) && json.rows.length === 4 && json.rows.every(r => r.ns && r.ns.direct && r.ns.frame && r.ns.direct.med > 0) && json.settings.minMs === 20 && json.settings.reps === 3 && json.machine.userAgent && json.mode === 'worker' && json.checks.vertices['1'].ok === true && json.format === 'label-bench');
    check('JSON: the product cells are there', json.product && [2, 4, 6, 8, 10].every(n => json.product.ns[n] && json.product.ns[n].bitRule && json.product.ns[n].matrixRoute) && json.product.ns[10].period8 && !json.product.ns[8].period8);
    check('JSON: other scenarios present', json.bodies && json.bodies.ns.buildFrame && json.warmup && json.warmup.targets.direct.runs.length === 3 && json.alloc && json.alloc.a16.plain);
    check('JSON file name', /^label-bench-\d{8}-\d{4}\.json$/.test(dj.suggestedFilename()), dj.suggestedFilename());
    const [dc] = await Promise.all([page.waitForEvent('download'), page.click('#dl-csv')]);
    const csv = parseCSV(fs.readFileSync(await dc.path(), 'utf8'));
    check('CSV: non-empty, header, 10 columns everywhere', csv.length > 40 && csv[0].join() === 'kind,scenario,key,name,median_ns,min_ns,max_ns,spread,ratio,verdict' && csv.every(r => r.length === 10), csv.length + ' rows');
    check('CSV: ratio rows carry a verdict word', csv.filter(r => r[0] === 'ratio' && r[1] === 'vertices').every(r => ['faster', 'slower', 'equal'].includes(r[9])));
    await page.click('#cp-text');
    await page.waitForFunction(() => document.getElementById('exp-msg').textContent.length > 0);
    const text = await page.inputValue('#textOut');
    check('text summary is readable and honest', /VERTICES/.test(text) && /timed, not proved/i.test(text) && /about equal within noise|faster|slower/.test(text) && text.split('\n').length > 30);
    // compare
    await page.click('#cmp-ref');
    check('compare with the embedded reference run renders', (await page.locator('#cmp-out table.cmp tbody').count()) >= 6 && /reference run on one 2-core VM, node 22/.test(await page.innerText('#cmp-out')) && new RegExp(refRatio6.replace('.', '\\.')).test(await page.innerText('#cmp-out')));
    check('compare shows the ratio between the two ratios for a common n', /\b\d\.\d\d\b/.test(await page.locator('#cmp-out table.cmp tbody').first().locator('tr').nth(4).innerText()));
    await page.click('#cmp-clear'); check('compare can be cleared', (await page.locator('#cmp-out table').count()) === 0);
    await page.setInputFiles('#cmp-file', { name: 'run.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(json)) });
    await page.waitForFunction(() => document.getElementById('cmp-out').querySelector('table'));
    check('compare with a downloaded JSON renders', (await page.locator('#cmp-out table.cmp').count()) === 1 && /1\.00/.test(await page.innerText('#cmp-out')));
    await page.setInputFiles('#cmp-file', { name: 'bad.json', mimeType: 'application/json', buffer: Buffer.from('{"x":1}') });
    await page.waitForFunction(() => /Could not/.test(document.getElementById('cmp-msg').textContent));
    check('a wrong file gives a plain message', true);

    // layout: 1100 and 375, light and dark
    const shot = async name => { await page.locator('#res-vertices').screenshot({ path: path.join(SHOTS, 'lb_test_' + name + '.png') }); await page.screenshot({ path: path.join(SHOTS, 'lb_test_top_' + name + '.png') }); };
    for (const [w, scheme] of [[1100, 'light'], [1100, 'dark'], [375, 'light'], [375, 'dark'], [360, 'light']]) {
      await page.setViewportSize({ width: w, height: 900 }); await page.emulateMedia({ colorScheme: scheme }); await sleep(450);
      check('no horizontal page scroll at ' + w + ' px, ' + scheme, await noOverflow(page), await page.evaluate(() => document.documentElement.scrollWidth + ' > ' + innerWidth));
      check('charts redrawn at ' + w + ' px', (await page.locator('.chartbox svg').count()) === 4 && (await page.locator('.chartbox svg').first().evaluate(e => e.getBoundingClientRect().width)) <= w);
      const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor); check('explicit dark/light body background at ' + scheme, scheme === 'dark' ? /rgb\(20, 20, 19\)/.test(bg) : /rgb\(252, 252, 251\)/.test(bg), bg);
      check('16 px side gutters at ' + w, await page.evaluate(() => { const r = document.querySelector('.wrap').getBoundingClientRect(); return r.left >= 0 && getComputedStyle(document.querySelector('.wrap')).paddingLeft === '16px'; }));
      await shot(w + '_' + scheme);
    }
    // keyboard: a control has a visible focus style and labels exist
    check('every select and checkbox has a label', await page.evaluate(() => [...document.querySelectorAll('select, input[type=checkbox], input[type=file]')].every(e => e.labels && e.labels.length > 0)));
    check('aria-live polite region exists', (await page.getAttribute('#status', 'aria-live')) === 'polite');
    check('no request left the file (only file:, blob:, data:)', reqs.every(u => /^(file|blob|data):/.test(u)), reqs.filter(u => !/^(file|blob|data):/.test(u)).join(' '));
    check('no page error and no console error (main run)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }

  // ---------------------------------------------------------------- 2b. the product scenario alone, up to n = 12
  {
    const { ctx, page, errs } = await open();
    await setOnly(page, ['product']); await page.selectOption('#prodN', '12');
    check('the product warning at n = 12 is shown and mentions the sign table', await page.locator('#warn-n').isVisible() && /16 MB/.test(await page.innerText('#warn-n')));
    await page.selectOption('#prodN', '14'); check('the n = 14 warning says the sign table is left out', /268 MB/.test(await page.innerText('#warn-n')) && /left out/.test(await page.innerText('#warn-n')));
    await page.selectOption('#prodN', '12');
    await page.click('#run'); await finished(page, 300000);
    const s = await st(page), c = s.cells.product;
    check('product run finished without error, in a Worker', (await page.textContent('#now')).startsWith('Finished') && !s.error && s.mode === 'worker', await page.textContent('#now'));
    check('product cells for n = 2, 4, 6, 8, 10, 12', Object.keys(c).map(Number).join() === '2,4,6,8,10,12');
    check('every n has the four plain variants; period 8 only from n = 10', [2, 4, 6, 8, 10, 12].every(n => ['bitRule', 'signTable', 'matmulGiven', 'matrixRoute'].every(v => c[n][v] && c[n][v].med > 0) && (n >= 10) === !!c[n].period8));
    // the page's correctness numbers (computed in the worker) equal node's, exactly
    let same = true; for (const n of [2, 4, 6, 8, 10, 12]) { const w = s.checks.product[n], nd = PK.productCheck(n); if (!(w && w.ok && nd.ok && w.checksum === nd.checksum && w.terms === nd.terms)) { same = false; console.log('product check differs at n =', n, JSON.stringify([w, nd])); } }
    check('the page and node give the same exact checksums for n = 2..12', same);
    check('the correctness line says what was compared', /same integer coefficients, compared exactly/.test(await page.innerText('#res-product .check')) && /16 × 16 blocks/.test(await page.innerText('#res-product .check')));
    check('the product table has a row for every n and a dash where a variant does not apply', (await page.locator('#res-product table.stack tbody tr').count()) === 6 && /–/.test(await page.locator('#res-product table.stack tbody tr').first().innerText()));
    check('row labels carry the operation counts (4^n terms against 8^k multiplications)', /16 terms vs 8 multiplications/.test(await page.locator('#res-product table.stack tbody tr').first().innerText()) && /17 M terms vs 262 k multiplications/.test(await page.locator('#res-product table.stack tbody tr').last().innerText()));
    // the verdict rule, recomputed here, for the matrix route against the sign table
    const grp = (await page.locator('#res-product table.cmp tbody').first().locator('tr').allInnerTexts()).slice(1);
    let rule = grp.length === 6; for (let i = 0; i < grp.length && rule; i++) { const n = [2, 4, 6, 8, 10, 12][i], v = verdictOf(c[n].signTable, c[n].matrixRoute); rule = grp[i].includes({ faster: 'faster', slower: 'slower', equal: 'about equal within noise' }[v]); if (!rule) console.log('product verdict mismatch at n =', n, v, grp[i]); }
    check('the page verdicts equal the rule recomputed here (matrix route against the sign table)', rule);
    // robust measured facts: the plain bit rule loses by a wide margin at n = 12 and wins at n = 2; the gain grows with n
    const q = n => c[n].bitRule.med / c[n].matrixRoute.med, qt = n => c[n].signTable.med / c[n].matrixRoute.med;
    check('at n = 12 the matrix route is at least 10 times faster than the plain bit rule', q(12) > 10, String(q(12)));
    check('at n = 2 the matrix route is slower than the sign-table bit rule (conversion costs more than it saves)', qt(2) < 1, String(qt(2)));
    check('the gain over the sign table grows from n = 8 to n = 12', qt(12) > qt(8), qt(8) + ' ' + qt(12));
    check('the chart has bars for the sign-table and plain-rule series', (await page.locator('#res-product .chartbox svg text.vl').count()) >= 10 && /hatched: against the plain rule/.test(await page.innerText('#res-product .legend')));
    check('the note says where the matrix route stops paying', /the bit rule is the faster one/.test(await page.innerText('#res-product')));
    const csv = await page.evaluate(() => window.__labelBench.buildCSV());
    check('CSV has product timings and ratios', /^timing,product,12,matrixRoute,/m.test(csv) && /^ratio,product,12,signTable\/matrixRoute,/m.test(csv) && /^ratio,product,10,signTable\/period8,/m.test(csv));
    const txt = await page.evaluate(() => window.__labelBench.buildText());
    check('the text summary has the product section', /PRODUCT: BIT RULE AGAINST MATRIX ROUTE/.test(txt) && /matrix route is [\d.]+x faster/.test(txt));
    // layout at 375 px
    await page.setViewportSize({ width: 375, height: 900 }); await sleep(400);
    check('no horizontal page scroll at 375 px with the product table', await noOverflow(page));
    await page.locator('#res-product').screenshot({ path: path.join(SHOTS, 'lb_test_product_375.png') });
    check('no errors (product run)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }

  // ---------------------------------------------------------------- 3. Stop in Worker mode
  {
    const { ctx, page, errs } = await open();
    await setOnly(page, ['vertices']); await page.selectOption('#minMs', '60'); await page.selectOption('#reps', '7'); await page.selectOption('#nTo', '8');
    check('presets follow the selects', (await page.getAttribute('#p-quick', 'aria-pressed')) === 'false' && (await page.getAttribute('#p-careful', 'aria-pressed')) === 'false');
    await page.click('#p-careful'); check('Careful preset sets 200 ms and 15 repetitions', (await page.inputValue('#minMs')) === '200' && (await page.inputValue('#reps')) === '15');
    await page.click('#p-quick'); await page.selectOption('#minMs', '60'); await page.selectOption('#reps', '7');
    await page.click('#run');
    await page.waitForFunction(() => { const s = window.__labelBench.state(); return s.cells.vertices && Object.keys(s.cells.vertices).length > 0; }, null, { timeout: 60000 });
    const t0 = Date.now(); await page.click('#stop');
    await finished(page, 8000);
    const dt = Date.now() - t0, c1 = Object.keys((await st(page)).cells.vertices || {}).length;
    check('Stop in Worker mode returns quickly', dt < 3000, dt + ' ms');
    check('Stop says so and keeps the partial rows', /Stopped/.test(await page.textContent('#now')) && (await st(page)).stopped === true && (await page.locator('#res-vertices table').count()) >= 1 && /stopped/i.test(await page.innerText('#banner')));
    check('exports stay available after Stop', !(await page.isDisabled('#dl-json')));
    const nCells = async () => (await page.evaluate(() => { const s = window.__labelBench.state(); return Object.values(s.cells.vertices || {}).reduce((a, r) => a + Object.keys(r).length, 0); }));
    const a = await nCells(); await sleep(1500); const b = await nCells();
    check('nothing is timed after Stop', a === b && a > 0 && a < 8 * 6, a + ' ' + b);
    // a second run after Stop works
    await page.selectOption('#nTo', '2'); await page.click('#run'); await finished(page);
    check('a new run after Stop works', /Finished/.test(await page.textContent('#now')) && (await st(page)).stopped === false);
    // n >= 9 warning
    await page.selectOption('#nTo', '10'); check('n >= 9 shows the warning about direct', await page.locator('#warn-n').isVisible() && /direct/.test(await page.innerText('#warn-n')));
    await page.selectOption('#nTo', '4'); check('the warning goes away', !(await page.locator('#warn-n').isVisible()));
    check('no errors (stop test)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }

  // ---------------------------------------------------------------- 4. the main-thread fallback: forced by #main, and by a Worker that cannot be created
  for (const [label, init, hash] of [['forced by #main', null, '#main'], ['Worker construction fails', () => { window.Worker = function () { throw new Error('blocked by the test'); }; }, '']]) {
    const { ctx, page, errs } = await open({}, init, hash);
    await page.selectOption('#nTo', '3'); await page.selectOption('#prodN', '8'); await page.click('#run'); await finished(page);
    const s = await st(page);
    check('fallback (' + label + '): main thread ran and says so', s.mode === 'main' && /main thread/.test(await page.textContent('#mode')) && s.modeNote.length > 0, s.mode + ' ' + s.modeNote + ' | ' + (s.error || ''));
    check('fallback (' + label + '): the reason is shown', label.includes('#main') ? /#main/.test(s.modeNote) : /could not be started/.test(s.modeNote) && /blocked by the test/.test(s.modeNote), s.modeNote);
    check('fallback (' + label + '): finished with results in every scenario', /Finished/.test(await page.textContent('#now')) && (await page.locator('.chip').count()) > 10 && (await page.locator('.chartbox svg').count()) === 4 && (await page.locator('#res-warm table').count()) === 1);
    check('fallback (' + label + '): warm-up is flagged as not a cold start', /Main-thread mode/.test(await page.innerText('#res-warm')) && s.warm.fresh === false && Object.values(s.warm.cold).every(a => a.length === 1));
    check('fallback (' + label + '): correctness check passed in all seven', (await page.locator('.check.ok').count()) === 7);
    check('no errors (fallback ' + label + ')', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }
  // Stop in main-thread mode
  {
    const { ctx, page, errs } = await open({}, null, '#main');
    await setOnly(page, ['vertices']); await page.selectOption('#nTo', '8'); await page.click('#run');
    await page.waitForFunction(() => { const s = window.__labelBench.state(); return s.cells.vertices && Object.keys(s.cells.vertices).length > 1; }, null, { timeout: 60000 });
    const t0 = Date.now(); await page.click('#stop'); await finished(page, 20000);
    check('Stop in main-thread mode returns after the current timing', Date.now() - t0 < 8000 && /Stopped/.test(await page.textContent('#now')) && (await st(page)).stopped === true, (Date.now() - t0) + ' ms');
    check('no errors (main-thread stop)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }
} finally { await browser.close(); fs.rmSync(tmpDir, { recursive: true, force: true }); }

if (fails.length) { console.log('\n' + fails.length + ' of ' + nchecks + ' checks failed'); process.exit(1); }
console.log(nchecks + ' checks passed; screenshots in ' + SHOTS);
console.log('LABEL BENCH OK');
