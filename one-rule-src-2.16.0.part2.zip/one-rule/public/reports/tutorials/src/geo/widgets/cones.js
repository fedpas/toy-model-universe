(function (id) {
  // The defects of an edge cone of angle 2 pi beta: the Euler integral chi(M) - (1 - beta) chi(Sigma) on S^4 > S^2, S^2 x football and
  // CP^2 > CP^1, the signature integral tau(M) - (1/3)(1 - beta^2)[Sigma]^2 on CP^2 > CP^1 (tau = [Sigma]^2 = -1 in the chart's orientation),
  // and the Einstein constant (3/2) beta^2 (2 - beta) of the self-dual Einstein cones. Exact fractions at the preset values.
  const el = document.getElementById(id); if (!el) return;
  const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
  const Q = (n, d = 1) => { if (d < 0) { n = -n; d = -d; } const g = gcd(n, d); return [n / g, d / g]; };
  const add = (x, y) => Q(x[0] * y[1] + y[0] * x[1], x[1] * y[1]), sub = (x, y) => add(x, [-y[0], y[1]]);
  const mul = (x, y) => Q(x[0] * y[0], x[1] * y[1]), eq = (x, y) => x[0] === y[0] && x[1] === y[1];
  const txt = x => (x[1] === 1 ? String(x[0]) : x[0] + '/' + x[1]).replace('-', '−');
  const one = Q(1), two = Q(2), three = Q(3);
  const F = {                                  // the four defects and the Einstein constant, as functions of beta
    s4: b => sub(two, mul(sub(one, b), two)),               // chi(S^4) - (1 - b) chi(S^2)
    fb: b => sub(Q(4), mul(sub(one, b), Q(4))),             // chi(S^2 x S^2) - (1 - b) chi(two spheres)
    cp: b => sub(three, mul(sub(one, b), two)),             // chi(CP^2) - (1 - b) chi(CP^1)
    sg: b => sub(Q(-1), mul(Q(1, 3), mul(sub(one, mul(b, b)), Q(-1)))),   // tau - (1/3)(1 - b^2)[Sigma]^2, tau = [Sigma]^2 = -1
    ei: b => mul(Q(3, 2), mul(mul(b, b), sub(two, b)))     // the Einstein constant of the self-dual cones
  };
  // self-test: the exact values that checks/selfcheck/gravity/logs/aty_cone_defects.log prints (aty_cone_defects.py)
  const LOG = [['s4', [1, 3], [2, 3]], ['s4', [1, 2], [1, 1]], ['s4', [2, 3], [4, 3]], ['s4', [2, 1], [4, 1]], ['s4', [3, 1], [6, 1]],
    ['fb', [1, 3], [4, 3]], ['fb', [1, 2], [2, 1]], ['fb', [2, 3], [8, 3]], ['fb', [2, 1], [8, 1]], ['fb', [3, 1], [12, 1]],
    ['cp', [1, 1], [3, 1]], ['cp', [1, 3], [5, 3]], ['cp', [1, 2], [2, 1]], ['cp', [2, 1], [5, 1]],
    ['sg', [1, 1], [-1, 1]], ['sg', [1, 3], [-19, 27]], ['sg', [1, 2], [-3, 4]], ['sg', [2, 1], [-2, 1]],
    ['ei', [25, 81], [85625, 354294]], ['ei', [49, 25], [7203, 31250]], ['ei', [1024, 2025], [1586495488, 2767921875]], ['ei', [81, 256], [8483373, 33554432]],
    ['ei', [2025, 1024], [282943125, 2147483648]], ['ei', [49, 100], [1087653, 2000000]], ['ei', [1024, 625], [355467264, 244140625]], ['ei', [1, 1], [3, 2]]];
  const bad = LOG.filter(([k, b, v]) => !eq(F[k](Q(b[0], b[1])), Q(v[0], v[1])));
  if (bad.length) { el.textContent = 'self-test failed: ' + bad.length + ' of ' + LOG.length + ' logged values differ'; return; }

  const PRESETS = [[1, 3], [1, 2], [2, 3], [1, 1], [2, 1], [3, 1]];
  el.innerHTML = '<div><label>β <input type="range" min="0.05" max="3" step="0.01" value="0.5" aria-label="beta, the cone angle over 2 pi"></label> <span class="cw-b"></span></div>' +
    '<div class="cw-p"></div><svg viewBox="0 0 320 170" width="320" height="170" role="img" aria-label="the four defects against beta"></svg><p class="widget__out" aria-live="polite"></p>';
  const r = el.querySelector('input'), sb = el.querySelector('.cw-b'), pr = el.querySelector('.cw-p'), svg = el.querySelector('svg'), out = el.querySelector('.widget__out');
  let exact = Q(1, 2);
  PRESETS.forEach(p => { const b = document.createElement('button'); b.type = 'button'; b.textContent = 'β = ' + txt(Q(p[0], p[1])); b.style.margin = '2px 4px 2px 0';
    b.addEventListener('click', () => { exact = Q(p[0], p[1]); r.value = String(p[0] / p[1]); show(); }); pr.appendChild(b); });
  r.addEventListener('input', () => { exact = null; show(); });
  const X = b => 34 + 270 * b / 3, Y = v => 150 - 130 * (v + 4) / 17;     // v from -4 to 13
  function chart(bf) {
    let s = '';
    for (const v of [-4, 0, 4, 8, 12]) s += `<line x1="34" y1="${Y(v)}" x2="304" y2="${Y(v)}" stroke="currentColor" stroke-opacity=".15"/><text x="30" y="${Y(v) + 4}" font-size="11" text-anchor="end" fill="currentColor" fill-opacity=".7">${String(v).replace('-', '−')}</text>`;
    for (const b of [0, 1, 2, 3]) s += `<text x="${X(b)}" y="166" font-size="11" text-anchor="middle" fill="currentColor" fill-opacity=".7">${b}</text>`;
    const curve = (fn, col) => { let d = ''; for (let i = 0; i <= 60; i++) { const b = 3 * i / 60; d += (i ? 'L' : 'M') + X(b).toFixed(1) + ' ' + Y(fn(b)).toFixed(1); } return `<path d="${d}" fill="none" stroke="${col}" stroke-width="2"/>`; };
    s += curve(b => 4 * b, '#2a78d6') + curve(b => 2 * b, '#eb6834') + curve(b => 1 + 2 * b, '#1baf7a') + curve(b => -(2 + b * b) / 3, '#6250d6');
    s += `<line x1="${X(bf)}" y1="10" x2="${X(bf)}" y2="150" stroke="currentColor" stroke-dasharray="3 3"/>`;
    for (const [fn, col] of [[b => 4 * b, '#2a78d6'], [b => 2 * b, '#eb6834'], [b => 1 + 2 * b, '#1baf7a'], [b => -(2 + b * b) / 3, '#6250d6']]) s += `<circle cx="${X(bf)}" cy="${Y(fn(bf))}" r="4" fill="${col}"/>`;
    svg.innerHTML = s;
  }
  function show() {
    const bf = exact ? exact[0] / exact[1] : +r.value;
    sb.textContent = exact ? txt(exact) : bf.toFixed(2);
    const v = k => exact ? txt(F[k](exact)) : (k === 's4' ? 2 * bf : k === 'fb' ? 4 * bf : k === 'cp' ? 1 + 2 * bf : k === 'sg' ? -(2 + bf * bf) / 3 : 1.5 * bf * bf * (2 - bf)).toFixed(4).replace('-', '−');
    out.textContent = [
      'the cone angle is 2πβ along Σ; β = 1 is no cone',
      'Euler, S⁴ ⊃ S²: 2 − 2(1 − β) = 2β = ' + v('s4') + ' (orange)',
      'Euler, S² × football: 4 − 4(1 − β) = 4β = ' + v('fb') + ' (blue)',
      'Euler, CP² ⊃ CP¹: 3 − 2(1 − β) = 1 + 2β = ' + v('cp') + ' (green)',
      'signature, CP² ⊃ CP¹: τ − (1 − β²)[Σ]²/3 = τ(2 + β²)/3 = ' + v('sg') + ' (violet; τ = [Σ]² = −1)',
      'self-dual Einstein cone: the Einstein constant (3/2)β²(2 − β) = ' + v('ei')
    ].join('\n');
    chart(bf);
  }
  show();
})
