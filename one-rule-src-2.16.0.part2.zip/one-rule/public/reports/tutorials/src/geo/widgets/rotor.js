(function (id) {
  // Two mirrors make a turn: two lines through the origin of the plane, the reflections x -> -n x n in their unit normals, and the rotor
  // R = n2 n1, all computed by the bit rule in Cl(2,0). Mirror 2 is followed continuously: after half a turn of mirror 2 its line is back
  // where it was, the turn of the plane is a full turn, and R has become -R.
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  function mul(x, y, eps) { const o = new Map(); for (const [a, ca] of x) for (const [b, cb] of y) { const s = sign(a, b, eps); if (s) o.set(a ^ b, (o.get(a ^ b) || 0) + s * ca * cb); } return o; }
  const vec = (u, v) => new Map([[1, u], [2, v]]);
  const get = (x, k) => x.get(k) || 0;
  function mirror(a, x, eps) {          // x -> -a x a^-1, a^-1 = a / (a a)
    const aa = get(mul(a, a, eps), 0), ai = new Map([...a].map(([k, v]) => [k, v / aa]));
    return new Map([...mul(mul(a, x, eps), ai, eps)].map(([k, v]) => [k, -v]));
  }
  // self-test 1: ten products of checks/selfcheck/steps15_17/bitcliff.py (figs_geo.py --products): [squares, a, b, sign, label]
  const STORED = [[[1, 1, 1], 3, 6, 1, 5], [[1, 1, 1], 7, 2, -1, 5], [[-1, -1], 3, 3, -1, 0], [[1, -1, -1, -1], 15, 6, -1, 9], [[1, 1, 1, 1], 15, 5, 1, 10],
    [[1, 1, 0], 7, 4, 0, 3], [[1, 1, 0], 7, 3, -1, 4], [[0, 0, 0], 1, 6, 1, 7], [[0, 0, 0], 5, 2, -1, 7], [[1, -1, 1, -1], 11, 13, 1, 6]];
  let fail = STORED.filter(([eps, a, b, s, c]) => sign(a, b, eps) !== s || (a ^ b) !== c).length;
  // self-test 2: the example of checks/selfcheck/mirrors.json: in Cl(0,2) the mirrors with normals (8/5, -4/5) then (2, 0) give ((3/5, -4/5), (4/5, 3/5))
  const M = [0, 1].map(i => mirror(vec(2, 0), mirror(vec(8 / 5, -4 / 5), vec(i === 0 ? 1 : 0, i === 1 ? 1 : 0), [-1, -1]), [-1, -1]));
  const want = [[3 / 5, -4 / 5], [4 / 5, 3 / 5]];
  if (Math.abs(get(M[0], 1) - want[0][0]) > 1e-12 || Math.abs(get(M[0], 2) - want[1][0]) > 1e-12 || Math.abs(get(M[1], 1) - want[0][1]) > 1e-12 || Math.abs(get(M[1], 2) - want[1][1]) > 1e-12) fail++;
  if (fail) { el.textContent = 'self-test failed: ' + fail + ' stored value(s) differ from the rule'; return; }

  const E = [1, 1];                       // Cl(2,0)
  el.innerHTML = '<div><label>mirror 1 at <input type="range" min="0" max="180" step="1" value="10" aria-label="angle of mirror 1"></label> <span class="rw-a1"></span></div>' +
    '<div><label>mirror 2 at <input type="range" min="0" max="360" step="1" value="40" aria-label="angle of mirror 2"></label> <span class="rw-a2"></span></div>' +
    '<div><button type="button">turn mirror 2 by 180°</button></div>' +
    '<svg viewBox="0 0 300 230" width="300" height="230" role="img" aria-label="the two mirrors, a vector and its images"></svg>' +
    '<p class="widget__out" aria-live="polite"></p>';
  const [r1, r2] = el.querySelectorAll('input'), b = el.querySelector('button'), svg = el.querySelector('svg'), out = el.querySelector('.widget__out');
  const s1 = el.querySelector('.rw-a1'), s2 = el.querySelector('.rw-a2');
  const deg = Math.PI / 180, f3 = v => (Math.abs(v) < 5e-10 ? 0 : v).toFixed(3).replace('-', '−');
  function show() {
    const a1 = +r1.value, a2 = +r2.value;
    s1.textContent = a1 + '°'; s2.textContent = a2 + '°';
    // unit normals, followed continuously: the line at angle t has the normal (-sin t, cos t)
    const n1 = vec(-Math.sin(a1 * deg), Math.cos(a1 * deg)), n2 = vec(-Math.sin(a2 * deg), Math.cos(a2 * deg));
    const x = vec(Math.cos(-25 * deg), Math.sin(-25 * deg));
    const x1 = mirror(n1, x, E), x2 = mirror(n2, x1, E);
    const R = mul(n2, n1, E);                                      // the rotor: scalar part n2.n1, e12 part n2 ^ n1
    const Rr = new Map([[0, get(R, 0)], [3, -get(R, 3)]]);          // its reverse
    const y = mul(mul(R, x, E), Rr, E);                              // R x R~ = x''
    const RR = get(mul(R, Rr, E), 0);
    const turn = 2 * (a2 - a1);
    const C = 150, S = 92, P = v => [C + S * get(v, 1), 115 - S * get(v, 2)];
    const line = (t, cls) => `<line x1="${C - 105 * Math.cos(t * deg)}" y1="${115 + 105 * Math.sin(t * deg)}" x2="${C + 105 * Math.cos(t * deg)}" y2="${115 - 105 * Math.sin(t * deg)}" stroke="currentColor" stroke-opacity=".55" stroke-dasharray="5 3"/>`;
    const arr = (v, col, w, dash) => { const [px, py] = P(v); return `<line x1="${C}" y1="115" x2="${px}" y2="${py}" stroke="${col}" stroke-width="${w}"${dash ? ' stroke-dasharray="4 3"' : ''}/><circle cx="${px}" cy="${py}" r="3.5" fill="${col}"/>`; };
    const [nx1, ny1] = P(vec(0.35 * get(n1, 1), 0.35 * get(n1, 2))), [nx2, ny2] = P(vec(0.35 * get(n2, 1), 0.35 * get(n2, 2)));
    const [tx, ty] = P(x), [t1x, t1y] = P(x1), [t2x, t2y] = P(x2);
    svg.innerHTML = `<circle cx="${C}" cy="115" r="${S}" fill="none" stroke="currentColor" stroke-opacity=".2"/>` + line(a1) + line(a2) +
      `<line x1="${C}" y1="115" x2="${nx1}" y2="${ny1}" stroke="currentColor" stroke-width="1.5"/><line x1="${C}" y1="115" x2="${nx2}" y2="${ny2}" stroke="currentColor" stroke-width="1.5"/>` +
      `<text x="${nx1 + 4}" y="${ny1 - 4}" font-size="12" fill="currentColor">n₁</text><text x="${nx2 + 4}" y="${ny2 - 4}" font-size="12" fill="currentColor">n₂</text>` +
      arr(x, 'currentColor', 2) + arr(x1, '#888888', 1.6, true) + arr(x2, '#2a78d6', 2.6) +
      `<text x="${tx + 6}" y="${ty + 4}" font-size="13" fill="currentColor">x</text><text x="${t1x + 6}" y="${t1y + 4}" font-size="13" fill="#888888">x′</text>` +
      `<text x="${t2x + 6}" y="${t2y + 4}" font-size="13" fill="#2a78d6" font-weight="700">x″</text>`;
    out.textContent = [
      'n₁ = (' + f3(get(n1, 1)) + ', ' + f3(get(n1, 2)) + '),  n₂ = (' + f3(get(n2, 1)) + ', ' + f3(get(n2, 2)) + ')   unit normals, Cl(2,0)',
      'R = n₂ n₁ = ' + f3(get(R, 0)) + ' + (' + f3(get(R, 3)) + ') e₁₂   by the bit rule;  R R̃ = ' + f3(RR),
      'x″ = R x R̃ = (' + f3(get(y, 1)) + ', ' + f3(get(y, 2)) + '), the two mirrors give (' + f3(get(x2, 1)) + ', ' + f3(get(x2, 2)) + ')',
      'the mirrors are ' + ((a2 - a1) % 180 + 180) % 180 + '° apart; the plane turns by 2(α₂ − α₁) = ' + turn + '° ≡ ' + (((turn % 360) + 360) % 360) + '°',
      (Math.abs(((a2 - a1) % 180)) === 0 ? (Math.abs(get(R, 0) + 1) < 1e-9 ? 'the lines coincide, the turn is the identity, and R = −1: the rotor of a full turn' : (Math.abs(get(R, 0) - 1) < 1e-9 ? 'the lines coincide and R = +1: no turn' : '')) : 'R = cos θ − sin θ e₁₂ with θ = α₂ − α₁ = ' + (a2 - a1) + '°, and R(θ + 180°) = −R(θ)')
    ].join('\n');
  }
  r1.addEventListener('input', show); r2.addEventListener('input', show);
  b.addEventListener('click', () => { const v = +r2.value; r2.value = String(v + 180 <= 360 ? v + 180 : v - 180); show(); });
  show();
})
