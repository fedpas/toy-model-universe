(function (id) {
  // The Hodge complement on the labels: pick the squares of the generators and a blade e_a; the widget shows the complement
  // a xor 1...1, the sign sigma(a) of the permutation (a, complement), and the products I e_a and e_a I computed by the bit rule.
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  // self-test: ten products of checks/selfcheck/steps15_17/bitcliff.py (figs_geo.py --products): [squares, a, b, sign, label of the product]
  const STORED = [[[1, 1, 1], 3, 6, 1, 5], [[1, 1, 1], 7, 2, -1, 5], [[-1, -1], 3, 3, -1, 0], [[1, -1, -1, -1], 15, 6, -1, 9], [[1, 1, 1, 1], 15, 5, 1, 10],
    [[1, 1, 0], 7, 4, 0, 3], [[1, 1, 0], 7, 3, -1, 4], [[0, 0, 0], 1, 6, 1, 7], [[0, 0, 0], 5, 2, -1, 7], [[1, -1, 1, -1], 11, 13, 1, 6]];
  const bad = STORED.filter(([eps, a, b, s, c]) => sign(a, b, eps) !== s || (a ^ b) !== c);
  if (bad.length) { el.textContent = 'self-test failed: ' + bad.length + ' of ' + STORED.length + ' stored products differ from the rule'; return; }

  const SUB = '₀₁₂₃₄₅₆₇₈₉';
  const blade = (a, n) => a === 0 ? '1' : 'e' + [...Array(n).keys()].filter(i => (a >> i) & 1).map(i => SUB[i + 1]).join('');
  const bits = (a, n) => [...Array(n).keys()].map(i => ((a >> i) & 1) ? '1' : '0').join('');
  const sgn = s => (s === 1 ? '+' : s === -1 ? '−' : '');
  const SQ = { '1': '+1', '-1': '−1', '0': '0' };
  let n = 3, eps = [1, 1, 1], a = 0b011;

  el.innerHTML = '<div class="hw-row"></div><div class="hw-sq"></div><div class="hw-bl"></div>' +
    '<svg class="hw-svg" viewBox="0 0 300 190" width="300" height="190" role="img" aria-label="the labels, the chosen blade and its complement"></svg>' +
    '<p class="widget__out" aria-live="polite"></p>';
  const rowN = el.querySelector('.hw-row'), rowSq = el.querySelector('.hw-sq'), rowBl = el.querySelector('.hw-bl');
  const svg = el.querySelector('.hw-svg'), out = el.querySelector('.widget__out');
  const btn = (txt, pressed, fn, label) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = txt; b.setAttribute('aria-pressed', pressed ? 'true' : 'false'); if (label) b.setAttribute('aria-label', label); b.addEventListener('click', fn); b.style.margin = '2px 4px 2px 0'; return b; };
  const lab = t => { const s = document.createElement('label'); s.textContent = t; return s; };

  function controls() {
    rowN.replaceChildren(lab('generators'), ...[2, 3, 4].map(k => btn(String(k), k === n, () => { n = k; eps = Array(n).fill(1); a = a & ((1 << n) - 1); controls(); show(); })));
    rowSq.replaceChildren(lab('squares'), ...eps.map((e, i) => btn('e' + SUB[i + 1] + '² = ' + SQ[String(e)], false, () => { eps[i] = e === 1 ? -1 : e === -1 ? 0 : 1; controls(); show(); }, 'square of e' + (i + 1) + ', press to change')));
    rowBl.replaceChildren(lab('blade'), ...[...Array(n).keys()].map(i => btn('e' + SUB[i + 1], ((a >> i) & 1) === 1, () => { a ^= 1 << i; controls(); show(); })));
  }

  function pos(m) {   // a picture of the labels: a square (n = 2), a cube (n = 3), two cubes side by side (n = 4)
    const L = n === 2 ? 110 : n === 3 ? 92 : 64;
    const x = m & 1, y = (m >> 1) & 1, z = (m >> 2) & 1, w = (m >> 3) & 1;
    const ox = n === 4 ? 30 + w * 140 : 70, oy = n === 4 ? 150 : 168;
    return [ox + L * x + 0.5 * L * z, oy - L * y - 0.36 * L * z];
  }
  function draw(F) {
    const N = 1 << n; let s = '';
    for (let m = 0; m < N; m++) for (let i = 0; i < n; i++) if (!((m >> i) & 1) && !(n === 4 && i === 3)) {
      const [x1, y1] = pos(m), [x2, y2] = pos(m | (1 << i));
      s += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="currentColor" stroke-opacity=".25"/>`;
    }
    const b = a ^ F, [ax, ay] = pos(a), [bx, by] = pos(b);
    s += `<line x1="${ax}" y1="${ay}" x2="${bx}" y2="${by}" stroke="#2a78d6" stroke-width="2.4"/>`;
    for (let m = 0; m < N; m++) {
      const [x, y] = pos(m), on = m === a, co = m === b;
      const fill = on ? '#2a78d6' : co ? '#eb6834' : 'currentColor';
      s += `<circle cx="${x}" cy="${y}" r="${on || co ? 5 : 3}" fill="${fill}"/>` +
        `<text x="${x + 6}" y="${y - 6}" font-size="12" fill="currentColor" font-weight="${on || co ? 700 : 400}">${blade(m, n)}</text>`;
    }
    svg.innerHTML = s;
  }

  function show() {
    const F = (1 << n) - 1, b = a ^ F;
    const sigma = reorderSign(a, b);                 // sigma(a): the sign of the permutation (a, complement)
    const sIa = sign(F, a, eps), saI = sign(a, F, eps), I2 = sign(F, F, eps);
    const nul = eps.some(e => e === 0);
    let reach = 0; for (let m = 0; m <= F; m++) if (sign(F, m, eps) !== 0) reach++;
    const cellName = 'Cl(' + eps.filter(e => e === 1).length + ',' + eps.filter(e => e === -1).length + (nul ? ',' + eps.filter(e => e === 0).length : '') + ')';
    const lines = [
      'cell ' + cellName + ', I = ' + blade(F, n) + ', I² = ' + (I2 === 0 ? '0' : sgn(I2) + '1'),
      'blade ' + blade(a, n) + ' (label ' + bits(a, n) + '), complement ' + blade(b, n) + ' (label ' + bits(b, n) + ' = a ⊕ ' + bits(F, n) + ')',
      'σ(a), the sign of the permutation (a, ā): ' + sgn(sigma) + '1, so on Λℝ' + String(n).replace(/\d/g, d => '⁰¹²³⁴⁵⁶⁷⁸⁹'[d]) + ' ⋆' + blade(a, n) + ' = ' + sgn(sigma) + blade(b, n),
      'I ' + blade(a, n) + ' = ' + (sIa === 0 ? '0' : sgn(sIa) + blade(b, n)) + ',   ' + blade(a, n) + ' I = ' + (saI === 0 ? '0' : sgn(saI) + blade(b, n)),
      'multiplication by I reaches ' + reach + ' of the ' + (F + 1) + ' labels' + (nul ? ': I² = 0, a duality but not a Hodge star' : ': it is invertible, I⁻¹ = ' + (I2 === 1 ? '' : '−') + 'I')
    ];
    out.textContent = lines.join('\n');
    draw(F);
  }
  controls(); show();
})
