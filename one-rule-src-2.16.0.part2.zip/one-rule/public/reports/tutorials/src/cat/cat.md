# Category theory on the bit rule

## Opening · one rule, three algebras

A first course in category theory asks of a mathematical object not what it is made of but how it maps. Which arrows come in and go out, which constructions are universal (a product is the best object with maps to two given ones), which functors carry one kind of structure to another, and which families of arrows commute with all of them ("natural" ones). A second course adds a tensor product with coherent associativity and symmetry (monoidal categories), and the algebras that live in such a category, among them the Frobenius algebras of two-dimensional field theory.

The bit rule gives this branch one small, completely computable world. Take n switches; a **label** a is a string of n bits, and the blade eₐ is the product of the generators that are on, in increasing order. The rule is

$$e_a e_b = s(a,b)\, e_{a\oplus b},$$

$$s(a,b) = (-1)^{N(a,b)}\prod_{i\in a\wedge b}\varepsilon_i ,$$

with $N(a,b)$ the number of pairs (i in a, j in b) with j < i and the squares $\varepsilon_i \in \{+1,-1,0\}$ the only input. It is associative for every n and every choice of squares (Thm T1; `cat·S1` checks all 331776 blade triples for the 81 choices with four generators), and p squares +1, q squares −1 and r squares 0 give the cell Cl(p,q,r). In the language of the course the rule holds one finite category (the cube of labels ordered by inclusion), one group (the labels under XOR), one partial monoid (disjoint union), a 2-cocycle (the sign), a symmetric monoidal structure (concatenation of generator lists, with the Koszul sign), Frobenius forms, complexes and an index. Each section below takes one notion of the course and shows its finite object, with the rows of the Atlas that state it and the logs that count it; the general theorems the course proves are marked *recalled*.

The worked example is n = 2: four labels 1, e₁, e₂, e₁₂ and three choices of squares. With (+,+), e₁ = diag(1, −1) and e₂ = [[0,1],[1,0]] multiply as the table says: M₂(ℝ) = Cl(2,0). With (−,−), i = e₁, j = e₂, k = e₁₂ satisfy i² = j² = k² = ijk = −1: the quaternions ℍ = Cl(0,2). With (0,0) the generators square to zero and anticommute: the exterior algebra Λ(ℝ²) = Cl(0,0,2). In category terms it is one group, ℤ₂², with three signs: the first two are 2-cocycles with values ±1 in two different classes (they differ in the squares, which a class keeps, `cat·K2a`), the third takes the value 0 and is a cocycle with values in the monoid {+1, −1, 0} (Thm T1).

![The three sign tables of n = 2: row a, column b, entry the product of the two blades; blue cells carry +, red cells −, grey cells vanish. Drawn by figs_cat.py from the bit rule of the repository (checks/researchers_checks/bitrule_A.py); the counts 0, 0, 7 vanishing and 4, 6, 1 negative products are recounted there and compared with the shipped tutorial, Part 0.](figs/fig01_n2_three_algebras.svg)

## Part I · The cube of labels as a category

For a reader with a first course: categories, functors, natural transformations, presheaves, limits. The Atlas has one category at the centre, the cube category Bₙ, and a few structures on it and beside it. C1 to C7 meet them one at a time, with B₂ and B₃ as the worked examples; C2 adds the cohomology of the sign, which is where the algebra of the rule enters the category.

### C1 · Category: objects, arrows, composition

**The course.** A category has objects and arrows; each arrow has a source and a target, each object an identity arrow, and two arrows that meet (the target of one is the source of the other) have a composite. Composition is associative and the identities are units (recalled: Mac Lane, *Categories for the Working Mathematician*, chapter I; Leinster, *Basic Category Theory*, chapter 1).

**The Atlas's object.** The cube category Bₙ has the 2ⁿ labels as objects and one arrow a → b whenever a ⊆ b, that is, whenever every switch that is on in a is on in b. The composite of a ⊆ b and b ⊆ c is a ⊆ c; the identity is a ⊆ a. SHP-007 states it on the cube: "Ordered by inclusion, the 2ⁿ corners form a category with one arrow S → T whenever S ⊆ T, 3ⁿ arrows in all"; the arrow S → T is the face of the cube on which the coordinates in S are 1 and those outside T are 0, of dimension |T∖S|. An arrow a → b adds the label t = a ⊕ b, which shares no switch with a, so Bₙ is also the translation category of the partial monoid of disjoint labels (C2): LNC-099 and `bd·mjc·3`, which checks the bijection on arrows together with sources, targets, identities and composition.

The counts have a one-line reason. For an arrow a ⊆ b each switch is in one of three states (off in both, on in both, switched on by the arrow), so there are 3ⁿ arrows; for a composable pair a ⊆ b ⊆ c there are four states, so 4ⁿ pairs; and a chain of k composable arrows (a k-simplex of the nerve) has (k + 2)ⁿ. The log of `bd·mjc·3` lists the simplices for k = 0 … 4: for n = 3 they are 8, 27, 64, 125, 216, and for n = 5 they are 32, 243, 1024, 3125, 7776 (`mjc_labels.log`). For B₂ that is 4 objects, 9 arrows and 16 composable pairs. B₃ has 27 arrows: 8 identities, 12 covering arrows (one switch added), 6 composites of length two and 1 of length three.

![B₃ twice. Top: the poset, its 12 covering relations (the Hasse diagram). Bottom: the category, with the 8 identities as loops, the 12 covering arrows solid, the 6 composites of length two dashed and the composite 1 → e₁₂₃ dotted. Drawn by figs_cat.py, which enumerates the 27 arrows and 64 composable pairs of B₃ from the labels.](figs/fig02_b3_poset_category.svg)

**Where the course goes further.** The categories of a course are mostly large (sets, groups, vector spaces) and have many arrows between two objects. Bₙ is finite and has at most one; the categories with several arrows in the Atlas are the finite ones its checks enumerate (`bd·mjc·9` lists all 584 connected categories with at most four objects and four non-identity arrows). Large categories, and the size questions they raise, are not in it.

> **Try it.** Count the arrows out of e₁ in B₃ and the arrows into e₁₂. Then show that a label a with |a| switches on has $2^{n-|a|}$ arrows out and $2^{|a|}$ arrows in, and sum over a to get 3ⁿ again.

### C2 · Monoid, group, partial monoid, and the sign as a cocycle

**The course.** A monoid is a category with one object: the arrows are the elements and composition is the product. A group is a monoid in which every arrow is invertible. A 2-cocycle α on a group G with values in the units of a ring gives the twisted group algebra with basis u_g and $u_g u_h = \alpha(g,h)\,u_{gh}$, and the product is associative exactly when α satisfies the cocycle identity; cohomologous cocycles give isomorphic algebras, so the algebras are classified by H²(G; ·) (recalled: Brown, *Cohomology of Groups*, chapter IV; Leinster, Example 1.1.8).

**The Atlas's object.** The labels with XOR are the group ℤ₂ⁿ, each label its own inverse; as a one-object category it has 2ⁿ arrows, all invertible. The sign is a normalised 2-cocycle on it: the reason Thm T1 gives for associativity is that "the sign is a bilinear form mod 2, hence a 2-cocycle of ℤ₂ⁿ", and with a null square the factor εᵢ is a cocycle with values in the monoid {+1, −1, 0} because the exponents agree as integers. So a cell with squares ±1 is the twisted group algebra ℝˢ[ℤ₂ⁿ] (the category lens's dictionary: "a bicharacter on V, hence a normalised 2-cocycle"). Which twisted group algebras occur? H²(ℤ₂ⁿ; 𝔽₂) is the space of quadratic forms on 𝔽₂ⁿ, of dimension n(n+1)/2 (Thm T6 (c); LNC-050b; `cat·K2a` solves the cocycle equations as linear systems and finds 1, 3, 6, 10 for n = 1 … 4). A class is fixed by the squares of the generators and by their commutators, and the Clifford algebras are the 2ⁿ classes in which every pair of generators anticommutes (`cat·K2b`); the other classes are twisted group algebras that are not Clifford algebras (recalled).

Inside the group sits a smaller structure. The disjoint sum a ⊕ b is defined only when a and b share no switch; with it the labels form a partial commutative monoid with unit 1 (the empty label) and 3ⁿ defined pairs, associative in the strong (Kleene) sense, where one side of the associative law is defined exactly when the other is, and no label but the unit has an inverse (LNC-099; `bd·mjc·1`, n ≤ 6). THM-003 puts the sign in three complexes at once. On the group the classes are the n(n+1)/2 of quadratic forms. On the partial monoid the ±1-valued 2-cocycles modulo coboundaries form 𝔽₂ to the power C(n,2), "one commutation bit per pair of generators, and restriction from the group is onto with kernel the n squares" (THM-003). On the category Bₙ, H² = 0: the bit-rule sign on composable pairs is the coboundary of the Jordan–Wigner string σ(S → T) = s(T∖S, S), and what the category keeps is the flux of the string around each square, −1 (THM-003; `bd·mjg·27`, `bd·mjp·7`).

![dim H² with 𝔽₂ coefficients for the three structures: the group ℤ₂ⁿ (n ≤ 4), the partial monoid of disjoint labels (n ≤ 5) and the nerve of the category Bₙ (n ≤ 4). Drawn by figs_cat.py, which solves the cocycle and coboundary equations over 𝔽₂ itself; its numbers are found word for word in the log of bd·mja·7 (mja_exterior.log).](figs/fig17_h2_three.svg)

The cube shows the same sign as a picture. Give the edge a → a ∪ {i} the sign (−1) to the number of switches of a below i. Then every square face of the cube has an odd number of minus edges, so it anticommutes, and this edge sign is the bit-rule sign: eᵢ eₐ = (−1)^#(j ∈ a, j < i) e_(a+i) when i is not in a (LNC-056; `cat·K1a`, `cat·K1b`). It is unique up to gauge: two anticommuting assignments differ by rescaling the labels by ±1, because H¹ of the cube vanishes; on the 3-cube 128 = 2⁷ of the 4096 assignments anticommute, one gauge orbit (Thm T6 (a); LNC-050; `cat·K1d` and `check_T6.log`).

![The Jordan–Wigner sign on the 12 edges of the 3-cube of labels, dashed where it is −1; each of the six square faces has an odd number of dashed edges. Drawn by figs_cat.py, which also tries all 4096 sign assignments and finds the 128 that make every square anticommute equal to the 128 regaugings of this one.](figs/fig16_cube_signs.svg)

#### If you want the proof

Let σ and σ′ both make every square anticommute. Their product τ = σσ′ has product +1 around every square, so τ is a 1-cocycle on the 2-skeleton of the cube with values in 𝔽₂. H¹ = 0 means τ is a coboundary: τ(a → b) = g(a)g(b) for a function g on the eight labels, and σ′ is σ after the rescaling eₐ ↦ g(a)eₐ. The functions g form a group of 2⁸ elements, and g and −g give the same τ, so the orbit has 2⁷ = 128 elements.

With null generators the group is not enough. The labels of Cl(p,q,r) with the product "zero when two labels share a null bit" form a monoid with zero, and the sign is a 2-cocycle on it, so the cell is a twisted contracted monoid algebra (LNC-086, a question: is there a cohomology of such cocycles in which the radical is a cohomological notion?). The radical itself is computed: the span J of the labels with a null bit is the Jacobson radical, of dimension 2ⁿ − 2^(p+q), and Cl(p,q,r)/J = Cl(p,q) (LNC-002; Thm T2; `cat·R1` on the 56 signatures with up to five generators).

**Where the course goes further.** Group cohomology in every degree, with any coefficients, and the extensions it classifies (recalled: Brown). The Atlas computes H² of three finite objects over 𝔽₂ and states which algebra each class gives; whether the twisted group algebra is a functor of the pair (group, cocycle) the rows do not ask. What they check is the functor Cl on quadratic spaces (C4) and its monoidal structure (C8).

> **Try it.** On the square B₂ there are 2⁴ = 16 ways to sign the four edges. Count those with an odd number of minus signs (the square anticommutes) and check that they are the 2⁴/2 = 8 regaugings of one of them.

### C3 · Preorder, poset, thin category

**The course.** "A preorder is a reflexive transitive binary relation"; as a category it is thin, with at most one arrow between two objects, and a poset is a preorder with no isomorphism between distinct objects (recalled: Leinster, Example 1.1.8). A poset has chains, a Hasse diagram of covering relations, an order complex whose simplices are its chains, and a Möbius function (recalled: Stanley, *Enumerative Combinatorics*, volume 1, chapter 3).

**The Atlas's object.** Bₙ is the Boolean lattice: thin, and acyclic (no arrow back but identities). LNC-138 states what acyclic buys: "A positive additive weight exists on a finite category exactly when it has no endomorphism but identities and no isomorphism between distinct objects", checked on 888 finite categories, of which 155 have a weight (`bd·mjc·12`; CAND-095). The chains of Bₙ are the orders in which switches are turned on. A maximal chain 1 ⊂ eᵢ ⊂ eᵢⱼ ⊂ … ⊂ 1…1 is an ordering of the n switches, so there are n! of them, and LNC-140 reads them as simplices: "The nerve of Bₙ triangulates the cube [0,1]ⁿ by n! simplices, one per maximal chain, so it is contractible; without the bottom and the top label it is a sphere S^{n−2}, whose reduced Euler characteristic is the Möbius number (−1)ⁿ" (CAND-093 gives the standard names: the Freudenthal triangulation, P. Hall's theorem). Counted with every length, the chains from 1 to the top are the Fubini numbers 1, 1, 3, 13, 75, 541, 4683 for n = 0 … 6 (the category lens, entry D71).

![Top: the six maximal chains of B₃, one for each order of the three switches. Bottom: counts in Bₙ for n = 0 … 6: objects, arrows, composable pairs, maximal chains and chains of every length from 1 to the top. Drawn by figs_cat.py, which counts by recursion over the labels; the simplex counts for n = 2 … 5 are compared with the log of bd·mjc·3.](figs/fig03_chains.svg)

A thin category is a category enriched in truth values: hom(a, b) is "true" or "false". Replace truth values by distances and the same labels carry a Lawvere metric: d(S, T) = |T∖S| has d(S, S) = 0 and the triangle law but no symmetry (LNC-139; `bd·mjc·17`); symmetrised by addition it is the Hamming distance, the path metric of the cube graph. The up-sets of Bₖ, the open sets of its Alexandrov topology, are counted by functors from Bₖ to the arrow category 𝟐 = {0 → 1}: 2, 3, 6, 20, 168 for k = 0 … 4 (`bd·mjc·30`, `mjc_comma.log`), the Dedekind numbers (CAND-106).

**Where the course goes further.** Lattices in general, Galois connections, the incidence algebra of any locally finite poset and its Möbius inversion (recalled: Stanley). The Atlas has the incidence algebra of Bₙ only (C11).

> **Try it.** Count the maximal chains of B₄ and check that its nerve fills the 4-cube with 4! = 24 simplices, one for each order of the four coordinates (the region x_σ(1) ≥ x_σ(2) ≥ x_σ(3) ≥ x_σ(4)).

### C4 · Functor

**The course.** A functor F: C → D sends objects to objects and arrows to arrows, keeps sources and targets, and preserves identities and composites (recalled: Mac Lane, I.3). A grading of an algebra by a monoid G is a functor in disguise: it gives every basis element a degree in G, and products add degrees.

**The Atlas's objects.** The first functor is the grade. Send every label to the one object of (ℕ, +) and the arrow a → b to |b| − |a|, the number of switches it adds: identities go to 0, composites to sums, and every arrow but an identity goes to a positive number (the category lens, entry D59; LNC-099 calls it the additive norm ‖a‖ = popcount(a); LNC-138 shows that on Bₙ every additive weight is a difference φ(cod) − φ(dom)). The second is the parity π(a) = |a| mod 2, a homomorphism of groups ℤ₂ⁿ → ℤ₂, since |a ⊕ b| = |a| + |b| − 2|a ∧ b|. The parity is the grading of super vector spaces (the category lens, entry D04), and it makes every cell a superalgebra.

The grade is not a grading of the cells, and the table shows why: on a pair that shares switches, the grade of the product drops by twice the number of shared ones. THM-006: "The popcount is an algebra grading only when every square is 0; with squares ±1 the 4^m − 3^m products of overlapping labels break it, and the parity π stays." Among the gradings in which every label has a degree, the universal grading group of Cl(p,q,r) is ℤ₂^(p+q) × ℤ^r: a null generator is exactly one whose ℤ₂-degree lifts to an additive ℤ-degree (LNC-003; Thm T2 (6); `cat·G1` on the 34 signatures with one to four generators). The restriction to label-homogeneous gradings matters: Cl(2,0) = M₂(ℝ) carries a ℤ-grading by its matrix units (LNC-020; `cat·G2`).

![Top: the grade as a functor from B₃ to the one-object category (ℕ, +); the labels are coloured by parity, the functor to ℤ₂. Bottom: |a| + |b| − |a ⊕ b| on the 64 pairs of labels: 0 on the 27 disjoint pairs (the arrows of B₃), an even number on the other 37. Drawn by figs_cat.py from the labels.](figs/fig04_grade_functor.svg)

The third functor is Cl itself. Restricting to a face, dividing by the radical and the mother map are Cl applied to maps of quadratic spaces, with Cl(σ∘μ) = Cl(σ)∘Cl(μ) (LNC-041; `bd·cat·17`).

The parity brings the Koszul sign. In super vector spaces the symmetry v ⊗ w ↦ (−1)^(|v||w|) w ⊗ v carries a minus sign exactly when both factors are odd. In a cell, swapping two labels costs $e_b e_a = (-1)^{|a||b| + |a\wedge b|}\, e_a e_b$ when the product is not zero: on disjoint labels the Koszul sign itself, for every choice of squares, and on overlapping ones the Koszul sign times (−1) to the number of shared switches (`bd·mja·4`: "disjoint blades satisfy e_a e_b = (-1)^{|a||b|} e_b e_a for every eps"; "overlapping pairs with nonzero product: exponent |a||b| + |a AND b|"). In the exterior algebra Λ(ℝʳ) the overlapping products vanish, so it is super-commutative: the Koszul sign is its whole commutation law (LNB-025c).

![Two sign tables on the 64 pairs of labels of B₃. Top: the Koszul sign of super vector spaces. Bottom: the swap sign of Cl(3,0), ringed on the 28 pairs where it differs from the Koszul sign, the pairs that share an odd number of switches. Drawn by figs_cat.py from the bit rule, which also checks the formula on all 27 choices of squares with n = 3.](figs/fig05_super_sign.svg)

@@widget koszul

**Where the course goes further.** Functor categories, adjoint functors, equivalences of categories (recalled: Mac Lane, IV). The Atlas has one adjunction, Δ ⊣ ∧ on Bₙ (C7), and leaves the universal grading group for arbitrary gradings open (LNC-085).

> **Try it.** In Cl(3,0) take a = e₁₂ and b = e₂₃. Compute eₐ e_b and e_b eₐ by the rule, then predict the swap sign from |a||b| + |a ∧ b| = 4 + 1. Check it in the widget, then make e₂ null and watch both products vanish.

### C5 · Natural transformation

**The course.** A natural transformation α: F ⇒ G between two functors C → D is a choice of arrow α_x: F(x) → G(x) for every object x such that for every arrow f: x → y the square G(f)∘α_x = α_y∘F(f) commutes; it is a natural isomorphism when every α_x is invertible (recalled: Mac Lane, I.4; Leinster, Definition 1.3.1).

**The Atlas's object.** Halving a cell. If some generator t has a non-zero square, the products fᵢ = eᵢ e_t (i ≠ t) anticommute, square to −εᵢ ε_t, and generate the even part: Cl⁰(p,q,r) ≅ Cl(p,q−1,r) through a t of square −1 and ≅ Cl(q,p−1,r) through a t of square +1, with the null generators riding along (LNC-036; LNC-117; Thm T5 (a); `cat·K5b`). The isomorphism depends on t. So it is not a natural isomorphism between functors of the cell alone; it is natural on pointed quadratic spaces (V, t) with t² ≠ 0: LNC-041 calls halving "a natural isomorphism Cl∘(halve) ⇒ Cl⁰ on pointed quadratic spaces", checked as `bd·cat·16`, and LNC-119 says the same. The physics use is the spinor step: Cl⁰(1,3) ≅ Cl(1,2) ≅ M₂(ℂ), whose even elements of norm 1 form Spin⁺(1,3) ≅ SL(2,ℂ) (LNC-121, standard).

What fails is exact. With only null generators there is no t, and the even part Λᵉᵛ(ℝʳ) is a Clifford algebra on r − 1 generators only for r ≤ 2; from r = 3 on its radical has too few layers (Thm T5 (d); LNC-063; LNC-091; `cat·K5b` in `cat_check.log`: "With only null generators it fails from 3 generators on").

![Top: halving four cells through a generator t; the squares of the fᵢ = eᵢ e_t and the cell they generate, checked on every pair of products (the last column counts the pairs). Bottom: with only null generators, the Loewy length of the even part (the number of layers of its radical) against that of Λ(ℝʳ⁻¹): they agree for r ≤ 2 only. Drawn by figs_cat.py, which builds the fᵢ by the rule and counts the layers by products.](figs/fig19_halving.svg)

Halving is one of four moves (LNC-073): join (the graded tensor product of C8), halve, restrict to a face (ι_T is always an injective homomorphism; π_T is one exactly when every generator outside T is null, LNC-038 and LNC-118 with `catw·P1`), and the complement a ↦ a ⊕ 1…1, which is not a map of algebras but the Frobenius structure of the cell (LNC-039; C9). A fifth map, the mother algebra, embeds Cl(p,q,r) in Cl(p+r,q+r) by sending each null generator to f⁺ − f⁻ (LNC-040; LNC-136; `cat·M1` on nine signatures). Reading the moves as steps "up and down" a ladder of boxes is ours (LNC-116; LNC-073b).

**Where the course goes further.** Natural transformations between any functors, the functor category, the Yoneda embedding as a natural isomorphism (C6), equivalences given by natural isomorphisms (recalled). The Atlas has one natural isomorphism and the maps of quadratic spaces it rests on.

> **Try it.** Halve Cl(1,3) through t = e₁ (square +1) instead of e₂. The rule Cl(q,p−1) gives Cl(3,0); both Cl(3,0) and Cl(1,2) are M₂(ℂ) as algebras, so the even part is the same algebra reached by a different map. Which generators of Cl(1,3) become the three anticommuting fᵢ?

### C6 · Presheaf, representable, Yoneda

**The course.** "A presheaf on A is a functor A^op → Set" (recalled: Leinster, Definition 1.2.15); with values in vector spaces, a functor to Vect. The representable presheaf hom(−, A) sends x to the set of arrows x → A, and Yoneda's lemma says that natural transformations hom(−, A) ⇒ F correspond to the elements of F(A) (recalled: Leinster, Theorem 4.2.1; Mac Lane, III.2). A sheaf is a presheaf on the open sets of a space whose sections glue.

**The Atlas's object.** The cell is a presheaf of vector spaces on Bₙ: S ↦ P(S) = span{eₐ : a ⊆ S}, and an arrow S ⊆ T goes to the restriction P(T) → P(S) that keeps eₐ when a ⊆ S and sends it to 0 otherwise. For n = 2 the dimensions are 1, 2, 2, 4. LNC-141 states what it is: "The cell is a sheaf of vector spaces on the Alexandrov space of Bₙ: over an open D, a down-set of labels, its sections are the blades with label in D (n ≤ 3). It is a sheaf of algebras only for the null cell: the projection Cl(T) → Cl(S) is an algebra map exactly when every generator in T∖S squares to 0." The same row identifies the label ring (𝔽₂ⁿ, xor, and), the Boolean ring of opens of the discrete n-point space, whose category of opens is Bₙ (the category lens, entries D66 and D67).

![The presheaf P on B₂: the four spaces and the restrictions (arrows downward, against the inclusions), each labelled with the blades it sends to 0. Below, whether the restriction from P({1,2}) is an algebra map in three cells, and the Yoneda count. Drawn by figs_cat.py, which tests every restriction on all 16 products and counts the natural transformations by brute force.](figs/fig06_presheaf_b2.svg)

A worked Yoneda example, ours: let F(S) be the set of subsets of S, with restriction x ↦ x ∩ S. A natural transformation from hom(−, T) to F picks an element of F(S) for every S ⊆ T, compatibly with the restrictions, and is therefore fixed by its value on T: there are |F(T)| = 2^|T| of them. The shipped tutorial counted them by brute force for every T in B₃; figs_cat.py repeats the count on B₂ and B₃.

**Where the course goes further.** The presheaf category as the free cocompletion, the Yoneda embedding, sheaves on sites and the topos of sheaves (recalled: Mac Lane and Moerdijk, *Sheaves in Geometry and Logic*). The Atlas has one presheaf of algebras, on the null cell, and leaves open what replaces it when a square is ±1 (Part I, question 3 below).

> **Try it.** In Cl(1,0,1) (e₁² = +1, e₂² = 0), check by hand that dropping e₂ (restriction to P({1})) respects products and that dropping e₁ does not: compute the image of e₁ e₁ = 1 both ways.

### C7 · Limits and colimits

**The course.** A product of two objects is an object with arrows to both through which every other such pair factors uniquely; it is the limit of a diagram with two objects and no arrows, and the coproduct is the colimit. The limit of the empty diagram is a terminal object, the colimit an initial one. In a poset, products are meets and coproducts are joins, and the product is right adjoint to the diagonal Δ: C → C × C (recalled: Leinster, chapters 2 and 5; Mac Lane, III.4).

**The Atlas's object.** In Bₙ the product of a and b is the meet a ∧ b (AND) and the coproduct is the join a ∨ b (OR). LNC-142: "In Bₙ every finite discrete diagram has a limit, the AND, and a colimit, the OR, and Δ ⊣ ∧ (n ≤ 4)." The initial object is the empty label 1, the terminal object the full label 1…1. The XOR a ⊕ b, the label of the product eₐ e_b in a cell, is not a limit: it is not above a or b unless they are disjoint, and it has no universal property in Bₙ. Where a and b share switches, the cell multiplies those shared generators by their squares: e₁₂ e₂₃ = ε₂ e₁₃ (LNB-025, ours, reads such a product as "two blades that share a bit are multiplied by contracting that bit with the square of its generator").

Prime names make the three operations arithmetic. Give the i-th switch the i-th prime, e₁ = 2, e₂ = 3, e₃ = 5, e₄ = 7, and a label the product of its primes: Bₙ becomes the divisors of 2·3·5·… ordered by divisibility. Then AND is the gcd, OR is the lcm, and XOR is ab/gcd². FUR-523 says it in the matter pages: "Each switch has its own prime; a box multiplies its switches’ primes. Combining two boxes multiplies and strikes out squares: the switch rule without its sign (an exact relabelling). The primes are only names (ours)." The kernel of the Atlas prints labels this way in its `primes` lens (`engines/bitrule.js`, function label).

![B₃ as the divisors of 30, with the labels a = 6 = e₁₂ and b = 15 = e₂₃ ringed together with their meet (∧, the gcd 3), their join (∨, the lcm 30) and their XOR (⊕, ab/gcd² = 10); below, the three operations in bits, primes and category terms. Drawn by figs_cat.py, which checks gcd, lcm, ab/gcd² and the universal property of meet and join on every pair of B₃ and B₄.](figs/fig07_and_or_xor.svg)

@@widget primes

A limit cone and a weight. LNC-142 goes on: "With a positive additive weight a limit cone is the unique cone of least total leg weight (on Bₙ and on random posets); a cone of least weight need not be a limit: in the bowtie c₁, c₂ < a, b the pair {a, b} has one and no limit." The category lens marks the least-action reading of that row partial (entry D79); this tutorial uses only the limits.

**Where the course goes further.** Limits of arbitrary diagrams, completeness, preservation of limits by right adjoints, the adjoint functor theorems (recalled: Mac Lane, V). In Bₙ every limit is a meet of finitely many labels, and every finite diagram has one.

> **Try it.** In B₄ with the primes 2, 3, 5, 7, take a = 42 and b = 70. Find the meet, the join and the XOR as numbers and as labels, and check in the widget that the product eₐ e_b of Cl(4,0) has the label 15 = e₂e₃.

### Three questions for a category theorist

1. **The monoid with zero.** LNC-086 asks whether there is a cohomology of the 2-cocycles of a monoid with zero (contracted monoid algebras, partial cocycles) in which the radical of Cl(p,q,r) is a cohomological notion. The nearest computed rows are THM-003 (the sign in three complexes, none with a zero) and LNC-002 (the radical). Open.
2. **Gradings.** Among label-homogeneous gradings the universal grading group is ℤ₂^(p+q) × ℤ^r (LNC-003), but M₂(ℝ) has more gradings. LNC-085 asks whether the universal grading group for arbitrary gradings is known, torsion part included. Open.
3. **The presheaf for every cell.** LNC-141 proves that the cell is a sheaf of vector spaces on the Alexandrov space of Bₙ and a sheaf of algebras only for the null cell. Is the general cell a sheaf of modules over that sheaf of algebras, or a sheaf of algebras in another category (super vector spaces with the Koszul sign, LNC-029)? Our question; no row asks it.

## Part II · Monoidal and super structure

One step beyond the syllabi of a first course: monoidal categories, braidings, super vector spaces, algebras inside them, and Frobenius algebras with the pictures of two-dimensional field theory. Here the category lens's dictionary has its richest rows.

### C8 · Monoidal categories, Vec_G, super vector spaces

**The course.** A monoidal category has a tensor product ⊗ of objects and arrows, a unit object and an associativity isomorphism subject to the pentagon (with unit isomorphisms and the triangle); a braiding is a natural isomorphism V ⊗ W → W ⊗ V subject to the hexagons, symmetric when applying it twice is the identity. Vec_G, the G-graded vector spaces, has the simple objects δ_g with δ_g ⊗ δ_h = δ_gh; twisting its associator by a 3-cocycle ω gives Vec_G^ω. Super vector spaces, sVec, are the ℤ₂-graded ones with the symmetry v ⊗ w ↦ (−1)^(|v||w|) w ⊗ v (recalled: Etingof, Gelaki, Nikshych and Ostrik, *Tensor Categories*, chapters 1, 2 and 8; Deligne and Morgan, *Notes on supersymmetry*).

**The Atlas's objects.** The labels are the simple objects of Vec(ℤ₂ⁿ) (the category lens, entry D01), and the parity is the grading that pulls back the symmetric structure of sVec (entry D04). The empty label is the unit (LNC-011: "The empty label (no bit set) is the unit: e∅e∅ = e∅ = 1. In the monoidal structure it is the unit object. It is never label 0."). The tensor product of cells is the concatenation of their generator lists. LNC-035: "Concatenating two lists of generators is the graded tensor product Cl(p,q,r) ⊗̂ Cl(p′,q′,r′): (a₁ ⊗ b₁)(a₂ ⊗ b₂) = (−1)^{|b₁||a₂|}a₁a₂ ⊗ b₁b₂, the sign being the parity of the inversions of the concatenated list; the clocks add." `cat·K5a` checks it on all label pairs for six pairs of signatures, null generators included, and `cat·K5c` checks that the sign of the rule is the parity of the inversions, by an independent bubble sort on all 65536 label pairs of eight generators. In the dictionary's words, Cl: (Quad, ⊥) → (sAlg, ⊗̂) is symmetric monoidal.

![Cl(1,1) ⊗̂ Cl(1,0) computed two ways: the sign table of the cell Cl(2,1) of the concatenated list (+,−,+), and the graded tensor product of the two factors with the Koszul factor (−1)^(|b₁||a₂|), which agrees on all 64 pairs; dots mark the 16 pairs whose Koszul factor is −1. Drawn by figs_cat.py from the rule of each factor and of the concatenated cell.](figs/fig08_graded_tensor.svg)

The associativity of ⊗̂ is the associativity of concatenating lists, and the braiding is the swap of two blocks of generators. For a label a in the first block and b in the second every pair (i in b, j in a) is out of order, so the rule gives e_b eₐ = (−1)^(|a||b|) eₐ e_b: the symmetry of sVec, as C4 showed label by label. The octonions show what a non-trivial associator looks like on the same eight labels of ℤ₂³: with the Albuquerque–Majid sign F the product is not associative, and the associator is ω(a,b,c) = (−1)^det(a,b,c) over 𝔽₂, −1 on the 168 independent triples (`cat·K3a`, from the 512 products of three units). ω is a 3-cocycle, the pentagon holds on all 4096 quadruples, and ω is the coboundary of F (`cat·K3b`; Thm T6 (d); CAND-094): the octonions are an algebra in Vec(ℤ₂³) with associator ω, and with the braiding F Fᵀ a commutative one, the quasialgebra of Albuquerque and Majid (the category lens, entry D41; their paper is recalled).

The clock is a functor out of this monoidal structure. The clock c = p − q mod 8 is the phase of the Gauss sum of the labels, $S = \sum_a i^{|a\cap P|-|a\cap Q|} = (1+i)^p(1-i)^q$, with P the generators of square +1 and Q those of square −1 (`cat·K4a`, exact Gaussian integers for all p + q ≤ 10). Concatenation adds clocks (LNC-117: "the clock adds (cat·K4a)"), so the clock is a homomorphism of monoids from the cells under ⊗̂ to ℤ₈. A null generator adds 0: the sum over the labels without a null bit is the Gauss sum of Cl(p,q,r)/J, and over all labels it is 2^r times that (LNC-055; LNC-018). Ungraded, the real Clifford algebras have five types; the pair (type of the cell, type of its even part) takes eight values as c runs through ℤ₈ (`cat·C1`). That these eight values are the graded Morita classes and form the Brauer–Wall group BW(ℝ) ≅ ℤ₈, generated by Cl(1,0), is Wall's theorem, recalled; its finite part is checked: concatenating two generator lists is the graded tensor product (all 225 ordered pairs of cells with p + q ≤ 4 and p′ + q′ ≤ 4, exact), the class (type, even type) of a cell depends on the clock alone on the 45 cells with p + q ≤ 8, and the class of a product is that of the sum of the clocks, so the clock is a homomorphism onto ℤ₈ generated by Cl(1,0) (CAND-004, proved by the Atlas; the Morita equivalence behind the word "class" stays recalled). With null generators the classes form the monoid ℤ₈ × ℕ, (clock, r), with no inverse for r ≥ 1 (LNC-055).

![The clock as a homomorphism to ℤ₈. On the dial, the type of each clock value and of its even part; in the table, the cells with p + q ≤ 4 placed by the phase of their Gauss sum. Drawn by figs_cat.py, which sums over the labels in exact Gaussian integers, reads the types from the squares of the labels, and finds the eight type pairs word for word in the log of cat·C1.](figs/fig09_clock_monoid.svg)

The eight repeats: eight generators of square +1 bring the clock back to 0, and Cl(p+8,q) ≅ Cl(p,q) ⊗ M₁₆(ℝ) (recalled, the Bott repeat in the algebra). The Atlas computes the clock, its additivity and the type pairs; the periodicity theorem of topology is not in it.

**Where the course goes further.** Coherence theorems, fusion and modular categories, the classification of pointed braided categories by quadratic forms (recalled: Etingof, Gelaki, Nikshych and Ostrik). The category lens records the Atlas's nearest rows: the form w = π + 2Q as a metric group (entry D05) and the automorphisms of the cell as braided autoequivalences of the pointed category (entry D44).

> **Try it.** Concatenate Cl(1,3) and Cl(3,1). Predict the clock of Cl(4,4) from 6 + 2, and check it against the Gauss sum (1 + i)⁴(1 − i)⁴ = 16.

### C9 · Frobenius algebras and the shadow of a 2d TQFT

**The course.** A Frobenius algebra is a finite-dimensional algebra A with a linear form ε whose pairing (x, y) ↦ ε(xy) is non-degenerate. Its Nakayama automorphism ν is fixed by ε(xy) = ε(y ν(x)); the form is symmetric when ν is the identity, and some form is symmetric exactly when ν is inner (recalled: Skowroński and Yamagata, *Frobenius Algebras I*). Equivalently, A has a comultiplication Δ: A → A ⊗ A, a map of A-bimodules with counit ε. The commutative ones are the two-dimensional topological quantum field theories: the circle goes to A, the pair of pants to the product m, the cup to the unit, the cap to ε, and a closed surface of genus g to the number ε(Hᵍ), where H, the handle element, is m∘Δ applied to 1 (recalled: Atiyah, *Topological quantum field theories*; Abrams; Kock, *Frobenius Algebras and 2D Topological Quantum Field Theories*).

**The Atlas's object.** Let λ(x) be the coefficient of the full label F = 1…1 in x. LNC-028: "λ(eₐe_b) ≠ 0 exactly when b = a ⊕ F, and then it is ±1. Because a and a ⊕ F share no bit, no square is ever used: the signed antidiagonal is the same for every signature, and the pairing is non-degenerate with null generators too. Cl(p,q,r) is a Frobenius algebra for every (p,q,r)." (Also LNC-004 and LNC-111; Thm T3 (F1); `cat·F1` on the 55 signatures with one to five generators, and `check_T3.log` on all 119 with n ≤ 6.) The Nakayama sign: λ(eₐe_b) = (−1)^(|b|(n−|b|)) λ(e_b eₐ), the identity for n odd and the grade involution α for n even (LNC-029; LNC-112; `cat·F2`). Ungraded, some symmetric Frobenius form exists exactly when n is odd or r = 0 (LNC-030; LNC-090; Thm T3 (F3); `cat·F3`): for n even with a null generator, every element that would implement α lies in the radical, so no unit does, and the projective algebra Cl(3,0,1) is Frobenius but not symmetric.

In super vector spaces the twist disappears. With b the complement of a the Nakayama sign is (−1)^(|a||b|), the Koszul sign, so λ(xy) = (−1)^(|x||y|) λ(yx) for homogeneous x and y in every signature: λ is super-symmetric and every cell is a symmetric Frobenius algebra in sVec (LNC-029; LNC-030; `bd·cat·5`, on all 3279 sign vectors with n ≤ 7). The forms themselves: every Frobenius form is λ(u·) with u a unit, and only the symmetric ones, when they exist, are a torsor under the central units (LNC-032; LNC-114; Thm T3, TOR; `cat·F5`); the super-symmetric ones are λ(z·) with z a unit of the super-centre Λ(ℝʳ), a torsor for every signature (`bd·cat·8`, 55 signatures), which turns the ungraded "dead end" of LNC-066 into a theorem in sVec. The scalar part ⟨x⟩₀, the trace of quantum mechanics, is the ungraded symmetric form; its pairing has rank 2^(p+q), blind to every label with a null bit, and multiplication by e_F is a metric Hodge star only when no generator is null (LNC-031; LNC-033; LNC-113; `cat·F4`; `bd·cat·6`), and in Cl(3,0) λ(x) = −⟨ωx⟩₀ with ω = e₁₂₃ (LNC-034; `check_T3.log`, line C2).

![The pairing λ(eₐ e_b) of Cl(3,0) and of Cl(3,0,1), labels in binary order, blue +1 and red −1: one entry in each row, on the antidiagonal b = a ⊕ 1…1. Below each, the Nakayama sign of every label: all + for n = 3, (−1)^|b| for n = 4. Drawn by figs_cat.py, which computes every product by the rule and checks the rank, the Nakayama sign and the super-symmetry on all pairs.](figs/fig10_frobenius.svg)

@@widget frobenius

#### If you want the proof

λ(eₐ e_b) is s(a,b) when a ⊕ b = F and 0 otherwise. a ⊕ b = F means that b is the complement of a, and then a ∧ b is empty, so s(a,b) = (−1)^N(a,b) with no square in it: the Gram matrix is a signed permutation matrix, invertible whatever the squares. For the Nakayama sign, every pair (i in a, j in b) of disjoint labels is out of order in exactly one of the two products, so N(a,b) + N(b,a) = |a||b|, and with |a| = n − |b| the ratio λ(eₐe_b)/λ(e_beₐ) is (−1)^(|b|(n−|b|)). For n odd one of |b|, n − |b| is even and the sign is +1.

The shadow of the field theory. The handle element of λ, H = Σₐ eₐ eᵃ with eᵃ the dual basis, is exactly 2ⁿ e_F in every cell with n ≤ 5, and it squares to 0 exactly when a generator is null (`bd·cat·22`). For the exterior algebra Λ(ℝʳ), which is super-commutative, LNB-025c draws the conclusion: with its top form it is "a commutative Frobenius monoid in super vector spaces, and not a special one"; in the super convention, with the copairing inverse to the pairing, m∘Δ is 0 for r even and multiplication by 2^r times the top label, which squares to 0, for r odd (hch·8, r ≤ 4), so the window element Σₐ eₐ eᵃ = 2ʳ e_F above is m∘Δ(1) only for r odd. In the dictionary of the field theory (recalled) the ungraded handle gives λ(1) = 0 to the sphere, λ(H) = 2ʳ to the torus and λ(Hᵍ) = 0 to every surface of genus g ≥ 2; this reading of `bd·cat·22` is ours, in the ungraded convention (the category theorist's reading of the Atlas computes it the same way and leaves the version with spin structures open). The cells with p + q ≥ 1 are not commutative, not even in the super sense, so they give no such theory (LNB-025d, ours). Two more rows of the same family: λ is the Berezin integral, and on the Grassmann cell the top coefficient of exp(Σ A_ij θᵢθⱼ) is the Pfaffian Pf(A) (CAND-123; `fock·P1`, n = 2 … 10); and a Frobenius algebra has a symmetric form exactly when its Nakayama automorphism is inner, so Λ(V) is symmetric exactly when dim V is odd (CAND-061).

![The pictures of a Frobenius algebra: the unit, the trace λ, the product m, the coproduct Δ and the handle m∘Δ. Below, the handle element H, H², λ(1) and λ(H) in five cells. The cobordism pictures are the recalled axioms; the table is drawn by figs_cat.py from the rule (the dual basis, the sum and the square computed exactly) and compared with the log of bd·cat·22.](figs/fig11_pair_of_pants.svg)

The Atiyah page of the Atlas (section 5, theme 11) puts it plainly: "No row uses 'TQFT', 'topological quantum field' or 'group ring'. What it has is the Frobenius side."

**Where the course goes further.** The equivalence between commutative Frobenius algebras and 2d TQFTs, open–closed and spin theories, the Frobenius algebras of fusion categories (recalled: Kock; Moore and Segal). LNB-037b asks whether the Frobenius forms of label algebras could serve as a finite test case for statements about open systems (open).

> **Try it.** In Cl(1,1), compute λ(e₁ e₂) and λ(e₂ e₁). Predict their ratio from the Nakayama sign (−1)^(|b|(n−|b|)) with n = 2 and b = e₂, then set the widget to (1,1,0) and read the strip.

### Three questions for a specialist in tensor categories

1. **A finite test case.** LNB-037b asks whether the Frobenius forms of label algebras can serve as a finite test case for category-theoretic statements about open systems. The nearest rows are LNB-025c (the commutative Frobenius monoid Λ(ℝʳ) in sVec, not special) and LNB-025d (the cospan reading, ours). Open.
2. **Which surfaces see label 0?** The handle element is nilpotent exactly when a generator is null (`bd·cat·22`). In a version with spin structures, where the torus should give a super-dimension, which surfaces see a null generator? The nearest row is LNC-077, which asks whether the Nakayama twist of the exterior and projective algebras is known and whether it matters for the duality of projective geometric algebra. Open.
3. **Wall inside the labels.** How much of BW(ℝ) ≅ ℤ₈ can be computed on the labels alone? The group law (`cat·K5a`), the clock (`cat·K4a`) and the type pairs (`cat·C1`) are; the class map and its group law are (CAND-004); graded Morita equivalence itself needs bimodules and stays recalled.

## Part III · Homological algebra on the labels

Complexes, exactness and homology; the incidence algebra of a poset and the representation theory of finite-dimensional algebras; Hochschild cohomology; and the index of a complex, the finite case of the index theorems. Each object is built from the same signs.

### C10 · The Koszul complex

**The course.** A chain complex is a sequence of linear maps with d∘d = 0; its homology measures the failure of exactness, and a contracting homotopy h with dh + hd = id proves exactness. The Koszul complex of a sequence x₁, …, x_n lives on the exterior algebra, with d the contraction by x; it is exact when the sequence is regular (recalled: Weibel, *An Introduction to Homological Algebra*, section 4.5; Eisenbud, *Commutative Algebra*, chapter 17).

**The Atlas's object.** Thm T6 (b): $d\,e_a = \sum_{i\in a} \sigma(a-i,i)\, e_{a-i}$ with σ(b, i) = (−1)^#(j ∈ b, j < i), the Jordan–Wigner sign of C2. It squares to zero, wedging with the first generator is a contracting homotopy, and the complex is exact, of total rank 2ⁿ⁻¹ and rank C(n−1, k−1) in degree k. `check_T6.log` (line KZ): "d^2 = 0 and dh + hd = id (h = wedge by e_0) on all labels for n <= 7; rank d = 2^{n-1} (exact) for n <= 6"; `cat·K1e` says the same and adds that the sign is that of the creation operators of the Fock space. LNC-056 ties the threads: "The same signs give the Koszul boundary, which squares to 0 and is exact."

![The Koszul complex on the labels of four generators: the spaces Λᵏ of dimension C(4,k) and, under each arrow, the rank of d; below, the total rank of d against 2ⁿ for n = 1 … 6. Drawn by figs_cat.py, which builds d from the sign, checks d² = 0 and dh + hd = id on every label and computes the ranks exactly.](figs/fig13_koszul_ranks.svg)

The same signs give two more complexes. With the arrows of Bₙ as cells and the bit-rule sign as orientation, the cube complex has ∂² = 0 and the homology of a point (LNC-140, n ≤ 5). And the radical of Cl(p,q,r) has the layers J^k/J^(k+1) of dimension C(r,k)·2^(p+q), with Loewy length r + 1 (LNC-016; Thm T2 (3); `cat·R2`), read from products, not from a formula.

A reading from physics stands beside this complex: CAND-142, "A nilpotent BRST charge Q (Q² = 0) defines the physical states as ker Q / im Q". Its finite part is checked (the Koszul boundary squares to 0 and is exact, with zero cohomology in every degree, for n ≤ 6; the null generators have zero expectation, every state vanishing on the radical, for n ≤ 5); the gauge-theory content is recalled, not on the engine (CAND-142, proved by the Atlas as a reading).

#### If you want the proof

d is the contraction with the vector (1, …, 1), and it is an antiderivation: d(e₁ ∧ x) = x − e₁ ∧ dx for the first generator e₁, whose contraction is 1. With h = e₁ ∧ ·, dh(x) + hd(x) = x − e₁ ∧ dx + e₁ ∧ dx = x. So every x with dx = 0 is d(hx): the complex is exact. Its Euler characteristic, Σ (−1)ᵏ C(n,k) = 0, is the super-dimension of C12.

**Where the course goes further.** Koszul complexes of regular sequences in commutative rings, spectral sequences, derived functors (recalled: Weibel). The Atlas has one complex per n, over ℝ, with exact ranks.

> **Try it.** For n = 3 compute d e₁₂₃ = e₂₃ − e₁₃ + e₁₂ from the sign, then apply d again and watch the six terms cancel in pairs.

### C11 · The incidence algebra, representation type, Hochschild cohomology

**The course.** The incidence algebra of a finite poset has a basis of the pairs x ≤ y and the convolution product; it is the path algebra of the Hasse diagram with the relations that make every square commute. Its modules are the representations; an algebra is of finite type when it has finitely many indecomposable modules, tame when they come in one-parameter families, and wild otherwise (recalled: Assem, Simson and Skowroński, *Elements of the Representation Theory of Associative Algebras*, volume 1). The Cartan matrix, the Euler form and the Tits form are the quadratic forms that govern the type. Hochschild cohomology HH^k(A) measures derivations (k = 1) and deformations (k = 2); for the incidence algebra of a poset it is the simplicial cohomology of its order complex (recalled: Gerstenhaber and Schack, *Simplicial cohomology is Hochschild cohomology*).

**The Atlas's object.** The incidence algebra of the cube is A_n = kBₙ = (kA₂)^⊗n, the path algebra of the n-cube with commuting squares (Thm T8). THM-004 builds it inside the neutral cell: "Over ℝ, A_n sits in the neutral cell Cl(n,n) = M₂ⁿ(ℝ) as the sum of the Peirce spaces P_T Cl(n,n) P_S over S ⊆ T, spanned by the 3ⁿ matrix units |T⟩⟨S|. The 2ⁿ Peirce idempotents and the Witt nulls (eᵢ + fᵢ)/2, the creation operators of T20 (e), generate it". Its radical, spanned by the arrows with S ≠ T, has dimension 3ⁿ − 2ⁿ and Loewy length n + 1, and its global dimension is n (THM-004; `bd·mja·10`, `bd·mja·11`, `bd·mja·14`). For n = 2: dimension 9, radical 5, J² of dimension 1, J³ = 0 (`mja_incidence.log`), and Ext between simples is one-dimensional exactly in degree |T∖S|. LNC-144 reads it as physics: "Read as occupation patterns, the labels make the cube category a category of creation processes", the arrow S → T being the matrix unit |T⟩⟨S| and [N, A] = |T∖S| A.

![The incidence algebra of B₂: its quiver (the Hasse diagram, with one commuting square), its nine matrix units |T⟩⟨S| (blue the idempotents, amber the radical), the Cartan matrix and its inverse, the Möbius function, which is the Euler form. Drawn by figs_cat.py, which generates the algebra from the creation operators of the null cell (left multiplication by eᵢ) and the projectors on the labels, and compares dimension, radical and its powers with the log of bd·mja·11.](figs/fig14_incidence_b2.svg)

Representation type (Thm T8). The Cartan matrix is the n-th Kronecker power of [[1,1],[0,1]] and the Euler form is the Möbius function; symmetrised, its signatures are (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0 … 5 (`check_T8.log`, line CART; LNC-051; LNC-058). The Tits form equals it for n ≤ 2 and has signatures (6,1,1), (14,2,0), (22,6,4) for n = 3, 4, 5 (line TITS). The algebra is of finite type for n ≤ 2 and not of finite type from n = 3, where the labels of grade 1 and 2 form a hexagon, the crown Ã₅ (line CROWN; LNC-052). Thm T8 records, over an algebraically closed field, tameness at n = 3 and a derived equivalence with the canonical algebra of type (3,3,3) as standard (Wang, Proposition 3.1; Ladkani, Example 2.2), and wildness for n ≥ 4 as recalled (de la Peña). The category page lists the question for k B₃ as open (LNC-054; LNC-083, which notes the Coxeter polynomial (x − 1)²(x² + x + 1)³ and that "it is not strongly simply connected, so the usual criterion does not apply").

![The symmetrised Euler form and the Tits form of k Bₙ for n = 0 … 5, as shares of positive, negative and null directions, with the type. Drawn by figs_cat.py, which diagonalises both forms exactly over the rationals and finds the signatures word for word in the log of check_T8; the names tame and wild are recalled.](figs/fig15_rep_type.svg)

Hochschild cohomology. `bd·mja·13` computes it: the incidence algebra of Bₙ is rigid, HH⁰ = ℝ and HH^k = 0 for k ≥ 1, "as the order complex of B_n is contractible" (C3), while the exterior algebras are not: Λ(ℝ¹) has HH of dimensions 2, 1, 1, 1 and Λ(ℝ²) of dimensions 2, 4, 6 in the degrees computed. For the cells themselves LNC-055 states that over its super-centre Λ(ℝʳ) a cell is graded Azumaya, "and its graded Hochschild groups HH¹ and HH² relative to Λ(ℝ^{r}) vanish (r = 1 with p + q ≤ 3 and r = 2 with p + q ≤ 2 …), so r is the base ring; for every (p,q,r) this follows from the separability of Cl(p,q) (pointer, source unread)" (the category lens, entry D18, with `bd·hh·3` and `bd·hh·5`).

**Where the course goes further.** Auslander–Reiten theory, tilting, derived categories, the classification of tame algebras (recalled: Assem, Simson and Skowroński). The representation type of the exterior algebra Λ(kʳ), finite for r ≤ 1, tame for r = 2 and wild for r ≥ 3, is recalled in LNC-084, which asks what it becomes for Cl(p,q) ⊗̂ Λ(ℝʳ).

> **Try it.** For n = 2 write the Cartan matrix C = [[1,1],[0,1]] ⊗ [[1,1],[0,1]] in the order 1, e₁, e₂, e₁₂, invert it, and check that the inverse has the entries (−1)^|T∖S| for S ⊆ T: the Möbius function of B₂.

### C12 · The index as a finite Lefschetz number

**The course.** For a complex of finite-dimensional spaces and a chain map f, the Lefschetz number L(f) = Σ (−1)ᵏ tr(f on Hᵏ) equals Σ (−1)ᵏ tr(f on Cᵏ), the Hopf trace formula; for f = id it is the Euler characteristic. The Lefschetz fixed-point theorem counts fixed points with it; the Atiyah–Bott formula and the index theorem extend it to elliptic operators, and in supersymmetric quantum mechanics the Witten index Tr(−1)^F e^(−βH) counts bosonic minus fermionic ground states, independent of β (recalled: Witten, *Constraints on supersymmetry breaking*; Atiyah and Bott, *A Lefschetz fixed point formula for elliptic complexes*).

**The Atlas's objects.** The super-dimension of the labels: Σₐ (−1)^|a| = 0 for the 2ⁿ labels, n ≥ 1 (T20 (d); `fock·W1`, n = 1 … 8, "each mode pairs |0> with |1>"). `cat·B1` gives its use: on the 2ⁿ labels the fermionic oscillators satisfy the ladder relations of the boson with the commutator replaced by the super-commutator, and "the dimension is 2^n but the super-dimension (trace of the parity) is 0, which is what a relation [a, a+] = 1 needs" (LNC-060). In a symmetric monoidal category this is the categorical trace of the identity, and the trace of a super-commutator vanishes (the category lens's dictionary, which marks the wording as ours). LNC-080 asks whether super-dimension 0 is the finite shadow of why the bosonic ladder needs infinite dimension (open).

![The labels of Λ(ℝⁿ) counted by grade, even grades green and odd amber, for n = 1 … 8: the dimension 2ⁿ and the super-dimension 0. Drawn by figs_cat.py from the labels of the null cell.](figs/fig12_superdimension.svg)

The Witten index on the labels: CAND-135, a row proved by the Atlas. On finite graded complexes built from Λ(ℝⁿ) with Q² = 0 and H = QQ† + Q†Q, Tr(−1)^F e^(−βH) is the Euler number of the cohomology, independent of β. `fock·W2` builds 164 complexes (Q conjugated by random graded invertible maps and deformed, and cut at a degree K) and finds Σ (−1)ᵏ dim Hᵏ = Σ (−1)ᵏ dim Cᵏ = (−1)^K C(n−1, K) in all of them; `fock·W3` computes the trace with numpy at β = 0.05, 0.5 and 5 and finds the exact Euler number every time, and two controls fail as they must: with Q² ≠ 0 the trace depends on β, and so does the plain trace Tr e^(−βH) (`fock_encodings.log`). The Atiyah page (theme 5) calls this "the finite case of the heat-kernel identity, exactly".

![The Euler numbers (−1)^K C(n−1, K) of the Koszul complexes on Λ(ℝⁿ), n = 1 … 6, cut at degree K; at K = n the complex is exact and the index is the super-dimension 0. Drawn by figs_cat.py, which builds Q as left multiplication by w = e₁ + 2e₂ + … in the null cell, computes the cohomology from exact ranks and the trace with numpy at three values of β.](figs/fig18_index.svg)

#### If you want the proof

Q maps the eigenspace of H with eigenvalue μ in degree k to the eigenspace with the same μ in degree k + 1, and Q† maps it back; for μ ≠ 0, QQ† + Q†Q = μ on it, so the space splits into pairs of equal dimension in adjacent degrees, which cancel in the supertrace. Only μ = 0 remains, the harmonic elements, one for each cohomology class: Tr(−1)^F e^(−βH) = Σ (−1)ᵏ dim Hᵏ for every β.

The Lefschetz number. For f = id the index is the Lefschetz number of the identity. The Atiyah page proposes the next check, which the Atlas has not run: on the cube complex of LNC-140, for each of the 2ⁿ n! symmetries f of the cube, Tr((−1)^F f e^(−βH)) should be 1 for every β and equal the signed count of the faces that f carries to themselves (recalled from the Atiyah–Bott formula). It is a computation the rule can do; it is not a row.

**Where the course goes further.** Elliptic operators on manifolds, the heat-kernel proof of the index theorem, the local index formula and the eta invariant (recalled; the Atiyah page lists them as beyond the Atlas).

> **Try it.** For n = 3 cut the complex at K = 1: the spaces have dimensions 1 and 3. Compute the Euler number and compare it with the entry (−1)¹ C(2, 1) of the table.

### Pointers beyond the course: enriched, comma, braided, Morita

No source is read in this tutorial for these structures; the rows and the dictionary's own tags carry them.

- **Enriched.** The insertion distance |T∖S| is a Lawvere metric, a category enriched in [0, ∞] (LNC-139; Lawvere's paper is recalled). Majkić's distance on the arrows of Bₙ is of the same kind (LNC-139).
- **Functor categories.** Majkić's comma-propagation levels C_(k+1) = C_k ↓ C_k are the functor categories Fun(Bₖ, C) (LNC-143, ours, computed for six base categories); the general statement is the cartesian closure of Cat with Bₖ₊₁ = Bₖ × B₁ (CAND-097).
- **Braided.** The automorphisms of the cell (V, Q, π) are the braided autoequivalences of a pointed braided category (the category lens, entry D44, with Drinfeld, Gelaki, Nikshych and Ostrik recalled).
- **Morita.** The Peirce decomposition and the Morita equivalence of A with eAe for a full idempotent e (CAND-098); the fibre and base of the Atlas have no category term in the dictionary (entry D48).
- **Not here.** Tian's DG category, whose K₀ is the ℤ-form of the algebra, has no counterpart and was not tested (LNC-069, open); bicategories and n-categories are not in the Atlas.

### Three questions for a representation theorist

1. **k B₃ over the reals.** Thm T8 records tameness at n = 3 and the derived equivalence with the canonical algebra of type (3,3,3) over an algebraically closed field (Wang; Ladkani). Does that settle LNC-083 for the real algebra the Atlas builds, and can the Atlas check the derived equivalence itself, with an explicit tilting complex? The nearest rows are LNC-058 (the forms) and LNC-054. Open.
2. **Label 0 and representation type.** LNC-084 recalls the type of Λ(kʳ) (finite, tame, wild for r ≤ 1, r = 2, r ≥ 3) and asks whether it measures how far label 0 is from invertible, and what it becomes for Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝʳ) with p + q ≥ 1. Open.
3. **The Lefschetz numbers of the cube.** The Atiyah page proposes the twisted index Tr((−1)^F f e^(−βH)) on the cube complex of LNC-140 for every symmetry f, expected 1 and the signed count of fixed faces. The nearest rows are CAND-135 (the untwisted index) and LNC-140 (the complex). Not computed.

## Closing table · one object, three names

| In the course | In the Atlas | Row and status |
|---|---|---|
| category, small and finite | the cube category Bₙ: labels and inclusions | SHP-007, LNC-099: proved by the Atlas |
| poset, thin acyclic category | the Boolean lattice of labels | LNC-056, LNC-138: proved by the Atlas |
| nerve, order complex | n! maximal chains, the cube [0,1]ⁿ | LNC-140: proved by the Atlas |
| group as a one-object category | the labels under XOR, ℤ₂ⁿ | THM-003: proved by the Atlas |
| 2-cocycle, twisted group algebra, H² | the sign s; quadratic forms | LNC-050b, THM-003: proved by the Atlas |
| partial monoid | the labels under disjoint sum | LNC-099: proved by the Atlas |
| monoid with zero, contracted algebra | the labels of a cell with null bits | LNC-086: open |
| Jacobson radical, Loewy series | J, the labels with a null bit | LNC-002, LNC-016: proved by the Atlas |
| functor to (ℕ, +) | the grade of an arrow | LNC-138: proved by the Atlas |
| ℤ₂-grading, sVec | the parity of a label | THM-006: proved by the Atlas |
| universal grading group | ℤ₂^(p+q) × ℤ^r | LNC-003: proved by the Atlas; LNC-085: open |
| functor on quadratic spaces | restrict, quotient, mother | LNC-041: proved by the Atlas |
| natural isomorphism | halving through t | LNC-117, LNC-119: proved by the Atlas |
| presheaf, sheaf | the cell over Bₙ | LNC-141: proved by the Atlas |
| Yoneda's lemma | natural maps from hom(−, T) | our example; no row |
| product, coproduct, adjunction Δ ⊣ ∧ | AND, OR | LNC-142: proved by the Atlas |
| divisor lattice | prime names, XOR = ab/gcd² | FUR-523: about the Atlas |
| monoidal unit | the empty label | LNC-011: proved by the Atlas |
| graded tensor product ⊗̂ | concatenation of generator lists | LNC-035, LNC-117: proved by the Atlas |
| symmetry of sVec | the swap sign of two labels | LNC-029: proved by the Atlas |
| associator, 3-cocycle | the octonion sign, (−1)^det | CAND-094: proved by the Atlas |
| Brauer–Wall group | the clock p − q mod 8 | LNC-055, CAND-004: proved by the Atlas |
| Frobenius algebra, Nakayama automorphism | the top-label form λ | LNC-028, LNC-029, LNC-111: proved by the Atlas |
| symmetric Frobenius algebra | n odd or r = 0; always in sVec | LNC-030: proved by the Atlas |
| commutative Frobenius monoid, 2d TQFT | Λ(ℝʳ) with λ, not special | LNB-025c: proved by the Atlas; LNB-025d: our reading |
| Berezin integral, Pfaffian | λ on the Grassmann cell | CAND-123: proved by the Atlas |
| Koszul complex | d on the labels | LNC-056, CAND-142: proved by the Atlas |
| incidence algebra | A_n inside Cl(n,n) | THM-004, LNC-144: proved by the Atlas |
| representation type | finite, then not finite from n = 3 | LNC-058: proved by the Atlas; LNC-083: open |
| Hochschild cohomology | rigid incidence algebra; graded Azumaya cells | THM-004, LNC-055: proved by the Atlas |
| super-dimension, Witten index | sdim 0; Tr(−1)^F e^(−βH) | CAND-135, LNC-060: proved by the Atlas; LNC-080: open |
| Lawvere metric, enriched category | the insertion distance | LNC-139: proved by the Atlas |
| functor category | comma levels Fun(Bₖ, C) | LNC-143: proved by the Atlas |

## Sources, and how far each was read

**The rows of the Atlas** (each read in full with `tools/proofs_todo.mjs --row`, with its status from `content/derived/status.json`): SHP-007; LNC-002, LNC-003, LNC-004, LNC-011, LNC-016, LNC-018, LNC-020, LNC-028, LNC-029, LNC-030, LNC-031, LNC-032, LNC-033, LNC-034, LNC-035, LNC-036, LNC-038, LNC-039, LNC-040, LNC-041, LNC-050, LNC-050b, LNC-051, LNC-052, LNC-054, LNC-055, LNC-056, LNC-058, LNC-060, LNC-063, LNC-066, LNC-069, LNC-073, LNC-073b, LNC-077, LNC-080, LNC-083, LNC-084, LNC-085, LNC-086, LNC-090, LNC-091, LNC-099, LNC-111, LNC-112, LNC-113, LNC-114, LNC-116, LNC-117, LNC-118, LNC-119, LNC-121, LNC-136, LNC-138, LNC-139, LNC-140, LNC-141, LNC-142, LNC-143, LNC-144; LNB-025, LNB-025c, LNB-025d, LNB-037b; THM-003, THM-004, THM-006; FUR-523; CAND-004, CAND-061, CAND-093, CAND-094, CAND-095, CAND-097, CAND-098, CAND-106, CAND-123, CAND-135, CAND-142. The other rows of the category page were read in the list of `steps/category` (215 rows) and are not cited.

**The theorems** T1, T2, T3, T5, T6, T8, T15 and T20 of `content/theorems.json`: statements, status notes and the lists of checks, read in full.

**The checks and their logs** (under `checks/selfcheck/proofs/logs/`, most in `reruns/`): `cat_check.log` (the 52 lines of `cat·S1` to `cat·C3`, read in full); `cat_frobenius.log` (`bd·cat·5` to `bd·cat·8`, `bd·cat·22`); `check_T3.log`, `check_T6.log`, `check_T8.log`, `check_T20.log`; `mja_incidence.log` (`bd·mja·9` to `bd·mja·15`); `mja_exterior.log` (`bd·mja·1` to `bd·mja·8`, `bd·mja·37`); `mjc_labels.log`, `mjc_sum.log`, `mjc_nerve.log`, `mjc_weight.log`, `mjc_comma.log`, `mjg_topology.log`, `mjp_fock.log`; `fock_encodings.log` (lines B, G, E, P and W); `lens_sch_check.compare.log` (the line `scw·P1c`). Cited without a log in the package: `bd·cat·16`, `bd·cat·17`, `catw·P1`, `bd·hh·3`, `bd·hh·5` (their records in `content/checks.json`). figs_cat.py finds 23 of its computed statements word for word in these files and the shipped tutorial; it prints the list when it runs.

**The pages of the Atlas.** `#/steps/category` (all its sections, through its rows); `#/steps/baez` (the section on the cospan paper, LNB-025 to LNB-025e); `#/logbook` (the researchers' table, THM-003 to THM-006); the category lens (`content/lenses.json`, key `cat`, all 153 entries of its dictionary); `reports/analyses/atiyah_lens.html` (section 5, themes 5 and 11, read in full; the rest of the page skimmed); `reports/analyses/reading_category_theory.html` (the summary and section 6, read; the rest skimmed); the kernel `engines/bitrule.js` (the sign function, copied into the widgets, and the `primes` lens).

**The shipped tutorial** `reports/html/bit_rule_tutorial.html`: Part 0 and Part C read in full; their order, their worked examples (n = 2, B₂, the Yoneda count) and their three questions are the base of this page.

**Textbooks and papers, recalled, not in the package** (none is in the second-source folder): S. Mac Lane, *Categories for the Working Mathematician*; T. Leinster, *Basic Category Theory*; S. Mac Lane and I. Moerdijk, *Sheaves in Geometry and Logic*; R. Stanley, *Enumerative Combinatorics*, volume 1; K. S. Brown, *Cohomology of Groups*; P. Etingof, S. Gelaki, D. Nikshych and V. Ostrik, *Tensor Categories*; P. Deligne and J. Morgan, *Notes on supersymmetry*; C. T. C. Wall, *Graded Brauer groups*; H. Albuquerque and S. Majid, *Quasialgebra structure of the octonions*; A. Skowroński and K. Yamagata, *Frobenius Algebras I*; M. Atiyah, *Topological quantum field theories*; L. Abrams, *Two-dimensional topological quantum field theories and Frobenius algebras*; J. Kock, *Frobenius Algebras and 2D Topological Quantum Field Theories*; G. Moore and G. Segal, *D-branes and K-theory in 2D topological field theory*; C. Weibel, *An Introduction to Homological Algebra*; D. Eisenbud, *Commutative Algebra with a View Toward Algebraic Geometry*; I. Assem, D. Simson and A. Skowroński, *Elements of the Representation Theory of Associative Algebras*, volume 1; M. Gerstenhaber and S. D. Schack, *Simplicial cohomology is Hochschild cohomology*; E. Witten, *Constraints on supersymmetry breaking*; M. Atiyah and R. Bott, *A Lefschetz fixed point formula for elliptic complexes*; F. W. Lawvere, *Metric spaces, generalized logic and closed categories*. Wang (arXiv:2407.11363) and Ladkani are cited as Thm T8 cites them, not read here.
