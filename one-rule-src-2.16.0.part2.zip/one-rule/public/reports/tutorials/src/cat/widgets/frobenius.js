(function (id) {
  // widgets/frobenius.js: the Frobenius form of a cell. Choose (p,q,r); the box draws the pairing λ(eₐ e_b), the coefficient of the
  // full label 1…1 in eₐ e_b, and the Nakayama sign of every label, and says which symmetry the form has. All of it is recomputed here
  // from the rule on every change; nothing is looked up.
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  const cell = (p, q, r = 0) => [...Array(p).fill(1), ...Array(q).fill(-1), ...Array(r).fill(0)];
  // self-test vectors (figs_cat.py checks them against the Atlas's rule): ten products of Cl(1,3), and λ(eₐ e_(a ⊕ 111)) in Cl(3,0)
  const EPS0 = [1, -1, -1, -1];
  const STORED = [[1, 1, 1], [1, 2, 1], [2, 1, -1], [3, 5, -1], [5, 3, 1], [6, 9, 1], [7, 7, -1], [11, 13, 1], [15, 15, -1], [12, 10, -1]];
  const LAMBDA30 = [1, 1, -1, 1, 1, -1, 1, 1];
  const lam = (a, b, eps) => (((a ^ b) === (1 << eps.length) - 1) ? sign(a, b, eps) : 0);
  const okP = STORED.every(([a, b, s]) => sign(a, b, EPS0) === s);
  const okL = LAMBDA30.every((v, a) => lam(a, a ^ 7, [1, 1, 1]) === v);
  if (!okP || !okL) { el.textContent = 'self-test failed'; return; }

  const SUB = '₀₁₂₃₄₅₆₇₈₉';
  const st = { p: 3, q: 0, r: 1 };
  el.innerHTML = '<div class="fw-ctl" style="display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center"></div>' +
    '<div class="fw-fig" style="margin-top:8px"></div><p class="widget__out"></p>';
  const ctl = el.querySelector('.fw-ctl'), fig = el.querySelector('.fw-fig'), out = el.querySelector('.widget__out');
  const names = { p: 'p (square +1)', q: 'q (square −1)', r: 'r (square 0)' };
  for (const k of ['p', 'q', 'r']) {
    const box = document.createElement('span');
    box.innerHTML = `<label>${names[k]}</label><button type="button" data-k="${k}" data-d="-1" aria-label="fewer">−</button> ` +
      `<b class="fw-v" data-k="${k}" style="display:inline-block;min-width:1.2em;text-align:center"></b> ` +
      `<button type="button" data-k="${k}" data-d="1" aria-label="more">+</button>`;
    ctl.appendChild(box);
  }
  ctl.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const k = b.dataset.k, d = +b.dataset.d, n = st.p + st.q + st.r;
    if (d > 0 && n >= 5) return;
    if (d < 0 && (st[k] === 0 || n <= 1)) return;
    st[k] += d; show();
  });
  function show() {
    for (const v of ctl.querySelectorAll('.fw-v')) v.textContent = st[v.dataset.k];
    const eps = cell(st.p, st.q, st.r), n = eps.length, N = 1 << n, F = N - 1;
    const cs = Math.min(22, Math.floor(288 / N)), W = N * cs, top = 16, left = 4;
    let nz = 0, perm = true, sym = true, ssym = true, nakOk = true;
    let svg = `<svg viewBox="0 0 ${W + 8} ${W + cs + 44}" width="${W + 8}" height="${W + cs + 44}" role="img" aria-label="the pairing matrix">`;
    svg += `<text x="${left}" y="11" font-size="11" style="fill:var(--muted,#6b6b64)">rows a, columns b (binary order); blue +1, red −1</text>`;
    svg += `<rect x="${left}" y="${top}" width="${W}" height="${W}" rx="3" style="fill:var(--tint,#f3f2ee)"/>`;
    for (let a = 0; a < N; a++) {
      let row = 0;
      for (let b = 0; b < N; b++) {
        const v = lam(a, b, eps);
        if (v !== lam(b, a, eps)) sym = false;
        if (v !== ((popcount(a) * popcount(b)) % 2 ? -1 : 1) * lam(b, a, eps)) ssym = false;
        if (!v) continue;
        row++; nz++;
        svg += `<rect x="${left + b * cs + 0.5}" y="${top + a * cs + 0.5}" width="${cs - 1}" height="${cs - 1}" rx="2" style="fill:${v > 0 ? '#2a78d6' : '#e34948'};fill-opacity:.75"/>`;
      }
      if (row !== 1) perm = false;
    }
    const ys = top + W + 18;
    svg += `<text x="${left}" y="${ys - 4}" font-size="11" style="fill:var(--muted,#6b6b64)">Nakayama sign ν(b) of each label b</text>`;
    for (let b = 0; b < N; b++) {
      const a = b ^ F, nu = lam(a, b, eps) * lam(b, a, eps);
      if (nu !== ((popcount(b) * (n - popcount(b))) % 2 ? -1 : 1)) nakOk = false;
      svg += `<rect x="${left + b * cs + 0.5}" y="${ys + 2}" width="${cs - 1}" height="${cs - 1}" rx="2" style="fill:${nu > 0 ? '#2a78d6' : '#e34948'};fill-opacity:.75"/>`;
    }
    fig.innerHTML = svg + '</svg>';
    const name = `Cl(${st.p},${st.q}${st.r ? ',' + st.r : ''})`;
    out.textContent =
      `${name}: n = ${n} generators, ${N} labels, ${N * N} pairs computed.\n` +
      `λ(eₐ e_b) ≠ 0 on ${nz} pairs, one in each row and column, at b = a ⊕ 1…1: ${perm ? 'non-degenerate (rank ' + N + ')' : 'DEGENERATE'}.\n` +
      `Nakayama sign: ${n % 2 ? 'always +1, the identity (n odd)' : '(−1)^|b|, the grade involution (n even)'}${nakOk ? '' : ' (formula FAILED)'}.\n` +
      `λ symmetric, λ(eₐ e_b) = λ(e_b eₐ): ${sym ? 'yes' : 'no'}.\n` +
      `Some symmetric Frobenius form exists (Thm T3, F3): ${n % 2 || st.r === 0 ? 'yes' : 'no: n is even and a generator is null'}.\n` +
      `Super-symmetric, λ(eₐ e_b) = (−1)^(|a||b|) λ(e_b eₐ): ${ssym ? 'yes, on every pair' : 'NO'}.`;
  }
  show();
})
