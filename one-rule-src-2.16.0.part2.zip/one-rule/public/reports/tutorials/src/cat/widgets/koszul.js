(function (id) {
  // widgets/koszul.js: the sign of a swap. Choose the squares of four generators and two labels a, b; the box multiplies both ways by
  // the rule and compares the swap sign σ (e_b eₐ = σ eₐ e_b) with the Koszul sign (−1)^(|a||b|) of super vector spaces. The strip
  // shows σ for the chosen a against all sixteen labels b, ringed where it differs from the Koszul sign.
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  // self-test vectors (figs_cat.py checks them against the Atlas's rule): ten products of the cell with squares (+1, +1, 0, −1)
  const EPS0 = [1, 1, 0, -1];
  const STORED = [[1, 1, 1], [1, 2, 1], [2, 1, -1], [3, 5, -1], [5, 3, 1], [6, 9, 1], [7, 7, 0], [11, 13, 1], [15, 15, 0], [12, 10, -1]];
  if (!STORED.every(([a, b, s]) => sign(a, b, EPS0) === s)) { el.textContent = 'self-test failed'; return; }

  const SUB = '₁₂₃₄', n = 4;
  const en = a => (a ? 'e' + [0, 1, 2, 3].filter(i => (a >> i) & 1).map(i => SUB[i]).join('') : '1');
  const sq = v => (v > 0 ? '+1' : v < 0 ? '−1' : '0');
  const st = { eps: [1, -1, -1, -1], a: 5, b: 12 };
  const row = (key, title) => `<div style="margin:4px 0"><label style="display:inline-block;min-width:5.6em">${title}</label>` +
    [0, 1, 2, 3].map(i => `<button type="button" data-row="${key}" data-i="${i}"></button>`).join(' ') + '</div>';
  el.innerHTML = row('eps', 'squares') + row('a', 'label a') + row('b', 'label b') + '<div class="kz-fig" style="margin-top:6px"></div><p class="widget__out"></p>';
  const fig = el.querySelector('.kz-fig'), out = el.querySelector('.widget__out');
  el.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const i = +b.dataset.i, k = b.dataset.row;
    if (k === 'eps') st.eps[i] = st.eps[i] === 1 ? -1 : st.eps[i] === -1 ? 0 : 1;
    else st[k] ^= 1 << i;
    show();
  });
  function show() {
    for (const b of el.querySelectorAll('button')) {
      const i = +b.dataset.i, k = b.dataset.row;
      if (k === 'eps') { b.textContent = `e${SUB[i]}² = ${sq(st.eps[i])}`; b.removeAttribute('aria-pressed'); }
      else { b.textContent = 'e' + SUB[i]; b.setAttribute('aria-pressed', String(!!((st[k] >> i) & 1))); }
    }
    const { eps, a, b } = st, ab = sign(a, b, eps), ba = sign(b, a, eps), kz = (popcount(a) * popcount(b)) % 2 ? -1 : 1, sh = popcount(a & b);
    const term = s => (s === 0 ? '0' : (s > 0 ? '+' : '−') + ' ' + en(a ^ b));
    let svg = `<svg viewBox="0 0 330 62" width="330" height="62" role="img" aria-label="swap signs of a against every label">`;
    svg += `<text x="2" y="11" font-size="11" style="fill:var(--muted,#6b6b64)">σ of ${en(a)} against b = 0 … 15; ringed: σ ≠ Koszul</text>`;
    for (let c = 0; c < 16; c++) {
      const s1 = sign(a, c, eps), s2 = sign(c, a, eps), x = 2 + c * 20.5;
      const sw = s1 === 0 ? 0 : s1 * s2, k2 = (popcount(a) * popcount(c)) % 2 ? -1 : 1;
      const fill = sw > 0 ? '#2a78d6' : sw < 0 ? '#e34948' : 'var(--tint,#f3f2ee)';
      svg += `<rect x="${x}" y="18" width="19" height="19" rx="3" style="fill:${fill};fill-opacity:${sw ? 0.7 : 1}"/>`;
      if (sw && sw !== k2) svg += `<circle cx="${x + 9.5}" cy="27.5" r="7" style="fill:none;stroke:var(--ink,#1a1a19);stroke-width:1.4"/>`;
      if (c === b) svg += `<rect x="${x - 1.5}" y="16.5" width="22" height="22" rx="4" style="fill:none;stroke:var(--acc,#184f95);stroke-width:2"/>`;
      svg += `<text x="${x + 9.5}" y="52" font-size="9.5" text-anchor="middle" style="fill:var(--muted,#6b6b64)">${c}</text>`;
    }
    fig.innerHTML = svg + '</svg>';
    let verdict;
    if (ab === 0) verdict = `the product is 0 both ways: a shared generator has square 0 (in Λ the overlapping products vanish).`;
    else if (sh === 0) verdict = `a and b share no generator: the swap sign is the Koszul sign, for every choice of squares.`;
    else verdict = `a and b share ${sh} generator${sh > 1 ? 's' : ''}: σ = Koszul × (−1)^${sh} = ${ab * ba > 0 ? '+1' : '−1'}.`;
    out.textContent =
      `eₐ = ${en(a)} (|a| = ${popcount(a)}), e_b = ${en(b)} (|b| = ${popcount(b)}), squares (${eps.map(sq).join(', ')}).\n` +
      `eₐ e_b = ${term(ab)}    e_b eₐ = ${term(ba)}\n` +
      `swap sign σ: ${ab === 0 ? 'none' : (ab * ba > 0 ? '+1' : '−1')};  Koszul sign (−1)^(|a||b|) = ${kz > 0 ? '+1' : '−1'}.\n` + verdict;
  }
  show();
})
