(function (id) {
  // widgets/primes.js: AND, OR and XOR of two labels, printed with prime names (e₁ = 2, e₂ = 3, e₃ = 5, e₄ = 7). The meet a ∧ b, the
  // product of B₄, is the gcd; the join a ∨ b, its coproduct, is the lcm; the label a ⊕ b of the product eₐ e_b is ab/gcd², and its
  // sign is computed in Cl(4,0) by the rule.
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  const PRIMES = [2, 3, 5, 7];
  const pn = a => PRIMES.reduce((v, p, i) => ((a >> i) & 1 ? v * p : v), 1);
  const gcd = (x, y) => (y ? gcd(y, x % y) : x);
  // self-test vectors (figs_cat.py checks them against the Atlas's rule): [a, b, the sign in Cl(4,0), the prime name of a ⊕ b]
  const EPS0 = [1, 1, 1, 1];
  const STORED = [[1, 1, 1, 1], [1, 2, 1, 6], [2, 1, -1, 6], [3, 5, -1, 15], [5, 3, 1, 15], [6, 9, 1, 210], [7, 7, -1, 1], [11, 13, -1, 15], [15, 15, 1, 1], [12, 10, 1, 15]];
  const okT = STORED.every(([a, b, s, x]) => sign(a, b, EPS0) === s && pn(a ^ b) === x && x === pn(a) * pn(b) / gcd(pn(a), pn(b)) ** 2);
  if (!okT) { el.textContent = 'self-test failed'; return; }

  const SUB = '₁₂₃₄';
  const en = a => (a ? 'e' + [0, 1, 2, 3].filter(i => (a >> i) & 1).map(i => SUB[i]).join('') : '1');
  const bits = a => [3, 2, 1, 0].map(i => (a >> i) & 1).join('');
  const st = { a: 3, b: 6 };
  const row = (key, title) => `<div style="margin:4px 0"><label style="display:inline-block;min-width:4.4em">${title}</label>` +
    [0, 1, 2, 3].map(i => `<button type="button" data-row="${key}" data-i="${i}">${PRIMES[i]} = e${SUB[i]}</button>`).join(' ') + '</div>';
  el.innerHTML = row('a', 'label a') + row('b', 'label b') + '<p class="widget__out"></p>';
  const out = el.querySelector('.widget__out');
  el.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; st[b.dataset.row] ^= 1 << +b.dataset.i; show(); });
  function show() {
    for (const b of el.querySelectorAll('button')) b.setAttribute('aria-pressed', String(!!((st[b.dataset.row] >> +b.dataset.i) & 1)));
    const { a, b } = st, pa = pn(a), pb = pn(b), g = gcd(pa, pb), s = sign(a, b, EPS0);
    const lab = x => `${pn(x)} = ${en(x)} (${bits(x)})`;
    out.textContent =
      `a = ${lab(a)}, b = ${lab(b)}\n` +
      `a ∧ b, AND, the meet (product of B₄):   gcd(${pa}, ${pb}) = ${lab(a & b)}\n` +
      `a ∨ b, OR, the join (coproduct):        lcm(${pa}, ${pb}) = ${lab(a | b)}\n` +
      `a ⊕ b, XOR, the label of eₐ e_b:        ${pa}·${pb}/${g}² = ${lab(a ^ b)}\n` +
      `in Cl(4,0): eₐ e_b = ${s > 0 ? '+' : '−'} ${en(a ^ b)}; the shared switches (${g === 1 ? 'none' : 'the gcd ' + g}) are squared to +1.\n` +
      `${(a & b) === 0 ? 'Disjoint labels: a ⊕ b = a ∨ b, an arrow a → a ∨ b of B₄ adds b.' : 'Overlapping labels: a ⊕ b lies below a ∨ b; the shared primes, a square gcd² inside ab, are divided out.'}`;
  }
  show();
})
