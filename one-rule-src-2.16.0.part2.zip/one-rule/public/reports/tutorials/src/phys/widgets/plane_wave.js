(function (id) {
  // plane_wave.js: a plane wave F = F0 f(ω t − k·x) on the labels of Cl(1,3). On it ∇ = Σ eₐ∂ₐ acts as F0 ↦ N F0 f′ with N = ω e₀ − k·e,
  // so ∇F = 0 for every profile f exactly when N F0 = 0: the kernel of an 8 × 6 matrix whose entries are bit-rule signs, found here by exact
  // elimination. Its dimension is 2 when ω² = |k|² and 0 otherwise (the light page, PAG-036; maxwell_selfcheck.py checks the wave f(t − z)).
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  const cell = (p, q, r = 0) => [...Array(p).fill(1), ...Array(q).fill(-1), ...Array(r).fill(0)];
  const C13 = cell(1, 3);
  // exact rationals [n, d]
  const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
  const Q = (n, d = 1) => { if (d < 0) { n = -n; d = -d; } const g = gcd(n, d); return [n / g, d / g]; };
  const qa = (x, y) => Q(x[0] * y[1] + y[0] * x[1], x[1] * y[1]), qm = (x, y) => Q(x[0] * y[0], x[1] * y[1]), qd = (x, y) => Q(x[0] * y[1], x[1] * y[0]);
  const qs = x => (x[1] === 1 ? String(x[0]) : x[0] + '/' + x[1]).replace('-', '−');
  const BIV = [3, 5, 6, 9, 10, 12], TGT = [1, 2, 4, 8, 7, 11, 13, 14];
  const NAME = { 3: 'γ₀₁', 5: 'γ₀₂', 6: 'γ₁₂', 9: 'γ₀₃', 10: 'γ₁₃', 12: 'γ₂₃', 1: 'γ₀', 2: 'γ₁', 4: 'γ₂', 8: 'γ₃', 7: 'γ₀₁₂', 11: 'γ₀₁₃', 13: 'γ₀₂₃', 14: 'γ₁₂₃' };
  function matrix(N) {                       // N: {mask: rational}; column j = N * e_BIV[j], read on the targets
    return TGT.map(t => BIV.map(b => { let v = Q(0); for (const g of Object.keys(N)) { if ((+g ^ b) === t) v = qa(v, qm(N[g], Q(sign(+g, b, C13)))); } return v; }));
  }
  function nullspace(M) {
    const A = M.map(r => r.slice()), piv = []; let r = 0;
    for (let c = 0; c < 6 && r < A.length; c++) {
      const p = A.findIndex((row, i) => i >= r && row[c][0] !== 0); if (p < 0) continue;
      [A[r], A[p]] = [A[p], A[r]]; const inv = A[r][c]; A[r] = A[r].map(x => qd(x, inv));
      for (let i = 0; i < A.length; i++) if (i !== r && A[i][c][0] !== 0) { const f = A[i][c]; A[i] = A[i].map((x, j) => qa(x, qm(Q(-1), qm(f, A[r][j])))); }
      piv.push(c); r++;
    }
    const free = [...Array(6).keys()].filter(c => !piv.includes(c));
    return free.map(f => { const x = Array(6).fill(Q(0)); x[f] = Q(1); piv.forEach((c, i) => { x[c] = qm(Q(-1), A[i][f]); }); return x; });
  }
  const Nof = (w, k) => { const N = { 1: w }; [2, 4, 8].forEach((g, i) => { if (k[i][0]) N[g] = qm(Q(-1), k[i]); }); return N; };
  // self-test: ten stored products (bitcliff.py) and the kernel dimensions of figs_phys.py along z, k = 1, ω = −2, −1, −1/2, 0, 1/2, 1, 2
  const STORED = [[1, 2, 1, 3], [2, 1, -1, 3], [3, 3, 1, 0], [6, 6, -1, 0], [15, 15, -1, 0], [14, 14, 1, 0], [5, 10, -1, 15], [7, 8, 1, 15], [12, 3, 1, 15], [9, 6, 1, 15]];
  const DIMS = [[-2, 0], [-1, 2], [-0.5, 0], [0, 0], [0.5, 0], [1, 2], [2, 0]];
  const z1 = [Q(0), Q(0), Q(1)];
  const bad = STORED.filter(([a, b, s, c]) => sign(a, b, C13) !== s || (a ^ b) !== c).length +
    DIMS.filter(([w, d]) => nullspace(matrix(Nof(Q(Math.round(w * 2), 2), z1))).length !== d).length;
  if (bad) { el.textContent = 'self-test failed: ' + bad + ' stored products or kernel dimensions disagree'; return; }

  const DIRS = [['z', [0, 0, 1], 1], ['x', [1, 0, 0], 1], ['(3,4,0)/5', [3, 4, 0], 5], ['(2,2,1)/3', [2, 2, 1], 3]];
  el.innerHTML = '<label>ω <input type="range" min="-12" max="12" value="4" data-k="w"> <b data-v="w"></b></label> ' +
    '<label>|k| <input type="range" min="1" max="12" value="4" data-k="k"> <b data-v="k"></b></label><br>' +
    '<span style="font-size:14px">direction of k: </span>' + DIRS.map((d, i) => '<button type="button" data-d="' + i + '" aria-pressed="' + (i === 0) + '">' + d[0] + '</button>').join(' ') +
    '<div class="widget__out" aria-live="polite"></div>';
  let dir = 0; const out = el.querySelector('.widget__out');
  const fmtF = x => BIV.map((b, j) => { if (!x[j][0]) return ''; const a = Q(Math.abs(x[j][0]), x[j][1]); return (x[j][0] > 0 ? '+ ' : '− ') + (a[0] === 1 && a[1] === 1 ? '' : qs(a) + ' ') + NAME[b]; }).filter(Boolean).join(' ').replace(/^\+ /, '');
  function square(x) {                       // F F by the bit rule: the scalar part is E² − B², the four-generator part is −2 E·B (PAG-036)
    const r = {}; BIV.forEach((a, i) => BIV.forEach((b, j) => { const m = a ^ b; r[m] = qa(r[m] || Q(0), qm(Q(sign(a, b, C13)), qm(x[i], x[j]))); })); return r;
  }
  function show() {
    const w = Q(+el.querySelector('[data-k="w"]').value, 4), km = Q(+el.querySelector('[data-k="k"]').value, 4), [nm, v, d] = DIRS[dir];
    el.querySelector('[data-v="w"]').textContent = qs(w); el.querySelector('[data-v="k"]').textContent = qs(km);
    const k = v.map(c => qm(km, Q(c, d))), N = Nof(w, k);
    let NN = Q(0); for (const a of Object.keys(N)) for (const b of Object.keys(N)) if (+a === +b) NN = qa(NN, qm(Q(sign(+a, +b, C13)), qm(N[a], N[b])));
    const K = nullspace(matrix(N));
    let s = 'N = ω γ₀ − k·γ, k along ' + nm + ';  N N = ' + qs(NN) + ' = ω² − |k|² by the bit rule (the cross terms cancel in twins)\n';
    s += 'kernel of F0 ↦ N F0 on the six bivector labels: dimension ' + K.length + '\n';
    if (K.length) {
      K.forEach((x, i) => { const sq = square(x); s += '  F' + (i + 1) + ' = ' + fmtF(x) + '   E² − B² = ' + qs(sq[0] || Q(0)) + ', E·B = ' + qs(qm(Q(-1, 2), sq[15] || Q(0))) + '\n'; });
      s += '∇F = 0 for every profile f: a light wave, ω = ' + (w[0] > 0 ? '+' : '−') + '|k|; both invariants vanish (a null field)';
    } else {
      const K1 = nullspace(matrix(Nof(km, k)))[0], NF = matrix(N).map(row => row.reduce((acc, m, j) => qa(acc, qm(m, K1[j])), Q(0)));
      const g1 = NF.slice(0, 4).some(q => q[0]), g3 = NF.slice(4).some(q => q[0]);
      s += 'no plane wave: ω² ≠ |k|². For the wave of ω = +|k|, N F0 has a grade-1 part ' + (g1 ? '≠ 0' : '= 0') + ' (Gauss, Ampère) and a grade-3 part ' + (g3 ? '≠ 0' : '= 0') + ' (Faraday, no monopole):\nthe two Maxwell equations fail together, in proportion to ω − |k|';
    }
    out.textContent = s;
  }
  el.addEventListener('input', show);
  el.addEventListener('click', e => { const b = e.target.closest('button[data-d]'); if (!b) return; dir = +b.dataset.d; el.querySelectorAll('button[data-d]').forEach(x => x.setAttribute('aria-pressed', String(x === b))); show(); });
  show();
})
