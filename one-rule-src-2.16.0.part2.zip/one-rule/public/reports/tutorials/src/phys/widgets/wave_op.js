(function (id) {
  // wave_op.js: which wave operator a cell Cl(p,q) gives. The diagonal of the square of the derivative, nabla nabla = sum e_a e_a d_a^2,
  // is read off the bit rule (e_a e_a = the square of generator a); the class is the rule of maxwell_selfcheck.symbol (check_T18, PAG-011).
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  const cell = (p, q, r = 0) => [...Array(p).fill(1), ...Array(q).fill(-1), ...Array(r).fill(0)];
  // self-test: ten products of Cl(1,3) as checks/selfcheck/steps15_17/bitcliff.py gives them, [a, b, sign, label of the product]
  const STORED = [[1, 2, 1, 3], [2, 1, -1, 3], [3, 3, 1, 0], [6, 6, -1, 0], [15, 15, -1, 0], [14, 14, 1, 0], [5, 10, -1, 15], [7, 8, 1, 15], [12, 3, 1, 15], [9, 6, 1, 15]];
  const C13 = cell(1, 3);
  const cls = (p, q) => (Math.min(p, q) === 0 ? 'elliptic' : Math.min(p, q) === 1 ? 'hyperbolic' : 'ultrahyperbolic');
  const CLASSES = [[1, 3, 'hyperbolic'], [3, 1, 'hyperbolic'], [2, 2, 'ultrahyperbolic'], [4, 0, 'elliptic'], [0, 4, 'elliptic']];   // maxwell_selfcheck.symbol
  const bad = STORED.filter(([a, b, s, c]) => sign(a, b, C13) !== s || (a ^ b) !== c).length + CLASSES.filter(([p, q, c]) => cls(p, q) !== c).length;
  if (bad) { el.textContent = 'self-test failed: ' + bad + ' stored products or classes disagree'; return; }

  const SUB = '₀₁₂₃₄₅₆₇₈₉', sub = n => String(n).split('').map(d => SUB[+d]).join('');
  el.innerHTML = '<label>p (square +1) <input type="range" min="0" max="8" value="1" data-k="p"> <b data-v="p"></b></label> ' +
    '<label>q (square −1) <input type="range" min="0" max="8" value="3" data-k="q"> <b data-v="q"></b></label>' +
    '<div class="widget__out" aria-live="polite"></div>';
  const inp = k => el.querySelector('input[data-k="' + k + '"]'), out = el.querySelector('.widget__out');
  function show() {
    let p = +inp('p').value, q = +inp('q').value;
    if (p + q > 9) { q = 9 - p; inp('q').value = q; }
    if (p + q === 0) { p = 1; inp('p').value = 1; }
    el.querySelector('[data-v="p"]').textContent = p; el.querySelector('[data-v="q"]').textContent = q;
    const eps = cell(p, q), n = p + q;
    const sq = [...Array(n).keys()].map(i => sign(1 << i, 1 << i, eps));               // e_i e_i by the bit rule
    const plus = sq.filter(s => s > 0).length, minus = sq.filter(s => s < 0).length;
    const diag = sq.map((s, i) => (s > 0 ? '+' : '−') + '∂' + sub(i + 1) + '²').join(' ');
    const c = cls(plus, minus), clock = ((p - q) % 8 + 8) % 8;
    let line = 'Cl(' + p + ',' + q + '): the squares of e₁ … e' + sub(n) + ' by the bit rule are ' + sq.map(s => (s > 0 ? '+1' : '−1')).join(' ') + '\n';
    line += '∇∇ = Σ eₐeₐ ∂ₐ² = ' + diag + '   (the 2·C(n,2) = ' + n * (n - 1) + ' off-diagonal terms cancel in twins)\n';
    line += 'class: ' + c + (c === 'hyperbolic' ? ' — a wave travels; the single ' + (plus === 1 ? 'plus' : 'minus') + ' switch is its time' : c === 'elliptic' ? ' — one sign: no wave, a Laplacian' : ' — two signs at least twice: no well-posed time direction') + '\n';
    line += 'clock p − q mod 8 = ' + clock + (n === 4 && c === 'hyperbolic' ? '   (this is space-time: ' + (p === 1 ? 'Cl(1,3), the Atlas’s choice' : 'Cl(3,1), its mirror') + ')' : '');
    out.textContent = line;
  }
  el.addEventListener('input', show); show();
})
