(function (id) {
  // einstein_ks.js: the Einstein tensor of a radial Kerr–Schild frame g = η + 2f(ρ) l l, recomputed in the browser from the closed form that
  // c1_birkhoff.log checks against the gravity engine (all 16 components, 28 samples): G^t_t = G^r_r = 2(ρf)′/ρ², the tangential eigenvalue
  // (ρf)″/ρ, and E_a(c) ∝ G − 3c δ (GRV-012, GRV-010). f is a Laurent polynomial with exact rational coefficients, so "vacuum" is decided
  // identically in ρ, not at one point.
  const el = document.getElementById(id); if (!el) return;
  const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
  const Q = (n, d = 1) => { if (d < 0) { n = -n; d = -d; } const g = gcd(n, d); return [n / g, d / g]; };
  const qa = (x, y) => Q(x[0] * y[1] + y[0] * x[1], x[1] * y[1]), qm = (x, y) => Q(x[0] * y[0], x[1] * y[1]);
  const qpow = (x, p) => { let r = Q(1); const b = p >= 0 ? x : Q(x[1], x[0]); for (let i = 0; i < Math.abs(p); i++) r = qm(r, b); return r; };
  const qs = x => (x[1] === 1 ? String(x[0]) : x[0] + '/' + x[1]).replace('-', '−');
  const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶' }, sup = p => String(p).split('').map(c => SUP[c]).join('');
  // Laurent polynomials {power: rational}
  const add = (A, p, c) => { const k = String(p); A[k] = qa(A[k] || Q(0), c); if (!A[k][0]) delete A[k]; return A; };
  function eigen(f) {                         // f -> { radial: 2(ρf)'/ρ², tangential: (ρf)''/ρ }  as Laurent polynomials
    const rad = {}, tan = {};
    for (const [p, c] of Object.entries(f)) { const k = +p; add(rad, k - 2, qm(c, Q(2 * (k + 1)))); add(tan, k - 2, qm(c, Q((k + 1) * k))); }
    return { rad, tan };
  }
  const shift = (A, c) => add({ ...A }, 0, qm(c, Q(-3)));            // G - 3c
  const at = (A, r) => Object.entries(A).reduce((s, [p, c]) => qa(s, qm(c, qpow(r, +p))), Q(0));
  const show_ = A => { const e = Object.entries(A).sort((a, b) => +b[0] - +a[0]); return e.length ? e.map(([p, c], i) => { const a = Q(Math.abs(c[0]), c[1]), one = a[0] === 1 && a[1] === 1 && +p; return (c[0] < 0 ? (i ? ' − ' : '−') : (i ? ' + ' : '')) + (one ? '' : qs(a)) + (+p ? 'ρ' + sup(+p) : ''); }).join('') : '0'; };
  // self-test: the closed forms of c1_birkhoff.log, f = ρ^k, k = −3 … 3: P_tt = 2(k+1)ρ^(k−2), P_tan = k(k+1)ρ^(k−2), here at ρ = 2;
  // and part 4 of the log: f = M/ρ + (c/2)ρ² solves E_a(c) = 0 for M in {1/3, −2, 5/7} and c in {0, 1/4, −1/3}
  const STORED = [[-3, [-1, 8], [3, 16]], [-2, [-1, 8], [1, 8]], [-1, [0, 1], [0, 1]], [0, [1, 2], [0, 1]], [1, [2, 1], [1, 1]], [2, [6, 1], [6, 1]], [3, [16, 1], [24, 1]]];
  let bad = STORED.filter(([k, r, t]) => { const e = eigen({ [k]: Q(1) }), a = at(e.rad, Q(2)), b = at(e.tan, Q(2)); return a[0] !== r[0] || a[1] !== r[1] || b[0] !== t[0] || b[1] !== t[1]; }).length;
  for (const M of [Q(1, 3), Q(-2), Q(5, 7)]) for (const c of [Q(0), Q(1, 4), Q(-1, 3)]) {
    const e = eigen({ '-1': M, 2: qm(c, Q(1, 2)) }); if (Object.keys(shift(e.rad, c)).length || Object.keys(shift(e.tan, c)).length) bad++;
  }
  if (bad) { el.textContent = 'self-test failed: ' + bad + ' closed forms of c1_birkhoff.log disagree'; return; }

  const S = [['M', 'M (the mass term M/ρ)', -8, 8, 4], ['s', 's (the charge term −s/ρ²)', 0, 8, 0], ['h', 'h (the term (h/2)ρ²)', -4, 4, 0],
    ['b', 'b (an extra term bρᵏ)', -4, 4, 0], ['k', 'k', -3, 3, 1], ['c', 'c (the engine’s cosmological term)', -4, 4, 0], ['r', 'ρ (the point)', 2, 16, 8]];
  el.innerHTML = S.map(([k, l, a, b, v]) => '<label style="display:block;margin:2px 0">' + l + ' <input type="range" min="' + a + '" max="' + b + '" value="' + v + '" data-k="' + k + '"> <b data-v="' + k + '"></b></label>').join(' ') +
    '<div class="widget__out" aria-live="polite"></div>';
  const v = k => +el.querySelector('[data-k="' + k + '"]').value, out = el.querySelector('.widget__out');
  function show() {
    const M = Q(v('M'), 4), s = Q(v('s'), 4), h = Q(v('h'), 4), b = Q(v('b'), 4), k = v('k'), c = Q(v('c'), 4), r = Q(v('r'), 4);
    [['M', M], ['s', s], ['h', h], ['b', b], ['k', Q(k)], ['c', c], ['r', r]].forEach(([n, x]) => { el.querySelector('[data-v="' + n + '"]').textContent = qs(x); });
    const f = {}; add(f, -1, M); add(f, -2, qm(s, Q(-1))); add(f, 2, qm(h, Q(1, 2))); add(f, k, b);
    const e = eigen(f), R = shift(e.rad, c), T = shift(e.tan, c), vac = !Object.keys(R).length && !Object.keys(T).length;
    let o = 'f(ρ) = ' + show_(f) + '\n';
    o += 'Gᵗₜ = Gʳᵣ = 2(ρf)′/ρ² = ' + show_(e.rad) + '   at ρ = ' + qs(r) + ': ' + qs(at(e.rad, r)) + '\n';
    o += 'G^θ_θ = G^φ_φ = (ρf)″/ρ = ' + show_(e.tan) + '   at ρ = ' + qs(r) + ': ' + qs(at(e.tan, r)) + '\n';
    o += 'E_a(c) ∝ G − 3c:  radial ' + show_(R) + ',  tangential ' + show_(T) + '\n';
    o += vac ? 'E_a(c) = 0 identically: a vacuum ' + (c[0] ? 'with the cosmological term (Schwarzschild–' + (c[0] > 0 ? 'de Sitter' : 'anti-de Sitter') + ' in this convention)' : '(Schwarzschild, for any M)') :
      'not a vacuum for this c' + (s[0] && !b[0] && h[0] === c[0] && h[1] === c[1] ? ': what is left, ±2sρ⁻⁴, is the stress of a point charge; E_a + κT_a = 0 when s = κQ²/4 (Reissner–Nordström, INP-050)' : '');
    out.textContent = o;
  }
  el.addEventListener('input', show); show();
})
