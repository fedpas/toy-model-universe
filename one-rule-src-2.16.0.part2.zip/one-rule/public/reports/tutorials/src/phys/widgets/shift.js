(function (id) {
  // shift.js: the shifted Dirac equation of Atiyah and Moore on the labels, (iD − m + iκ e^(−τD))ψ = 0, on the plane waves of mass E.
  // On those waves e^(−τD) is the right factor e^(J E τ) = cos Eτ + J sin Eτ (ATY-005), so the equation is one element a + bJ of the
  // algebra spanned by 1 and J = γ₂γ₁, multiplied here with the bit rule: ordinary half (E − m) + κ e^(JEτ) J, other half −(E + m) + κ e^(−JEτ) J.
  // A plane wave exists exactly when both parts vanish: cos Eτ = 0 and E = m + κ sin Eτ (ATY-005, shd·QNT in shifted_dirac.log).
  const el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  const cell = (p, q, r = 0) => [...Array(p).fill(1), ...Array(q).fill(-1), ...Array(r).fill(0)];
  const C13 = cell(1, 3);
  const Jc = sign(4, 2, C13), J2 = Jc * Jc * sign(6, 6, C13);          // J = γ₂γ₁ = Jc γ₁₂ (label 6), J² = J2
  const mul = ([a, b], [c, d]) => [a * c + b * d * J2, a * d + b * c];     // (a + bJ)(c + dJ)
  function residual(m, k, E, cs, sn) {
    const ord = mul([cs, sn], [0, 1]), oth = mul([cs, -sn], [0, 1]);
    return { ord: [E - m + k * ord[0], k * ord[1]], oth: [-(E + m) + k * oth[0], k * oth[1]] };
  }
  const zero = r => Math.abs(r[0]) < 1e-12 && Math.abs(r[1]) < 1e-12;
  // self-test: ten stored products (bitcliff.py) and the points of shifted_dirac.log (shd·QNT): [m, κ, E, cos Eτ, sin Eτ, half, exists]
  const STORED = [[1, 2, 1, 3], [2, 1, -1, 3], [3, 3, 1, 0], [6, 6, -1, 0], [15, 15, -1, 0], [14, 14, 1, 0], [5, 10, -1, 15], [7, 8, 1, 15], [12, 3, 1, 15], [9, 6, 1, 15]];
  const LOG = [[3, 2, 5, 0, 1, 'ord', true], [3, 2, 1, 0, -1, 'ord', true], [3, 2, 3, 1, 0, 'ord', false], [3, 2, 5, 1, 0, 'ord', false],
    [3, 2, 4, 0, 1, 'ord', false], [1, 4, 5, 0, 1, 'ord', true], [1, 4, 3, 0, 1, 'oth', true], [3, 2, 1, 0, 1, 'oth', false]];
  const bad = STORED.filter(([a, b, s, c]) => sign(a, b, C13) !== s || (a ^ b) !== c).length + (J2 === -1 ? 0 : 1) +
    LOG.filter(([m, k, E, c, s, h, ok]) => zero(residual(m, k, E, c, s)[h]) !== ok).length;
  if (bad) { el.textContent = 'self-test failed: ' + bad + ' stored products or log points disagree'; return; }

  el.innerHTML = '<label>m <input type="range" min="0" max="6" value="3" data-k="m"> <b data-v="m"></b></label> ' +
    '<label>κ <input type="range" min="0" max="6" value="2" data-k="k"> <b data-v="k"></b></label><br>' +
    '<label>E <input type="range" min="1" max="32" value="20" data-k="E"> <b data-v="E"></b></label> ' +
    '<label>τ <input type="range" min="0" max="500" value="31" data-k="t"> <b data-v="t"></b></label>' +
    '<div data-snap style="margin:6px 0"></div><svg viewBox="0 0 360 200" width="360" height="200" role="img" aria-label="the lattice of allowed shifts"></svg>' +
    '<div class="widget__out" aria-live="polite"></div>';
  const $ = s => el.querySelector(s), out = $('.widget__out'), svg = $('svg'), snapBox = $('[data-snap]');
  let snapped = null;                                        // [j, half] when the point sits exactly on the lattice
  const lattice = (m, k) => {
    const pts = [];
    for (let j = 0; j < 16; j++) {
      const E1 = m + (j % 2 ? -k : k); if (E1 > 0 && (j + .5) * Math.PI / E1 <= 5 && E1 <= 8) pts.push([j, E1, (j + .5) * Math.PI / E1, 'ord']);
      if (j % 2 === 0 && k > m) { const E2 = k - m; if ((j + .5) * Math.PI / E2 <= 5 && E2 <= 8) pts.push([j, E2, (j + .5) * Math.PI / E2, 'oth']); }
    }
    return pts;
  };
  const X = t => 30 + t / 5 * 320, Y = E => 180 - E / 8 * 170;
  function draw(m, k, E, tau, pts) {
    let s = '<line x1="30" y1="180" x2="350" y2="180" stroke="currentColor" opacity=".4"/><line x1="30" y1="10" x2="30" y2="180" stroke="currentColor" opacity=".4"/>';
    for (let j = 0; j < 14; j++) { const c = (j + .5) * Math.PI; let d = ''; for (let i = 0; i <= 80; i++) { const t = c / 8 + (5 - c / 8) * i / 80; if (t > 0 && t <= 5) d += (d ? ' L' : 'M') + X(t).toFixed(1) + ',' + Y(c / t).toFixed(1); } if (d) s += '<path d="' + d + '" fill="none" stroke="currentColor" opacity=".18"/>'; }
    [m + k, m - k].forEach(v => { if (v > 0 && v <= 8) s += '<line x1="30" x2="350" y1="' + Y(v) + '" y2="' + Y(v) + '" stroke="currentColor" opacity=".45" stroke-dasharray="4 3"/>'; });
    pts.forEach(([j, E1, t, h]) => { s += '<circle cx="' + X(t).toFixed(1) + '" cy="' + Y(E1).toFixed(1) + '" r="5" fill="' + (h === 'ord' ? 'var(--acc,#184f95)' : '#1baf7a') + '"><title>Eτ = (' + j + ' + 1/2)π, E = ' + E1 + (h === 'oth' ? ' (other half)' : '') + '</title></circle>'; });
    s += '<circle cx="' + X(tau).toFixed(1) + '" cy="' + Y(E).toFixed(1) + '" r="8" fill="none" stroke="currentColor" stroke-width="2"/>';
    s += '<text x="352" y="194" font-size="11" text-anchor="end" fill="currentColor">τ (0 to 5)</text><text x="34" y="18" font-size="11" fill="currentColor">E (0 to 8)</text>';
    svg.innerHTML = s;
  }
  function show() {
    const m = +$('[data-k="m"]').value, k = +$('[data-k="k"]').value; let E = +$('[data-k="E"]').value / 4, tau = +$('[data-k="t"]').value / 100;
    const pts = lattice(m, k); let cs, sn, exact = false;
    if (snapped) { const p = pts.find(q => q[0] === snapped[0] && q[3] === snapped[1]); if (p) { E = p[1]; tau = p[2]; cs = 0; sn = p[0] % 2 ? -1 : 1; exact = true; } else snapped = null; }
    if (!exact) { cs = Math.cos(E * tau); sn = Math.sin(E * tau); }
    $('[data-v="m"]').textContent = m; $('[data-v="k"]').textContent = k; $('[data-v="E"]').textContent = +E.toFixed(3); $('[data-v="t"]').textContent = tau.toFixed(3);
    snapBox.innerHTML = '<span style="font-size:14px">snap to an allowed point: </span>' + (pts.length ? pts.map(([j, E1, t, h]) => '<button type="button" data-j="' + j + '" data-h="' + h + '">j = ' + j + ', E = ' + E1 + (h === 'oth' ? ' (other half)' : '') + '</button>').join(' ') : '<i>none in view</i>');
    draw(m, k, E, tau, pts);
    const r = residual(m, k, E, cs, sn), f = v => (Math.abs(v) < 1e-12 ? '0' : v.toFixed(4).replace('-', '−'));
    let s = 'J = γ₂γ₁, J² = ' + J2 + ' by the bit rule; on the waves of mass E, e^(−τD) is the right factor cos Eτ + J sin Eτ' + (exact ? ' (exact: Eτ = (' + snapped[0] + ' + 1/2)π)' : '') + '\n';
    s += 'ordinary half: (E − m − κ sin Eτ) + (κ cos Eτ) J = ' + f(r.ord[0]) + ' + ' + f(r.ord[1]) + ' J  → ' + (zero(r.ord) ? 'a plane wave exists' : 'no plane wave') + '\n';
    s += 'other half:    (κ sin Eτ − E − m) + (κ cos Eτ) J = ' + f(r.oth[0]) + ' + ' + f(r.oth[1]) + ' J  → ' + (zero(r.oth) ? 'a plane wave exists' : 'no plane wave') + '\n';
    s += 'the lattice: Eτ = (j + 1/2)π with E = m + (−1)ʲκ' + (k > m ? ', and E = κ − m on the other half for even j' : '') + '; nowhere else';
    out.textContent = s;
  }
  el.addEventListener('input', e => { if (e.target.dataset.k === 'E' || e.target.dataset.k === 't') snapped = null; show(); });
  el.addEventListener('click', e => { const b = e.target.closest('button[data-j]'); if (!b) return; snapped = [+b.dataset.j, b.dataset.h]; show(); });
  snapped = [0, 'ord']; show();
})
