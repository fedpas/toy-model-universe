(function (id) {
  // cones.js: the Euler and signature integrals of a 4-metric with an edge cone of angle 2πβ along a surface Σ (Atiyah and LeBrun,
  // Theorems 2.1 and 2.2, recalled): (1/32π²)∫ε R∧R = χ(M) − (1 − β)χ(Σ) and (1/12π²)∫Σ Rᵃᵇ∧Rᵃᵇ = τ(M) − (1/3)(1 − β²)[Σ]².
  // The gravity engine computes both integrals exactly on three families (ATY-020, ATY-021); this box evaluates the right-hand sides in
  // exact fractions and checks itself against the integrals that aty_cone_defects.log prints.
  const el = document.getElementById(id); if (!el) return;
  const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
  const Q = (n, d = 1) => { if (d < 0) { n = -n; d = -d; } const g = gcd(n, d); return [n / g, d / g]; };
  const qa = (x, y) => Q(x[0] * y[1] + y[0] * x[1], x[1] * y[1]), qm = (x, y) => Q(x[0] * y[0], x[1] * y[1]), neg = x => [-x[0], x[1]];
  const qs = x => (x[1] === 1 ? String(x[0]) : x[0] + '/' + x[1]).replace('-', '−'), eq = (x, y) => x[0] === y[0] && x[1] === y[1];
  // the families: [name, χ(M), χ(Σ), τ(M), [Σ]², Σ]  (τ(CP²) = [CP¹]² = −1 in the chart orientation of the log)
  const FAM = [['S⁴, cone along S²', 2, 2, 0, 0, 'S²'], ['S² × football', 4, 4, 0, 0, 'two spheres'], ['CP², cone along a line', 3, 2, -1, -1, 'CP¹']];
  const euler = (f, b) => qa(Q(f[1]), neg(qm(qa(Q(1), neg(b)), Q(f[2]))));
  const sig = (f, b) => qa(Q(f[3]), neg(qm(Q(1, 3), qm(qa(Q(1), neg(qm(b, b))), Q(f[4])))));
  // self-test: the exact integrals of aty_cone_defects.log, [family, β, Euler, signature or null]
  const LOG = [[0, [1, 3], [2, 3], [0, 1]], [0, [1, 2], [1, 1], [0, 1]], [0, [2, 3], [4, 3], [0, 1]], [0, [2, 1], [4, 1], [0, 1]], [0, [3, 1], [6, 1], [0, 1]],
    [1, [1, 3], [4, 3], [0, 1]], [1, [1, 2], [2, 1], [0, 1]], [1, [2, 3], [8, 3], [0, 1]], [1, [2, 1], [8, 1], [0, 1]], [1, [3, 1], [12, 1], [0, 1]],
    [2, [1, 3], [5, 3], [-19, 27]], [2, [1, 2], [2, 1], [-3, 4]], [2, [1, 1], [3, 1], [-1, 1]], [2, [2, 1], [5, 1], [-2, 1]]];
  const bad = LOG.filter(([i, b, e, s]) => !eq(euler(FAM[i], b), e) || !eq(sig(FAM[i], b), s)).length;
  if (bad) { el.textContent = 'self-test failed: ' + bad + ' integrals of aty_cone_defects.log disagree'; return; }

  el.innerHTML = '<label>β = k/12, k <input type="range" min="1" max="36" value="4"> <b></b></label>' +
    '<svg viewBox="0 0 360 160" width="360" height="160" role="img" aria-label="Euler integrals against β"></svg><div class="widget__out" aria-live="polite"></div>';
  const inp = el.querySelector('input'), lab = el.querySelector('b'), svg = el.querySelector('svg'), out = el.querySelector('.widget__out');
  const X = b => 34 + b / 3 * 316, Y = v => 150 - v / 13 * 140, COL = ['#2a78d6', '#eb6834', '#1baf7a'];
  function show() {
    const b = Q(+inp.value, 12), bf = b[0] / b[1]; lab.textContent = qs(b);
    let s = '<line x1="34" y1="150" x2="350" y2="150" stroke="currentColor" opacity=".4"/><line x1="34" y1="10" x2="34" y2="150" stroke="currentColor" opacity=".4"/>';
    FAM.forEach((f, i) => { s += '<line x1="' + X(0) + '" y1="' + Y(f[1] - f[2]).toFixed(1) + '" x2="' + X(3) + '" y2="' + Y(f[1] + 2 * f[2]).toFixed(1) + '" stroke="' + COL[i] + '" stroke-width="2"/>'; s += '<circle cx="' + X(bf).toFixed(1) + '" cy="' + Y(f[1] - (1 - bf) * f[2]).toFixed(1) + '" r="5" fill="' + COL[i] + '"><title>' + f[0] + '</title></circle>'; });
    s += '<line x1="' + X(1) + '" x2="' + X(1) + '" y1="10" y2="150" stroke="currentColor" opacity=".25" stroke-dasharray="3 3"/><text x="' + (X(1) + 3) + '" y="20" font-size="11" fill="currentColor">β = 1, smooth</text>';
    s += '<text x="350" y="146" font-size="11" text-anchor="end" fill="currentColor">β (0 to 3)</text>';
    svg.innerHTML = s;
    let o = 'β = ' + qs(b) + ' (cone angle 2πβ):\n';
    FAM.forEach(f => { o += '  ' + f[0] + ':  Euler integral ' + f[1] + ' − (1 − β)·' + f[2] + ' = ' + qs(euler(f, b)) + ';  signature integral ' + qs(sig(f, b)) + '\n'; });
    o += eq(b, Q(1)) ? 'β = 1: no cone, the integrals are χ and τ themselves' : 'the defect against the smooth value: Euler −(1 − β)χ(Σ), signature −(1/3)(1 − β²)[Σ]² (blue S⁴, orange S² × football, green CP²)';
    out.textContent = o;
  }
  inp.addEventListener('input', show); show();
})
