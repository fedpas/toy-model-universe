# Physics on the bit rule: the four engines

Physics asks for equations that hold in every frame: Maxwell's for light, Dirac's for the electron, Yang–Mills for the forces of the nucleus, Einstein's for gravity. A first course writes them with indices, matrices and the number $i$. The Atlas writes all four on one object: $n$ switches, the $2^n$ settings of the switches (the labels), and one product of labels, the bit rule. Choose the square of each switch, $+1$, $-1$ or $0$, and the rule is the Clifford algebra $\mathrm{Cl}(p,q,r)$ of that signature (theorem T1 of the Atlas proves the product associative for every $n$ and every choice of squares). Space-time is the cell $\mathrm{Cl}(1,3)$: one switch of square $+1$, time, and three of square $-1$, space. Every equation below is a statement about products of these sixteen labels, with polynomials in four coordinates as coefficients, and a script of the Atlas checks it exactly; its log ships with the package.

The four engines are four pieces of the package's code that take polynomial fields on the labels and return the terms of an equation: the light engine (Maxwell, Part 1), the Dirac engine with its coupling step (Part 2), the gauge engine for Yang–Mills and charged matter (Part 3), and the gravity engine for the frame, the curvature and the Einstein form (Part 4). For each key equation this page shows the trick that makes it computable on labels, the row that states it, what the engine checks and at what scope, a figure drawn from a log, and twenty lines of a script that compute it. Part 5 says what the Atlas does not reach. A row id such as EQN-006 links to the row; its frame tells how far the Atlas has checked it (proved by the Atlas, standard, our reading, open, input).

**One rule, three algebras.** Take $n = 2$. The labels are $1, e_1, e_2, e_{12}$. The bit rule multiplies two labels by the XOR of their bits, with a sign: a factor $-1$ for every pair of switches that must be swapped to bring the product into order, times the square $\varepsilon_i$ of every switch that is on in both factors,
$$e_a e_b = s(a,b)\, e_{a\oplus b},\qquad s(a,b) = (-1)^{N(a,b)}\prod_{i\in a\wedge b}\varepsilon_i .$$
Figure 1 computes the sixteen products for the three choices of squares. With squares $(+,+)$ the table is that of the real $2\times 2$ matrices, $\mathrm{Cl}(2,0)\cong M_2(\mathbb{R})$; with $(-,-)$ it is the quaternions $\mathbb{H}$; with $(0,0)$ the exterior algebra $\Lambda\mathbb{R}^2$. Physics uses all three at once. The bivector $e_{12}$ squares to $-1$, $+1$ and $0$ in the three cells, and its exponential is a rotation, a boost and a translation: the harmonic, the inverted and the free oscillator of Part E3 of the shipped tutorial, and the trichotomy of LAB-015. In space-time the same switch-by-switch squares make the electric planes boosts and the magnetic planes rotations (Part 1).

![Figure 1. The sixteen products of the cell row 2 for the squares (+,+), (−,−) and (0,0): row a, column b, the entry e_a e_b, with its sign (blue +, orange −, grey 0). 0, 0 and 7 products vanish; 4, 6 and 1 carry a minus sign. Drawn by figs_phys.py from Alg(eps).blade_mul of checks/selfcheck/steps15_17/bitcliff.py; the counts are asserted against the shipped tutorial's Part 0.](figs/n2_three_algebras.svg)

## Part 0 · The rule and the frame

### F1 · Labels, the product and the signature

**The physics.** Special relativity is the statement that the quadratic form $t^2 - x^2 - y^2 - z^2$ is the same for every inertial observer. A first course meets it as the Minkowski metric $\eta = \mathrm{diag}(1,-1,-1,-1)$ and the Lorentz group that keeps it. Which sign belongs to time is a convention; that exactly one direction has the other sign is physics: it is what lets a wave travel.

**The trick.** The metric is not an extra structure on the labels. It is the list of squares: $\gamma_0\gamma_0 = +1$ and $\gamma_i\gamma_i = -1$ for the four switches of $\mathrm{Cl}(1,3)$, and the bit rule does the rest. Two different switches anticommute, so $(\sum_\mu k_\mu\gamma_\mu)^2 = k_0^2 - k_1^2 - k_2^2 - k_3^2$: the Minkowski square of a vector is the product of the vector with itself, its cross terms cancelling in pairs. The Atlas uses $\mathrm{Cl}(1,3)$ with $\gamma_0^2 = +1$ (INP-025); the mirror $\mathrm{Cl}(3,1)$ reads the same system with the signs swapped, and which sign is called time is a convention (INP-011), as is the count of the clock $c = p - q \bmod 8$, which assumes that $p$ counts the generators of square $+1$ (INP-017).

**On the labels.** Figure 2 lists the sixteen labels of $\mathrm{Cl}(1,3)$ by grade with the square of each. Six square to $+1$ (the scalar, $\gamma_0$, the three planes $\gamma_{0i}$ that hold time, and $\gamma_{123}$) and ten to $-1$. The planes $\gamma_{0i}$ square to $+1$, so their exponentials are boosts; the planes $\gamma_{ij}$ of space square to $-1$, so theirs are rotations. The pseudoscalar $\gamma_{0123}$ squares to $-1$: in space-time duality is a complex structure, a fact Part 4 uses for the Petrov types.

![Figure 2. The sixteen labels of Cl(1,3) in five columns by grade (1, 4, 6, 4, 1), each with its name, its bits (bit 0 on the right is γ₀) and its square: blue +1, orange −1. Drawn by figs_phys.py from bitcliff.Alg(sig(1, 3)); the counts (6, 10, 0) are Alg.counts().](figs/cl13_labels.svg)

**Why one minus switch, or one plus switch.** Light obeys a wave equation, and the second derivative of a field on the labels is the square of $\nabla = \sum_a e_a\partial_a$. Its diagonal is $\sum_a \varepsilon_a\partial_a^2$, read off the squares, and its off-diagonal terms cancel in twins (Part 1). A wave operator is hyperbolic, so that a field given at one time has one future, exactly when one sign occurs once: one plus switch or one minus switch. The row says it in the Atlas's words, "Waves that travel like light need a box with exactly one plus switch or exactly one minus switch" (LNS-102), and the light page states the full trichotomy, elliptic, hyperbolic, ultrahyperbolic, with the null generators included (PAG-011, theorem T18). The log of check_T18.py has the line "F: a hyperbolic direction exists only for signatures (1, n−1) and (n−1, 1)" and ends "check_T18: 3643 of 3643 assertions hold". Figure 3 draws the class for every cell with $p + q \le 8$; the widget below lets you pick the cell.

![Figure 3. The wave operator of every cell Cl(p,q) with p + q from 1 to 8: E elliptic (all squares of one sign), H hyperbolic (one sign occurs once), U ultrahyperbolic; the small figure is the clock p − q mod 8. Only the two edges of the triangle next to the axes are hyperbolic; Cl(1,3) and Cl(3,1) are framed. Drawn by figs_phys.py: the squares by bitcliff, the class by symbol() of checks/selfcheck/maxwell_selfcheck.py; the statement F of check_T18.log is matched.](figs/wave_types.svg)

@@widget wave_op

**The clock.** The class of a cell on the eight-hour clock is $c = p - q \bmod 8$, the phase of the Gauss sum $\sum_a i^{\,\mathrm{pos}(a)-\mathrm{neg}(a)} = (1+i)^p(1-i)^q$ over the $2^n$ labels (RSN-029), and the Brown invariant of a $\mathbb{Z}_4$ form on the labels (LAB-017, LAB-018). Space-time sits at hour 6, $\mathrm{Cl}(1,3)\cong M_2(\mathbb{H})$, its mirror at hour 2, $\mathrm{Cl}(3,1)\cong M_4(\mathbb{R})$ (ATL-017). The same eight hours count the phases of time-reversal-invariant Kitaev chains, a ground-state degeneracy that depends on the winding difference mod 8 only (LAB-021): the clock is physics in condensed matter, while in this tutorial it fixes the matrix size of spinors (Part 2).

**What the engine checks, and at what scope.** The rule is associative for every $n$ (T1, proved); the squares and the class are computed for every cell the figures show. Nothing in this section is a measurement: the signature is an input, and the bit rule then makes it an algebra.

**Beyond the finite object.** The Lorentz group as a manifold, its unitary representations (Wigner), and the passage from the algebra to fields on curved space-time go beyond one cell; the Atlas meets the first at a point (Part 2, the little groups of CAND-126) and the last through frames (Part 4).

> **Try it.** The product of checks/selfcheck/steps15_17/bitcliff.py, word for word (two functions; the class wraps the squares). In that folder, with plain python3:
>
> ```python
> def reorder_sign(a, b):
>     """sign from moving every generator of b to its place past the larger generators of a"""
>     a >>= 1
>     s = 0
>     while a:
>         s += pc(a & b)
>         a >>= 1
>     return -1 if s & 1 else 1
>     def blade_mul(self, a, b):
>         c = reorder_sign(a, b)
>         m = a & b
>         i = 0
>         while m:
>             if m & 1:
>                 c *= self.eps[i]
>                 if c == 0:
>                     return 0, a ^ b
>             m >>= 1
>             i += 1
>         return c, a ^ b
> ```
>
> ```text
> >>> from bitcliff import Alg, sig
> >>> A = Alg(sig(1, 3))
> >>> [A.blade_mul(a, a)[0] for a in range(16)]
> [1, 1, -1, 1, -1, 1, -1, -1, -1, 1, -1, -1, -1, -1, 1, -1]
> >>> A.blade_mul(1, 2), A.blade_mul(2, 1)
> ((1, 3), (-1, 3))
> ```
>
> The squares of the sixteen labels are the column of Figure 2; $\gamma_0\gamma_1 = +\gamma_{01}$ and $\gamma_1\gamma_0 = -\gamma_{01}$. One folder up, `from maxwell_selfcheck import symbol` and `symbol(1, 3)` print `{'plus': 1, 'minus': 3, 'class': 'hyperbolic', 'well_posed_along': 'time'}`; `symbol(2, 2)` is ultrahyperbolic. Change `sig(1, 3)` to `sig(3, 1)` and predict the squares before you print them.

### Three questions for a physicist (Part 0)

1. *Is the choice between $\mathrm{Cl}(1,3)$ and $\mathrm{Cl}(3,1)$ physical?* The Atlas treats it as a convention (INP-011): the light step reads the same system in the mirror (MAP-003). The two algebras differ ($M_2(\mathbb{H})$ against $M_4(\mathbb{R})$), so the real spinors they carry differ; which of the two a theory of neutral fermions needs is the Pin question, which the clock page lists as open (LAB-016).
2. *What does an ultrahyperbolic cell such as $\mathrm{Cl}(2,2)$ do?* It has waves but no direction along which a Cauchy problem is well posed (PAG-011). That a hyperbolic symbol gives a well-posed initial-value problem is a pointer the Atlas does not check (PAG-034, open).
3. *Does the clock choose the physics?* In this tutorial it chooses the type of the algebra and so the size of a spinor; its reading as a bordism class (LAB-018) and as the mod-8 classification of Kitaev chains (LAB-021) is checked on finite models only.

## Part 1 · The light engine: Maxwell

### F2 · Maxwell's equation is one product

**The physics.** Maxwell's four equations, Gauss $\nabla\cdot\mathbf{E} = \rho$, Ampère $\partial_t\mathbf{E} - \nabla\times\mathbf{B} = -\mathbf{J}$, Faraday $\partial_t\mathbf{B} + \nabla\times\mathbf{E} = 0$ and $\nabla\cdot\mathbf{B} = 0$, are two equations in the language of forms: $dF = 0$ and $d{\star}F = J$, with $F$ the field tensor of six components. In the space-time algebra of Hestenes they are one equation, $\nabla F = J$, with $F$ a bivector and $J$ a vector (the light page names Hestenes as its source, PAG-010; ATL-017 states the equation for the cell).

**The trick.** Multiply a vector label $e_a$ by a bivector label $e_{bc}$. If $a$ is one of $b, c$, the shared switch squares away and the product is a vector: a *drop*. If not, the product is a trivector: an *add*. So $\nabla F = \sum_a e_a\,\partial_a F$ has a grade-1 part and a grade-3 part and nothing else, and the two parts are the two halves of Maxwell: the grade-1 part is $d{\star}F = J$ (Gauss and Ampère), the grade-3 part is $dF = 0$ (Faraday and no monopole) (RSN-025, ATL-017). Of the 48 choices of a piece of $F$, a direction and drop or add, 24 are steps, three at each corner and three at each face of the tetrahedron $t, x, y, z$, and they carry the signs of the textbook equations (MAP-036).

**On the labels.** The equation is EQN-006, "∇F = J (Maxwell) · Calibration 1; cells n = 2 to 7". Figure 4 shows the four views of the light page: the algebra, which sees the squares; the simplex, where the six pieces of $F$ sit on the six edges, the electric ones at the time corner and the magnetic ones round the base (PAG-035); the cube, where they are the middle layer of the sixteen labels; and the whole numbers, where $t, x, y, z$ are named by the primes $2, 3, 5, 7$, a label by the product of its primes, and a step divides by a prime (a drop) or multiplies by one (an add) (MAP-037). The three notations depend only on how many switches there are; the signs belong to the algebra (MAP-004). Figure 5 is the result: the 24 terms of Maxwell's equation in $\mathrm{Cl}(1,3)$, each the sign of one bit-rule product and one partial derivative.

![Figure 4. Maxwell’s field on the labels of Cl(1,3) in four views: (a) the six bivector labels with their squares (E boosts, B turns); (b) the simplex t x y z with E on the edges at t and B round the base; (c) the cube by grade, with the 12 drops to grade 1 and the 12 adds to grade 3; (d) the labels as products of the primes 2, 3, 5, 7, a drop dividing and an add multiplying. Drawn by figs_phys.py from phys_spec(3) and build_cell() of checks/selfcheck/maxwell_selfcheck.py and the bit rule of bitcliff.py.](figs/maxwell_views.svg)

![Figure 5. The 24 terms of ∇F = J in Cl(1,3): the rows are the eight equations (the target label of grade 1 or 3), the columns the six components of F; each cell is the sign and the derivative of the term, from the incidences of build_cell() in checks/selfcheck/maxwell_selfcheck.py. Below: the number of terms n·C(n,2) for n = 2 to 7, parsed from step_lines.log (2, 9, 24, 50, 90, 147). Drawn by figs_phys.py.](figs/maxwell_terms.svg)

**What the engine checks, and at what scope.** maxwell_selfcheck.py builds $\nabla F = J$ on every split of $n = k + d$ generators with $1 \le k, d \le 4$ and $k + d \le 7$, fifteen cells in all, with exact polynomial fields; in each it searches all sign conventions of the field components and finds exactly two that reproduce the textbook equations, differing by an overall sign, $q \to -q$ (PAG-008, MAP-003); a positive field energy then fixes the relative sign of source and force (bd·sol·17). The counts $n\binom{n}{2}$ = 2, 9, 24, 50, 90, 147 for $n = 2$ to 7 are printed by step_lines.py, whose log has them twice, from the stored data and from the closed form. What is put in by hand: the action (INP-001), the grades of $F$ and $J$ (INP-004), the flat chart (INP-003), units with $c = \varepsilon_0 = \mu_0 = 1$ (INP-006), and the Lorentz force law, the grade-1 part of $Fu$ (INP-007).

**The Hodge star is the complement.** In the forms $dF = 0$, $d{\star}F = J$, the star sends a plane to the complementary plane with a sign. On the labels it is multiplication by the pseudoscalar, $I e_S = \pm e_{\bar S}$, the label XOR $1111$; the sign that makes it the star, $\sigma(S)$, the sign of the permutation $(S, \bar S)$, is checked for $n = 1$ to 8 against the determinant route (CAND-062, sm16·D1). In $\mathrm{Cl}(1,3)$ the map squares to $-1$ on the planes; Part 4 uses the same map on curvature.

### F3 · The wave operator and charge conservation

**The physics.** Taking the divergence of Ampère's law gives charge conservation, and taking the curl twice gives the wave equation. In the course both are short computations with vector identities.

**The trick.** Both are one more product. $\nabla\nabla = \sum_{a,b} e_a e_b\,\partial_a\partial_b$ has 16 terms in $\mathrm{Cl}(1,3)$. The 12 off the diagonal pair up as twins of opposite sign, $e_a e_b = -e_b e_a$ with equal derivatives, and cancel; the diagonal leaves $\partial_t^2 - \partial_x^2 - \partial_y^2 - \partial_z^2$ on every piece of $F$ (MAP-039). Figure 6 draws the sixteen products. Charge conservation is the same cancellation one grade down: from each piece of $F$, two drops along its two directions reach the scalar label by two roads whose signs are $+1$ and $-1$, so $\nabla\nabla F$ has no scalar part, which is $\partial_t\rho + \nabla\cdot\mathbf{J} = 0$, and two adds cancel the same way in the four-volume part (MAP-038). With one space direction the equation has two terms and the conservation law is the statement that the charge between two points changes exactly by the current through the ends, checked against finite differences for a hump of $E$ on a closed line (MAP-040).

![Figure 6. The sixteen products e_a e_b of two generators of Cl(1,3): on the diagonal the squares +1, −1, −1, −1, off it the twins ±γ_ab of opposite sign, which cancel in ∇∇ because ∂_a∂_b = ∂_b∂_a. Drawn by figs_phys.py from bitcliff.Alg(sig(1, 3)); the twelve twins are asserted.](figs/box_twins.svg)

**What the engine checks.** On three random polynomial fields per cell, maxwell_selfcheck.py asserts that $\nabla F$ has grades 1 and 3 only and that $\nabla(\nabla F) = \square F$ component by component, exactly (RSN-025); step_lines.log has the line "the wave equation, grades 1 and 3 only, charge conservation, two sign conventions: in every cell: the line prints True".

### F4 · A plane wave on the labels

**The physics.** In vacuum, $\mathbf{E}$ and $\mathbf{B}$ of a plane wave are at right angles to each other and to the direction of travel, of equal size, and the wave moves at the speed of light; the two invariants $E^2 - B^2$ and $\mathbf{E}\cdot\mathbf{B}$ vanish.

**The trick.** On a field $F = F_0\, f(\omega t - \mathbf{k}\cdot\mathbf{x})$ the derivative acts as one fixed vector: $\nabla F = N F_0\, f'$ with $N = \omega\gamma_0 - \mathbf{k}\cdot\boldsymbol{\gamma}$. So $\nabla F = 0$ for every profile $f$ exactly when $N F_0 = 0$, a linear map from the six bivector labels to the eight odd labels whose entries are bit-rule signs. Multiply once more: $N N F_0 = (\omega^2 - k^2)F_0$, so a non-zero kernel needs $\omega^2 = k^2$. Figure 7 computes the kernel for $\mathbf{k}$ along $z$ and 33 values of $\omega$: it is two-dimensional at $\omega = \pm k$ and zero elsewhere, and at $\omega = k$ it is spanned by $\gamma_{01} + \gamma_{13}$ ($E_x$ with $B_y$) and $\gamma_{02} + \gamma_{23}$ ($E_y$ with $B_x$).

![Figure 7. A plane wave on the labels: the dimension of the kernel of F₀ ↦ (ω e_t − k e_z)F₀ on the six bivectors of Cl(1,3), for k = 1 and ω from −2 to 2 in steps of 1/8, exact; at ω = k the two kernel elements. Drawn by figs_phys.py with bprod() of checks/selfcheck/maxwell_selfcheck.py and exact elimination.](figs/plane_wave.svg)

The light page states the invariants of every field: every observer finds the same $E^2 - B^2$, the number part of $F^2$, and the same $\mathbf{E}\cdot\mathbf{B}$, minus half its four-generator part; a boost or a rotation $RF\tilde R$ leaves both unchanged in rational arithmetic, and a light wave has both zero at every speed up to 0.95 of light along $x$ (PAG-036). A boost $R = \cosh(\eta/2) - \sinh(\eta/2)e_{tx}$ mixes the components across $x$ as the textbook law $\mathbf{E}' = \gamma(\mathbf{E} + \mathbf{v}\times\mathbf{B})$ says, and the drift frame of crossed fields is found exactly (PAG-037). The page checks that the plane wave $f(t - z)$ and the Coulomb field solve $\nabla F = J$; it does not solve for them (INP-010). The widget recomputes the kernel for any $\omega$, $|\mathbf{k}|$ and four directions, and the two invariants of each kernel element by the bit rule.

@@widget plane_wave

**Beyond the finite object.** Radiation from moving charges, retarded potentials and the Green's function of $\square$ need integrals over space-time, which a polynomial field in one chart does not hold. The charge in the field is treated in six situations by the light page (circle, hyperbola, drift, a wave, a point charge, the relativistic perihelion; RSN-026, whose words are "Nothing predicts anything").

> **Try it.** The bit rule and the derivative of checks/selfcheck/maxwell_selfcheck.py, word for word (bit 0 is time; `p` generators square to +1):
>
> ```python
> def bprod(a, b, p=1):                       # generators 0..p-1 square to +1 (time), the rest to -1 (space)
>     s = 1; t = a >> 1
>     while t:
>         s *= -1 if bin(t & b).count('1') % 2 else 1; t >>= 1
>     c = a & b; i = 0
>     while c:
>         if c & 1: s *= 1 if i < p else -1
>         c >>= 1; i += 1
>     return a ^ b, s
> def nabla(F, n, p):                          # grad F = sum_a e_a d_a F
>     R = {}
>     for m, P in F.items():
>         for a in range(n):
>             mm, s = bprod(1 << a, m, p); R = mv_add(R, {mm: pscale(pder(P, a), s)})
>     return R
> ```
>
> A field is a dictionary from labels to polynomials, a polynomial a dictionary from exponents $(t, x, y, z)$ to fractions. In checks/selfcheck, build the wave $(\omega t - kz)^3(\gamma_{01} + \gamma_{13})$ and differentiate it:
>
> ```text
> >>> from maxwell_selfcheck import nabla
> >>> from fractions import Fraction as Fr
> >>> from math import comb
> >>> def wave(w, k): return {(3 - j, 0, 0, j): Fr(comb(3, j) * w ** (3 - j) * (-k) ** j) for j in range(4)}
> ...
> >>> nabla({3: wave(1, 1), 10: wave(1, 1)}, 4, 1)
> {}
> >>> G = nabla({3: wave(2, 1), 10: wave(2, 1)}, 4, 1)
> >>> sorted((m, bin(m).count('1')) for m in G)
> [(2, 1), (11, 3)]
> ```
>
> At $\omega = k$ the derivative vanishes identically; at $\omega = 2k$ it has one grade-1 part (on $\gamma_1$: Ampère) and one grade-3 part (on $\gamma_{013}$: Faraday), so both Maxwell equations fail together, in proportion to $\omega - k$. The run of the whole script ends with the line `ALL MAXWELL CHECKS PASS` (maxwell_selfcheck.plain.log).

### Three questions for a physicist (Part 1)

1. *Does the engine know Maxwell's equations in a medium?* The constitutive relation is an input: in vacuum $H = {\star}F$, in a medium $H = \chi(F)$ with 36 components, 20 principal, 15 skewon and 1 axion (INP-002, bd·sol·14); the 21 of a Lagrangian medium are the symmetric pairs of the six planes, the octahedron of Part 4 (LNS-013). Extra time directions have no causal medium (INP-012).
2. *Can the Lorentz force be derived instead of postulated?* On the light page it is postulated (INP-007). The stress $-\tfrac12 FaF$ is used as the source of gravity on Reissner–Nordström (MAT-007); deriving the force from the divergence of that stress is not a row of the Atlas.
3. *Where are radiation and the retarded field?* Not on the labels: the Coulomb field and the plane wave are given fields that the page checks (INP-010). A field defined by an integral over the past light cone is beyond the polynomial fields of one chart (LNS-069).

## Part 2 · The Dirac engine: Dirac and the coupling step

### F5 · Dirac's equation in the real algebra

**The physics.** The Dirac equation $(i\gamma^\mu\partial_\mu - m)\psi = 0$ is a first-order equation whose square is the Klein–Gordon equation: its plane waves have $E^2 = \mathbf{k}^2 + m^2$, it describes a particle of spin ½, and $\bar\psi\gamma^\mu\psi$ is a conserved current. A course writes it with four complex $4\times4$ matrices and a complex spinor of four components.

**The trick.** The complex unit is a bivector of the frame. $J = \gamma_2\gamma_1$ squares to $-1$ and commutes with $\gamma_0$; acting on the right of an even element $\psi$ of $\mathrm{Cl}(1,3)$ it does the work of $i$, and the equation becomes Hestenes' form
$$\nabla\psi J = m\,\psi\gamma_0 ,$$
an equation in the real algebra with 8 real components, the even labels, the eight corners of the demicube (EQN-008, MAP-017). $J$ is a complex structure chosen in the algebra, not given by it: for $n \ge 4$ it is gauge, one rotor orbit, while at $n = 3$ the choices $J$ and $-J$ differ (INP-024). The positive involution $\gamma_0\tilde\psi\gamma_0$, the time orientation and the frame on the right are inputs of the step (INP-022, INP-023); its action is $\langle\nabla\psi I\gamma_3\tilde\psi\rangle_0 - m\langle\psi\tilde\psi\rangle_0$, whose stationarity gives the equation (INP-021, bd·phy·18).

**Plane waves on the labels.** Put $\psi = P\,e^{sJ k\cdot x}$ with a constant even amplitude $P$ and the phase on the right, $s = \pm1$ the sector. Then $\nabla$ acts as $P \mapsto s\hat k P J$ with $\hat k = \sum_\mu k_\mu\gamma_\mu$ and $\hat k^2 = Q(k) = k_0^2 - \mathbf{k}^2$, and the equation becomes a linear map on the eight real dimensions of $P$. Its kernel is four-dimensional exactly on the shell $Q(k) = m^2$, half of $\psi$, and zero off it; in $n$ generators it is $2^{n-2}$ per sector (shd·ORD). The log of shifted_dirac.py says it at $n = 4$, $m = 3$: "a kernel of 4 real dimensions per sector at k = (3,0,0,0), (5,4,0,0), (−3,0,0,0), (7,2,6,0) (Q = 9) and none at (4,0,0,0), (5,3,0,0), (0,3,0,0)". Figure 8 computes the kernel at every integer point of a window of the $(k_1, k_0)$ plane and at rational points of the hyperbola. The Atlas's theorem T16 states the determinant behind it, $\det(P - m) = (m^2 - Q(k))^{N/2}$, and check_T16.log has "Hestenes 8x8 symbol det = +1 * (p^2 − m^2)^4" and "391 of 391 assertions hold". The dispersion $E^2 = k^2 + m^2$, its lowest point $E = m$ and a speed $dE/dk$ below 1 for $m > 0$ are drawn by the electron leaf (EQN-030, EQN-031).

![Figure 8. Plane-wave solutions of ∇ψJ = mψγ₀ on the labels, m = 3: the real dimension of the kernel at the integer points of the (k₁, k₀) window (blue, 4 per sector, on the shell k₀² − k₁² = 9; small rings, 0, off it) and at sixteen rational points of the hyperbola (green). Both sectors give the same dimension at every point. Drawn by figs_phys.py with bmul() of checks/selfcheck/coupling_selfcheck.py and the operator bD(P)J − mP of shifted_dirac.py; the points of shd·ORD in shifted_dirac.log are asserted.](figs/dirac_shell.svg)

**Spin at rest and the half-turn.** At rest, $k = (m, 0, 0, 0)$, the kernel is the even Pauli part $1, \gamma_2\gamma_3, \gamma_3\gamma_1, \gamma_1\gamma_2$; on it the operators $S_k\psi = \tfrac12\sigma_k\psi\sigma_3$ satisfy $[S_i, S_j]\psi = \epsilon_{ijk}S_k\psi J$ and $\sum S_k^2 = \tfrac34$: spin ½, derived from the mass shell (dirac_limits.log, dlim·WIG). The stabiliser of a timelike momentum has the Lie algebra su(2), that of a null momentum e(2), Wigner's little groups (CAND-126; the groups themselves are recalled). Spin ½ shows in the rotor of a turn: in $\mathrm{Cl}(2,0)$, $R = \cos(\varphi/2) + \sin(\varphi/2)B$ with $B^2 = -1$ is $-1$ after one full turn and $+1$ only after two (SPN-006).

**The current.** $X = \psi\gamma_0\tilde\psi$ is the Dirac current: a vector for $n = 3, 4$, with a grade-5 part from $n = 5$, conserved on solutions for $n = 3, 4, 5$ (MAP-018). The reason is one line about the labels: for an even $\psi$ the product $\psi\gamma_0\tilde\psi$ is odd and equal to its own reverse, and the reverse of a blade of grade $k$ is $(-1)^{k(k-1)/2}$ times the blade, so only the grades $k \equiv 1 \bmod 4$ survive: 1, 5, 9 (CPL-012). The log of opened_4.py checks it for $n = 1$ to 10 with every blade of these grades present (opn·CUR), and with a wrong involution the grades 3 and 7 appear, which a control line records. Figure 9 draws the table, with the size of $\psi$ in units of one Dirac spinor: exactly one at $n = 3$ and 4, two at $n = 5$ and 6, four at 7 and 8 (CPL-003). At $n = 5$ the extra half is a second Dirac field: right multiplication by $Q = \gamma_1\gamma_2\gamma_3\gamma_4$ splits $\psi$ into two halves that obey the same equation, and the current is the sum of their currents (CPL-007b).

![Figure 9. The grades of the current ψγ₀ψ̃ of an even ψ in Cl(1,n−1) for n = 1 to 10 (the cells give the number of blades, C(n,1), C(n,5), C(n,9)), and the real dimension of the even ψ against one Dirac spinor, with their ratio (green: exactly one, n = 3 and 4). Drawn by figs_phys.py from current_structure() and ladder_row() of checks/selfcheck/coupling_selfcheck.py for n ≤ 8; rows 9 and 10 parsed from opened_4.log (opn·CUR).](figs/current_grades.svg)

**What the engine checks, and at what scope.** The incidences, the determinant and the covariance of the equation (INP-021, check_T16.py); the kernels on the shell for $n = 3, 4, 5$ exactly on the labels and with complex Dirac matrices at $n = 4$ (shifted_dirac.py); the grades of the current for $n \le 10$ (opened_4.py). What is put in: the grade of $\psi$, the complex structure $J$, the time orientation.

**Beyond the finite object.** Second quantization, the Dirac sea and the spin-statistics theorem need Hilbert spaces of states (LNS-025). Charge conjugation, parity, time reversal and their product act on the equation and are checked on the labels in dirac_limits.py (dlim·CPT); what they mean for particles and antiparticles is the textbook's next chapter, not a row.

> **Try it.** The derivative and the current of checks/selfcheck/coupling_selfcheck.py, word for word (`F` is `Fraction`; `bmul`, `rsign`, `popc`, `sqs`, `fadd`, `fmul`, `fder` are defined above them in the file):
>
> ```python
> def nabla(A, sq):
>     n = len(sq); out = {}; one = {(0,) * n: F(1)}
>     for mu in range(n): out = fadd(out, fmul({1 << mu: one}, fder(A, mu), sq))
>     return out
> def current_structure(n, p, gam=0):
>     sq = sqs(n, p); ev = [m for m in range(1 << n) if popc(m) % 2 == 0]; coef = {}
>     for S in ev:
>         m1, s1 = bmul(S, 1 << gam, sq)
>         for T in ev:
>             m2, s2 = bmul(m1, T, sq); coef.setdefault(m2, {})[(S, T)] = s1 * s2 * rsign(popc(T))
>     surv = {}
>     for blade, d in coef.items():
>         mon = {}
>         for (S, T), c in d.items():
>             key = (min(S, T), max(S, T)); mon[key] = mon.get(key, 0) + c
>         nz = {k: v for k, v in mon.items() if v != 0}
>         if nz: surv[blade] = nz
>     return surv
> ```
>
> `current_structure` multiplies every pair of even labels $S, T$ through $\gamma_0$ with the sign of the reverse of $T$, and keeps the blades whose quadratic form in the components of $\psi$ does not cancel. In checks/selfcheck:
>
> ```text
> >>> from coupling_selfcheck import current_structure, ladder_row
> >>> [sorted({bin(b).count('1') for b in current_structure(n, 1)}) for n in range(1, 9)]
> [[1], [1], [1], [1], [1, 5], [1, 5], [1, 5], [1, 5]]
> >>> [ladder_row(n)['psi_over_dirac'] for n in range(1, 9)]
> ['1/2', '1/2', '1', '1', '2', '2', '4', '4']
> >>> [ladder_row(n)['J_count'] for n in range(1, 6)]
> [0, 0, 1, 3, 6]
> ```
>
> The first line is the grade table of Figure 9, the second the ratio column (CPL-003), the third the number of bivectors of square $-1$ that commute with $\gamma_0$, the candidates for $J$: none at $n = 1, 2$, so no charged field there (CPL-006), then 1, 3, 6 (MAP-018). Replace `rsign(popc(T))` by `1` and the grade 3 appears: that is the control line of opn·CUR.

### F6 · The coupling step and a shifted Dirac equation

**The physics.** An electron in a field obeys the Dirac equation with $\partial_\mu$ replaced by $\partial_\mu + ieA_\mu$, minimal coupling, and is the source of Maxwell's field through its current. The two equations come from one action, and the gauge freedom $\psi \to e^{i\alpha}\psi$, $A \to A - \partial\alpha/e$ is what makes the current conserved.

**The trick.** On the labels the coupled system is
$$\nabla(\psi)J - eA\psi - m\psi\gamma_0 = 0,\qquad \nabla(\nabla A) = eX,\quad X = \psi\gamma_0\tilde\psi ,$$
and the coupling reuses the $n$ cube edges at each corner of the Dirac step: the only new thing is a factor $A$ on edges already drawn (CPL-001). The gauge rotor is the right factor $e^{J\varepsilon}$: coupling_selfcheck.py checks to first order that $\psi \to \psi(1 + J\varepsilon)$, $A \to A - \nabla\varepsilon/e$ changes the equation by a term proportional to the equation itself, exactly on random polynomial fields, and a control with the wrong sign of the coupling term breaks the identity. One action, $\langle\nabla\psi I\gamma_3\tilde\psi - m\psi\tilde\psi - eA\psi\gamma_0\tilde\psi\rangle_0 + \tfrac12\langle FF\rangle_0$, gives both equations with one $e$; the size of $e$ is free, the sign of the source relative to the coupling is fixed (CPL-005, INP-027, INP-028). From $n = 5$ the current has a grade-5 part that $\nabla F$ has no slot for, and the coupling term $\langle A\psi\gamma_0\tilde\psi\rangle_0 = A\cdot\langle X\rangle_1$ sees the vector part only, so no projection is chosen by hand (CPL-002, CPL-009). This is the known Dirac–Maxwell system in Hestenes' form (CPL-004); the counts of its terms are EQN-009.

**A worked example: the shifted Dirac equation.** Atiyah and Moore propose a Dirac operator with a shift, $(i\hbar D - mc + ik\,e^{-\tau D})\psi = 0$ ("A shifted view of fundamental physics"; the Atlas reads the paper on the Atiyah page). It is a test of the method because $e^{-\tau D}$ is an exponential of a differential operator, which looks out of reach of finite algebra. The trick: on a plane wave the operator $bD = (\nabla\psi)\gamma_0$ is a linear map with $bD^2 = -Q(k)$, a scalar, so its exponential has a closed form,
$$e^{-\tau\,bD} = \cos E\tau - \frac{\sin E\tau}{E}\,bD\qquad (Q(k) = E^2 > 0),$$
by the power series of cos and sin (recalled; scipy's expm agrees to $4.6\times10^{-14}$). On the ordinary solutions of mass $E$ it is the right factor $e^{JE\tau}$: the translation by $\tau$ along $k/E$ for the waves $e^{-Jk\cdot x}$ and by $-\tau$ for the waves $e^{+Jk\cdot x}$, a retard in one sector and an advance in the other (ATY-005). The shifted equation on these waves is then one element $a + bJ$ of the algebra of $1$ and $J$, and a plane wave exists exactly when both parts vanish:
$$\cos E\tau = 0,\qquad E = m + \kappa\sin E\tau :\qquad E\tau = (n+\tfrac12)\pi,\quad E = m + (-1)^n\kappa .$$
This is the paper's quantization condition and rest energy. The log has it at $m = 3$, $\kappa = 2$: "at E tau = pi/2, E = 5 … and at E tau = 3 pi/2, E = 1 … the solutions are exactly the ordinary solutions of mass E, 4 per sector", and "no plane wave at: tau = lambda_C (E tau = 2 pi); tau = lambda_C/2; tau = 0 (E = m)", where $\lambda_C = 2\pi/E$. For $\kappa > m$ a second branch $E = \kappa - m$ lies on the other half ($m = 1$, $\kappa = 4$: $E = 3$), and at a null frequency there is no plane wave unless $m = \kappa = 0$: a massless fermion cannot be shifted. Figure 10 draws the lattice; the widget computes the element $a + bJ$ with the bit rule for any $m$, $\kappa$, $E$, $\tau$.

![Figure 10. (a) The lattice of allowed shifts of (iD − m + iκe^(−τD))ψ = 0 for m = 3, κ = 2: plane waves exist only where a curve Eτ = (j + 1/2)π meets E = m + (−1)ʲκ (blue dots); the rings are points the log lists with no plane wave (τ = 0, Eτ = π, Eτ = 2π). (b) A fixed shift of the whole mass term by a, θ = k·a: solutions only at the quarter turns (blue), none at the rational points (3/5, 4/5) and (5/13, 12/13). Drawn by figs_phys.py from shifted_dirac.log (shd·QNT, shd·RET).](figs/shift_lattice.svg)

@@widget shift

The same plane waves answer the variants. A retarded shift of the whole mass term, $\nabla\psi J = m\psi(x - a)\gamma_0$, has plane waves only for $\theta = k\cdot a$ in $(\pi/2)\mathbb{Z}$, on the spacelike shell at the odd quarter turns (ATY-004). The covariant shift $iD\psi = m\,e^{-\tau D}\psi$ keeps the waves of mass $m$ exactly when $m\tau \in \pi\mathbb{Z}$, one Compton period giving the ordinary solutions and half a period those of mass $-m$, in each of four frames (ATY-006). The paper's other operators, $D_-$, $D_s$, $D_c$, read uniformly as $D + \kappa f(\tau D)$, give the same lattice, a transcendental relation $E = m - \kappa\sin E\tau$ with no quantization, or a quantization with no mass shift (ATY-007). With a constant potential the fixed shift is not gauge covariant and needs the transport factor $e^{-JeA\cdot a}$, while $e^{-\tau bD_A}$ depends on $k - eA$ only (ATY-008). At the quantized shift the shifted solution is $\psi J$: the current and the spin vector are unchanged and the frame vectors $\psi\gamma_1\tilde\psi$, $\psi\gamma_2\tilde\psi$ reverse, a quarter turn of $\psi$ and a half turn of its frame (ATY-009). The formal series of the paper's squared operators have constant terms $-\kappa^2$, $\kappa^2$ and $0$: with the Weitzenböck formula (recalled, not checked) the leading equations read Ricci $= \pm\kappa^2$ or 0, a cosmological term of either sign or none (ATY-010). Why advanced and retarded terms come together is our reading, with the paper's reason, the two signs of frequency, being what the labels show (ATY-011).

**What the engine checks, and at what scope.** Plane waves of one frequency with constant amplitude and a constant potential; $n = 3, 4, 5$ on the labels, $n = 4$ with complex Dirac matrices and scipy; the shift enters through exact pairs $(\cos\theta, \sin\theta)$; 64 lines, 0 failures ("checks: 64 ok, 0 FAIL"). The shift vector itself is not built, and the shifted Ricci operators exist only as formal series in one commuting variable (the script's Scope line).

> **Try it.** Shortened from checks/selfcheck/proofs/shifted_dirac.py (the fault switches and the other variants left out); `alg.J` is $J$, `alg.g[0]` is $\gamma_0$, `alg.lin` adds multiples, `alg.mul` is the bit-rule product:
>
> ```python
> def bD(alg, P, k, sg, A=None, e=0):
>     """(nabla P + e A P J) gamma_0 on the amplitude of sector sg: (sg khat + e A) P J gamma_0"""
>     v = alg.lin((sg, alg.vec(k)), (e, alg.vec(A) if A else {}))
>     return alg.mul(alg.mul(alg.mul(v, P), alg.J), alg.g[0])
> def ordinary(alg, k, sg, m, A=None, e=0):
>     return lambda P: alg.lin((1, alg.mul(bD(alg, P, k, sg, A, e), alg.J)), (-m, P))
> class Expo:                                    # exp(-tau bD) in closed form, E^2 = Q(k) > 0
>     def minus(self, P):                        # exp(-tau bD) P
>         a = self.alg
>         if self.null:
>             return a.lin((1, P), (-self.tau, self.D(P)))
>         return a.lin((self.c, P), (-self.s / self.E, self.D(P)))
> def paper_eq(alg, X, m, kap):
>     def L(P):
>         base = alg.lin((1, alg.mul(X.D(P), alg.J)), (-m, P))
>         term = alg.mul(X.minus(P), alg.J)
>         return alg.lin((1, base), (kap, term))
>     return L
> ```
>
> Each equation is a linear map on the even amplitude $P$, and the script's `kernel()` finds its solutions by exact elimination. Run `python3 selfcheck/proofs/shifted_dirac.py` from the package root; the shipped log has, among its 64 lines,
>
> ```text
>   ok   [bit] n = 4, m = 3, kappa = 2: at E tau = pi/2, E = 5 (k = (5,0,0,0), (13,12,0,0), (7,2,4,2), (-5,0,0,0)) and at E tau = 3 pi/2, E = 1 (k = (1,0,0,0), (3,2,2,0), (5,4,2,2)) the solutions are exactly the ordinary solutions of mass E, 4 per sector: E = m + (-1)^n kappa
>   ok   [ctl] without the factor i (kappa exp(-tau D) in place of i kappa exp(-tau D)): none at (E tau = pi/2, E = 5), and 4 dimensions at tau = 0 with E = m - kappa = 1: the i moves the lattice by a quarter turn and excludes tau = 0
> ```
>
> Run it with `--fault NOI` and the wrong version, the shift term without its $i$, goes into the main lines; by the script's own rule the run must then end with FAILS. The $i$ of the paper, here the right $J$, is what puts the lattice on the quarter turns.

### Three questions for a physicist (Part 2)

1. *What are the extra components of $\psi$ from $n = 5$?* At $n = 5$ a second Dirac field, with no cross term in the current (CPL-007b). What the copies stand for, a flavour or a taste reading, and the grade-5 part of the current on one copy for $n \ge 6$, are open (CPL-007c).
2. *Does the shift quantize anything in nature?* On the labels it quantizes the plane waves of the paper's equation (ATY-005). A physical reading, why advanced and retarded terms come together, is ours (ATY-011); the shifted operator on a curved background exists only as a formal series (ATY-010).
3. *Is there a neutral fermion in the low cells?* At $n = 1, 2$ there is no $J$ and so no charged field; a neutral (Majorana) form was not built (CPL-006, open).

## Part 3 · The gauge engine: Yang–Mills and matter

### F7 · Yang–Mills: the gauge algebra from the commutator graph

**The physics.** Yang–Mills theory replaces the one potential of Maxwell by a potential with values in a Lie algebra, $F = dA + A\wedge A$, with the field equation $D{\star}F = {\star}J$ and the Bianchi identity $DF = 0$. Its classical solutions include the BPST instanton, a self-dual field on Euclidean $\mathbb{R}^4$ with topological charge 1, and the Wu–Yang monopole. Atiyah and Manton found that the holonomy of an instanton along lines is a good Skyrme field, a model of the nucleon.

**The trick.** A Lie algebra is a table of structure constants; on the labels the table is computed, not looked up. Two bivector labels anticommute exactly when they share one index, and then their commutator is $\pm2$ times the bivector on the symmetric difference of the two labels (MAP-016, checked for every signature with $p + q \le 8$). So the bivectors $B_{ab}$ of $\mathrm{Cl}(0,m)$ are so(m) with structure constants that are bit-rule signs, and the picture of the algebra is a graph: the labels as vertices, the anticommuting pairs as edges. Its closed triangles $\{B_{ab}, B_{bc}, B_{ac}\}$, one for each index triple, are so(3) subalgebras; from $m = 4$ the graph also has open triangles $\{B_{ab}, B_{ac}, B_{ad}\}$, which are not (YM-001). Figure 11 draws it at $m = 4$: the octahedron with 12 edges, 3 commuting antipodal pairs, 4 closed and 4 open faces.

![Figure 11. The commutator graph of the six bivectors of Cl(0,4): solid edges are the 12 anticommuting pairs (one shared index), dashed lines the 3 commuting pairs (no shared index); the green faces are the 4 closed triangles, each an so(3); the other 4 faces, the outer {B₀₁, B₀₂, B₀₃} among them, are open. The counts for m = 2 to 8 are parsed from step_lines.log. Drawn by figs_phys.py from algebra(4) of checks/selfcheck/yangmills_selfcheck.py.](figs/comm_graph.svg)

**On the labels.** The field equation is $D^\mu F_{\mu\nu} = J_\nu$ with gauge algebra so(m) (EQN-010), and $m = 2$ gives exactly Maxwell's incidences; for $m \ge 3$ the only new terms are the commutator terms, $2(m-2)$ quadratic terms per field component (YM-002). The Bianchi identity, the first-order covariance $\delta F = g[F, \lambda]$ and the covariant conservation $D^\nu J_\nu = 0$ forced by the equation are checked exactly on random polynomial fields for seven pairs $(m, n)$ from $(2,3)$ to $(5,4)$, as step_lines.log lists them. The action is rebuilt, not assumed: the stationarity of $-\tfrac12 K F\wedge{\star}F - K A\wedge{\star}J$, with $K = \langle B_A B_B\rangle_0 = -1$ on each generator, gives $D{\star}F = -{\star}J$ as an exact polynomial identity of the first variation, $\delta L = \delta A\wedge E + d(\ldots)$, for $m = 2, 3, 4$; the topological term $KF\wedge F$ is $d$ of the Chern–Simons form and adds nothing to the equation (INP-033). This is the textbook system with gauge algebra so(m), rebuilt (YM-004).

**BPST at rational points.** In the regular gauge the instanton is a self-dual so(4) = su(2) ⊕ su(2) connection (CAND-124). The log of ym_solutions.py checks it at 24 rational points with $\rho^2 \in \{1, 4/9, 9\}$: $F = {\star}F$ on every coefficient of the jets with the bit-rule star, $F^a_{\mu\nu} = -4\eta^a_{\mu\nu}\rho^2/(x^2+\rho^2)^2$ exactly, $D{\star}F = 0$ with the engine's covariant derivative, and the density $\sum_a F^a\wedge F^a = 96\rho^4/(x^2+\rho^2)^4\,dx^{1234}$, whose integral divided by $16\pi^2$ is exactly 1, the radial integral being $1/(12\rho^4)$. The controls: the anti-instanton gives $-1$, the field $2A$ is not a solution, and $\rho^2 \to -\rho^2$ keeps the local equations but has no finite action. The Wu–Yang monopole solves $D{\star}F = 0$ at 20 rational points away from the origin, with $\sum_a B^aB^a = 1/r^4$, the field of an abelian monopole of unit charge.

**Holonomy is a Skyrme field.** Along every line $x + te_4$ the BPST potential lies on one bivector $\hat x\cdot B$, so the values commute and the path ordering is trivial; the holonomy is $\exp(\theta\,\hat x\cdot B)$ with $\theta = \pi r/\sqrt{r^2 + \rho^2}$, and $-U = \exp(-f\,\hat x\cdot B)$ with the hedgehog profile
$$f(r) = \pi\Big(1 - \big(1 + \rho^2/r^2\big)^{-1/2}\Big)$$
of Atiyah and Manton (ATY-012). At Pythagorean data the profile is rational: $(r, \rho^2) = (3, 16)$ gives $f/\pi = 2/5$, $(7, 576)$ gives $18/25$, $(5, 144)$ gives $8/13$, exactly (skyrme_holonomy.log, sky·LINE). Its degree, the baryon number, is 1, equal to the instanton number (sky·DEG); along circles orthogonal to a sphere the same instanton gives the Skyrme field on hyperbolic space of Atiyah and Sutcliffe (ATY-013). Figure 12 draws the density and the profile. The energies of the Skyrme model are computed by a standard route only, in floats: the line profile has least energy $E = 1.2432$ at $\lambda^2 = 2.109$, 0.95 % above the massless Skyrmion $E = 1.23145$ (ATY-014); no row of the Atlas holds the Skyrme energy.

![Figure 12. (a) The BPST instanton: the radial density 2π²r³ · 96ρ⁴/(r² + ρ²)⁴ / 16π² for ρ = 1, whose area is exactly 1, the instanton number. (b) The holonomy along the lines x + t e₄: the hedgehog profile f(r)/π = 1 − (1 + ρ²/r²)^(−1/2), with the three Pythagorean data of skyrme_holonomy.log, exact, and the tail ρ²/(2r²). Drawn by figs_phys.py from ym_solutions.log and skyrme_holonomy.log.](figs/bpst_skyrme.svg)

The instanton is what makes the two numbers agree. For the field $cA$ the holonomy has baryon number $c$, while the Chern–Simons value is $3c^2 - 2c^3$: they agree only at $c = 0$ and $c = 1$, and at $c = 2$ they are $-4$ and $2$ (Figure 13; skyrme_holonomy.log, part 2). A non-abelian source of gravity is built on the Einstein static universe $\mathbb{R}\times S^3$ of radius $R$: the meron $A = \tfrac12\theta$ solves $D{\star}F = 0$ on the engine's curved frame (among $\lambda = 0, \tfrac14, \tfrac12, \tfrac34, 1, \tfrac32$ only $0, \tfrac12, 1$ do, and $\lambda = 1$ is pure gauge), its stress is homogeneous with $\rho = 3p = 3/(2R^4)$, and the Einstein form closes with $\kappa = R^2$ and $\Lambda = 3/(2R^2)$ (YM-007b). The abelian case closes Reissner–Nordström at 7 rational points (YM-007).

![Figure 13. The field cA built on the BPST instanton: its Chern–Simons value 3c² − 2c³ (blue) and the baryon number c of its holonomy along lines (orange) meet only at c = 0 and c = 1; at c = 2 they are −4 and 2. Drawn by figs_phys.py from the lines of skyrme_holonomy.log, part 2.](figs/chern_simons.svg)

**Other gauge algebras.** so(m) is what grade 2 gives; other Lie algebras come with one datum. u(n) is the centraliser of $J = B_{01} + B_{23} + \ldots$ in so(2n), of dimension $n^2$ for $n = 1$ to 6, and so(10) contains su(3) ⊕ su(2) ⊕ u(1), the algebra of the Standard Model, as the centraliser of two such complex structures inside su(5), as in the Spin(10) model (YM-006). Which gauge algebra, if any, the model uses is open (YM-006b).

**Beyond the finite object.** The instanton number is an integral over $\mathbb{R}^4$; the Atlas computes it exactly because the radial integral is elementary. The moduli space of instantons, $8k - 3$ parameters at charge $k$ (recalled from Hitchin's account on the Atiyah page), ADHM and Donaldson's invariants are not reached; the Atiyah page names a check that could be added, the five zero modes of BPST from the conformal Killing fields.

> **Try it.** The structure constants of so(m) from the bit product, word for word from checks/selfcheck/yangmills_selfcheck.py (`algebra`, and four lines of `structure`):
>
> ```python
> def algebra(m):
>     sq = [-1] * m; gens = [(1 << i) | (1 << j) for i in range(m) for j in range(i + 1, m)]; idx = {g: k for k, g in enumerate(gens)}
>     f = {}                                                                     # f[(a, b)] = {c: coefficient}
>     for a, ga in enumerate(gens):
>         for b, gb in enumerate(gens):
>             m1, s1 = bmul(ga, gb, sq); m2, s2 = bmul(gb, ga, sq); assert m1 == m2
>             if s1 != s2:
>                 assert popc(m1) == 2 and abs(s1 - s2) == 2
>                 f[(a, b)] = {idx[m1]: s1 - s2}
>     return gens, idx, f
>     # in structure(m):
>     for i, j, k in tri:                                                        # each index triple is a closed so(3)
>         a, b, c = idx[(1 << i) | (1 << j)], idx[(1 << j) | (1 << k)], idx[(1 << i) | (1 << k)]
>         assert set(f[(a, b)]) == {c} and set(f[(b, c)]) == {a} and set(f[(a, c)]) == {b}
>     assert len(pairs) == 3 * len(tri) == m * (m - 1) * (m - 2) // 2
> ```
>
> A commutator is the difference of the two products, $s_1 - s_2 = \pm2$, and it is non-zero exactly when the two signs differ. In checks/selfcheck:
>
> ```text
> >>> from yangmills_selfcheck import structure
> >>> {k: v for k, v in structure(4).items() if k in ('gens', 'noncommuting_pairs', 'commuting_pairs', 'triangles')}
> {'gens': 6, 'noncommuting_pairs': 12, 'commuting_pairs': 3, 'triangles': 4}
> >>> [structure(m)['noncommuting_pairs'] for m in range(2, 9)]
> [0, 3, 12, 30, 60, 105, 168]
> ```
>
> The second line is the row of step_lines.log that Figure 11 quotes, $3\binom{m}{3}$. Try `structure(5)` and count the open triangles yourself: every vertex of the graph has $2(m-2)$ neighbours.

### F8 · Matter: one generation on sixteen labels

**The physics.** A generation of the Standard Model is sixteen Weyl fermions (with a right-handed neutrino): the quark doublet, two antiquark singlets, the lepton doublet, the positron and the antineutrino, with hypercharges $1/6, -2/3, 1/3, -1/2, 1, 0$. The gauge theory is consistent only if six anomaly sums vanish, and in the Spin(10) model the sixteen are one half-spinor of so(10).

**The trick.** The sixteen are the even labels of five bits. Name bits 0 and 1 the weak switches and bits 2, 3, 4 the colour switches; let $a$ and $b$ count the weak and the colour switches that are on. Then the charges are read off the bits:
$$Y = \tfrac{a}{2} - \tfrac{b}{3},\qquad Q = (x\,\&\,1) - \tfrac{b}{3},\qquad T_3 = \tfrac{(x\,\&\,1) - ((x \gg 1)\,\&\,1)}{2},$$
as the statement of sm16_labels.py writes them. The six classes $(a, b)$ of even labels are the six multiplets of the textbook table one to one, with the colour dimension from $b$ and the weak dimension from $a$ (Figure 14). Naming each switch by its own prime makes a label a square-free number, and the product of two labels the product of their numbers with every squared prime divided out: the switch rule without its sign, an exact relabelling, and the primes are only names (FUR-523, a reading of the dictionary page).

![Figure 14. One generation on the sixteen even labels of five bits: rows b (colour bits on), columns a (weak bits on); each cell is one multiplet with its hypercharge, and each label is printed as colour bits | weak bits with its charge Q. The six anomaly sums and the ratio Tr T₃²/Tr Q² = 3/8 are recomputed by the script and asserted against sm16_labels.log. Drawn by figs_phys.py.](figs/sm16.svg)

**On the labels: the anomalies.** Over the sixteen even labels the sums are SU(3)³ 0, SU(2)²U(1) 0, SU(3)²U(1) 0, U(1)³ 0, gravitational U(1) 0, and the number of doublets is 4, even, so Witten's global SU(2) condition holds too: the log line of sm16·A1, computed three ways, from the labels, from the traces of Fock matrices of five fermionic modes, and from the textbook table (LNB-103, CAND-003). The controls see each condition: the 10 alone or the $\bar 5$ alone are anomalous, and only cancel together with the singlet; the sixteen without the lepton doublet have 3 doublets, an odd number; the hypercharge with the weak and colour coefficients exchanged gives $\sum Y^3 = -325/54$. The cubic trace $\mathrm{tr}\,T_a\{T_b, T_c\}$, the coefficient of the gauge anomaly of a representation, vanishes on both half-spinors of so(n,n) for $n = 2, 4, 5, 6$ and not for $n = 3$, where so(3,3) = sl(4,ℝ) acts on its 4 (sm16·B). Over the sixteen, $\mathrm{Tr}\,T_3^2 = 2$ and $\mathrm{Tr}\,Q^2 = 16/3$, the ratio $3/8$ of grand unification; the script's scope line says what it is: "a ratio of traces (the unification value), nothing more".

**The star exchanges 16 and $\overline{16}$.** The complement $x \mapsto x \oplus 11111$ is the Hodge star of $\Lambda(\mathbb{R}^5)$ up to the sign of the permutation $(S, \bar S)$; for odd $n$ it exchanges the even and the odd labels, the two eigenspaces of the volume element, and it negates every weight of sl(5), and so $Y$ and $Q$ (CAND-062, sm16·D). So charge conjugation, $16 \leftrightarrow \overline{16}$, is a bit flip of all five switches. The real form matters: the bivectors of $\mathrm{Cl}(0,10)$ give the compact so(10), Killing signature $(0, 45, 0)$, with a positive-definite invariant form on its 32; those of $\mathrm{Cl}(5,5)$ give the split so(5,5), signature $(25, 20, 0)$, whose only invariant symmetric form has signature $(16, 16, 0)$, so no positive-definite invariant form exists there (sm16·E).

**The engine for charged matter.** The gauge algebra of F7 acts on internal blades by left multiplication, through the demicube edges of the internal cube (MAT-001); the source of the gauge field has four components per generator, built from pairs of components of $\Psi$, and it is conserved covariantly exactly when the matter equation holds (MAT-003), the abelian case being the current of the coupling step (MAT-002). One action fixes the ratio of the two couplings, $\kappa/g = -1$ in the normalisation $K = -1$ (MAT-005), and the Noether current of each generator is $j^a$, with $D_\mu j^{a\mu} = -2\langle E\gamma_0, B_a\Psi\rangle$ off shell (INP-037). The counts are EQN-011. The representation is a choice, the spinor-type one, and a chiral coupling is not treated (INP-039, MAT-006).

**Beyond the finite object.** Three generations, the masses and mixings, the Higgs field and the breaking of so(10) are not on the labels; the script's scope line: "nothing here decides a gauge group, three generations or anything about nature".

> **Try it.** The labels and the charges, word for word from checks/selfcheck/proofs/sm16_labels.py, after two lines that the script takes from its imports (`from fractions import Fraction as F` and `pc = lambda x: bin(x).count('1')`):
>
> ```python
> a_of = lambda x: pc(x & 3)                                           # weak bits set
> b_of = lambda x: pc(x >> 2)                                          # colour bits set
> LAB = list(range(32))
> EVEN = [x for x in LAB if pc(x) % 2 == 0]; ODD = [x for x in LAB if pc(x) % 2 == 1]
> Y_true = lambda x: F(a_of(x), 2) - F(b_of(x), 3)
> Qf = lambda x: (x & 1) - F(b_of(x), 3)
> T3f = lambda x: F((x & 1) - ((x >> 1) & 1), 2)
> ```
>
> ```text
> >>> print(sum(Y_true(x) for x in EVEN), sum(Y_true(x) ** 3 for x in EVEN), sum(T3f(x) ** 2 for x in EVEN), sum(Qf(x) ** 2 for x in EVEN))
> 0 0 2 16/3
> >>> sorted({(a_of(x), b_of(x), str(Y_true(x))) for x in EVEN})
> [(0, 0, '0'), (0, 2, '-2/3'), (1, 1, '1/6'), (1, 3, '-1/2'), (2, 0, '1'), (2, 2, '1/3')]
> >>> all(Y_true(x ^ 31) == -Y_true(x) for x in EVEN)
> True
> ```
>
> The gravitational and the cubic U(1) sums vanish, the traces give $2/(16/3) = 3/8$, the six classes carry the six hypercharges of the table, and the complement negates $Y$. Sum $Y^3$ over the labels of popcount 2 only, the 10, and you find the $5/36$ of the control line.

### Three questions for a physicist (Part 3)

1. *Which gauge group, and why so(m)?* so(p,q) is what grade 2 gives; the Standard Model algebra appears inside so(10) with one datum (YM-006), and which algebra the model uses is open (YM-006b).
2. *Where is the chiral coupling of the electroweak theory?* The doublets of the standard theory are left-handed and charged under two groups; a chiral coupling, and with it a scalar doublet for the masses, is not treated (MAT-006, open).
3. *Is there a non-abelian source of gravity with $\Lambda = 0$?* The meron needs the cosmological term (YM-007b); an asymptotically flat Einstein–Yang–Mills solution is not built (YM-007c, open).

## Part 4 · The gravity engine: gravity I and II

### F9 · Gravity I: frame, connection and curvature

**The physics.** In Cartan's form of general relativity a gravitational field is a frame $e^a$, four 1-forms that make the metric $g = \eta_{ab}e^a e^b$, and a connection $\omega^{ab}$, 1-forms with values in the Lorentz algebra. Curvature and torsion are $R^{ab} = d\omega^{ab} + \omega^a{}_c\wedge\omega^{cb}$ and $T^a = de^a + \omega^a{}_b\wedge e^b$. In four dimensions the Riemann tensor has 20 components, 10 in the Ricci part, which the field equation constrains, and 10 in the Weyl part, the free gravitational field, whose algebraic type is the Petrov classification.

**The trick.** Differential forms are the bit rule with null generators. Give each coordinate differential its own switch with square 0: then $dx^\mu dx^\mu = 0$ and $dx^\mu dx^\nu = -dx^\nu dx^\mu$, so the product of the cell $\mathrm{Cl}(0,0,n)$ is the wedge product, its sign on a sequence of generators is the Levi-Civita symbol, and $d = \sum_\mu dx^\mu\partial_\mu$ is one more product. The connection takes values in the bivector labels of the frame algebra $\mathrm{Cl}(1, n-1)$, whose commutators are the graph of F7, and the curvature is the Yang–Mills field strength with coupling ½:
$$R = d\omega + \tfrac14[\omega, \omega],\qquad T = de + \omega e$$
(EQN-012). So $d$, $\wedge$ and the curvature are all products of labels: two cells, one with null squares for the forms and one with the signature for the frame. The added ingredient over Yang–Mills is the second index type, the frame, which carries torsion (GRV-002).

**On the labels.** The second Bianchi identity $DR = 0$, the first, $DT = Re$, and the covariance $\delta R = \tfrac12[R, \lambda]$ are derived for every $n$ from three facts about the bit rule, associativity, $dd = 0$ and the derivation property of $d$ (a plain-text derivation, not a machine-checked proof), and checked exactly on three independent random polynomial fields per $n = 3, 4, 5$ with integer jet coefficients uniform in $[-50, 50]$, a false identity passing with probability at most $(3/101)^3$, and as an exact polynomial identity at $n = 3$ (GRV-001, GRV-002). On spinors, $[D, D]\psi = \tfrac12 R\psi$ is the gauge identity of F8 with a different generator (GRV-003). The connection is a function of the frame: the map $\omega \to T$ is a constant square matrix whose inverse is the Cartan–Koszul formula, $L\cdot S = -1$ exactly for $n = 2$ to 8 (GRV-006). This is first-order Cartan gravity; the dimension $n^2(n^2-1)/12$ and the Ricci–Weyl split are textbook (GRV-004).

**Riemann = Ricci + Weyl.** A curvature is a symmetric pairing of planes, an element of $\mathrm{Sym}^2(\Lambda^2)$, and the first Bianchi identity removes the four-form part: $\mathrm{Sym}^2(\Lambda^2 V) = \ker b \oplus \Lambda^4 V$ with $b(\alpha\cdot\beta) = \alpha\wedge\beta$, and $\ker b$, the algebraic curvature tensors, has dimension $n^2(n^2-1)/12$ (RSN-032). On it the Ricci contraction has rank $n(n+1)/2$ for $n \ge 3$ and rank 1 at $n = 2$, and its kernel, the Weyl part, has dimension $n(n+1)(n+2)(n-3)/12$: 0 at $n = 3$, 10 at $n = 4$, 35 at 5, 84 at 6, and 0 at $n = 2$, where the formula gives $-2$ (RSN-018, RSN-032). The log of opened_4.py prints the table from the engine's own curvature space, from semistandard tableaux and from numpy, and Figure 15 draws it.

![Figure 15. The symmetric pairs of planes, Sym²(Λ²), for n = 2 to 8, as shares of one bar: the Ricci part (blue), the Weyl part (orange) and the four-form part Λ⁴ that the Bianchi map removes (violet); the totals are 1, 6, 21, 55, 120, 231, 406. Drawn by figs_phys.py from the table of opened_4.log (opn·WEYL) and the lines catl·B2 of catw_lines.log; the closed forms are asserted.](figs/curvature_counts.svg)

**The octahedron of planes.** In four dimensions the six planes $e_{01}, \ldots, e_{23}$ are the six bivector labels, the vertices of the octahedron of F7. A symmetric pair of planes is a vertex (a plane with itself, 6), an edge (two planes sharing one index, 12) or an antipodal pair (two disjoint planes, which commute, 3): $6 + 12 + 3 = 21$, the dimension of $\mathrm{Sym}^2(\Lambda^2)$, and the three antipodal pairs are the three cross terms of $F\wedge F$ (LNS-013). The same 21 are the area metric of a general linear electrodynamics from a Lagrangian, while a general local medium has 36, 20 principal, 15 skewon and 1 axion, and the axion does not enter the wave operator (LNS-013, bd·sol·14). In $\mathrm{Cl}(1,3)$ the pseudoscalar times a plane is the complementary plane and squares to $-1$, so duality is a complex structure on the six planes: the 21 split $9 + 12$, the trace-free Ricci part (9) against Weyl 10, scalar 1 and the trace the Bianchi identity removes, and the Weyl part is one complex symmetric trace-free $3\times3$ matrix $Q = E + iB$ over the three antipodal pairs. Its Jordan form is the Petrov type: D for Schwarzschild, Schwarzschild–(anti-)de Sitter and Kerr, N for plane waves, O for de Sitter and FRW, I for random frames (LNS-013d); types II and III are built from their Jordan forms at one point (CAND-089, gm·petrov·1–3). The Weyl 2-form is conformally invariant, and so is the type (GRV-004b). Figure 16 draws the octahedron with the duality on its antipodes.

![Figure 16. The octahedron of the six planes of a four-space: 6 vertices (a plane with itself), 12 edges (two planes sharing one index), 3 antipodal pairs in orange (two disjoint planes, the cross terms of F∧F): 21 symmetric pairs. The pseudoscalar maps each plane to its antipode, with square −1 in Cl(1,3) and +1 in Cl(4,0), as aty_cone_defects.log prints and figs_phys.py recomputes with bitcliff; the fill is the square of the plane in Cl(1,3).](figs/octahedron_planes.svg)

**The real split in the Euclidean cells.** In $\mathrm{Cl}(4,0)$ and $\mathrm{Cl}(0,4)$ the pseudoscalar squares to $+1$: there is no complex structure, the star splits the planes $3 + 3$, and $W = W^+ + W^-$ is a real split (LNS-013d, ATY-023). The two characteristic 4-forms are the two pairings of the octahedron: $\varepsilon_{abcd}R^{ab}\wedge R^{cd}$ pairs each plane with its antipode, $\sum_{a<b}R^{ab}\wedge R^{ab}$ each plane with itself, and at every sample point $\varepsilon R\wedge R = 4(|W|^2 - |\mathring r|^2/2 + s^2/24)\,d\mu$ and $\sum R^{ab}\wedge R^{ab} = (|W^+|^2 - |W^-|^2)\,d\mu$ exactly (ATY-023; the octahedron reading is ours, the block decomposition textbook). On this engine the models of matter of Atiyah, Manton and Schroers are curvatures at rational points: Taub–NUT in the Gibbons–Hawking form, $V = 1 + m/r$, has $E_a(0) = 0$ at 8 rational points, a curvature that is self-dual with $W^+$ of type D and eigenvalues $-\mu, -\mu, 2\mu$, $\mu = m/(r+m)^3$, and $|Rm|^2 = 24m^2/(r+m)^6$ (ATY-017); the round $S^4$ has $W = 0$, and $\mathbb{C}P^2$ with the Fubini–Study metric has $\mathrm{Ric} = 6g$, $W^- = 0$ for the complex orientation, $W^+$ of type D with eigenvalues $-2, -2, 4$, and $|W^+|^2 = 96$ (ATY-018). Figure 17 draws the eigenvalues.

![Figure 17. (a) Taub–NUT: m² times the eigenvalues of W⁺, the simple 2μ and the double −μ with μ = m/(r + m)³, against x = r/m, with the 8 rational points of the log (m = 2, 1/2 and 3 fall on one curve in these units). (b) CP²: the double eigenvalue −2 and the simple 4 of W⁺; S⁴: W = 0. Drawn by figs_phys.py from the lines G1 and G3 of aty_matter_models.log (aty·matter·4 to 7).](figs/weyl_eigen.svg)

**What the engine checks, and at what scope.** The identities for every $n$ by a plain-text lemma chain, exactly at $n = 3$ in the jet coefficients, and on random fields with a stated false-pass bound for $n = 3$ to 5; the counts for $n = 2$ to 8; the Petrov types at one rational point per frame. The script's own words: "The bound is the result; a pass adds no physics" (gravity_selfcheck.py).

**Beyond the finite object.** A curvature here is a 2-jet at a point of one chart. The global structure of a space-time, its causal structure, singularities and topology, needs gluing charts, which the Atlas does not do: "the atlas is pointwise algebra and finite combinatorics, its fields are polynomials in one chart" (LNS-023, open).

> **Try it.** Forms as the bit rule with null generators, and the curvature, word for word from checks/selfcheck/gravity_selfcheck.py (`wedge` is the same loop as `d` with `bmul(a, b, self.sq0)`; `padd`, `pder` and `Fm.add` add and differentiate polynomials):
>
> ```python
> class Forms:
>     def __init__(self, n): self.n = n; self.sq0 = [0] * n
>     def d(self, X):
>         r = {}
>         for a, p in X.items():
>             for mu in range(self.n):
>                 dp = pder(p, mu)
>                 if not dp: continue
>                 m, s = bmul(1 << mu, a, self.sq0)
>                 if s == 0: continue
>                 x = padd(r.get(m, {}), dp, s)
>                 if x: r[m] = x
>                 else: r.pop(m, None)
>         return r
> class Grav:
>     def curvature(self, om):                                                   # R^C = d omega^C + (1/4) f_AB^C omega^A ^ omega^B
>         Fm = self.Fm; R = [Fm.d(om[C]) for C in range(self.G)]
>         for (A, B), (C, f) in self.L.f.items(): R[C] = Fm.add(R[C], Fm.wedge(om[A], om[B]), F(f, 4))
>         return R
> ```
>
> In checks/selfcheck (a form is a dictionary from masks of the $dx^\mu$ to polynomials):
>
> ```text
> >>> from gravity_selfcheck import Forms
> >>> Fm = Forms(4)
> >>> x = lambda mu: {0: {tuple(int(i == mu) for i in range(4)): 1}}
> >>> Fm.d(x(0)), Fm.wedge(Fm.d(x(1)), Fm.d(x(0)))
> ({1: {(0, 0, 0, 0): 1}}, {3: {(0, 0, 0, 0): -1}})
> >>> f = {0: {(2, 1, 0, 3): 5, (1, 1, 1, 1): -2}}
> >>> Fm.d(Fm.d(f)), Fm.wedge(Fm.d(x(2)), Fm.d(x(2)))
> ({}, {})
> ```
>
> $d$ of the coordinate $x^0$ is $dx^0$; $dx^1\wedge dx^0 = -dx^{01}$ is the reordering sign of the bit rule; $dd = 0$ and $dx^2\wedge dx^2 = 0$ come from the null squares, with no rule written for them. The curvature line is then the Yang–Mills line of F7 with $\tfrac14$ for the coupling.

### F10 · Gravity II: the Einstein form

**The physics.** Einstein's equation $G_{\mu\nu} + \Lambda g_{\mu\nu} = 8\pi G\,T_{\mu\nu}$ ties the Ricci part of the curvature to matter. Its classic solutions are Schwarzschild, unique among spherically symmetric vacua by Birkhoff's theorem, Reissner–Nordström for a charge and Kerr for a rotating mass; the sign of $\Lambda$ separates de Sitter from anti-de Sitter. In four Euclidean dimensions the integrals of the two characteristic 4-forms are the Euler number and the signature (Gauss–Bonnet–Chern and Hirzebruch).

**The trick.** The Einstein term is one more product with the frame, and the cosmological term is one more generator. The Einstein form is
$$E_a = \sum_{b<c}\varepsilon_{abcd}\,F^{bc}\wedge e^d,\qquad F^{bc} = R^{bc} + c\, e^b\wedge e^c$$
in four dimensions (EQN-013), and for any frame $E_a = -(G^b{}_a - \Lambda_n\delta^b{}_a)\,\Theta_b$ exactly, with $G$ the Einstein tensor of the metric $e^\top\eta e$ and $\Lambda = 3c$ at $n = 4$ (GRV-010; the shipped tutorial's Part E4 reads the log of a4_einstein_tensor.py). $F$ is the curvature of the algebra with one generator more: the de Sitter or anti-de Sitter algebra, and the sign of the cosmological term is minus the sign of the square of the extra generator, $k = -s$. With space squaring $-1$, an extra generator that squares to $-1$ like space gives de Sitter and one that squares to $+1$ like time gives anti-de Sitter: the choice is the square of one switch, and which convention reads it is an input (GRV-007, INP-049).

**Where the Einstein form vanishes.** $E_a(c) = 0$ holds exactly where $F(c)$ is the Weyl 2-form: at any point $F(c) - W$ is the trace-free Ricci part plus a multiple of $e^a e^b$, which is $E_a(c)$ written again, so both say $\mathrm{Ric} = -3c\,\eta$; Cartan flatness, $F = 0$, is stronger, since it needs the Weyl part to vanish too: zero on (anti-)de Sitter, type D on Schwarzschild–(anti-)de Sitter and Kerr, never the Weyl 2-form on Reissner–Nordström (GRV-004d; 21 torsion-free frames and 96 (frame, $c$) pairs in both conventions). The Einstein form is the $e$-variation of the Einstein–Cartan action with a cosmological term, as an exact polynomial identity on random fields (GRV-005), and its covariant derivative is torsion terms only, the Bianchi identity that forces the source to be conserved (GRV-008).

**Schwarzschild, derived in a class.** In the Kerr–Schild frames with a radial null direction and any $f(\rho)$, the mixed Einstein tensor is linear in the 2-jet of $f$: $G^t{}_t = G^r{}_r = 2(\rho f)'/\rho^2$, the tangential eigenvalue is $(\rho f)''/\rho$, and $E_a(c) = 0$ reduces to $(\rho f)' = \tfrac32 c\rho^2$; its solutions are $f = M/\rho + (c/2)\rho^2$, that is $g_{tt} = 1 - 2M/\rho - c\rho^2$ (GRV-012). The log of c1_birkhoff.py checks the closed form against the engine in all 16 components at 28 samples, finds for $f = \rho^k$ the coefficients $2(k+1)$ and $k(k+1)$ of $\rho^{k-2}$, and, in a Laurent ansatz $\rho^{-3}\ldots\rho^3$ with the unknown $c$, a null space of dimension exactly two, "span{M/rho, (c/2) rho^2}". Figure 18 draws the coefficients: only $k = -1$ makes both vanish, and $k = 2$ makes them equal, a constant that the cosmological term absorbs. The class is restricted, one function and one null congruence: this is not the general Birkhoff theorem (GRV-012). The widget recomputes the eigenvalues for any Laurent $f$ in exact fractions and decides vacuum identically in $\rho$.

![Figure 18. The Einstein tensor of the radial Kerr–Schild frames f = ρᵏ, k = −3 to 3: the radial eigenvalue 2(ρf)′/ρ² = 2(k + 1)ρ^(k−2) (blue) and the tangential (ρf)″/ρ = k(k + 1)ρ^(k−2) (orange). k = −1, M/ρ, is the only vacuum; at k = 2 both are 6, the cosmological term. Drawn by figs_phys.py from the closed forms of c1_birkhoff.log, which the script parses and recomputes.](figs/birkhoff.svg)

@@widget einstein_ks

**Charge and rotation.** With the Maxwell stress $T(a) = -\tfrac12 FaF$ of a point charge and $A = (Q/\rho)\,l$, the engine's Einstein form obeys $E_a + \kappa T_a = 0$ exactly when the charge term of $f = M/\rho - s/\rho^2$ is $s = \kappa Q^2/4$, on all 16 components at 7 rational points and 4 parameter sets (MAT-007, INP-050); the coupling $\kappa$ is a free constant that the Poisson equation of the weak static limit calibrates to $8\pi G$ (INP-050, GRV-011). On the Kerr–Schild frame of Kerr with $M = 5$, $a = 3$ the Einstein form vanishes, and the engine's connection gives the surface gravity $\kappa_H = 2/45$ on the horizon $r_+ = 9$ and $\Omega_H = 1/30$, the Boyer–Lindquist values (EQN-020; c2_kerr.log).

**Cones: the Euler and the signature defects.** Atiyah and LeBrun compute the two characteristic integrals of a 4-metric with a cone of angle $2\pi\beta$ along a surface $\Sigma$:
$$\frac{1}{32\pi^2}\int\varepsilon_{abcd}R^{ab}\wedge R^{cd} = \chi(M) - (1-\beta)\chi(\Sigma),\qquad \frac{1}{12\pi^2}\int\sum_{a<b}R^{ab}\wedge R^{ab} = \tau(M) - \tfrac13(1-\beta^2)[\Sigma]^2 .$$
The engine computes both integrals exactly on three families (ATY-020, ATY-021). On $S^4$ with the cone along $S^2$ the Euler integral is $2\beta$ and on $S^2$ times a football with two cone points $4\beta$, at $\beta = 1/3, 1/2, 2/3, 2, 3$; on $\mathbb{C}P^2$ with a cone along a line it is $1 + 2\beta$, and the signature integral is $\tau(\mathbb{C}P^2)(2 + \beta^2)/3$: $-19/27, -3/4, -1, -2$ at $\beta = 1/3, 1/2, 1, 2$, with $\tau = [\mathbb{C}P^1]^2 = -1$ in the chart's orientation. The paper's self-dual Einstein cones on $(\mathbb{C}P^2, \mathbb{C}P^1)$ are built at eight rational points: one half of the Weyl tensor is zero, $\mathring r = 0$, and the Einstein constant is $\tfrac32\beta^2(2-\beta)$, as printed (ATY-022). Figure 19 draws the defects; the widget evaluates both formulas at any $\beta$ in exact fractions and checks itself against the log. Reading the paper's Theorem A through the Einstein form is ours (ATY-024); the limits to gravitational instantons are recalled, not computed (ATY-025).

![Figure 19. (a) The Euler integral (1/32π²)∫εR∧R against β: S⁴ with the cone along S² (2β), S² × football (4β), CP² with the cone along a line (1 + 2β). (b) The signature integral of CP², −(2 + β²)/3 in the chart orientation, and 0 for the other two. Dots: the exact integrals of aty_cone_defects.log (ATY-020, ATY-021); lines: the theorems of Atiyah and LeBrun. Drawn by figs_phys.py, which parses the log and asserts each dot on its line.](figs/cone_defects.svg)

@@widget cones

**What the engine checks, and at what scope.** The Einstein tensor identity on three random non-vacuum frames per $n = 3, 4, 5$ with a false-pass bound of $5.2\times10^{-5}$ (GRV-010); solutions at rational points of named families, never a statement for all $\beta$, all frames or all connections; the integrals of the cone families exactly, because their densities are rational functions of one variable whose degree the script bounds and then interpolates (aty_cone_defects.log, part 4: "a polynomial of degree 23 … the interpolant through D+1 of the 40 points matches the other 16").

**Beyond the finite object.** The general Birkhoff theorem, the uniqueness of Kerr, the singularity and positive-mass theorems, gravitational waves beyond the linear order and black-hole thermodynamics as more than identities among $\kappa_H$, $\Omega_H$ and $\Phi_H$ (the first law and Smarr are checked as classical identities, EQN-020) are global or analytic statements that the Atlas does not reach.

> **Try it.** The Einstein form of checks/selfcheck/gravity_selfcheck.py, word for word (`self.eps` is the sign the null product gives to a sequence of generators, the Levi-Civita symbol):
>
> ```python
>     def einstein(self, om_unused, e, R, c=0):
>         """E_a = sum_{b<c} eps_{a b c d...} F^{bc} ^ e^{d1} ^ ... ^ e^{dk} (d sorted), F^{bc} = R^{bc} + c e^b ^ e^c;  needs n >= 3"""
>         n, Fm, L = self.n, self.Fm, self.L; k = n - 3; E = []
>         F_ = {}
>         for (a, b) in itertools.combinations(range(n), 2):
>             A = L.idx[(1 << a) | (1 << b)]; F_[(a, b)] = Fm.add(R[A], Fm.wedge(e[a], e[b]), c) if c else R[A]
>         for a in range(n):
>             tot = {}
>             for b, cc in itertools.combinations(range(n), 2):
>                 if a in (b, cc): continue
>                 rest = [x for x in range(n) if x not in (a, b, cc)]; s = self.eps([a, b, cc] + rest)
>                 form = F_[(b, cc)]
>                 for d in rest: form = Fm.wedge(form, e[d])
>                 tot = Fm.add(tot, form, s)
>             E.append(tot)
>         return E, F_
> ```
>
> The cosmological term is the line that adds $c\,e^b\wedge e^c$ to the curvature: the square of the extra generator, read as a number. Run `python3 selfcheck/gravity/c1_birkhoff.py` from the package root (about 18 seconds); the shipped log has
>
> ```text
>   ok   [bit] radial eigenvalue = G^t_t = 2 (f0 + rho0 f1)/rho0^2 = 2 (rho f)'/rho^2, and the (t, x) cross components vanish (7 radii/directions, random jets)
>   ok   [bit] the null space is exactly span{M/rho, (c/2) rho^2}: no other Laurent term (k = -3..3) and no other c: the extra solutions are absent
>   ok   [bit] E_a(c) = 0, all 16 components, for f = M/rho + (c/2) rho^2 with M in {1/3, -2, 5/7} and c in {0, 1/4, -1/3}: 63 samples (M free: the integration constant of the ODE)
> FAILS (C1): none
> ```
>
> Set $s$ in the widget above and watch the residual $\pm2s\rho^{-4}$ appear with opposite signs in the radial and the tangential eigenvalue: that is the stress of a point charge, which the check c3_rn.py closes with $s = \kappa Q^2/4$ (INP-050).

### Three questions for a physicist (Part 4)

1. *Is Schwarzschild the only spherically symmetric vacuum?* In the radial Kerr–Schild class, yes, with the cosmological term (GRV-012); the general Birkhoff theorem, for every spherically symmetric metric, is not checked.
2. *Does the engine see gravitational radiation?* Plane waves are of Petrov type N at a point (LNS-013d) and the weak static limit gives Poisson (GRV-011); the energy carried by a wave, a global quantity, is beyond one chart (LNS-023).
3. *Which sign of $\Lambda$ does the algebra prefer?* None: the sign is the square of one more generator, an input with its convention (INP-049); the shifted Ricci series of Atiyah and Moore give $\pm\kappa^2$ or 0 alike (ATY-010).

## Part 5 · What the Atlas cannot reach in physics

### F11 · The finite object and its edge

The Atlas is finite-dimensional algebra on labels with engines on polynomial fields. In the Atlas's words, "Our rule works at one point at a time, with a finite number of switches; spaces with endless directions are out of its reach" (LNS-069, open), and the category page states the same scope as a definition, "Finite-dimensional algebra only" (LNC-001). Four kinds of physics lie past that edge.

**Quantization.** Every field on this page is classical: a spinor is a section of a finite algebra, not an operator on a Hilbert space. Banach and Hilbert spaces, the spectral theorem and the bosonic Fock space are listed as gaps, with measurement and mixed states beyond $\mathrm{Cl}(3,0)$ (LNS-025, open). The fermionic Fock space of five modes is finite and the Atlas uses it (the 32 labels of F8), but path integrals, renormalization, the S-matrix and anomalies as quantum effects are not computed; the anomaly sums of F8 are the conditions, read on the labels, not the loop diagrams.

**Infinite dimensions and gluing.** A field here is a polynomial in one chart, or its jet at a rational point. Topology, bundles and connections as sections over a manifold need gluing (LNS-023, open). Integrals over space-time appear only where the integrand is a rational function of one variable (the instanton number, the cone integrals), and the Atiyah page lists what that leaves out: "KO of a space, the index of an elliptic operator, the moduli spaces of instantons and monopoles, twistor space and the Penrose transform, the moment map and the symplectic quotient, the topological field theories of dimensions 3 and 4, the Atiyah–Hitchin metric, the G-signature theorem, the Berry–Robbins problem, or any statement for all β, all forms or all connections where it has checked finitely many" (atiyah_lens.html, section 8).

**Moduli spaces.** The BPST instanton is one point of a moduli space of dimension $8k - 3$ at charge $k$ (recalled); the Atlas computes the point, not the space, and the Skyrme energies only by a standard route in floats (ATY-014). The check the Atiyah page proposes, the five zero modes from the conformal Killing fields, is not a row of the Atlas.

**Measurements.** No number of nature is predicted. The light page's words are "nothing is predicted" (PAG-008); the coupling constants $e$, $g$ and $\kappa$ are free (INP-028, INP-035, INP-050), $\kappa = 8\pi G$ is a calibration by Newton's shell theorem (INP-050), the gauge algebra and the chirality of the weak force are open (YM-006b, MAT-006), and the 3/8 of F8 is a ratio of traces. What the Atlas gives in place of predictions is a ledger: each equation with its row, its inputs listed as input rows, its check with a control that fails, and the scope of the check in numbers.

## Closing table · one object, three names

| The course's name | The Atlas's name | Row and status |
|---|---|---|
| Minkowski metric, signature | the squares of four switches, the cell Cl(1,3) | INP-025, INP-011 (inputs) |
| a hyperbolic wave operator | one switch of the minority sign | LNS-102, PAG-011 (proved by the Atlas) |
| field tensor $F_{\mu\nu}$ | a bivector on six labels | ATL-017 (proved by the Atlas) |
| Maxwell's four equations | $\nabla F = J$, its grade-1 and grade-3 parts | EQN-006, RSN-025, MAP-036 (proved by the Atlas) |
| charge conservation, $\square$ | two steps cancel; twins cancel | MAP-038, MAP-039 (proved by the Atlas) |
| invariants $E^2 - B^2$, $\mathbf{E}\cdot\mathbf{B}$ | scalar and four-generator parts of $F^2$ | PAG-036 (proved by the Atlas) |
| Hodge star | the complement map with the sign $\sigma(S)$ | CAND-062 (proved by the Atlas) |
| Dirac equation and $i$ | $\nabla\psi J = m\psi\gamma_0$, $J = \gamma_2\gamma_1$ | EQN-008 (proved by the Atlas), INP-024 (input) |
| mass shell | kernel of 4 per sector on $Q(k) = m^2$ | MAP-017 (proved by the Atlas) |
| spin ½, little groups | the even Pauli part at rest; the rotor $-1$ after a turn | CAND-126, SPN-006 (proved by the Atlas) |
| Dirac current | $\psi\gamma_0\tilde\psi$, grades $\equiv 1 \bmod 4$ | MAP-018, CPL-012 (proved by the Atlas) |
| Dirac spinor count | one spinor exactly at $n = 3, 4$ | CPL-003 (proved by the Atlas) |
| minimal coupling, U(1) gauge | a factor $A$ on edges; $\psi \to \psi(1 + J\varepsilon)$ | CPL-001, CPL-005 (proved by the Atlas) |
| shifted Dirac equation | the right factor $e^{JE\tau}$; the lattice $\cos E\tau = 0$ | ATY-005 (proved by the Atlas), ATY-011 (our reading) |
| so(3) structure constants | closed triangles of the commutator graph | YM-001 (proved by the Atlas) |
| Yang–Mills from the action | an exact first variation | INP-033 (proved by the Atlas) |
| BPST instanton | a self-dual field at rational points, number 1 | CAND-124 (proved by the Atlas) |
| Skyrmion from holonomy | the line holonomy, degree 1 | ATY-012, ATY-013 (proved by the Atlas) |
| one generation, anomaly cancellation | the 16 even labels of five bits | LNB-103, CAND-003 (proved by the Atlas) |
| charge conjugation 16 ↔ $\overline{16}$ | $x \mapsto x \oplus 11111$ | CAND-062 (proved by the Atlas) |
| spin connection, curvature 2-form | $R = d\omega + \tfrac14[\omega,\omega]$, forms as null generators | EQN-012, GRV-002 (proved by the Atlas) |
| Riemann = Ricci + Weyl | the kernel of the Bianchi map, with its Ricci rank | RSN-018, RSN-032 (proved by the Atlas) |
| Petrov classification | the Jordan type of $Q = E + iB$ | LNS-013d, CAND-089 (proved by the Atlas) |
| Einstein equation with $\Lambda$ | $E_a(c)$, $\Lambda = 3c$ | GRV-010, GRV-004d (proved by the Atlas) |
| the sign of $\Lambda$ | the square of one more generator | INP-049 (input), GRV-007 (proved by the Atlas) |
| Schwarzschild, Birkhoff | the Kerr–Schild class, null space span{M/ρ, (c/2)ρ²} | GRV-012 (proved by the Atlas) |
| Reissner–Nordström | the stress $-\tfrac12FaF$ closes $E_a$ at $s = \kappa Q^2/4$ | MAT-007 (proved by the Atlas), INP-050 (input) |
| Gauss–Bonnet and signature with a cone | the two pairings of the octahedron | ATY-020, ATY-021, ATY-023 (proved by the Atlas) |
| quantization, Hilbert space | out of reach | LNS-025, LNS-069 (open) |

## Sources, and how far each was read

**The rows.** Every id above was read with `node tools/proofs_todo.mjs --row ID` (its text, status, evidence and dependencies; the longest rows as far as the claims quoted here): the rows shown on the pages light, clock, cells, steps/dirac, steps/spin, steps/coupling, steps/ym, steps/matter, steps/grav1, steps/grav2 and steps/nullsurf, the statements of the theorems T1, T16 and T18 in content/theorems.json, and the candidates CAND-003, CAND-062, CAND-089, CAND-124 and CAND-126 of content/candidates.json.

**The checks and their logs.** Read in full: checks/selfcheck/proofs/logs/step_lines.log, check_T18.log, shifted_dirac.log (shd·OP, ORD, RET, SYM, OWN, COV, QNT, NUL, VAR, GAU, BIL, SER), skyrme_holonomy.log (sky·LAB, LINE, DEG, CIRC, TOR, TAIL, NUM), sm16_labels.log (sm16·A to E), maxwell_selfcheck.plain.log, and checks/selfcheck/gravity/logs/aty_matter_models.log (aty·matter), aty_cone_defects.log, c1_birkhoff.log, ym_solutions.log. Read in part: opened_4.log (opn·CUR and opn·WEYL), catw_lines.log (catl·B1, B2, B4), dirac_limits.log (the section heads, dlim·WIG, EXTRA, CPT), reruns/check_T16.log (its summary lines), c2_kerr.log (the horizon lines), ym_action.log (its first 28 lines). The scripts whose code is quoted, read at the functions quoted and in their docstrings: checks/selfcheck/steps15_17/bitcliff.py, checks/selfcheck/maxwell_selfcheck.py, checks/selfcheck/coupling_selfcheck.py, checks/selfcheck/yangmills_selfcheck.py, checks/selfcheck/gravity_selfcheck.py, checks/selfcheck/proofs/shifted_dirac.py and checks/selfcheck/proofs/sm16_labels.py. Every output printed in a try box was produced by running that code against the package; the lines of shifted_dirac.log and c1_birkhoff.log are quoted from the shipped logs.

**The pages of the Atlas.** #/rule, #/cells, #/clock, #/light, #/steps and its pages #/steps/dirac, #/steps/spin, #/steps/coupling, #/steps/ym, #/steps/matter, #/steps/grav1, #/steps/grav2, #/steps/nullsurf, #/steps/schuller and #/steps/baez, through their rows; the Atiyah page (reports/analyses/atiyah_lens.html): theme 8 of its map (self-duality, instantons and the Yang–Mills action) and its section "What the Atlas cannot reach", read in full, the other themes through their "Beyond" lines.

**The shipped tutorial.** "The bit rule and four college courses" (reports/html/bit_rule_tutorial.html): Part 0 with its worked example at $n = 2$, and Part E (E3, the oscillator; E4, the gravity log), read in full. It has no physics part; this page is that part.

**Recalled, not in the package.** J. D. Jackson, *Classical Electrodynamics* (Maxwell's equations, plane waves, invariants); D. Hestenes, *Space-Time Algebra*, and C. Doran and A. Lasenby, *Geometric Algebra for Physicists* (the forms $\nabla F = J$ and $\nabla\psi I\sigma_3 = m\psi\gamma_0$); S. Weinberg, *The Quantum Theory of Fields*, vol. 1 (little groups); A. Belavin, A. Polyakov, A. Schwarz and Yu. Tyupkin, "Pseudoparticle solutions of the Yang–Mills equations"; M. Atiyah and N. Manton, "Skyrmions from instantons"; M. Atiyah and P. Sutcliffe, "Skyrmions, instantons, mass and curvature"; M. Atiyah and G. Moore, "A shifted view of fundamental physics"; M. Atiyah and C. LeBrun, "Curvature, cones and characteristic numbers"; H. Georgi and S. Glashow, "Gauge theories without anomalies", and E. Witten, "An SU(2) anomaly"; J. Baez and J. Huerta, "The algebra of grand unified theories"; C. Misner, K. Thorne and J. Wheeler, *Gravitation*, and R. Wald, *General Relativity* (Cartan's structure equations, Birkhoff, Kerr); H. Stephani, D. Kramer, M. MacCallum, C. Hoenselaers and E. Herlt, *Exact Solutions of Einstein's Field Equations* (Petrov types). The Atiyah papers are read by the Atlas on its Atiyah page; here they are recalled through the rows that cite them.
