(function (id) {
  // reads a log of the Atlas's check scripts: the lines "ok [tag] ..." and "FAIL [tag] ...", the headings, a "fault:" line, and the last line
  const LINE = /^\s*(ok|FAIL)\b\s*(?:\[([^\]]+)\])?\s*(.*)$/;
  const PASS_LAST = [/^FAILS(?: \([^)]*\))?: none$/, /^\d+\/\d+ checks hold$/, /^ALL [A-Z ]+ PASS$/];
  const WRAP = /^EXIT \d+\s+SECONDS [\d.]+$/;                       // a line a runner adds after the script's own last line
  const SUMMARY = /(?:^|: )(\d+)(?: of |\/)(\d+) (?:assertions|claims|checks|core checks) hold/;
  function parse(text) {
    const lines = String(text).replace(/\r/g, '').split('\n'), tags = {}; let ok = 0, fail = 0, heads = 0, fault = null, last = '';
    for (const l of lines) {
      const m = LINE.exec(l);
      if (m) { const t = m[2] || '(no tag)'; tags[t] = tags[t] || { ok: 0, FAIL: 0 }; tags[t][m[1]]++; if (m[1] === 'ok') ok++; else fail++; }
      else if (/^(\d+[a-z]?\.|\(\d+\)|==|[A-Z][A-Z0-9-]*\d*\.)\s/.test(l)) heads++;
      const f = /^fault: (\S+)/.exec(l); if (f) fault = f[1];
      if (l.trim() && !WRAP.test(l.trim())) last = l.trim();
    }
    const sum = SUMMARY.exec(last);                                    // a script that prints no check lines, only a count: "N of M ... hold", "N/M ... hold"
    if (sum && ok + fail === 0) { ok = +sum[1]; fail = +sum[2] - +sum[1]; }
    const summed = PASS_LAST.some(re => re.test(last)) || (!!sum && +sum[1] === +sum[2]), failsLine = /^FAILS(?: \([^)]*\))?: \[/.test(last);
    let verdict;
    if (fault) verdict = fail > 0 || failsLine ? 'a fault run that ends with FAILS: the fault ' + fault + ' is seen' : 'a fault run that passes: the fault ' + fault + ' is NOT seen (a finding: say which quantity the script does not read)';
    else if (fail === 0 && summed) verdict = 'passes: no FAIL line and the last line sums up with none';
    else if (fail > 0 || failsLine) verdict = 'fails: ' + fail + ' FAIL line(s); the last line lists them';
    else verdict = 'no summary line: the run may have stopped early (read the end of the log)';
    return { ok, fail, heads, tags, fault, last, verdict };
  }
  // self-test: two runs of scripts/dirac_rest.py (the plain run and the run with --fault LEFTJ), cut to their check lines, with their counts
  const SAMPLES = {
    pass: '\n1. the rest solutions of nabla psi J = m psi g0 (series in t, exact on the labels)\n  ok   [bit] psi_0 = 2 R with R = (3 + 4 e12)/5 (5 + 12 e23)/13: psi_0 rev(psi_0) = rho = 4\n  ok   [bit] psi = psi_0 exp(-J m t), m = 3: the equation holds at every order t^0 ... t^7\n  ok   [bit] the even psi_0 that commute with g0 span 4 real dimensions: 1, e12, e13, e23 (the even Pauli part), each a solution\n  ok   [std] Dirac matrices: G_a G_b + G_b G_a = 2 eta_ab; the rest equation (G0 - 1) u = 0 has 4 real dimensions\n  ok   [bit==std] the two counts of rest solutions agree (4 = 4)\n  ok   [ctl] psi_0 = 1 + e01 (a boost part) is not a solution: the order t^0 fails\n\nchecks: 6 ok, 0 FAIL\nFAILS (DIRAC-REST): none\n',
    fault: 'fault: LEFTJ (a wrong version in the main lines; the run must end with FAILS)\n\n1. the rest solutions of nabla psi J = m psi g0 (series in t, exact on the labels)\n  ok   [bit] psi_0 = 2 R with R = (3 + 4 e12)/5 (5 + 12 e23)/13: psi_0 rev(psi_0) = rho = 4\n  FAIL [bit] psi = psi_0 exp(-J m t), m = 3: the equation holds at every order t^0 ... t^7\n  FAIL [bit] the even psi_0 that commute with g0 span 4 real dimensions: 1, e12, e13, e23 (the even Pauli part), each a solution\n  ok   [std] Dirac matrices: G_a G_b + G_b G_a = 2 eta_ab; the rest equation (G0 - 1) u = 0 has 4 real dimensions\n  ok   [bit==std] the two counts of rest solutions agree (4 = 4)\n  FAIL [ctl] psi_0 = 1 + e01 (a boost part) is not a solution: the order t^0 fails\n\nchecks: 3 ok, 3 FAIL\nFAILS (DIRAC-REST): [\'[bit] psi = psi_0 exp(-J m t), m = 3: the equation holds at every order t^0 ... t^7\']\n'
  };
  const EXPECT = { pass: [6, 0, 1, 'FAILS (DIRAC-REST): none'], fault: [3, 3, 1, null] };
  const selfTest = Object.entries(EXPECT).every(([k, [o, f, h, l]]) => { const r = parse(SAMPLES[k]); return r.ok === o && r.fail === f && r.heads === h && (l === null || r.last === l) && (k === 'fault') === !!r.fault; });
  if (typeof document === 'undefined') return { parse, SAMPLES, selfTest };
  const el = document.getElementById(id); if (!el) return;
  if (!selfTest) { el.textContent = 'self-test failed'; return; }
  el.innerHTML = '<div><button type="button" data-s="pass">a passing run</button> <button type="button" data-s="fault">a fault run</button> <button type="button" data-s="clear">empty</button></div>' +
    '<textarea class="lr-in" rows="8" spellcheck="false" aria-label="a log to read" style="width:100%;box-sizing:border-box;font:12px ui-monospace,Menlo,Consolas,monospace;margin:8px 0"></textarea>' +
    '<p class="widget__out lr-out" aria-live="polite"></p>';
  const ta = el.querySelector('.lr-in'), out = el.querySelector('.lr-out');
  function show() {
    const r = parse(ta.value), order = ['bit', 'std', 'std2', 'bit==std', 'ctl', 'cmp'];
    const tags = Object.keys(r.tags).sort((a, b) => (order.indexOf(a) + 1 || 99) - (order.indexOf(b) + 1 || 99));
    const rows = tags.map(t => '  ' + ('[' + t + ']').padEnd(12) + String(r.tags[t].ok).padStart(5) + ' ok ' + String(r.tags[t].FAIL).padStart(5) + ' FAIL');
    out.textContent = 'check lines: ' + (r.ok + r.fail) + ' (' + r.ok + ' ok, ' + r.fail + ' FAIL), headings: ' + r.heads + (r.fault ? ', fault: ' + r.fault : '') + '\n' +
      (rows.length ? rows.join('\n') + '\n' : '') + 'last line: ' + (r.last || '(none)') + '\nverdict: ' + r.verdict;
  }
  el.addEventListener('click', ev => { const b = ev.target.closest('button'); if (!b) return; ta.value = b.dataset.s === 'clear' ? '' : SAMPLES[b.dataset.s]; show(); });
  ta.addEventListener('input', show);
  ta.value = SAMPLES.fault; show();
})
