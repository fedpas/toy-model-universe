(function (id) {
  // the bit rule, as engines/bitrule.js (popcount, nPairs, reorderSign, sign), line for line
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  // self-test: ten products [squares, a, b, sign, label] computed by checks/researchers_checks/bitrule_A.py (scripts/test_widgets.mjs re-derives them)
  const STORED = [[[1, -1, -1, -1], 13, 6, 1, 11], [[1, -1, -1, -1], 6, 13, -1, 11], [[1, -1, -1, -1], 15, 15, -1, 0], [[1, 1], 1, 2, 1, 3], [[1, 1], 2, 1, -1, 3],
    [[-1, -1], 3, 3, -1, 0], [[0, 0], 1, 1, 0, 0], [[1, 1, -1, 0], 11, 14, 0, 5], [[-1, -1, -1, -1, -1], 31, 21, -1, 10], [[1, 1, 1, -1, -1, 0], 45, 54, 0, 27]];
  const selfTest = STORED.every(([e, a, b, s, m]) => sign(a, b, e) === s && (a ^ b) === m);
  const SUB = '₀₁₂₃₄₅₆₇₈₉';
  const blade = (m, n) => { const t = []; for (let i = 0; i < n; i++) if ((m >> i) & 1) t.push('e' + SUB[i + 1]); return t.length ? t.join('') : '1'; };
  const bits = (m, n) => { let s = ''; for (let i = n - 1; i >= 0; i--) s += (m >> i) & 1; return s; };
  const sq = e => (e > 0 ? '+1' : e < 0 ? '−1' : '0');
  /** the steps of e_a e_b: the pairs that swap, their count, the shared switches with their squares, the sign and the label */
  function steps(a, b, eps) {
    const n = eps.length, pairs = [];
    for (let i = 0; i < n; i++) if ((a >> i) & 1) for (let j = 0; j < i; j++) if ((b >> j) & 1) pairs.push([i, j]);
    const shared = []; for (let i = 0; i < n; i++) if (((a & b) >> i) & 1) shared.push(i);
    return { pairs, N: pairs.length, shared, s: sign(a, b, eps), label: a ^ b };
  }
  if (typeof document === 'undefined') return { popcount, nPairs, sign, steps, STORED, selfTest };
  const el = document.getElementById(id); if (!el) return;
  if (!selfTest) { el.textContent = 'self-test failed'; return; }
  const st = { n: 4, eps: [1, -1, -1, -1], a: 0b1101, b: 0b0110 };
  el.innerHTML = '<div class="pw-row"><label>switches n <select class="pw-n">' + [1, 2, 3, 4, 5, 6].map(k => '<option' + (k === 4 ? ' selected' : '') + '>' + k + '</option>').join('') + '</select></label>' +
    ' <button type="button" class="pw-cell" data-c="1,3">Cl(1,3)</button> <button type="button" class="pw-cell" data-c="3,0">Cl(3,0)</button> <button type="button" class="pw-cell" data-c="0,0,4">Λ (all 0)</button></div>' +
    '<div class="pw-row pw-sq"></div><div class="pw-row pw-a"></div><div class="pw-row pw-b"></div><p class="widget__out pw-out" aria-live="polite"></p>';
  const q = s => el.querySelector(s), out = q('.pw-out');
  const btn = (k, on, label, title) => '<button type="button" data-k="' + k + '" aria-pressed="' + on + '" title="' + title + '">' + label + '</button>';
  function draw() {
    const n = st.n;
    q('.pw-sq').innerHTML = '<label>squares</label>' + st.eps.map((e, i) => '<label>e' + SUB[i + 1] + '² <select data-i="' + i + '">' + [1, -1, 0].map(v => '<option value="' + v + '"' + (v === e ? ' selected' : '') + '>' + sq(v) + '</option>').join('') + '</select></label>').join('');
    q('.pw-a').innerHTML = '<label>a</label>' + [...Array(n)].map((_, i) => btn(i, !!((st.a >> i) & 1), 'e' + SUB[i + 1], 'switch ' + (i + 1) + ' of a')).join(' ');
    q('.pw-b').innerHTML = '<label>b</label>' + [...Array(n)].map((_, i) => btn(i, !!((st.b >> i) & 1), 'e' + SUB[i + 1], 'switch ' + (i + 1) + ' of b')).join(' ');
    const r = steps(st.a, st.b, st.eps);
    const lines = [];
    lines.push('e_a e_b = ' + blade(st.a, n) + ' · ' + blade(st.b, n) + '      a = ' + bits(st.a, n) + ', b = ' + bits(st.b, n) + ' (e₁ is the right-hand bit)');
    lines.push('1  label:  a XOR b = ' + bits(st.a, n) + ' XOR ' + bits(st.b, n) + ' = ' + bits(r.label, n) + '  →  ' + blade(r.label, n));
    lines.push('2  swaps:  pairs (i on in a, j on in b, j < i): ' + (r.pairs.length ? r.pairs.map(([i, j]) => '(e' + SUB[i + 1] + ', e' + SUB[j + 1] + ')').join(' ') : 'none') + '  →  N = ' + r.N + ', (−1)^N = ' + (r.N & 1 ? '−1' : '+1'));
    lines.push('3  shared: a AND b = ' + bits(st.a & st.b, n) + (r.shared.length ? '  →  ' + r.shared.map(i => 'e' + SUB[i + 1] + '² = ' + sq(st.eps[i])).join(', ') : '  →  none'));
    lines.push('4  sign:   ' + (r.N & 1 ? '−1' : '+1') + (r.shared.length ? ' · ' + r.shared.map(i => sq(st.eps[i])).join(' · ') : '') + ' = ' + sq(r.s));
    lines.push(r.s === 0 ? 'result:  ' + blade(st.a, n) + ' · ' + blade(st.b, n) + ' = 0   (a shared switch has square 0)' : 'result:  ' + blade(st.a, n) + ' · ' + blade(st.b, n) + ' = ' + (r.s < 0 ? '−' : '+') + blade(r.label, n));
    out.textContent = lines.join('\n');
  }
  el.addEventListener('click', ev => {
    const t = ev.target.closest('button'); if (!t) return;
    if (t.classList.contains('pw-cell')) { const [p, qq, rr = 0] = t.dataset.c.split(',').map(Number); st.n = p + qq + rr; st.eps = [...Array(p).fill(1), ...Array(qq).fill(-1), ...Array(rr).fill(0)]; st.a &= (1 << st.n) - 1; st.b &= (1 << st.n) - 1; q('.pw-n').value = String(st.n); draw(); return; }
    const k = +t.dataset.k, row = t.parentElement.classList.contains('pw-a') ? 'a' : 'b'; st[row] ^= 1 << k; draw();
  });
  el.addEventListener('change', ev => {
    const t = ev.target;
    if (t.classList.contains('pw-n')) { const n = +t.value; st.eps = [...Array(n)].map((_, i) => (i < st.eps.length ? st.eps[i] : 1)); st.n = n; st.a &= (1 << n) - 1; st.b &= (1 << n) - 1; }
    else if (t.dataset.i != null) st.eps[+t.dataset.i] = +t.value;
    draw();
  });
  draw();
})
