#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tests/chains.test.mjs — the chains of round 14 (docs/round14/STORY_ROUND.md §2, §3, §5; D52–D60; owner B1), on the merged tables after `npm run content`
// and on the fixture tests/chains/fixture/ (three chains on real rows of rule · ideas and matter/model · axes, a lead story row, good and broken spans;
// synthetic tables for the extraction). In this order:
//   A  extraction  tools/story/extract_chains.mjs: the fixture's eleven cases (a line, a fork, a cycle, a ladder, twins, a singleton attached by a shared
//                  parent, a hub that links nothing, a shared input that links nothing, a contradicts pair kept apart, a directed cycle broken, a long
//                  path cut) give the chains written by hand; the four pilot drafts are SPINE.md §4's mechanical drafts; the CLI run twice gives the same
//                  bytes
//   B  pilot       content/chains/pilot/chains.json: the 17 chains of SPINE.md §4 as composed (positions, mentions, links), every derived field (links,
//                  shape, joins) what the tools compute from the positions; the departures recorded are those --diff lists (a note when they drift)
//   C  merged      on the merged tables: V1–V10 again (tools/merge_chains.mjs on the merged rows, texts and pages: no error); content/chains.json is that
//                  merge's table; each section's chains are its chains in order; every chain's rows exist and sit on its section (told positions with
//                  role result or detail); every storied chain's spans cover its positions in order and are text records; the book is consistent (the
//                  base of tools/merge_story.mjs has no section field chains); no home moved against that base; every accepted entry of the labelling
//                  overlays of depends (content/story/depends_*.json, round 15) holds in rows.json and the base restores the original depends
//   D  fixture     the fixture merged in memory in place of the pilot: three storied chains, eleven spans keyed with their chain, the lead accepted
//                  (V4, V9); a second merge gives the same tables; and the whole pipeline (check, merges, build) run twice on a copy of the repository's
//                  content with the fixture gives the same bytes (D59); there, merge_chains --retire moves a translator draft of a row told only in a
//                  storied chain to content/chains/retired.json and the next run drops it from texts.json (D54), a second --retire moving nothing;
//                  on a small table of its own, a page's hero without a short learner text keeps its full draft and one with a short text does not (D66)
//   E  checker    tools/check_learner_texts.mjs on the fixture: the good spans pass R1–R13 and C1–C11, the broken ones fail with the rules the fixture
//                  names; --explain <chain id> prints the worksheet of every position
//   F  rendered    (when src/components/Chain.jsx exists) the pilot pages, shifted and matter, and the fixture's pages, rendered server-side at phys/math ×
//                  research/learner and under the lenses cat, geo and furey: at research level the data-row order of each ol.chain__list is the chain's
//                  positions (no sorting), each connective the word of its link, a mention the compact statement with its "Told in" link; at learner
//                  level a storied chain is one paragraph of the lead's learner text and the spans in order, an unstoried one the rows' learner texts
//                  in chain order (every chain of the tables is storied from 2.15.0: the fallback is drawn on the fixture without the spans of one chain)
//   G  mutants     ten, each caught: a span missing, two out of order, an unearned "So", a status word dropped (the checker); a mention not told on the
//                  page, a link without an edge, a told row not placed, a lead that is not a story row (the merge); a moved home (merge_story); a chain
//                  sorted by kind at research level in mathematics (the order check of F)
// Usage: node tests/chains.test.mjs          (exit 1 on a failure; the offline modules from NODE_MODULES, default /opt/npm-tools/node_modules)
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as X from '../tools/story/extract_chains.mjs';
import { mergeChains, readChainOverlay, retire } from '../tools/merge_chains.mjs';
import { mergeStory, baseTables, readDependsOverlays } from '../tools/merge_story.mjs';
import * as LC from '../tools/check_learner_texts.mjs';
import { testBlock, testRow } from '../tools/migrate/story_from_v15.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const C = path.join(ROOT, 'content'), FX = path.join(ROOT, 'tests', 'chains', 'fixture');
const NM = process.env.NODE_MODULES || '/opt/npm-tools/node_modules';
const readJSON = (f, fb) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fb);
const J = n => readJSON(path.join(FX, n), null);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

let checks = 0, part = '';
const failures = [], notes = [];
const ok = (cond, msg) => { checks++; if (!cond && failures.length < 300) failures.push(`${part} ${msg}`); return !!cond; };
const heading = t => { part = t.split(' ')[0]; console.log(t); };

const T = X.loadTables(ROOT);
const rows = readJSON(path.join(C, 'rows.json'), []), texts = readJSON(path.join(C, 'texts.json'), []), pages = readJSON(path.join(C, 'pages.json'), []);
const status = readJSON(path.join(C, 'derived', 'status.json'), {}), table = readJSON(path.join(C, 'chains.json'), null);
const rowById = new Map(rows.map(r => [r.id, r]));
const fixture = { chains: J('chains.json'), rows: J('rows.json'), texts: J('texts.json'), learner: J('spans.good.json') };
const tb = { testBlock, testRow };
const SEQ = (rows2, links, twins = {}, mention = []) => X.fmtSeq(rows2, links, twins, mention).replace(/—(cycle|equiv|continues)←/g, '—$1');   // SPINE.md writes an undirected relation without its side

// ================================================================================================================ A. the extraction
heading('A extraction — the fixture, the pilot drafts of SPINE.md §4, determinism');
{
  const fx = J('extract.json');
  const FT = X.makeTables(fx);
  for (const [sec, want] of Object.entries(fx.expect)) {
    const r = X.extractSection(FT, 'fx', sec);
    const got = { chains: r.chains.map(c => ({ rows: c.rows, links: c.links, shape: c.shape, ...(Object.keys(c.twins).length ? { twins: c.twins } : {}), ...(c.attached.length ? { attached: c.attached.map(a => a.id) } : {}) })),
      side: r.side, ...(r.kept.length ? { kept: r.kept } : {}), ...(r.cycles.length ? { cycles: r.cycles } : {}) };
    ok(same(got, want), `the fixture case ${sec}: ${JSON.stringify(got)} — expected ${JSON.stringify(want)}`);
  }
  ok(Object.keys(fx.expect).length === 11, 'the fixture holds the eleven cases');
  // the mechanical drafts of SPINE.md §4 (MAX = 8, the pilot groups); rule · ideas on the tables labelled by A62 (round 15: GEN-002 on GEN-001 and
  // GEN-007 on GEN-003 derives, GEN-006 on GEN-004 instance; docs/round15/A62_APPLIED.md), the other three as SPINE.md §4 drew them; with the rows of
  // pass 12a (round 15, docs/round15/PROOFS_ROUND12A.md): GEN-033 (on GEN-019, GEN-026, GEN-030) and GEN-034 (on GEN-030, GEN-019, GEN-026) on rule ·
  // ideas and cells · cards, FUR-041 (on FUR-035, ATY-028, …) on steps/baez · bz-generation; the composed chains of B are unchanged, the four rows side
  // notes, and the pilot's `extracted` records what --diff lists on these tables
  const DRAFTS = {
    'rule|ideas|GEN': ['GEN-001 —derives→ GEN-002',
      'GEN-010 —derives→ GEN-013 —derives→ GEN-016 —equiv·GEN-013→ GEN-017 —derives→ GEN-018 —derives→ GEN-021 —derives→ GEN-023 —derives→ GEN-026 —equiv·GEN-017→ GEN-031 —derives·GEN-026→ GEN-033',
      'GEN-003 —derives→ GEN-004 —derives·GEN-003→ GEN-005 —derives→ GEN-006 —derives·GEN-003→ GEN-007 —derives·GEN-003→ GEN-015 —derives→ GEN-020 —derives→ GEN-030 —derives→ GEN-034',
      'GEN-009 —derives→ GEN-014 —derives→ GEN-019 —derives→ GEN-024 —equiv·GEN-019→ GEN-025 —derives→ GEN-029 —derives·GEN-024→ GEN-032',
      'GEN-022', 'GEN-027', 'GEN-028', 'side GEN-008'],
    'cells|cards|GEN': ['GEN-012 —order→ GEN-016 —derives·GEN-012→ GEN-021 —derives→ GEN-022 —derives·GEN-021→ GEN-023 —derives→ GEN-026 —derives·GEN-021→ GEN-027 —equiv·GEN-023→ GEN-028 —derives·GEN-026→ GEN-033 attached GEN-031',
      'GEN-019 —derives→ GEN-024 —equiv·GEN-019→ GEN-025 —derives→ GEN-029 —derives·GEN-024→ GEN-032', 'GEN-020 —derives→ GEN-030 —derives→ GEN-034', 'side GEN-011'],
    'steps/coupling|eq-coupling|ATY,FUR': ['FUR-013 —derives→ FUR-024 —derives→ FUR-025 —derives·FUR-024→ FUR-026 —derives·FUR-025→ FUR-036 —derives·FUR-024→ FUR-037',
      'ATY-004 —derives→ ATY-005 —derives→ ATY-006 —derives·ATY-005→ ATY-007 —derives·ATY-004→ ATY-008 —derives·ATY-005→ ATY-011 —instance→ ATY-041 —derives→ ATY-038 —derives→ ATY-043 —derives·ATY-041→ ATY-046',
      'ATY-039 —derives→ ATY-042 —derives→ ATY-044 —derives·ATY-039→ ATY-045 —instance→ ATY-047', 'ATY-009 —derives→ ATY-037 —derives→ ATY-040', 'side '],
    'steps/baez|bz-generation|ATY,FUR,CAND': ['FUR-011 —derives→ FUR-012 —derives→ FUR-020 —derives·FUR-012→ FUR-021 —derives·FUR-020→ FUR-023 —derives→ FUR-030 —derives→ FUR-031 —derives·FUR-021→ FUR-033 —derives·FUR-020→ FUR-034',
      'CAND-003 —derives→ ATY-028 —derives→ FUR-035 —derives→ FUR-041', 'CAND-019 —derives→ FUR-022 —derives→ FUR-029', 'side CAND-071, CAND-062'],
  };
  for (const [k, want] of Object.entries(DRAFTS)) {
    const [route, sec, groups] = k.split('|');
    const r = X.extractSection(T, route, sec, { groups: new Set(groups.split(',')) });
    const got = [...r.chains.map(c => SEQ(c.rows, c.links, c.twins) + (c.attached.length ? ` attached ${c.attached.map(a => a.id).join(', ')}` : '')), `side ${r.side.join(', ')}`];
    ok(same(got, want), `${route} · ${sec}: the mechanical draft is SPINE.md §4's\n      got  ${got.join('\n           ')}`);
  }
  // determinism: the CLI twice, the same bytes
  const run = a => spawnSync(process.execPath, [path.join(ROOT, 'tools/story/extract_chains.mjs'), ...a], { cwd: ROOT, encoding: 'utf8' }).stdout;
  for (const a of [['--page', 'steps/baez', '--json'], ['--counts']]) { const x = run(a), y = run(a); ok(x.length > 100 && x === y, `extract_chains ${a.join(' ')} gives the same bytes twice`); }
  const counts = X.countsTable(T).total;
  notes.push(`A the extraction of every story page: ${counts.pages} pages, ${counts.sections} sections, ${counts.rows} rows, ${counts.chains} chains holding ${counts.inChains} (+ ${counts.attached} attached), ${counts.side} side notes, ${counts.singles} singletons (docs/round14/B1_NOTES.md explains the differences from SPINE.md §6.1)`);
}

// ================================================================================================================ B. the pilot
heading('B pilot — content/chains/pilot/chains.json as SPINE.md §4 composes it');
const pilot = readJSON(path.join(C, 'chains', 'pilot', 'chains.json'), []);
{
  const COMPOSED = {
    'rule.ideas.genesis': 'GEN-001 —derives→ GEN-002 —order→ GEN-003 —derives→ GEN-004 —derives·GEN-003→ GEN-005 —derives→ GEN-006 —derives·GEN-003→ GEN-007 —order→ GEN-008 —order→ GEN-009',   // links 1 and 6 re-linked on A62's edges (round 15)
    'rule.ideas.blocks': 'GEN-010 —derives→ GEN-013 —equiv→ GEN-017 —equiv→ GEN-031 —derives·GEN-017→ GEN-018',
    'rule.ideas.car': '(GEN-003) —derives→ GEN-015 —derives→ GEN-020',
    'rule.ideas.null': 'GEN-021 —derives→ GEN-022 —derives·GEN-021→ GEN-023 —equiv→ GEN-028 —derives·GEN-021→ GEN-027',
    'rule.ideas.limit': 'GEN-014 —derives→ GEN-019 —derives→ GEN-024 —derives→ GEN-032 —derives·GEN-019→ GEN-026 —equiv→ GEN-030 —cycle→ GEN-016',
    'rule.ideas.routes': 'GEN-025 —derives→ GEN-029',
    'cells.cards.null': 'GEN-012 —derives→ GEN-021 —derives→ GEN-022 —derives·GEN-021→ GEN-023 —equiv→ GEN-028 —derives·GEN-021→ GEN-027',
    'cells.cards.limit': 'GEN-020 —order→ GEN-019 —derives→ GEN-024 —derives→ GEN-032 —derives·GEN-019→ GEN-026 —equiv→ GEN-030 —cycle→ GEN-016',
    'cells.cards.routes': 'GEN-025 —derives→ GEN-029',
    'steps-coupling.eq-coupling.shift-waves': 'ATY-004 —derives→ ATY-005 —derives→ ATY-009 —derives·ATY-005→ ATY-006 —derives·ATY-005→ ATY-007 —derives·ATY-004→ ATY-008 —derives·ATY-005→ ATY-011',
    'steps-coupling.eq-coupling.shift-energy': 'ATY-037 —order→ ATY-041 —derives→ ATY-038 —derives→ ATY-039 —derives·ATY-038→ ATY-040',
    'steps-coupling.eq-coupling.shift-tensor': 'ATY-042 —derives→ ATY-043 —derives·ATY-042→ ATY-044',
    'steps-coupling.eq-coupling.off-modes': '(ATY-041) —derives→ ATY-045 —derives·ATY-041→ ATY-046 —derives→ ATY-047',
    'steps-coupling.eq-coupling.fibre-mass': 'FUR-013 —derives→ FUR-024 —derives→ FUR-025 —derives·FUR-024→ FUR-026 —derives·FUR-025→ FUR-036 —derives·FUR-024→ FUR-037',
    'steps-baez.bz-generation.weights': 'FUR-011 —derives→ FUR-012 —derives→ FUR-020 —derives·FUR-012→ FUR-021 —derives·FUR-020→ FUR-023 —derives·FUR-020→ FUR-034',
    'steps-baez.bz-generation.no-mass': 'CAND-003 —derives→ ATY-028 —derives→ FUR-035',
    'steps-baez.bz-generation.fock': 'CAND-019 —derives→ FUR-022 —derives→ FUR-029 —derives→ FUR-030 —derives→ FUR-031 —order→ CAND-071 —derives·FUR-022→ FUR-033',
  };
  const SHAPES = { 'rule.ideas.genesis': 'ladder', 'rule.ideas.limit': 'cycle', 'cells.cards.limit': 'cycle', 'rule.ideas.car': 'line', 'rule.ideas.routes': 'line', 'cells.cards.routes': 'line', 'steps-baez.bz-generation.no-mass': 'line' };
  ok(same(pilot.map(c => c.id).sort(), Object.keys(COMPOSED).sort()), `the pilot holds the 17 chains of SPINE.md §4 (${pilot.length})`);
  for (const c of pilot) {
    if (!ok(COMPOSED[c.id], `${c.id} is not a chain of SPINE.md §4`)) continue;
    ok(SEQ(c.rows, c.links, c.twins, c.mention) === COMPOSED[c.id], `${c.id}: ${SEQ(c.rows, c.links, c.twins, c.mention)} — SPINE.md §4 composes ${COMPOSED[c.id]}`);
    ok(c.shape === (SHAPES[c.id] || 'fork'), `${c.id}: shape ${c.shape}, SPINE.md §4 says ${SHAPES[c.id] || 'fork'}`);
    const re = X.chainRecord(T, { ...c, contrasts: Object.fromEntries((c.links || []).map((l, i) => [c.rows[i + 1], l.rel === 'contrasts' ? l.note : null]).filter(([, n]) => n)) });
    ok(same(re.links, c.links) && re.shape === c.shape, `${c.id}: its links and shape are what the tables give its positions`);
    ok(c.story === 'none' && c.lead === null && typeof c.title.phys === 'string' && typeof c.title.math === 'string' && typeof c.title.learner === 'string', `${c.id}: story none, no lead, three titles`);
  }
  const js = X.joinsOf(T, pilot);
  for (const c of pilot) ok(same(js.get(c.id), c.joins), `${c.id}: its joins are the edges from the rows told in earlier chains of ${c.page}`);
  const d = X.diffChains(T, pilot);
  const drift = pilot.filter(c => { const x = d.get(c.id); return !x || x.component !== c.extracted.component || !same(x.departures, c.extracted.departures); });
  if (drift.length) notes.push(`B the departures recorded for ${drift.map(c => c.id).join(', ')} differ from what --diff lists now (the tables moved since the composition: node tools/story/extract_chains.mjs --diff content/chains/pilot/chains.json)`);
  else notes.push(`B the departures of the 17 pilot chains are those --diff lists (${pilot.reduce((n, c) => n + c.extracted.departures.length, 0)} in all)`);
}

// ================================================================================================================ C. the merged tables
heading('C merged — V1–V10 on the merged tables, the table, the section fields, the placements, the book, the homes');
const ids0 = readJSON(path.join(C, 'story', 'ids.json'), {}), pending0 = readJSON(path.join(C, 'story', 'pending.json'), []);
const reserved = new Set([...Object.values(ids0), ...pending0.map(p => p && p.id).filter(Boolean)]);
{
  ok(Array.isArray(table), 'content/chains.json is a table (npm run content writes it)');
  const ov = readChainOverlay();
  const bare = pages.map(p => ({ ...p, sections: (p.sections || []).map(s => { const { chains, ...rest } = s; return rest; }) }));
  const m = mergeChains({ rows, texts, pages: bare, status, runs: readJSON(path.join(C, 'check_runs.json'), []), reserved, r14: new Set(ov.rows.map(x => x.rec && x.rec.id)) }, ov);
  ok(!m.errors.length, `V1–V10 hold on the merged tables${m.errors.length ? ': ' + m.errors.slice(0, 6).join(' | ') : ''}`);
  ok(same(m.chains, table), 'content/chains.json is the table the merge computes from the owners\' files and the merged tables');
  const secChains = new Map(); for (const p of pages) for (const s of p.sections || []) if (s.chains) secChains.set(`${p.route}|${s.id}`, s.chains);
  const want = new Map(); for (const c of table || []) { const k = `${c.page}|${c.section}`; want.set(k, [...(want.get(k) || []), c]); }
  for (const [k, list] of want) ok(same(secChains.get(k), [...list].sort((a, b) => a.order - b.order).map(c => c.id)), `${k.replace('|', ' · ')}: its field chains lists its chains in order`);
  for (const k of secChains.keys()) ok(want.has(k), `${k.replace('|', ' · ')}: a field chains without a chain of content/chains.json`);
  for (const c of table || []) {
    for (const id of [...c.rows, ...Object.values(c.twins || {})]) ok(rowById.has(id), `${c.id}: ${id} is a row`);
    for (const id of X.toldOf(c)) ok((rowById.get(id) || { shownOn: [] }).shownOn.some(so => so.page === c.page && so.section === c.section && (so.role === 'result' || so.role === 'detail')), `${c.id}: the told position ${id} sits on ${c.page} · ${c.section}`);
    const spans = texts.filter(t => t.chain === c.id);
    if (c.story === 'none') { ok(!spans.length, `${c.id}: an unstoried chain has no span (V10: no partial story)`); continue; }
    c.rows.forEach((p, i) => ok(spans.some(t => t.row === p && t.span === i + 1 && t.register === 'span' && t.level === 'learner'), `${c.id}: span ${i + 1} of ${p} is a text record`));
  }
  for (const t of texts.filter(t => t.chain != null)) { const c = (table || []).find(x => x.id === t.chain); ok(c && (c.rows[t.span - 1] === t.row || (c.twins || {})[c.rows[t.span - 1]] === t.row), `the span ${t.row} · ${t.chain} · ${t.span} is that position of its chain`); }
  // the book: what the merge wrote is restored by baseTables — no section field chains, no span — and no home moved against that base
  const base = baseTables();
  ok(base.pages.every(p => (p.sections || []).every(s => !('chains' in s))), 'the base of merge_story (its book restored) has no section field chains: every field chains is in content/story/merged.json');
  ok(base.texts.every(t => t.chain == null), 'the base has no span: every span is in the book');
  const renames = (readJSON(path.join(C, 'story', 'landing.json'), {}).routes) || {};
  const homeOf = r => { const s = [...(r.shownOn || [])].map((so, i) => ({ so, i })).sort((a, b) => (a.so.order ?? 0) - (b.so.order ?? 0) || a.i - b.i)[0]; return s ? s.so.page : null; };
  let moved = 0; for (const b of base.rows) { const r = rowById.get(b.id); if (!r) continue; const h = homeOf(b); if ((h in renames ? renames[h] : h) !== homeOf(r)) moved++; }
  ok(moved === 0, `no home moved against the base (${moved} moved)`);
  // the labelling overlays of depends (round 15, A62; merge_story step 0): every accepted entry holds in the merged rows, and the book keeps the original
  // depends of every row they changed, which the base restores (a re-migration keeps the pass)
  const dov = readDependsOverlays(), accepted = dov.entries.filter(({ e }) => e && e.verdict === 'accept');
  const hasDep = (id, d, rel) => ((rowById.get(id) || {}).depends || []).some(x => x.id === d && x.rel === rel);
  for (const { e, at } of accepted) {
    const op = e.op || 'add';
    ok(op === 'add' ? hasDep(e.row, e.id, e.rel) : op === 'drop' ? !hasDep(e.row, e.id, e.rel) : op === 'set-cycle' ? hasDep(e.row, e.id, 'cycle') && !hasDep(e.row, e.id, e.rel) : hasDep(e.id, e.row, e.rel), `${at}: the accepted ${op} holds in rows.json`);
  }
  const bk = readJSON(path.join(C, 'story', 'merged.json'), {}), baseById = new Map(base.rows.map(r => [r.id, r]));
  ok(!dov.errors.length && Object.entries(bk.depends || {}).every(([id, x]) => same((baseById.get(id) || {}).depends, x.orig)), 'the base restores the original depends of every row the labelling overlays changed (book.depends)');
  notes.push(`C the labelling overlays: ${accepted.length} accepted entries hold in rows.json; the book records ${Object.keys(bk.depends || {}).length} rows' depends`);
  notes.push(`C ${(table || []).length} chains on ${new Set((table || []).map(c => c.page)).size} pages, ${(table || []).filter(c => c.story !== 'none').length} storied, ${texts.filter(t => t.chain != null).length} spans; ${base.rows.length} homes of the base kept`);
}

// ================================================================================================================ D. the fixture merged
heading('D fixture — merged in memory, twice; the pipeline twice on a copy');
let fres = null;
{
  fres = mergeStory({ chains: fixture });
  ok(!fres.errors.length, `the fixture merges${fres.errors.length ? ': ' + fres.errors.slice(0, 4).join(' | ') : ''}`);
  ok(fres.chains.length === 3 && fres.chains.every(c => c.story === 'draft'), `three storied chains (${fres.chains.map(c => `${c.id} ${c.story}`).join(', ')})`);
  const sp = fres.texts.filter(t => t.chain != null);
  ok(sp.length === 11 && sp.every(t => t.register === 'span' && Number.isInteger(t.span)), `eleven spans in texts.json, each with its chain and position (${sp.length})`);
  ok(sp.filter(t => t.row === 'GEN-003').length === 2, 'GEN-003 has a span in each of its two chains (the text key holds the chain)');
  const lead = fres.rows.find(r => r.id === 'GEN-751');
  ok(lead && lead.shownOn.length === 1 && lead.shownOn[0].role === 'chain' && fres.chains.find(c => c.id === 'rule.ideas.fixture-core').lead === 'GEN-751', 'the lead story row GEN-751 is merged, of role chain, leading its chain');
  ok(!fres.rows.some(r => r.id === 'GEN-751') || fres.book.rows.includes('GEN-751'), 'the round-14 row is in the book');
  const again = mergeStory({ tables: { rows: fres.rows, texts: fres.texts, pages: fres.pages, book: fres.book }, chains: fixture });
  for (const k of ['rows', 'texts', 'pages', 'book', 'chains']) ok(same(fres[k], again[k]), `a second merge gives the same ${k}`);
  // the whole pipeline, twice, on a copy of content/ and tools/ with the fixture in place of the pilot (D59: one merge, one book)
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'one-rule-chains-'));
  try {
    fs.cpSync(C, path.join(tmp, 'content'), { recursive: true }); fs.cpSync(path.join(ROOT, 'tools'), path.join(tmp, 'tools'), { recursive: true }); fs.mkdirSync(path.join(tmp, 'docs'));
    fs.rmSync(path.join(tmp, 'content', 'chains', 'pilot'), { recursive: true, force: true });
    // the storyteller's files of the real pages leave the copy too (their spans name the pilot's chains, which the copy drops): the fixture's spans alone
    fs.rmSync(path.join(tmp, 'content', 'chains', 'learner'), { recursive: true, force: true });
    const fxDir = path.join(tmp, 'content', 'chains', 'fixture'); fs.mkdirSync(fxDir, { recursive: true }); fs.mkdirSync(path.join(tmp, 'content', 'chains', 'learner'), { recursive: true });
    for (const n of ['chains', 'rows', 'texts']) fs.copyFileSync(path.join(FX, `${n}.json`), path.join(fxDir, `${n}.json`));
    fs.copyFileSync(path.join(FX, 'spans.good.json'), path.join(tmp, 'content', 'chains', 'learner', 'fixture.json'));
    const STEPS = ['check_learner_texts.mjs', 'merge_chains.mjs --check', 'merge_learner_texts.mjs', 'merge_explore.mjs', 'merge_physics.mjs', 'merge_story.mjs', 'build_content.mjs'];
    const OUT = ['content/rows.json', 'content/texts.json', 'content/pages.json', 'content/chains.json', 'content/story/merged.json', 'content/derived/status.json', 'docs/COVERAGE.md'];
    const pipeline = () => { for (const s of STEPS) { const [f, ...a] = s.split(' '); const r = spawnSync(process.execPath, [path.join(tmp, 'tools', f), ...a], { cwd: tmp, encoding: 'utf8' }); if (r.status !== 0) return `${s}: exit ${r.status} ${String(r.stdout).split('\n').slice(-4).join(' ')}`; } return null; };
    const e1 = pipeline(); ok(!e1, `the pipeline runs on the copy with the fixture${e1 ? ': ' + e1 : ''}`);
    const first = OUT.map(f => fs.readFileSync(path.join(tmp, f), 'utf8'));
    const e2 = pipeline(); ok(!e2, `the pipeline runs a second time${e2 ? ': ' + e2 : ''}`);
    OUT.forEach((f, i) => ok(fs.readFileSync(path.join(tmp, f), 'utf8') === first[i], `the second run writes the same bytes: ${f}`));
    const tt = JSON.parse(first[1]); ok(tt.filter(t => t.chain != null).length === 11, 'the pipeline keeps the eleven spans (every merge keys a span with its chain: merge_explore, merge_physics, merge_learner_texts, merge_story)');
    // D54's retirement: a translator draft of GEN-004 (told only in the storied chain fixture-core) leaves content/texts_learner*.json for
    // content/chains/retired.json with its wave, and texts.json at the next run; a second --retire moves nothing
    const draft = { row: 'GEN-004', lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full', body: 'Pair plus spectator: one fused pair and one switch of square zero; in a fixed basis there are 3 choices of pair and 2 sign orders, and the lone switch has no partner, so no sign: it is not yet a state, a charge or a motion.', status: 'draft', source: 'translator:learner@2026-10-17', termsUsed: [], keptNumbers: ['2', '3'] };
    fs.writeFileSync(path.join(tmp, 'content', 'texts_learner_zz_retire.json'), JSON.stringify([draft], null, 1) + '\n');
    const e3 = pipeline(); ok(!e3, `the pipeline runs with a draft of GEN-004${e3 ? ': ' + e3 : ''}`);
    const has = () => JSON.parse(fs.readFileSync(path.join(tmp, 'content', 'texts.json'), 'utf8')).some(t => t.row === 'GEN-004' && t.level === 'learner' && t.source === draft.source && t.chain == null);
    ok(has(), 'the draft of GEN-004 is merged into texts.json');
    const rt = spawnSync(process.execPath, [path.join(tmp, 'tools', 'merge_chains.mjs'), '--retire', 'test-wave'], { cwd: tmp, encoding: 'utf8' });
    const retired = readJSON(path.join(tmp, 'content', 'chains', 'retired.json'), []);
    ok(rt.status === 0 && retired.some(r => r.row === 'GEN-004' && r.wave === 'test-wave' && r.from === 'content/texts_learner_zz_retire.json' && r.body === draft.body), `--retire moves the draft of GEN-004 to content/chains/retired.json with its wave (${String(rt.stdout).trim()})`);
    ok(!readJSON(path.join(tmp, 'content', 'texts_learner_zz_retire.json'), [null]).length, 'the draft leaves its texts_learner file');
    const e4 = pipeline(); ok(!e4 && !has(), `the next run drops the retired draft from texts.json${e4 ? ': ' + e4 : ''}`);
    const rt2 = spawnSync(process.execPath, [path.join(tmp, 'tools', 'merge_chains.mjs'), '--retire', 'test-wave'], { cwd: tmp, encoding: 'utf8' });
    ok(rt2.status === 0 && readJSON(path.join(tmp, 'content', 'chains', 'retired.json'), []).length === retired.length, '--retire a second time moves nothing (idempotent)');
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
  // D66 (round 15): a page's hero without a short learner text keeps its full draft (the page top draws the hero's short register, else its full text);
  // with a short learner text its full draft retires as any told row's. On a small table of its own: two rows told in one storied chain, one the hero
  const hx = fs.mkdtempSync(path.join(os.tmpdir(), 'one-rule-retire-'));
  try {
    const W2 = (n, d) => { fs.mkdirSync(path.dirname(path.join(hx, n)), { recursive: true }); fs.writeFileSync(path.join(hx, n), JSON.stringify(d, null, 1) + '\n'); };
    const at = (id, order) => ({ id, shownOn: [{ page: 'p', section: 's', order, role: 'result' }] });
    const dr = id => ({ row: id, lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full', body: `The words of ${id}.`, status: 'draft', source: 'translator:learner@2026-10-10', termsUsed: [], keptNumbers: [] });
    const run = (shortOf) => {
      W2('chains.json', [{ id: 'p.s.c', page: 'p', section: 's', order: 1, rows: ['HX-001', 'HX-002'], mention: [], twins: {}, story: 'draft' }]);
      W2('rows.json', [at('HX-001', 1), at('HX-002', 2)]);
      W2('pages.json', [{ route: 'p', hero: { row: 'HX-001', figure: null }, sections: [{ id: 's' }] }]);
      W2('texts.json', shortOf ? [{ ...dr(shortOf), register: 'short', body: 'Short words.' }] : []);
      W2('texts_learner_hx.json', [dr('HX-001'), dr('HX-002')]);
      W2('chains/retired.json', []);
      return { r: retire('test-wave', { content: hx }), book: readJSON(path.join(hx, 'chains', 'retired.json'), []).map(x => x.row), left: readJSON(path.join(hx, 'texts_learner_hx.json'), []).map(x => x.row) };
    };
    const a = run(null);
    ok(same(a.book, ['HX-002']) && same(a.left, ['HX-001']) && same(a.r.heroes, ['HX-001']), `D66: the hero without a short learner text keeps its full draft, the other told row's retires (book ${a.book.join(', ')}; kept ${a.left.join(', ')})`);
    const b = run('HX-001');
    ok(same(b.book, ['HX-001', 'HX-002']) && !b.left.length && !b.r.heroes.length, `D66: with a short learner text the hero's full draft retires too (book ${b.book.join(', ')})`);
  } finally { fs.rmSync(hx, { recursive: true, force: true }); }
}

// ================================================================================================================ E. the checker
heading('E checker — the fixture\'s good and broken spans; the worksheet');
const Tl = LC.loadTables({ chains: fixture.chains });
Tl.rowById.set('GEN-751', fixture.rows[0]); Tl.research.set('GEN-751', fixture.texts[0].body);
const checkAll = recs => [...LC.check(recs, Tl), ...LC.checkChains(recs, Tl, tb)];
{
  const g = checkAll(fixture.learner);
  ok(!g.length, `the good spans pass R1–R13 and C1–C11${g.length ? ': ' + g.slice(0, 5).map(f => `${f.rule} ${f.row} ${f.msg}`).join(' | ') : ''}`);
  const exp = J('expected.json'), bf = checkAll(J('spans.broken.json'));
  for (const r of exp.rules) ok(bf.some(f => f.rule === r), `the broken spans fail ${r} (${exp.why[r]})`);
  for (const r of new Set(bf.filter(f => /^C/.test(f.rule)).map(f => f.rule))) ok(exp.rules.includes(r), `the broken spans fail ${r}, a chain rule the fixture does not plant`);
  const w = spawnSync(process.execPath, [path.join(ROOT, 'tools/check_learner_texts.mjs'), '--explain', 'rule.ideas.genesis'], { cwd: ROOT, encoding: 'utf8' });
  ok(w.status === 0 && [1, 2, 3, 4, 5, 6, 7, 8, 9].every(n => w.stdout.includes(`\n${n}. GEN-00${n}`)) && /open with one of: so, hence/.test(w.stdout) && /our reading \/ ours/.test(w.stdout), '--explain rule.ideas.genesis prints the worksheet: every position, the words of its link, the status word of GEN-006');
}

// ================================================================================================================ F. rendered
heading('F rendered — the research order, the connectives, the mentions; the learner stories');
// the order check of a chain list: the rows in the order drawn are the chain's positions shown at these settings, in chain order (no sorting)
const orderCheck = (dom, want) => same(dom, want);
const DESIGN_WORDS = { derives: 'So', from: 'From', instance: 'A case of it', equiv: 'Equivalently', 'uses-input': 'With an input', cycle: 'And back', continues: 'And', contrasts: 'By contrast', order: 'Beside it', back: 'It rests on' };
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr']);
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
const decode = s => s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => (e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)) : ENT[e.toLowerCase()] ?? m));
function parseHTML(html) {
  const root = { tag: '#root', attrs: {}, children: [] }, stack = [root];
  const re = /<!--[\s\S]*?-->|<\/([a-zA-Z][\w:-]*)\s*>|<([a-zA-Z][\w:-]*)((?:\s+[^\s"'>/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?)*)\s*(\/?)>|([^<]+)/g;
  let m;
  while ((m = re.exec(html))) {
    if (m[0].startsWith('<!--')) continue;
    if (m[1]) { const t = m[1].toLowerCase(); for (let i = stack.length - 1; i > 0; i--) if (stack[i].tag === t) { stack.length = i; break; } continue; }
    if (m[2]) { const a = {}; const ar = /([^\s"'>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g; let x; while ((x = ar.exec(m[3] || ''))) a[x[1].toLowerCase()] = decode(x[2] ?? x[3] ?? x[4] ?? ''); const node = { tag: m[2].toLowerCase(), attrs: a, children: [] }; stack[stack.length - 1].children.push(node); if (!m[4] && !VOID.has(node.tag)) stack.push(node); continue; }
    if (m[5]) stack[stack.length - 1].children.push({ text: decode(m[5]) });
  }
  return root;
}
const hasClass = (n, c) => !!(n.attrs && n.attrs.class && n.attrs.class.split(/\s+/).includes(c));
function* walk(n) { yield n; for (const c of n.children || []) yield* walk(c); }
const findAll = (n, pred) => [...walk(n)].filter(x => x !== n && x.tag && pred(x));
const find = (n, pred) => findAll(n, pred)[0] || null;
const textOf = n => (n.text != null ? n.text : (n.children || []).map(textOf).join(''));
/** the statements of a node that are not inside another statement, in document order */
const topStatements = n => { const out = []; const go = x => { for (const c of x.children || []) { if (!c.tag) continue; if (hasClass(c, 'statement')) out.push(c); else go(c); } }; go(n); return out; };
let rendered = { renders: 0, chains: 0, lists: 0, connectives: 0, mentions: 0, stories: 0, fallbacks: 0 }, genesisMath = null;
if (!fs.existsSync(path.join(ROOT, 'src/components/Chain.jsx'))) notes.push('F skipped: src/components/Chain.jsx is not there yet (the renderer, B2)');
else {
  const req = createRequire(path.join(NM, 'noop.js'));
  const esbuild = req('esbuild'), katex = req('katex');
  const VOC = await import(pathToFileURL(path.join(ROOT, 'src/app/vocab.js')).href);
  ok(same(VOC.CHAIN_WORDS, DESIGN_WORDS), `CHAIN_WORDS of src/app/vocab.js are the words of STORY_ROUND.md §4.4 (${JSON.stringify(VOC.CHAIN_WORDS)})`);
  for (const [k, w] of Object.entries(VOC.CHAIN_WORDS)) ok(w.length <= 24 - (k === 'from' ? 9 : 0), `the connective "${w}" is short enough (≤ 24 characters with an id after From)`);
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'one-rule-chains-ssr-'));
  const exists = p => fs.existsSync(path.join(ROOT, p));
  const bundle = async name => {
    const outfile = path.join(tmp, name);
    await esbuild.build({ entryPoints: [path.join(ROOT, 'src/app/ssr.jsx')], absWorkingDir: ROOT, outfile, bundle: true, platform: 'node', format: 'esm', target: 'node20', jsx: 'automatic',
      loader: { '.js': 'jsx', '.css': 'empty' }, alias: { '@one-rule/figures': exists('src/figures/index.js') ? './src/figures/index.js' : './src/pages/optional/figures.js', '@one-rule/logbook': exists('src/logbook/LogbookPage.jsx') ? './src/logbook/LogbookPage.jsx' : './src/pages/optional/logbook.jsx' },
      nodePaths: [NM], define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'error',
      banner: { js: "import { createRequire as __oneRuleCreateRequire } from 'node:module'; const require = __oneRuleCreateRequire(import.meta.url);" } });
    return import(pathToFileURL(outfile).href);
  };
  const baseTablesFor = () => {
    const t = {};
    for (const f of fs.readdirSync(C).filter(f => f.endsWith('.json'))) t[f.slice(0, -5)] = readJSON(path.join(C, f));
    for (const f of fs.readdirSync(path.join(C, 'derived')).filter(f => f.endsWith('.json'))) t['derived_' + f.slice(0, -5)] = readJSON(path.join(C, 'derived', f));
    t.version = { contentVersion: 'test', appVersion: readJSON(path.join(ROOT, 'package.json')).version };
    return t;
  };
  const visibleIn = (r, mode) => !r || !Array.isArray(r.visibleTo) || !r.visibleTo.length || r.visibleTo.includes(mode);
  const word = l => (l.dir === 'back' ? DESIGN_WORDS.back : DESIGN_WORDS[l.rel] || DESIGN_WORDS.order);
  /** render a set of routes at the four settings and under three lenses, and hold every chain drawn to its record */
  const checkRenders = (ssr, tables, routes, label) => {
    const R = new Map(tables.rows.map(r => [r.id, r]));
    const byChain = new Map((tables.chains || []).map(c => [c.id, c]));
    const settings = [];
    for (const lens of [null, 'cat', 'geo', 'furey']) for (const mode of ['phys', 'math']) for (const level of ['research', 'learner']) settings.push({ mode, level, lens });
    for (const route of routes) for (const s of settings) {
      const q = new URLSearchParams(); if (s.mode === 'math') q.set('m', 'math'); if (s.level === 'learner') q.set('l', 'learner'); if (s.lens) q.set('lens', s.lens);
      const where = `${label} #/${route}${q.toString() ? '?' + q : ''}`;
      let html; try { html = ssr.render(`#/${route}${q.toString() ? '?' + q : ''}`); } catch (e) { ok(false, `${where}: render threw ${e.message}`); continue; }
      rendered.renders++;
      const doc = parseHTML(html);
      // the chains of the page with a position shown at these settings (a row with no text at the level is not drawn, 02 §2: a chain none of
      // whose rows has a learner text yet is not drawn at learner level, D54)
      const showsHere = c => c.rows.some(row => { const id = visibleIn(R.get(row), s.mode) ? row : (c.twins || {})[row] && visibleIn(R.get(c.twins[row]), s.mode) ? c.twins[row] : null; return id && ssr.textFor(id, { mode: s.mode, level: s.level, lens: s.lens, chain: c.id }) != null; });
      const want = (tables.chains || []).filter(c => c.page === route && showsHere(c)).map(c => c.id).sort();
      const drawn = findAll(doc, n => n.tag === 'div' && hasClass(n, 'chain') && n.attrs['data-chain']);
      ok(same([...new Set(drawn.map(n => n.attrs['data-chain']))].sort(), want), `${where}: the chains drawn are the page's chains with a position shown (${drawn.length} drawn, ${want.length} expected)`);
      for (const div of drawn) {
        const c = byChain.get(div.attrs['data-chain']); if (!c) continue;
        rendered.chains++;
        const twins = c.twins || {};
        const shownAt = row => (visibleIn(R.get(row), s.mode) ? row : twins[row] && visibleIn(R.get(twins[row]), s.mode) ? twins[row] : null);
        const here = id => ssr.textFor(id, { mode: s.mode, level: s.level, lens: s.lens, chain: c.id }) != null;
        const shown = c.rows.map((row, i) => ({ row, i, id: shownAt(row) })).filter(x => x.id && here(x.id));
        if (s.level === 'research') {
          const list = find(div, n => n.tag === 'ol' && hasClass(n, 'chain__list'));
          if (!ok(list, `${where} ${c.id}: an ol.chain__list at research level`)) continue;
          rendered.lists++;
          const items = findAll(list, n => n.tag === 'li' && hasClass(n, 'chain__item'));
          const dom = items.map(li => (topStatements(li)[0] || { attrs: {} }).attrs['data-row']);
          ok(orderCheck(dom, shown.map(x => x.id)), `${where} ${c.id}: the rows drawn ${dom.join(' ')} are the chain's positions ${shown.map(x => x.id).join(' ')} (no sorting)`);
          if (c.id === 'rule.ideas.genesis' && s.mode === 'math' && !s.lens) genesisMath = { dom, want: shown.map(x => x.id) };
          let prevShown = null, prevIdx = -1;
          items.forEach((li, k) => {
            const pos = shown[k]; if (!pos) return;
            const rel = find(li, n => hasClass(n, 'chain__rel'));
            if (k === 0) ok(!rel, `${where} ${c.id}: no connective before the first position`);
            else {
              const link = c.links[pos.i - 1], skipped = pos.i - 1 !== prevIdx;
              let allow;
              if (link.dir === 'back') allow = [DESIGN_WORDS.back];
              else if (link.from) { const at = shownAt(link.from); allow = at && shown.some(x => x.id === at && x.i < pos.i) ? [at === prevShown ? word({ rel: link.rel }) : `${DESIGN_WORDS.from} ${at}`] : [DESIGN_WORDS.order]; }
              else allow = skipped ? [word(link), DESIGN_WORDS.order] : [word(link)];
              rendered.connectives++;
              ok(rel && rel.attrs['data-connective'] === 'chain' && allow.includes(textOf(rel)), `${where} ${c.id}: the connective before ${pos.id} reads "${rel ? textOf(rel) : '(none)'}", the link ${JSON.stringify(link)} gives ${allow.join(' or ')}`);
            }
            if ((c.mention || []).includes(pos.row)) {
              rendered.mentions++;
              const st = topStatements(li)[0], told = st && find(st, n => hasClass(n, 'statement__told'));
              ok('data-mention' in li.attrs && st && hasClass(st, 'statement--mention') && told && /^Told in /.test(textOf(told)), `${where} ${c.id}: the mention ${pos.id} is the compact statement with its "Told in" link`);
            }
            prevShown = pos.id; prevIdx = pos.i;
          });
        } else {
          const lead = c.lead && visibleIn(R.get(c.lead), s.mode) && ssr.textFor(c.lead, { mode: s.mode, level: s.level, lens: s.lens }) != null ? [c.lead] : [];
          if (div.attrs['data-storied'] === 'true') {
            const p = find(div, n => n.tag === 'p' && hasClass(n, 'chain__story'));
            if (!ok(p && p.attrs['data-chain'] === c.id, `${where} ${c.id}: a storied chain is one p.chain__story`)) continue;
            rendered.stories++;
            const dom = topStatements(p).map(n => n.attrs['data-row']);
            ok(same(dom, [...lead, ...shown.map(x => x.id)]), `${where} ${c.id}: the story is the lead's learner text and the spans in order (${dom.join(' ')})`);
            for (const x of shown) ok(tables.texts.some(t => t.chain === c.id && t.row === x.id && t.span === x.i + 1 && t.register === 'span'), `${where} ${c.id}: ${x.id} is told by its span`);
            ok(!find(div, n => n.tag === 'ol' && hasClass(n, 'chain__list')), `${where} ${c.id}: a storied chain draws no list at learner level`);
          } else {
            const list = find(div, n => n.tag === 'ol' && hasClass(n, 'chain__list'));
            if (!ok(list, `${where} ${c.id}: an unstoried chain falls back to its list`)) continue;
            rendered.fallbacks++;
            const dom = findAll(list, n => n.tag === 'li' && hasClass(n, 'chain__item')).map(li => (topStatements(li)[0] || { attrs: {} }).attrs['data-row']);
            ok(orderCheck(dom, shown.map(x => x.id)), `${where} ${c.id}: the fallback draws the rows' learner texts in chain order (${dom.join(' ')})`);
            ok(!find(list, n => hasClass(n, 'chain__rel')), `${where} ${c.id}: no connective word at learner level`);
            for (const x of shown) ok(!tables.texts.some(t => t.chain === c.id && t.row === x.id), `${where} ${c.id}: an unstoried chain has no span of ${x.id}`);
          }
        }
      }
    }
  };
  // the tables as merged, then the fixture merged in place of the pilot (its storied chains), each in a bundle of its own
  const real = baseTablesFor();
  const ssrA = await bundle('ssr-a.mjs'); ssrA.setKatexEngine(katex); ssrA.prime(real);
  const PAGES = ['rule', 'cells', 'steps/coupling', 'steps/baez', 'shifted', 'matter'].filter(r => pages.some(p => p.route === r));
  checkRenders(ssrA, real, PAGES, 'tables');
  if (fres && !fres.errors.length) {
    const fx = baseTablesFor();
    Object.assign(fx, { rows: fres.rows, texts: fres.texts, pages: fres.pages, chains: fres.chains });
    fx.derived_status = { ...fx.derived_status, 'GEN-751': { status: 'meta', new: false, badge: null, signature: [0, 0, 1], grade: 1, neighbours: [], flagsLegacy: [], openAlso: false } };
    const ssrB = await bundle('ssr-b.mjs'); ssrB.setKatexEngine(katex); ssrB.prime(fx);
    checkRenders(ssrB, fx, ['rule', 'matter/model'], 'fixture');
    // D54's fallback: every chain of the tables is storied from 2.15.0, so the fallback is drawn on the fixture with the spans of fixture-axes left
    // out (that chain unstoried: its rows in their learner texts, in chain order, without connective words)
    const AXES = 'matter-model.axes.fixture-axes';
    const fres2 = mergeStory({ chains: { ...fixture, learner: fixture.learner.filter(t => t.chain !== AXES) } });
    if (ok(!fres2.errors.length && (fres2.chains.find(c => c.id === AXES) || {}).story === 'none', `the fixture without the spans of ${AXES} merges, that chain unstoried`)) {
      const fu = baseTablesFor();
      Object.assign(fu, { rows: fres2.rows, texts: fres2.texts, pages: fres2.pages, chains: fres2.chains, derived_status: fx.derived_status });
      const ssrC = await bundle('ssr-c.mjs'); ssrC.setKatexEngine(katex); ssrC.prime(fu);
      checkRenders(ssrC, fu, ['matter/model'], 'fixture (axes unstoried)');
    }
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  ok(rendered.lists > 0 && rendered.connectives > 0 && rendered.mentions > 0 && rendered.stories > 0 && rendered.fallbacks > 0, `every kind was drawn and checked (${JSON.stringify(rendered)})`);
}

// ================================================================================================================ G. mutants
heading('G mutants — ten, each caught');
{
  const caught = (recs, rule) => checkAll(recs).some(f => f.rule === rule);
  const good = fixture.learner;
  const idx = (row, chain) => good.findIndex(r => r.row === row && r.chain === chain);
  const seed = 'rule.ideas.fixture-seed', core = 'rule.ideas.fixture-core';
  ok(caught(good.filter((r, i) => i !== idx('GEN-002', seed)), 'C2'), 'mutant 1, a span missing: caught (C2)');
  ok(caught(good.map((r, i) => (i === idx('GEN-001', seed) ? { ...r, span: 2 } : i === idx('GEN-002', seed) ? { ...r, span: 1 } : r)), 'C3'), 'mutant 2, two spans out of order: caught (C3)');
  ok(caught(good.map((r, i) => (i === idx('GEN-002', seed) ? { ...r, body: 'So ' + r.body.charAt(0).toLowerCase() + r.body.slice(1) } : r)), 'C4'), 'mutant 3, an unearned "So" on an order link: caught (C4)');
  ok(caught(good.map((r, i) => (i === idx('GEN-006', core) ? { ...r, body: r.body.replace(', is our reading here.', ' holds here.') } : r)), 'C5'), 'mutant 4, a status word dropped: caught (C5)');
  const merged = over => mergeStory({ chains: { ...fixture, ...over } }).errors;
  const fc = fixture.chains, byId = id => fc.find(c => c.id === id);
  ok(merged({ chains: fc.filter(c => c.id !== seed) }).some(e => /mention GEN-003 is told in no other chain/.test(e)), 'mutant 5, a mention not told on the page: caught (V2)');
  ok(merged({ chains: fc.map(c => (c.id === core ? { ...c, links: c.links.map((l, i) => (i === 1 ? { rel: 'derives' } : l)) } : c)) }).some(e => /no depends edge backs it/.test(e)), 'mutant 6, a link without an edge: caught (V3)');
  ok(merged({ chains: fc.map(c => (c.id === seed ? { ...c, rows: ['ATY-004', ...c.rows.slice(1)] } : c)) }).some(e => /ATY-004 is told here but not placed/.test(e)), 'mutant 7, a told row not placed: caught (V2)');
  ok(merged({ chains: fc.map(c => (c.id === core ? { ...c, lead: 'GEN-004' } : c)) }).some(e => /lead GEN-004 is not a story row/.test(e)), 'mutant 8, a lead that is not a story row: caught (V4)');
  ok(merged({ layout: [{ row: 'ATY-004', page: 'rule', section: 'ideas', order: 1000, role: 'result', add: true }] }).some(e => /ATY-004.*home would move/.test(e)), 'mutant 9, a moved home: caught (merge_story, D51)');
  const kindOf = id => (rowById.get(id) || {}).kind || '';
  const base = genesisMath || { dom: byId(seed) ? pilot.find(c => c.id === 'rule.ideas.genesis').rows : [], want: pilot.find(c => c.id === 'rule.ideas.genesis').rows };
  const sorted = [...base.dom].sort((a, b) => (kindOf(a) < kindOf(b) ? -1 : kindOf(a) > kindOf(b) ? 1 : 0));
  ok(!same(sorted, base.dom) && !orderCheck(sorted, base.want), `mutant 10, a chain sorted by kind at research level in mathematics: caught by the order check (${genesisMath ? 'on the drawn list' : 'on the chain\'s rows'}: ${sorted.join(' ')})`);
}

// ================================================================================================================ report
for (const n of notes) console.log(`note: ${n}`);
console.log(`chains: ${checks} checks; ${pilot.length} pilot chains, ${(table || []).length} merged; ${rendered.renders} renders (${rendered.chains} chains: ${rendered.lists} lists, ${rendered.connectives} connectives, ${rendered.mentions} mentions, ${rendered.stories} stories, ${rendered.fallbacks} fallbacks)`);
if (failures.length) { console.log(`FAIL: ${failures.length} problem(s)\n - ${failures.slice(0, 60).join('\n - ')}`); process.exit(1); }
console.log('PASS: the extraction gives its fixture and SPINE.md §4\'s drafts, deterministically; the pilot is SPINE.md §4\'s composition; V1–V10 hold on the merged tables, the table and the section fields agree, the book restores, no home moved; the fixture merges twice to the same tables and through the pipeline to the same bytes; the checker passes the good spans and catches the broken; the chains drawn keep their order, their words, their mentions and their stories; ten mutants caught');
