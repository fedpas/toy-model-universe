// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The clock (step 1, Conventions page), gauge gravity (step 12, equations page) and finite groups (step 17, lenses page): the engine behind the tabs (labelsEngine.js) against the scripts' logs and against the bit rule,
// the copy (English and Italian, plain and formal), the step numbering, the frame copy of the Conventions page, and the three branches of the Map tree that open the tabs.
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);
import { execSync } from 'child_process';
import * as E from './labelsEngine.js';
import { COPY } from './labelsCopy.js';
import { PAGE, PAGE_YL, SHORT, TABS_LBL } from './conventionsCopy.js';
import { PAGES, STORY, STORY_YL } from './storyCopy.js';
import { STEP_GROUPS, STEP_OFFSET, stepNo, stepTotal, stepEyebrow, NAV_NAMES, NAV_NAMES_YL, STEP_NAMES, STEP_NAMES_YL } from './steps.js';
import { TREE, flat } from './mapData.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const near = (a, b, t = 1e-9) => Math.abs(a - b) <= t * Math.max(1, Math.abs(a), Math.abs(b));
const LOG = f => fs.readFileSync('selfcheck/steps15_17/logs/' + f, 'utf8');
const L1 = LOG('labels_check.log'), L2 = LOG('gtg_check.log'), L3 = LOG('groups_check.log');

// ---- 0. the scripts and their logs ship with the package and end in their all-pass line
ok(/ALL LABELS CHECKS PASS/.test(L1) && /ALL GTG\/RDK CHECKS PASS/.test(L2) && /ALL GROUP CHECKS PASS/.test(L3), 'the three logs end in their all-pass lines');
for (const f of ['bitcliff.py', 'permgroup.py', 'labels_check.py', 'gtg_check.py', 'groups_check.py', 'run_mutations.py']) ok(fs.existsSync('selfcheck/steps15_17/' + f), 'selfcheck/steps15_17/' + f + ' is in the package');
let numpy = true; try { execSync('python3 -c "import numpy"', { stdio: 'ignore' }); } catch { numpy = false; }
if (numpy && !process.env.SKIP_PY) {
  const run = f => { try { return execSync('python3 ' + f, { cwd: 'selfcheck/steps15_17', encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }); } catch (e) { return String(e.stdout || '') + String(e.stderr || e.message); } };
  ok(/ALL LABELS CHECKS PASS/.test(run('labels_check.py')), 'labels_check.py passes now');
  ok(/ALL GTG\/RDK CHECKS PASS/.test(run('gtg_check.py')), 'gtg_check.py passes now');
  ok(/ALL GROUP CHECKS PASS/.test(run('groups_check.py')), 'groups_check.py passes now');
} else console.log('note: numpy is not installed; the three scripts were not re-run (the logs were compared)');

// ---- 1. the clock and the cells (the clock step)
{
  let cells = 0, dimOk = true, gaussOk = true, typeOk = true;
  for (let p = 0; p <= 12; p++) for (let q = 0; p + q <= 12; q++) { if (p + q < 1 && !(p === 0 && q === 0)) continue; const w = E.wedderburn(p, q), g = E.gaussSum(p, q); cells++; if (w.dim !== 2 ** (p + q)) dimOk = false; if (g.c !== w.c || g.norm2 !== 2 ** (p + q)) gaussOk = false; }
  ok(cells === 91, 'cells n <= 12: 91 (the log says 91)'); ok(/91 cells n<=12/.test(L3), 'groups_check.log has the 91 cells');
  ok(dimOk, 'k^2 * dim(field) * copies = 2^n for every cell n <= 12'); ok(gaussOk, 'the Gauss sum has norm 2^n and phase c = p - q mod 8 for every cell n <= 12');
  const T = (p, q, t, k) => { const w = E.wedderburn(p, q); return w.type === t && w.k === k; };
  ok(T(1, 0, 'R2', 1) && T(0, 1, 'C', 1) && T(2, 0, 'R', 2) && T(0, 2, 'H', 1) && T(0, 3, 'H2', 1) && T(3, 0, 'C', 2) && T(4, 0, 'H', 2) && T(1, 1, 'R', 2) && T(8, 0, 'R', 16) && T(0, 8, 'R', 16), 'textbook cells: Cl(1,0)=R+R, Cl(0,1)=C, Cl(2,0)=M2(R), Cl(0,2)=H, Cl(0,3)=H+H, Cl(3,0)=M2(C), Cl(4,0)=M2(H), Cl(8,0)=M16(R)');
  ok(E.TYPES.join() === 'R,R2,R,C,H,H2,H,C', 'the types around the clock');
  let emb = 0, embOk = true; for (let p = 0; p <= 8; p++) for (let q = 0; p + q <= 8; q++) { const e = E.embedCheck(p, q); emb++; if (!e.ok) embOk = false; for (let j = 0; j < p + q; j++) { const hasP = (e.images[j] >> (p + q) & 3) === 3; if (hasP !== (j >= p)) embOk = false; } }
  ok(emb === 45 && embOk, 'every Cl(p,q), n <= 8 (45 cells), embeds in Cl(n+2,0): squares, anticommutation, odd images; only the negative generators carry P');
  // the trinity
  const gc = E.gridCounts(6); ok(gc.ell === 516 && gc.hyp === 1616 && gc.par === 64 && gc.total === 2197, 'grid [-6,6]^3: 516 / 1616 / 64');
  ok(/elliptic \(X\^2 < 0\)\s+516/.test(L1) && /hyperbolic \(X\^2 > 0\)\s+1616/.test(L1) && /parabolic \(X\^2 = 0, X != 0\)\s+64/.test(L1), 'the same three counts are in labels_check.log');
  let sq = true; for (let a = -3; a <= 3; a++) for (let b = -3; b <= 3; b++) for (let c = -3; c <= 3; c++) { const r = E.squareByBitRule(a, b, c); if (r.scalar !== E.traceless(a, b, c) || r.rest !== 0) sq = false; const M = E.matrixOf(a, b, c), s = E.traceless(a, b, c); const M2 = [[M[0][0] * M[0][0] + M[0][1] * M[1][0], M[0][0] * M[0][1] + M[0][1] * M[1][1]], [M[1][0] * M[0][0] + M[1][1] * M[1][0], M[1][0] * M[0][1] + M[1][1] * M[1][1]]]; if (M2[0][0] !== s || M2[1][1] !== s || M2[0][1] !== 0 || M2[1][0] !== 0) sq = false; }
  ok(sq, 'X^2 = a^2 + b^2 - c^2 by the bit rule of Cl(2,0) and by the 2x2 matrices, for 343 integer generators');
  let ex = true; for (const [a, b, c] of [[0, 0.5, 0.5], [0, 0, 1], [0, 1, 0], [0.3, -0.7, 0.2], [1, 0.4, 0.1], [0, 0, 0]]) for (const t of [0, 0.37, 1.1]) { const h = 1e-6, E1 = E.expTX(a, b, c, t + h), E0 = E.expTX(a, b, c, t - h), X = E.expTX(a, b, c, t), M = E.matrixOf(a, b, c); for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { const d = (E1[i][j] - E0[i][j]) / (2 * h), XM = M[i][0] * X[0][j] + M[i][1] * X[1][j]; if (Math.abs(d - XM) > 1e-5) ex = false; } const A = E.expTX(a, b, c, 0.4), B = E.expTX(a, b, c, 0.9), C = E.expTX(a, b, c, 1.3); for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) if (Math.abs(A[i][0] * B[0][j] + A[i][1] * B[1][j] - C[i][j]) > 1e-9) ex = false; }
  ok(ex, 'exp(tX): d/dt exp(tX) = X exp(tX) and exp(t)exp(u) = exp(t+u) in the elliptic, hyperbolic and parabolic cases');
  ok(E.trinityClass(E.traceless(...E.springX(1))) === -1 && E.trinityClass(E.traceless(...E.springX(0))) === 0 && E.trinityClass(E.traceless(...E.springX(-1))) === 1 && near(E.traceless(...E.springX(0.7)), -0.7), 'the spring k > 0, 0, < 0 is rotation, translation, boost, and X^2 = -k');
  const sp = E.springX(0.6), Mx = E.matrixOf(...sp); ok(near(Mx[0][1], 1) && near(Mx[1][0], -0.6) && near(Mx[0][0], 0), 'the spring generator is [[0,1],[-k,0]]');
}
// ---- bivectors at n = 4
{
  const v40 = E.bivector4(4, 0, [1, 0, 0, 0, 0, 1]), v31 = E.bivector4(3, 1, [1, 0, 0, 0, 0, 1]), v22 = E.bivector4(2, 2, [1, 0, 0, 0, 0, 1]);
  ok(v40.S === -2 && v40.W === 2 && v31.S === 0 && v31.W === 2 && v22.S === -2 && v22.W === 2 && v40.other === 0, '(e12 + e34)^2 = -2 + 2 e1234 in Cl(4,0) and Cl(2,2), 2 e1234 in Cl(3,1): the log lines');
  ok(/\(e12 \+ e34\)\^2 = \{0: -2, 15: 2\}/.test(L1) && /Cl\(3, 1\):  \(e12 \+ e34\)\^2 = \{15: 2\}/.test(L1), 'the same three squares are in labels_check.log');
  const cx = E.bivector4(2, 2, [1, 1, 0, 0, 1, 0]); ok(cx.label === 'complex' && cx.disc === -3 && cx.S === 1 && Math.abs(cx.W) === 2, 'the preset "a complex pair" in Cl(2,2): S = 1, |W| = 2, discriminant -3 (roots exp(+-i pi/3))');
  ok(E.SIGS4.filter(([p, q]) => !(p === 2 && q === 2)).every(([p, q]) => E.bivector4(p, q, [1, 1, 0, 0, 1, 0]).kind === 'real'), 'the same bivector has real roots in the other four signatures');
  ok(E.bivector4(3, 1, [1, 0, 0, 0, -1, 0]).label === 'null', 'a null simple bivector exists in Cl(3,1) (e12 - e24)');
  // the roots solve the quadratic and B^2 has only grades 0 and 4
  const r = E.lcg(99); let quad = true, grades = true;
  for (const [p, q] of E.SIGS4) for (let i = 0; i < 200; i++) { const c = Array.from({ length: 6 }, () => Math.round(r() * 8 - 4)), v = E.bivector4(p, q, c); if (v.other !== 0) grades = false; const [l1, l2] = v.lam; const sum = l1[0] + l2[0], prod = l1[0] * l2[0] - l1[1] * l2[1]; if (Math.abs(sum - v.S) > 1e-9 || Math.abs(prod - v.W * v.W * v.I2 / 4) > 1e-9) quad = false; }
  ok(grades && quad, 'for 1000 random bivectors B^2 has only a scalar and an e1234 part, and the two roots satisfy l1 + l2 = S, l1 l2 = W^2 I^2 / 4');
  const mc = E.SIGS4.map(([p, q]) => E.sampleBivectors(p, q, 400));
  ok(mc.every((m, i) => (i === 2 ? m.complex > 100 && m.complex < 260 : m.complex === 0)), 'complex roots only in Cl(2,2): ' + mc.map(m => m.complex).join(', '));
  ok(/complex lambda \(loxodromic, the Riesz "counter-example"\) occurs in Cl\(2,2\) = M_4\(R\) ONLY/.test(L1), 'labels_check.log says the same');
  ok(mc[2].complex / (mc[2].real + mc[2].complex) > .35 && mc[2].complex / (mc[2].real + mc[2].complex) < .55, 'about 45 per cent complex in Cl(2,2) (the log has 33 of 72)');
}
// ---- 2. gauge gravity (Step 12)
{
  for (const g of [0, 0.6, 1, 5 / 3, 3, -2]) ok(near(E.pgSquareByBitRule(g), g * g - 1), `(e_r + g e_t)^2 = g^2 - 1 by the bit rule of Cl(1,1) at g = ${g}`);
  ok(E.pgClass(3 / 5) === -1 && E.pgClass(1) === 0 && E.pgClass(5 / 3) === 1 && near(E.pgSquare(3 / 5), -16 / 25) && near(E.pgSquare(5 / 3), 16 / 9), 'outside -16/25, horizon 0, inside 16/9 (the log lines G2)');
  ok(/g=3\/5 outside.*-16\/25/.test(L2) && /g=1 on the horizon.*= 0/.test(L2) && /g=5\/3 inside.*16\/9/.test(L2), 'gtg_check.log has the three lines');
  ok(near(E.pgG(1, 0.5), 1) && E.pgClass(E.pgG(1, 0.5)) === 0 && E.pgClass(E.pgG(0.5, 0.5)) === 1 && E.pgClass(E.pgG(2, 0.5)) === -1, 'g = sqrt(2M/r): the horizon at r = 2M');
  const R = E.pgRays(0.5), R1 = E.pgRays(1), R2 = E.pgRays(2); ok(near(R.out, .5) && near(R1.out, 0) && near(R2.out, -1) && near(R2.inn, -3) && near(R.rain, -.5), 'light rays dr/dt = -g +- 1: the outgoing ray stands still at g = 1 and falls in for g > 1');
  const rv = E.pgRays(0.5, -1); ok(near(rv.out, 1.5) && near(rv.inn, -.5) && near(rv.rain, .5), 'reversing time (g -> -g) tilts the cones the other way');
  const rows = { 4: [20, 10, 10], 5: [50, 15, 35], 6: [105, 21, 84], 7: [196, 28, 168], 8: [336, 36, 300] };
  for (const [m, [a, b, c]] of Object.entries(rows)) { const k = E.curvature(+m); ok(k.riemann === a && k.ricci === b && k.weyl === c && k.riemann === k.ricci + k.weyl, `n = ${m}: ${a} = ${b} + ${c}`); ok(new RegExp(`^\\s*${m}\\s+${a}\\s+${b}\\s+${c}\\s`, 'm').test(L2), `n = ${m}: the row is in gtg_check.log`); }
  const k3 = E.curvature(3), k2 = E.curvature(2); ok(k3.riemann === 6 && k3.ricci === 6 && k3.weyl === 0 && k2.riemann === 1 && k2.weyl === 0 && E.curvature(3).scalarOnly && !E.curvature(4).scalarOnly, 'n = 3: 6 = 6 + 0; n = 2: Riemann 1; B^2 is a scalar up to n = 3');
}
// ---- 3. finite groups (Step 17)
{
  const esc = s => s.replace(/[+]/g, '\\+');
  for (const [m, e] of Object.entries(E.RAILS.E)) ok(new RegExp(`^\\s*${m}\\s+${esc(e[0])}\\s+\\d+\\s+${e[2]}\\s+${e[3]}\\s+${e[4]}\\s+${e[3]}\\s`, 'm').test(L3), `E rail n = ${m}: ${e[0]}, |W| ${e[2]}, image ${e[3]}, kernel ${e[4]} is in groups_check.log`);
  for (const [m, a] of Object.entries(E.RAILS.A)) { ok(new RegExp(`^\\s*${m}\\s+${a[0]}\\s+${a[1]}\\s+${a[2]}\\s+1\\s*$`, 'm').test(L3), `A rail n = ${m}: class ${a[0]}, S image ${a[1]}, |O(Q)| ${a[2]} is in groups_check.log`); ok(a[1] === E.factorial(+m + 1), `n = ${m}: the image is |S_(n+1)| = ${(+m) + 1}!`); }
  ok(Object.values(E.RAILS.E).every(e => e[2] === e[3] * e[4]), 'W(E_n) order = image times kernel');
  ok(Object.entries(E.RAILS.A).filter(([, a]) => a[1] === a[2]).map(([m]) => m).join() === '2,3,4,5' && E.RAILS.A[6][2] / E.RAILS.A[6][1] === 8 && E.RAILS.A[7][2] / E.RAILS.A[7][1] === 64 && E.RAILS.A[8][2] / E.RAILS.A[8][1] === 960, 'S_(n+1) fills O(Q) for n = 2..5 and has index 8, 64, 960 at n = 6, 7, 8');
  ok(E.RAILS.E[8][2] === 696729600 && E.RAILS.E[8][3] === 348364800 && E.RAILS.E[7][2] === 2903040, '|W(E8)| = 696 729 600, |W(E7)| = 2 903 040');
  // Golay
  const G = E.golay(); ok(JSON.stringify(G.hist) === '{"0":1,"8":759,"12":2576,"16":759,"24":1}' && G.octads.length === 759, 'Golay weights 0:1, 8:759, 12:2576, 16:759, 24:1');
  ok(/weights \{0: 1, 8: 759, 12: 2576, 16: 759, 24: 1\}/.test(L3), 'the same weights are in groups_check.log');
  ok(new Set(G.words).size === 4096 && Array.from(G.words).every(w => E.popcount(w) % 4 === 0), '4096 distinct words, every weight divisible by 4');
  let closed = true, orth = true; const W = Array.from(G.words); for (let i = 0; i < 300; i++) { const a = W[(i * 97) % 4096], b = W[(i * 389 + 11) % 4096]; if (!(new Set(W)).has(a ^ b) && closed) closed = false; if (E.popcount(a & b) % 2) orth = false; }
  ok(closed && orth, 'sums of words are words and words are pairwise orthogonal (sample of 300 pairs)');
  const S = new Set(W); let allSum = true; for (let i = 0; i < 12; i++) for (let j = 0; j < 12; j++) if (!S.has(W[1 << i] ^ W[1 << j])) allSum = false; ok(allSum, 'sums of generators are words');
  let steiner = 0, five = 0; const O = G.octads;
  for (let a = 0; a < 24; a++) for (let b = a + 1; b < 24; b++) for (let c = b + 1; c < 24; c++) for (let d = c + 1; d < 24; d++) for (let e = d + 1; e < 24; e++) { const m = (1 << a) | (1 << b) | (1 << c) | (1 << d) | (1 << e); let h = 0; for (const o of O) if ((o & m) === m) h++; five++; if (h === 1) steiner++; }
  ok(five === 42504 && steiner === 42504, 'every one of the 42 504 five-sets lies in exactly one octad: S(5,8,24)');
  const o0 = O[0], bits = []; for (let i = 0; i < 24; i++) if (o0 >> i & 1) bits.push(i);
  ok([1, 2, 3, 4, 5].map(k => O.filter(o => { const m = bits.slice(0, k).reduce((s, i) => s | (1 << i), 0); return (o & m) === m; }).length).join() === '253,77,21,5,1', 'octads through 1, 2, 3, 4, 5 points: 253, 77, 21, 5, 1');
  ok(E.octadThrough(O, bits.slice(0, 5).reduce((s, i) => s | (1 << i), 0)) === o0 && E.octadThrough(O, 1) === 'many', 'octadThrough finds the unique octad');
  // primes
  const newp = {}; for (const m of L3.matchAll(/^\s+(\d+): \[([\d, ]*)\]$/gm)) newp[+m[1]] = m[2] ? m[2].split(', ').map(Number) : [];
  ok(Object.keys(newp).length === 23, 'the log lists the primes entering at n = 2..24');
  ok(Object.entries(newp).every(([m, ps]) => JSON.stringify(E.newPrimes(+m)) === JSON.stringify(ps)), 'newPrimes(n) equals the log for n = 2..24');
  const ordLog = /\{3: 2, 5: 4, 7: 3, 11: 10, 13: 12, 17: 8, 19: 18, 23: 11, 29: 28, 31: 5, 41: 20, 47: 23, 59: 58, 71: 35\}/.test(L3); ok(ordLog && E.MONSTER_PRIMES.slice(1).every(p => ({ 3: 2, 5: 4, 7: 3, 11: 10, 13: 12, 17: 8, 19: 18, 23: 11, 29: 28, 31: 5, 41: 20, 47: 23, 59: 58, 71: 35 })[p] === E.ordTwo(p)) && E.MONSTER_PRIMES.length === 15, 'ord_p(2) of the 14 odd Monster primes equals the log');
  ok(E.newPrimes(6).length === 0 && E.newPrimes(36).length > 0, 'n = 6 brings no new prime (Zsigmondy)');
}
// ---- 4. the page: order, numbering, names, copy
ok(PAGES.indexOf('conventions') === PAGES.indexOf('atlas') + 1 && PAGES.indexOf('maxwell') === PAGES.indexOf('conventions') + 1 && PAGES.indexOf('lenses') === PAGES.indexOf('furey') + 1 && PAGES.indexOf('map') === PAGES.indexOf('lenses') + 1 && !PAGES.includes('labels'), 'the Conventions page (the clock) follows the atlas, the lenses page (the finite groups) follows Furey, the map follows the lenses page, and no labels page remains');
ok(STEP_GROUPS.core.join() === 'clock' && stepNo('core', 'clock') === 1 && stepTotal('core') === 20 && STEP_GROUPS.eq.includes('gauge') && STEP_OFFSET.eq === STEP_GROUPS.core.length && stepNo('eq', 'gauge') === 12 && stepTotal('eq') === 20 && STEP_GROUPS.lens[0] === 'groups' && STEP_OFFSET.lens === stepNo('eq', 'rigid') && stepNo('eq', 'rigid') === 16 && stepNo('lens', 'groups') === 17 && stepTotal('lens') === 20 && stepTotal('shapes') === 3 && !STEP_GROUPS.labels, 'the three steps are the clock (1 of 20), gauge gravity (12 of 20) and the finite groups (17 of 20); every step of the story counts to 20, the shapes page to 3');
ok(stepEyebrow('en', 'core', 'clock').startsWith('STEP 1 OF 20 · ') && stepEyebrow('en', 'eq', 'gauge').startsWith('STEP 12 OF 20 · ') && stepEyebrow('it', 'lens', 'groups').startsWith('PASSO 17 DI 20 · ') && stepEyebrow('en', 'shapes', 'gosset').startsWith('STEP 3 OF 3 · '), 'eyebrows: STEP 1 OF 20, STEP 12 OF 20, PASSO 17 DI 20, and the shapes page STEP 3 OF 3');
for (const lang of ['en', 'it']) {
  for (const id of ['clock', 'gauge', 'groups']) for (const D of [NAV_NAMES, NAV_NAMES_YL, STEP_NAMES, STEP_NAMES_YL]) ok(typeof D[lang][id] === 'string' && D[lang][id].length > 3, `${lang} ${id} has a name in each of the four lists`);
  ok(STORY[lang].pages.conventions === PAGE[lang] && STORY_YL[lang].pages.conventions === PAGE_YL[lang] && STORY[lang].nav.conventions && STORY[lang].tabsLbl.conventions === TABS_LBL[lang] && !STORY[lang].pages.labels && !STORY_YL[lang].pages.labels && !STORY[lang].nav.labels && !STORY[lang].tabsLbl.labels, `${lang}: STORY holds the Conventions page copy, the nav name and the tab label, and nothing is left of the labels page`);
  for (const P of [PAGE[lang], PAGE_YL[lang]]) ok(P.h && P.does && P.before && P.after && P.tags.length === 4 && P.tags.map(t => t[0]).join() === 'checked standard,standard,checked standard ours,checked open', `${lang}: page copy has heading, text, before, after and the four tags (audit round-2 flags)`);
  ok(SHORT[lang].length === 2 && SHORT[lang][0].length > 60 && SHORT[lang][0].length < 330 && SHORT[lang][1].length > 60 && SHORT[lang][1].length < 460, `${lang}: the two short readings fit the limits of test_audience`);
}
const shape = (o, p = '') => Object.entries(o).flatMap(([k, v]) => (v && typeof v === 'object' && !Array.isArray(v) ? shape(v, p + k + '.') : [p + k + (typeof v === 'function' ? '()' : Array.isArray(v) ? '[' + v.length + ']' : '')]));
ok(shape(COPY.en).join() === shape(COPY.it).join(), 'English and Italian copy have the same shape');
ok(shape(COPY.en).length > 150, 'the copy is not empty (' + shape(COPY.en).length + ' entries)');
// plain words for the Young Learner: no formula markup, no algebra names
const yl = []; const collect = (o, p) => { for (const [k, v] of Object.entries(o)) { const path = p + '.' + k; if (typeof v === 'string') { if (/Y$/.test(k) || /\.(ledeY|namesY|typesY|rowsY|rotorY)/.test(path)) yl.push([path, v]); } else if (Array.isArray(v)) { if (/Y$/.test(k)) v.forEach((s, i) => typeof s === 'string' && yl.push([path + i, s])); } else if (v && typeof v === 'object') collect(v, path); } };
for (const lang of ['en', 'it']) { collect(COPY[lang], lang); yl.push([lang + '.page.does', PAGE_YL[lang].does], [lang + '.page.h', PAGE_YL[lang].h], [lang + '.short', SHORT[lang][0]]); PAGE_YL[lang].tags.forEach((t, i) => yl.push([lang + '.tag' + i, t[1]])); }
ok(yl.length > 60, 'the plain texts were found (' + yl.length + ')');
for (const [path, s] of yl) ok(!/[\^_{}√∑⟨⟩≠≤≥·]|Cl\(|\bO\(Q\)|M_\d|\bGL\b|\bW\(E/.test(s), `plain text without formulas: ${path}: ${s.slice(0, 80)}`);
// every status word used is one of the four
// the clock tab: the Brown invariant with its scope r = 0 / r >= 1 (checked), the Brown invariant as a Pin- surface and a lattice signature with the physics names of the same Z8 (checked standard), the junction of two chain stacks (checked);
// the gauge tab: the horizon null as one element in two algebras (checked); the groups tab: the triple (V, Q, pi) for every n (checked standard) and the S_{n+1} line split into a checked one and an ours one
const GLANCE = { clock: 'checked standard,standard,checked ours,checked standard,checked,checked,checked ours,checked input,checked standard,checked,checked', gauge: 'checked standard ours input,checked standard input,checked,open', groups: 'checked standard,standard,checked standard,checked,ours,open' };
for (const lang of ['en', 'it']) for (const [id, t] of Object.entries(COPY[lang].tabs)) ok(t.glance.tags.map(x => x[0]).join() === GLANCE[id], `${lang}: tab ${id} has its status lines (audit round-2 flags and the v11 additions)`);
// the page names every script and test it stands on
ok(['labels_check.py', 'gtg_check.py', 'groups_check.py'].every(s => Object.values(COPY.en.tabs).some(t => t.glance.script.includes(s))), 'the tabs name the three scripts');
// the present statements of the strips (labelsCopy.js): the ranges of the core checks as the script runs them (test_core.mjs holds the script side), one name for the horizon reading, the mutants attributed to the scripts they ran on, a note on the checks with no version and no changelog file
for (const lang of ['en', 'it']) {
  const g = id => COPY[lang].tabs[id].glance;
  ok(/core·B1 for n ≤ 5, core·B2 for n ≤ 6, core·B3 for n ≤ 8/.test(g('clock').tags.map(x => x[1]).join(' ')), `${lang}: the clock line gives the range of B1, B2 and B3 separately`);
  const gauge = g('gauge').tags.map(x => x[1]).join(' ');
  ok(!/0 class|0 label|etichetta 0/.test(gauge) && /a null vector of the \(t, r\) plane Cl\(1,1\)/.test(gauge) && /one element in two algebras: the radial gradient at g = 1, ℓ = e_\{r\} \+ e_\{t\}, is a paired null of the spacetime algebra Cl\(1,3\), whose dagger partner is e_\{t\} − e_\{r\}, and the null generator of the tangent algebra Cl\(0,2,1\) of the surface, which generates its radical \(bd·str·21, bd·xph·3\)/.test(gauge), `${lang}: the gauge line says what r = 2M is and that the horizon null is one element in two algebras, with no "0 class" or "0 label"`);
  const clk = g('clock').tags.map(x => x[1]);
  ok(/^the clock is the Brown \(Arf–Brown–Kervaire\) invariant of the Z_\{4\} enhancement w of the dot product/.test(clk[8]) && /Kirby–Taylor, Thm 3\.2/.test(clk[8]) && /Debray–Gunningham, Thm 3\.12 and 3\.15/.test(clk[8]) && /Taylor, Thm 2\.5/.test(clk[8]) && /Atiyah–Bott–Shapiro, a pointer, source unread/.test(clk[8]) && !/our identification/.test(clk.join(' ')), `${lang}: the Brown-invariant line cites the sources it stands on (Kirby–Taylor, Debray–Gunningham, Taylor) and keeps the ABS identification a pointer`);
  ok(/^within one model, two stacks of time-reversal-invariant Kitaev chains/.test(clk[10]) && /depends on \(W − W′\) mod 8 only, 1, 2, 2, 4, 2, 4, 2, 2 for the residues 0 to 7/.test(clk[10]) && /\(bd·fk·1–3\)$/.test(clk[10]), `${lang}: the junction line states its model and the computed table`);
  // the form w on the labels (bd·mja·23, bd·mjp·31, bd·mjp·22, bd·mjp·38, bd·mja·36, bd·mjg·28, bd·mjp·32): after the line of the clock sum, the charge, the product, the frame; after the Pin line, the integer weights
  ok(/^on disjoint addresses \(a ∩ b = ∅\) w adds, w\(a \+ b\) = w\(a\) \+ w\(b\): it is a Z_\{4\} charge with w\(a\) = Σ ε_\{j\} over the generators of a, the popcount mod 4 for Cl\(n,0\) \(bd·mja·23, n ≤ 6\); among all quadratic forms Q′ on the addresses, π \+ 2Q′ adds on disjoint addresses exactly for the 2\^\{n\} forms of the cells with squares ±1 \(bd·mja·23, n ≤ 5\); with null generators the form that adds gives them charge 0, as in the exponent of the clock sum, while π \+ 2Q on all of V gives a null generator charge 1 and adds on disjoint addresses only for Cl\(0,0,1\) and Cl\(0,1,1\) \(n ≤ 4; bd·mjp·31\)$/.test(clk[5]), `${lang}: w is a Z4 charge on disjoint labels; additivity singles out the forms of the cells; with null bits the additive form gives them charge 0`);
  ok(/^the clock sum is the product Π_\{j\}\(1 \+ i\^\{ε_\{j\}\}\) over the generators \(bd·mjp·31, every ε in \{\+1, −1, 0\}\^\{n\}, n ≤ 6\), the grand partition function of n modes with charges ε_\{j\} at the fugacity i: the clock is its phase, and a null generator is a zero mode, a factor 2 with no phase/.test(clk[6]) && /reading the sum as a partition function is ours$/.test(clk[6]) && COPY[lang].tabs.clock.glance.tags[6][0] === 'checked ours', `${lang}: the clock sum as a partition function: the product is checked, the reading ours`);
  ok(/^the disjoint sum of addresses is frame data: its automorphisms are the n! permutations of the generators \(n ≤ 3; bd·mja·36, bd·mjp·38\)/.test(clk[7]) && /one frame on which w is the charge Σ ε_\{j\} for every cell Cl\(p,q\) with n ≤ 3 and for Cl\(4,0\) and Cl\(0,4\), and two for Cl\(1,3\), Cl\(2,2\) and Cl\(3,1\), where \|O\(V, w\)\| = 12, 8, 12 \(bd·mjp·38\); which frame is used is an input$/.test(clk[7]), `${lang}: the disjoint sum is frame data, two frames from n = 4`);
  ok(/^positive integer weights k_\{j\} on the generators, added over the generators of an address and read mod 4, give a Z_\{4\} refinement of the dot product exactly when every k_\{j\} is odd; it is then the form w of the cell with ε_\{j\} = \+1 for k_\{j\} ≡ 1 and −1 for k_\{j\} ≡ 3 mod 4, whose Brown invariant is p − q mod 8, and the popcount gives Cl\(n,0\) and the clock n mod 8 \(bd·mjg·28, n ≤ 6, 100 random weight vectors per n\); a weight k_\{j\} ≡ 0 is a null generator of charge 0, and a weight k_\{j\} ≡ 2 gives the form of no cell \(bd·mjp·32, 884 weight vectors, n ≤ 5\)$/.test(clk[9]), `${lang}: integer weights mod 4: odd weights are the forms of the cells, a weight 2 mod 4 of none`);
  ok(!/core·B1/.test(clk.slice(5, 8).concat(clk[9]).join(' ')), `${lang}: the range line of the clock sum stays the only one that cites core·B1`);
  ok(/^The finite lens: keep the signs of the bit rule and drop the real coefficients\./.test(COPY[lang].tabs.groups.lede[0]) && /every cell is the same commutative algebra, and it is not semisimple \(bd·alg·23\)/.test(COPY[lang].tabs.groups.lede[0]) && !/replace the real numbers by the two elements 0 and 1|The bit rule keeps working/.test(COPY[lang].tabs.groups.lede[0]), `${lang}: the groups lede keeps the signs and drops the coefficients; over 0 and 1 every cell is the same algebra`);
  ok(/w\(a\) = π\(a\) \+ 2Q\(a\) mod 4/.test(COPY[lang].tabs.clock.ledeM[0]) && !/w\(a\) = \|a\| \+ 2Q/.test(COPY[lang].tabs.clock.ledeM[0]), `${lang}: the clock text writes the Z4 form as the parity plus twice the sign bit`);
  ok(/groups_check\.py \(part[si] A–F\) · log groups_check\.log · 33 mut\w+ (over|su) groups_check\.py, gtg_check\.py, labels_check\.py (and|e) bitcliff\.py/.test(g('groups').script), `${lang}: the 33 mutants are attributed to the four scripts they ran on`);
  const note = COPY[lang].checkedNote, noteY = COPY[lang].checkedNoteY;
  ok(!/README_update|v\d+(\.\d+)?\b/.test(note) && /README\.md/.test(note) && fs.existsSync('./README.md'), `${lang}: the note on the checks names a file that is in the package and no version`);
  ok(typeof noteY === 'string' && noteY.length > 30 && !/python|script|\.md|\.py|\.js|README|v\d/i.test(noteY) && !/[\^_{}√∑⟨⟩≠≤≥·]/.test(noteY), `${lang}: the Young Learner's note on the checks has no file name, no language name and no formula: ${noteY}`);
}
// the Map tree has a branch for each of the three tabs: it opens the tab's own anchor, names the tab's script and carries the flags of the tab's glance strip (plus `input` when the needs strip lists an input line)
const ANCHOR = fs.readFileSync('LabelsTabs.jsx', 'utf8').match(/LABELS_ANCHOR = \{([^}]*)\}/)[1];
const BRANCH = { clock: ['conventions', 'cv-clock', 'labels_check.py'], gauge: ['equations', 'eq-gauge', 'gtg_check.py'], groups: ['lenses', 'ln-groups', 'groups_check.py'] };
const nodesOf = flat(TREE);
for (const [id, [page, anchor, script]] of Object.entries(BRANCH)) {
  const x = nodesOf.find(y => y.id === id), parent = nodesOf.find(y => (y.kids || []).some(k => k.id === id));
  ok(!!x, `the Map tree has a branch for the ${id} tab`);
  if (!x) continue;
  ok(x.go[0] === page && x.go[1] === anchor, `${id}: the branch opens ${page}#${anchor}`);
  ok(new RegExp(`\\b${id}: '${anchor}'`).test(ANCHOR), `${id}: the anchor ${anchor} is the section id of the tab (LABELS_ANCHOR)`);
  ok(parent && parent.id === page, `${id}: the branch sits under the ${page} branch (${parent && parent.id})`);
  ok(String(x.script).split(/,\s*/).includes(script) && fs.existsSync('selfcheck/steps15_17/' + script), `${id}: the branch names ${script}, which ships in selfcheck/steps15_17`);
  const fl = new Set(COPY.en.tabs[id].glance.tags.flatMap(t => String(t[0]).split(/\s+/)));
  for (const k of ['checked', 'standard', 'ours', 'open']) ok(x.tags.includes(k) === fl.has(k), `${id}: the flag ${k} on the branch matches the glance strip of the tab`);
}
ok(!nodesOf.some(x => x.go[0] === 'labels'), 'no branch opens a page called labels (the three tabs are tabs of the Conventions, equations and lenses pages)');
// LAB-006: the Weyl map eigenvalues carry their unit, (4, −2, −2) × (−M/2r³) = (−2, 1, 1) M/r³, as gtg_check.py S10 and G8 compute them
for (const l of ['en', 'it']) ok(/the Weyl map of a point mass, eigenvalues \(4, −2, −2\) in units of −M\/\(2r\^\{3\}\), i\.e\. \(−2, 1, 1\)M\/r\^\{3\}, which the curvature operator of the metric reproduces/.test(COPY[l].tabs.gauge.glance.tags[1][1]), `${l}: the Weyl map eigenvalues with their unit`);
console.log(bad ? `${bad} FAILURES of ${n}` : `ALL LABELS-PAGE TESTS PASS: ${n} checks`); process.exit(bad ? 1 : 0);
