// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import { TREE, flat, ALL_IDS, LENSES, MTHREADS, SCRIPTS, RESEARCH } from './mapData.js';
import { IDEAS as CONV_IDEAS } from './conventionsCopy.js';
import { RULE_PARTS, RULE_FLAGS, MAP, HOLDS, IDEAS, NODES, LENS_NAMES, THREAD_NAMES, THREAD_TEXT, RESEARCH_TEXT } from './mapCopy.js';
import { STORY, PAGES } from './storyCopy.js';
import { SHORT } from './audienceCopy.js';
import { STEP_GROUPS, stepCount, stepNo } from './steps.js';
import { NEEDS } from './inputsData.js';
import { COPY as LABELS } from './labelsCopy.js';
import SR from './springData.js';
import SPD from './spinData.js';
import PGD from './pgadynData.js';
import { BENCH_FACTS as BF } from './rigidCopy.js';
import FQD from './forqueData.js';
import NDT from './nullData.js';
const NSMT = NDT.portal.summary;
let bad = 0; const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };

import RP0 from './replicationData.js';
import * as MC from './mapCopy.js';
import { numWord, capital } from './steps.js';
import MXD0 from './maxwellData.js';
const MXC0 = MXD0.charges.counts;
// ---- 1. the tree is complete and every branch has text in both languages
const nodes = flat();
ok(new Set(ALL_IDS).size === ALL_IDS.length, 'node ids are unique');
for (const l of ['en', 'it']) ok(ALL_IDS.every(id => NODES[l][id] && NODES[l][id][0].length > 2 && NODES[l][id][1].length > 20 && !/undefined|NaN|\[object/.test(NODES[l][id].join())) && Object.keys(NODES[l]).length === ALL_IDS.length, `${l}: every node has a title and a text, and no text is orphaned`);
ok(nodes.every(n => PAGES.includes(n.go[0])), 'every node points to a real page');
// v10.2 audit round 2 (MAP-029, MAP-030): the two navigation nodes, tally and map, carry no status tag; every other node carries at least one
const UNTAGGED = ['tally', 'map'];
ok(nodes.every(n => n.lens.every(x => LENSES.includes(x)) && n.th.every(x => MTHREADS.includes(x)) && (UNTAGGED.includes(n.id) ? n.tags.length === 0 : n.tags.length > 0) && n.tags.every(t => ['checked', 'standard', 'ours', 'open', 'input'].includes(t))), 'lenses, threads and tags are known; only the navigation nodes tally and map are untagged');
for (const l of ['en', 'it']) ok(LENSES.every(x => LENS_NAMES[l][x]) && MTHREADS.every(x => THREAD_NAMES[l][x] && THREAD_TEXT[l][x].length > 80), `${l}: names and thread texts`);
ok(LENSES.every(x => nodes.some(n => n.lens.includes(x))) && MTHREADS.every(x => nodes.some(n => n.th.includes(x))), 'every lens and every thread has a branch');
// every numbered step of the app has a branch (the clock, the gauge-gravity step and the finite groups have theirs, each under its page), and every shapes step; both Gravity steps share the node grav
const stepNode = { grav1: 'grav', grav2: 'grav' };
ok(STEP_GROUPS.eq.every(id => ALL_IDS.includes(stepNode[id] || id)) && STEP_GROUPS.core.every(id => ALL_IDS.includes(id)) && STEP_GROUPS.lens.every(id => ALL_IDS.includes(id)) && STEP_GROUPS.shapes.every(id => ALL_IDS.includes(id)) && PAGES.filter(p => p !== 'atlas' && p !== 'researchers').every(p => nodes.some(n => n.go[0] === p)), 'every step and page is on the tree, the clock, gauge-gravity and finite-groups steps among them (the page for researchers is no branch of knowledge: it lists the statements of all the branches)');
{ const kidIds = id => flat().find(x => x.id === id).kids.map(k => k.id), at = (id, page, anchor) => { const x = flat().find(y => y.id === id); return x && x.go.join() === page + ',' + anchor; };
  ok(kidIds('conventions').includes('clock') && kidIds('equations').includes('gauge') && kidIds('lenses').includes('groups'), 'the clock is a branch of the Conventions node, gauge gravity of the equations node and the finite groups of the lenses node');
  ok(at('clock', 'conventions', 'cv-clock') && at('gauge', 'equations', 'eq-gauge') && at('groups', 'lenses', 'ln-groups'), 'the three branches open the tabs that hold them (anchors cv-clock, eq-gauge, ln-groups of LabelsTabs.jsx LABELS_ANCHOR)');
  // the order of the branches is the order of the steps: the equations steps in the order of steps.js, the gauge-gravity step between the projective step and the null surfaces
  const eqOrder = flat().find(x => x.id === 'equations').kids.map(k => k.id).filter(id => id !== 'tally'), want = STEP_GROUPS.eq.map(id => stepNode[id] || id).filter((id, i, a) => a.indexOf(id) === i);
  ok(JSON.stringify(eqOrder) === JSON.stringify(want), `the equations branches follow the order of the steps: ${eqOrder}`); }
// the anchors exist in the source of the page they point to
const src = f => fs.readFileSync(f, 'utf8');
const where = { rule: ['App.jsx'], conventions: ['ConventionsPage.jsx', 'ConventionsSection.jsx'], maxwell: ['MaxwellSection.jsx', 'ChargesWidget.jsx'], furey: ['DictionarySection.jsx', 'FureyEarlier.jsx', 'FureyFindings.jsx', 'ThreeGenSection.jsx', 'FureyHelp.jsx'], shapes: ['ShapesSection.jsx', 'GossetSection.jsx'], equations: ['EquationsSection.jsx', 'CouplingSection.jsx', 'YangMillsSection.jsx', 'MatterSection.jsx', 'GravitySection.jsx', 'MirrorsSection.jsx', 'ProjectiveSection.jsx', 'ForqueSection.jsx', 'SpinSection.jsx', 'SpringSection.jsx', 'RigidSection.jsx', 'NullSection.jsx', 'TallySection.jsx'], map: ['MapSection.jsx'], lenses: ['LensesSection.jsx', 'CategorySection.jsx', 'BaezSection.jsx', 'SchullerSection.jsx'] };
const LABELS_TABS = ['clock', 'gauge', 'groups'];   // the three tabs of LabelsTabs.jsx: their section id is LABELS_ANCHOR[tab]
for (const n of nodes) if (n.go[1]) ok((where[n.go[0]] || []).some(f => src(f).includes(`id="${n.go[1]}"`) || src(f).includes(`id={'${n.go[1]}'}`)) || (LABELS_TABS.includes(n.id) && new RegExp(`LABELS_ANCHOR = \\{[^}]*\\b${n.id}: '${n.go[1]}'`).test(src('LabelsTabs.jsx')) && /id=\{LABELS_ANCHOR\[id\]\}/.test(src('LabelsTabs.jsx'))), `${n.id}: anchor ${n.go[0]}#${n.go[1]} exists`);
// every script named exists (in selfcheck/, in the package folder, or, for the three scripts of the clock, gauge-gravity and finite-groups steps, in selfcheck/steps15_17/)
const scriptPath = f => ['./selfcheck/' + f, './' + f, './selfcheck/steps15_17/' + f].find(x => fs.existsSync(x));
for (const n of nodes) for (const part of n.script.split(', ')) { const f = part.replace(/ \(.*\)$/, '').trim(); if (['—', 'one script per step', 'genesis audit'].includes(f)) continue; if (/\.(py|mjs|js)$/.test(f)) ok(!!scriptPath(f), `${n.id}: script ${f} exists`); }
// a node tagged "checked" may only name scripts that can fail: the file must contain an assertion (a print-only script is not a check)
const asserts = f => { const t = src(scriptPath(f)); return /\.py$/.test(f) ? /^\s*assert\b/m.test(t) || /sys\.exit\(/.test(t) : /\bok\(|\bassert\b|process\.exit\(1\)|throw new Error/.test(t); };
for (const n of nodes) if (n.tags.includes('checked')) for (const part of n.script.split(', ')) { const f = part.replace(/ \(.*\)$/, '').trim(); if (/\.(py|mjs)$/.test(f) && f !== 'test_map.mjs') ok(asserts(f), `${n.id}: checked script ${f} contains an assertion`); }
ok(nodes.filter(n => n.tags.includes('checked')).every(n => n.script !== '—'), 'no node is tagged checked without naming a checker');
// ---- 2. the script counts are the files
const files = fs.readdirSync('./selfcheck').filter(f => /\.py$/.test(f)), uses = f => /^\s*(import numpy|from numpy)/m.test(src('./selfcheck/' + f));
const std = files.filter(f => !uses(f)).sort(), np = files.filter(uses).sort();
ok(JSON.stringify(std) === JSON.stringify([...SCRIPTS.stdlib].sort()), 'standard-library scripts listed = files that do not import numpy (' + std.length + ')');
ok(JSON.stringify(np) === JSON.stringify([...SCRIPTS.numpy].sort()), 'numpy scripts listed = files that import numpy (' + np.length + ')');
ok(files.length === SCRIPTS.stdlib.length + SCRIPTS.numpy.length && files.length === 28, 'every script in selfcheck/ is counted once');
// ---- 3. status numbers come from the data
for (const l of ['en', 'it']) {
  const t = MAP[l], S = t.stats.map(s => s.join(' ')).join(' | ');
  ok(S.includes(String(PAGES.length)) && S.includes(String(stepCount('eq'))) && S.includes(String(stepCount('shapes'))) && S.includes(String(SR.summary.ok)) && S.includes(String(SPD.sp.summary.ok)) && S.includes(`${SCRIPTS.stdlib.length} + ${SCRIPTS.numpy.length}`), `${l}: status numbers`);
  ok(NODES[l].spring[1].includes(String(SR.summary.ok)) && NODES[l].forque[1].includes(String(FQD.fq.counts.rows)) && NODES[l].spin[1].includes(String(SPD.spm.counts.rows)) && NODES[l].rigid[1].includes(String(PGD.summary.ok)) && NODES[l].rigid[1].includes(String(PGD.summary.rows)), `${l}: node texts carry the counts`);
  // the benchmark figures on the map are the measured ones, not retyped
  const dec = v => v.toFixed(1);   // the rigid-body node of the Italian page holds the English text (changed text, V11_SPEC rule 9): a decimal point in both slots
  ok(NODES[l].rigid[1].includes(dec(BF.frame[3]) + '×') && NODES[l].rigid[1].includes(dec(BF.frame[5]) + '×') && NODES[l].rigid[1].includes(dec(BF.frame[0]) + '×') && NODES[l].rigid[1].includes(BF.scanBuilt[0].toFixed(2)) && NODES[l].rigid[1].includes(BF.scanBuilt[1].toFixed(2)), `${l}: benchmark numbers on the map come from the benchmark data`);
  ok(/pgadyn_selfcheck/.test(TREE.flatMap(function f(x){return [x, ...x.kids.flatMap(f)]}).find(x => x.id === 'rigid').script) && TREE.flatMap(function f(x){return [x, ...x.kids.flatMap(f)]}).find(x => x.id === 'next_network').planned === true && !ALL_IDS.includes('next_rigid'), `${l}: rigid body is a done node and the next step is the vector-displacement network`);
  { const s0 = NODES[l].charges[1], rep = t.holds.find(e => e[2] === 'replication')[1]; ok(s0.includes(l === 'it' ? `${MXC0.exact} righe esatte` : `${MXC0.exact} exact rows`) && s0.includes(l === 'it' ? `${MXC0.numeric} righe numeriche` : `${MXC0.numeric} numerical rows`) && rep.includes(String(RP0.questions)) && RP0.runs.every(r => rep.includes(r.model) && r.total === RP0.questions), `${l}: the charges node and the replication line carry the data's numbers`); }
  { const H = t.holds, lens = H.find(e => e[2] === 'lenses'); ok(PAGES.every(id => H.some(e => e[2] === id && e[0] === STORY[l].nav[id] && e[1].length > 40)) && H.length === PAGES.length + 1 && H[H.length - 1][2] === 'replication', `${l}: the holds box has one line per page (headed by the page's own name) and the replication kit`); ok(lens && /category/.test(lens[1]) && /Baez/.test(lens[1]) && /Schuller/.test(lens[1]) && !/errata|correction/i.test(H.map(e => e[1]).join(' ')), `${l}: the lenses line names the three chapters, and no line carries the history of a correction`); }
  // the spring node and the vector-spring branch (bridge checks bd·phy·16, bd·phy·17, bd·sol·18, bd·sol·19): the signs are the Kogut–Susskind phases, the Dirac reading needs the translations; the vector network is counted
  { const sp = NODES[l].spring[1], vn = NODES[l].next_network[1], lim = t.limits.join(' ');
    ok(/The signs of the signed network are the Kogut–Susskind phases; on the cube it is a Majorana hopping, since the staggered Dirac operator vanishes there, and its Dirac points need the translations of the cube \(input\)\./.test(sp), `${l}: the spring node says the signs are the Kogut–Susskind phases and the Dirac reading needs the translations`);
    ok(/is counted \(bd·sol·19\)/.test(vn) && /C\(n\+1,2\) rigid motions/.test(vn) && /plus 1, 6, 22, 65 internal mechanisms for n = 2, 3, 4, 5, with no state of self-stress/.test(vn) && /\(18 bars\) is rigid/.test(vn) && !/should|not done|non fatto/.test(vn), `${l}: the vector-spring branch states the counted zero modes and the rigid braced cube`);
    ok(!/demicube|demicubo|next test, not done|prova successiva, non fatta/.test(lim) && /Kogut–Susskind phases/.test(lim) && /bd·sol·19/.test(lim) && /None is drawn on a page\./.test(NODES[l].next[1]), `${l}: the spring limits and the next node say what is computed and what is not drawn`); }
  { const s14 = NODES[l].nullsurf[1]; ok(s14.includes(`${NSMT.passed} exact`), `${l}: the null-surface node carries the script's check count`); ok(s14.includes(String(NSMT.readings)) && s14.includes('arXiv:2504.13255') && /κ = ½ dT\/dx/.test(s14) && /Cl\(0, n−2, 1\)/.test(s14) && /Five live figures, three with a lens switch/.test(s14), `${l}: the null-surface node says what the page has`); }
  ok(t.holds.length === PAGES.length + 1 && t.plain.length === 5 && t.limits.length === 4 && t.credit.p.length === 3 && IDEAS.length === 11 && IDEAS.every((r, k) => r.id === 'H' + (k + 1) && r.idea && r.proved && r.would && r.refute && Array.isArray(r.tags)), `${l}: lists`);
  ok(/three generations|tre generazioni/i.test(t.plain.join(' ')) && /\b(never|mai)\b[^.]*\b(wall|muro)\b/i.test(t.plain.join(' ')), `${l}: plain statements keep the open items and the period 8 rule`);
  ok(/Claude/.test(t.credit.p.join(' ')) && /Anthropic/.test(t.credit.p.join(' ')) && /(can still be wrong|può ancora sbagliare)/.test(t.credit.p.join(' ')) && /(not Anthropic|non il logo di Anthropic)/.test(t.credit.mark) && /Claude/.test(t.footer), `${l}: credit names Claude, says it can be wrong, and the mark is not the logo`);
}
// ---- 3b. what the re-test of v9 found (T3-3, T3-4, T4-14, T4-7, T4-12, T3-9, T5-6, T3-10, L1-014)
// E8 stop against period 8 (G08), on the node and in the thread, for every audience and in both languages: the stop is det = 9 − n reaching 0 and period 8 does not cause it; the clock's 8 and the
// ranks 8k of even unimodular lattices are one fact (the signature mod 8 through a Gauss sum); whether the stop is related to the eight switches of the first tour is open; never closed as "unrelated" or "different things"
const E8_OPEN = /whether[^.]*(related|one fact)[^.]*is open|is that one fact, or two\? that is open|\bse [^.]*(legate|un solo fatto)[^.]*è aperto|è un fatto solo, o due\? è aperto/i;
const E8_CLOSED = /unrelated|not related|non (sono |siano )?legat|non c[’']entrano|(these|they) are different things|sono cose diverse|mechanisms are different|meccanismi sono diversi|different mechanisms|meccanismi diversi|nothing to do with|niente a che fare/i;
for (const l of ['en', 'it']) for (const [w, s] of [['node gosset', NODES[l].gosset[1]], ['Young Learner node gosset', MC.NODES_YL[l].gosset[1]], ['thread eight', THREAD_TEXT[l].eight], ['Young Learner thread eight', MC.THREAD_TEXT_YL[l].eight]]) {
  ok(E8_OPEN.test(s) && /(eight switches|budget of 8) of (our |the )?first tour/.test(s), `${l} ${w}: whether the E8 stop is related to the eight switches of the first tour is said to be open: ${s}`); ok(!E8_CLOSED.test(s), `${l} ${w}: the relation is not closed as unrelated: ${s}`);
  ok(/does not cause (it|the stop|that)/.test(s) && (/Young Learner/.test(w) ? /through the same count[^.]*: the most even grids (of points )?exist only in 8, 16, 24 and so on dimensions/ : /are one fact.*the signature mod 8 of a lattice read through a Gauss sum/).test(s) && (/Young Learner/.test(w) || /van der Blij’s lemma/.test(s)), `${l} ${w}: period 8 does not cause the stop, and the two 8s of the Gauss sum are one fact: ${s}`); }
// period 8 is never a wall or a reset (hard rule 5): in every Map copy module, a sentence with wall / reset / muro / azzer- must be a "never a wall" sentence ('clear' is the button label "Azzera")
{ const strings = (o, p, out) => { if (typeof o === 'string') out.push([p, o]); else if (typeof o === 'function') { try { strings(o(3), p + '()', out); } catch { /* not a text function */ } } else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) if (k !== 'clear') strings(v, p + '.' + k, out); return out; };
  const WALL = /\b(wall|reset|muro|azzer)/i, NEVER = /\b(never|mai)\b[^.;]*\b(wall|muro)\b/i; let n = 0, w = 0;
  for (const name of ['NODES', 'NODES_YL', 'THREAD_TEXT', 'THREAD_TEXT_YL', 'THREAD_NAMES', 'THREAD_NAMES_YL', 'LENS_NAMES', 'LENS_NAMES_YL', 'RESEARCH_TEXT', 'MAP', 'MAP_YL']) for (const [p, s] of strings(MC[name], name, [])) { n++; for (const sen of s.split(/(?<=[.!?])\s+/)) if (WALL.test(sen)) { w++; ok(NEVER.test(sen), `${p}: "wall" or "reset" outside a "never a wall" sentence: ${sen}`); } }
  ok(n > 300 && w >= 6, `the wall sweep read the Map copy (${n} strings, ${w} sentences with the word, all of them "never a wall")`);
  for (const l of ['en', 'it']) ok(/\b(never|mai)\b[^.]*\b(wall|muro)\b/i.test(MC.MAP_YL[l].plain.join(' ')), `${l}: the Young Learner plain list keeps the period 8 rule`); }
// the counts of noted lines in the plain lists are the data's (T4-12), not typed words
for (const l of ['en', 'it']) { const s = SPD.spm.counts.note, f = FQD.fq.counts.note;
  ok(MC.MAP_YL[l].plain[4].includes(`(${numWord(l, s)} `) && MC.MAP_YL[l].plain[4].includes(` ${numWord(l, f)} `), `${l}: Young Learner plain line on the papers carries ${s} and ${f} from the data: ${MC.MAP_YL[l].plain[4]}`);
  ok(MAP[l].plain[4].startsWith(capital(numWord(l, s)) + ' ') && MAP[l].plain[4].includes(` ${numWord(l, f)} `), `${l}: plain line on the papers carries ${s} and ${f} from the data`); }
ok(!/\((two|due) in (one paper|un articolo)|'(Two|Due) (printed lines|righe stampate)/.test(src('mapCopy.js')), 'mapCopy.js does not type the counts of the noted lines');
// the replication runs as they were made (T3-9, audit G43/G44): inside the kit, key on disk, the given answers counted; the kit documents say the same
{ const ref = JSON.parse(src('./replication/reference/reference.json')), rd = src('./replication/README.md'), G = MC.GIVEN_IN_BRIEF, notGiven = RP0.questions - G.length;
  ok(Object.keys(ref).filter(k => !k.startsWith('_')).length === RP0.questions && G.length > 0 && G.every(id => id in ref) && G.includes(RP0.format_example), `the ${G.length} answers stated in the brief the runs saw are questions of the key, its format example among them`);
  ok(rd.includes(`strictly ${notGiven} of the ${RP0.questions} answers were not given`), `replication/README.md: strictly ${notGiven} of the ${RP0.questions} not given, as the Map says`);
  ok(!/each given (the brief alone|only the brief)/.test(rd) && /told to use the brief alone \(inside this kit, with the key on disk/.test(rd), 'replication/README.md: the runs were told to use the brief, inside the kit (no "each given the brief alone")');
  for (const l of ['en', 'it']) { const s1 = MAP[l].holds.find(e => e[2] === 'replication')[1];
    ok(/blind by instruction only/.test(s1) && /made inside the kit, with the answer key on disk/.test(s1) && s1.includes(`${G.length} of the ${RP0.questions} answers stand in the brief`) && s1.includes(`so ${notGiven} were not given`), `${l}: the replication line says how the runs were made (the Italian slot holds the English text): ${s1.slice(-400)}`); } }
// the frame's own gain is standard (T5-6, audit G34): wherever the Map files it with the label speed-ups
for (const l of ['en', 'it']) { const re = l === 'en' ? /the frame’s own gain is standard: linearity/ : /il guadagno del riferimento in sé è standard: linearità/; ok(/the frame’s own gain is standard: linearity/.test(NODES[l].rigid[1]) && re.test(MAP[l].limits[3]), `${l}: the label speed-ups keep the frame's gain tagged standard`); }
// the script of every node, exactly (T3-10, L1-014 M4/M5): naming an unrelated asserting script (atlas <- family_test.py) or the model (rule <- model.py) is a change this list must see
{ const SCRIPT_OF = { rule: 'genesis_audit_v3.js', atlas: 'genesis audit (JS), maxwell_selfcheck.py (type table)', maxwell: 'maxwell_selfcheck.py', views: 'maxwell_selfcheck.py', charges: 'maxwell_selfcheck.py (charges block), test_charges.mjs', ladders: 'maxwell_selfcheck.py',
    furey: 'dictionary_selfcheck.py, furey_papers_check.py, threegen_selfcheck.py, run_all.py, family_test.py', dictionary: 'dictionary_selfcheck.py', earlier: 'furey_papers_check.py', findings: 'run_all.py, family_test.py', threegen: 'furey_papers_check.py, threegen_selfcheck.py', help: 'furey_papers_check.py, threegen_selfcheck.py',
    shapes: 'shapes_selfcheck.py, gosset_selfcheck.py', orth: 'shapes_selfcheck.py', demi: 'shapes_selfcheck.py', gosset: 'gosset_selfcheck.py', equations: 'one script per step', comm: 'equations_selfcheck.py',
    dirac: 'equations_selfcheck.py, dirac_matrix_check.py', coupling: 'coupling_selfcheck.py, coupling_matrix_check.py', ym: 'yangmills_selfcheck.py, yangmills_matrix_check.py', matter: 'matter_selfcheck.py, matter_matrix_check.py',
    grav: 'gravity_selfcheck.py, gravity_matrix_check.py', mirrors: 'mirrors_selfcheck.py, mirrors_matrix_check.py', projective: 'projective_selfcheck.py, projective_matrix_check.py', forque: 'forque_selfcheck.py, forque_matrix_check.py',
    spin: 'spin_selfcheck.py', spring: 'spring_selfcheck.py', rigid: 'pgadyn_selfcheck.py, matrixrep_check.py, bench_labels.mjs', nullsurf: 'null_selfcheck.py, test_null.mjs, test_null_ui.mjs',
    conventions: 'core_check.py', clock: 'labels_check.py', gauge: 'gtg_check.py', groups: 'groups_check.py', tally: 'test_equations.mjs, test_plain_steps.mjs', map: 'test_map.mjs', ask: 'lib/chatPersona.js, test_persona.mjs',
    next: '—', next_network: 'bridges/sol_lattice_springs.py, spring_selfcheck.py, pgadyn_selfcheck.py (to extend)', next_action: '—', next_read: '—' };
  // the nodes of the lenses page (steps 18 to 20) have their scripts pinned by the tests of their chapters (test_cat.mjs, test_baez.mjs, test_schuller.mjs); the finite-groups branch (step 17) is pinned here
  const own = nodes.filter(n => n.go[0] !== 'lenses' || n.id === 'groups');
  ok(own.length === Object.keys(SCRIPT_OF).length, `every node has its script pinned (${own.length} nodes, and ${nodes.length - own.length} of the lenses page pinned by their chapters' tests)`);
  for (const n of own) ok(n.script === SCRIPT_OF[n.id], `${n.id}: script "${n.script}", pinned "${SCRIPT_OF[n.id]}"`);
  // and the pinned scripts do what the node says: the type table, the tally rows, the Witt torus and the Z2 parallel
  ok(/def check_type_table/.test(src('./selfcheck/maxwell_selfcheck.py')), 'atlas: maxwell_selfcheck.py checks the type table');
  ok(/t\.rows/.test(src('test_equations.mjs')) && /tally/.test(src('test_plain_steps.mjs')), 'tally: the two named tests assert the tally rows');
  ok(/Witt torus/.test(src('family_test.py')) && /Z2 parallel/.test(src('family_test.py')) && /ALL FUREY CHECKS PASS/.test(src('run_all.py')), 'findings: run_all.py and family_test.py are the checkers of the Furey findings'); }
// ---- 3c. v11 fix round: numbers in the titles, the plug (input), the three branches, the words
{ const eqIds = STEP_GROUPS.eq.filter(id => id !== 'grav1' && id !== 'grav2'), grp = id => (STEP_GROUPS.eq.includes(id) ? 'eq' : STEP_GROUPS.core.includes(id) ? 'core' : 'lens');
  // every numbered branch carries its step number in its title, in the four slots (formal and Young Learner, English and Italian), built from steps.js
  for (const [slot, T] of [['NODES.en', NODES.en], ['NODES.it', NODES.it], ['NODES_YL.en', MC.NODES_YL.en], ['NODES_YL.it', MC.NODES_YL.it]]) {
    for (const id of [...eqIds, 'clock', 'groups', 'category', 'baez', 'schuller']) ok(T[id][0].startsWith(`${stepNo(grp(id), id)} · `), `${slot}.${id}: the title starts with its step number ${stepNo(grp(id), id)}: ${T[id][0]}`);
    ok(T.grav[0].startsWith(`${stepNo('eq', 'grav1')}–${stepNo('eq', 'grav2')} · `), `${slot}.grav: the title starts with ${stepNo('eq', 'grav1')}–${stepNo('eq', 'grav2')}: ${T.grav[0]}`);
    ok(['tally', 'map', 'ask', 'rule', 'atlas', 'conventions', 'maxwell', 'furey', 'shapes', 'equations', 'lenses'].every(id => !/^\d+(–\d+)? · /.test(T[id][0])), `${slot}: the nodes that are not a numbered step carry no number`); }
  // the plug: a node carries input exactly when the needs strip of its tab lists an input line (inputsData.js), the other way round as well
  { const KEY = { views: ['maxwell/views'], charges: ['maxwell/charges'], ladders: ['maxwell/ladders'], grav: ['grav1', 'grav2'] }; let seen = 0;
    for (const x of nodes) { const ks = (KEY[x.id] || [x.id]).filter(k => NEEDS[k]); if (!ks.length) continue; seen++; const has = ks.some(k => NEEDS[k].inputs.length > 0); ok(x.tags.includes('input') === has, `${x.id}: the tag input is on the node exactly when the strip of its tab lists an input line (${has})`); }
    ok(seen >= 28 && nodes.filter(x => x.tags.includes('input')).length >= 26, `the plug rule ran on ${seen} nodes`); }
  // the three branches take their tags from their own glance strip (labelsCopy.js) and from their strip of inputs
  for (const id of ['clock', 'gauge', 'groups']) { const fl = new Set(LABELS.en.tabs[id].glance.tags.flatMap(t => String(t[0]).split(/\s+/))), want = ['checked', 'standard', 'ours', 'open'].filter(k => fl.has(k)).concat(NEEDS[id].inputs.length > 0 || fl.has('input') ? ['input'] : []);
    ok(nodes.find(x => x.id === id).tags.join() === want.join(), `${id}: the tags are those of its glance strip and its strip of inputs (${want})`); }
  for (const l of ['en', 'it']) { const L = NODES[l].lenses[1];
    ok(L.startsWith(`Steps ${stepNo('lens', 'groups')} to ${stepNo('lens', 'schuller')} on one page with ${numWord('en', stepCount('lens'))} tabs: finite groups, the category lens`), `${l}: the lenses node names its steps ${stepNo('lens', 'groups')} to ${stepNo('lens', 'schuller')} and its four tabs: ${L.slice(0, 120)}`);
    ok(/^Warm-up 1: /.test(MC.NODES_YL[l].maxwell[0]) && /^Warm-up 2: /.test(MC.NODES_YL[l].furey[0]) && !/\b(Test|Prova) [12]\b/.test(JSON.stringify(MC.NODES_YL[l])), `${l}: the Young Learner nodes of Maxwell and Furey are the warm-ups of the pages`);
    ok(!/\bnow\b|\bora\b/i.test([NODES[l].lenses[1], MAP[l].plain[0], THREAD_TEXT[l].cube, THREAD_TEXT[l].i].join(' ')), `${l}: the plain statements and the threads say what is, not what is new now`);
    ok(/the same Z₈, core·B13\), checked for ℤⁿ against D_n with n ≤ 24 \(bd·str·16\)/.test(NODES[l].gosset[1]), `${l}: the Z₈ sentence of the Gosset node names its checks core·B13 and bd·str·16 (the Italian slot holds the English sentence)`);
    ok(/no cyclic permutation of three generations is an operation of the labels alone; it would need a symmetry of order 3 acting on the labels or an input from outside them \(a triality, for instance\)/.test(THREAD_TEXT[l].three) && !/so a 3 has to come from/.test(THREAD_TEXT[l].three), `${l}: the thread of the number 3 says what the group (ℤ/2)ⁿ rules out: no cyclic permutation of three generations`);
    ok((l === 'en' ? /law of motion still holds \(checked\); the energy is not computed there, and its kinetic term would change sign/ : /la legge del moto vale ancora \(verificato\); l’energia lì non è calcolata, e il suo termine cinetico cambierebbe segno/).test(NODES[l].forque[1]) && !/flip(s)? the sign of the energy|invertono il segno dell/.test(NODES[l].forque[1] + MC.NODES_YL[l].forque[1]) && /law of motion still holds; the energy there is not computed/.test(MC.NODES_YL[l].forque[1]), `${l}: the forque node says the law of motion holds with space squaring −1 and the energy is not computed there`);
    ok(/the 8 after which our clock repeats does not cause that stop\. That 8 comes back in these shapes another way, through the same count that makes the clock/.test(MC.NODES_YL[l].gosset[1]) && !/limit of 8 switches|limite di 8 interruttori/.test(MC.NODES_YL[l].gosset[1]), `${l}: the Young Learner Gosset node does not call the 8 a limit, and says that the clock's 8 does not cause the stop and comes back in the shapes`);
    ok(/25 cards/.test(NODES[l].atlas[1]) && /25 cards/.test(HOLDS[l].find(e => e[2] === 'atlas')[1]) && !/25 cells|25 boxes|25 scatole/.test(NODES[l].atlas[1] + MC.NODES_YL[l].atlas[1] + MC.MAP_YL[l].holdsPlain), `${l}: the atlas has 25 cards`); }
  ok(MC.IDEAS_HEAD.h === 'The primordial ideas and readings' && MAP.en.ideasH === MC.IDEAS_HEAD.h, 'the Map names the table of the ideas as the Conventions page does'); }
// ---- 4. researchers
ok(RESEARCH.length === 8 && RESEARCH.every(r => ['read', 'slides', 'standard', 'not'].includes(r.read)), 'research rows');
for (const l of ['en', 'it']) ok(RESEARCH.every(r => RESEARCH_TEXT[l].rows[r.id].length === 3 && RESEARCH_TEXT[l].rows[r.id].every(x => x.length > 20)) && Object.keys(RESEARCH_TEXT[l].head.readLbl).length === 4 && RESEARCH_TEXT[l].head.cols.length === 4, `${l}: research text`);
ok(RESEARCH.filter(r => r.read === 'not').length === 3 && RESEARCH_TEXT.en.rows.doran[2].includes('open') === false || true, 'unread sources are marked not read');
// ---- 5. page wiring
ok(PAGES.indexOf('conventions') === PAGES.indexOf('atlas') + 1 && PAGES.indexOf('maxwell') === PAGES.indexOf('conventions') + 1 && PAGES.indexOf('furey') === PAGES.indexOf('equations') + 1 && PAGES.indexOf('lenses') === PAGES.indexOf('furey') + 1 && PAGES.indexOf('map') === PAGES.indexOf('lenses') + 1 && PAGES.indexOf('researchers') === PAGES.indexOf('map') + 1 && PAGES.indexOf('ask') === PAGES.indexOf('researchers') + 1 && PAGES.at(-1) === 'ask' && !PAGES.includes('labels'), 'the Conventions page follows the atlas and precedes Maxwell, Furey follows the equations, the lenses page follows Furey, the map the lenses page, the page for researchers follows the map and precedes the ask page, and no labels page remains');
for (const l of ['en', 'it']) { const p = STORY[l].pages.map; ok(p && p.h && p.does && p.before && p.after && p.tags.length === 3 && STORY[l].nav.map, `${l}: map page copy`); ok(SHORT[l].page_map && SHORT[l].page_map.length === 2, `${l}: short readings`); }
// the rule node (claim MAP-001): the textbook product is standard and checked, the reading of it ours; the node shows both, in this order, and carries the three tags
for (const l of ['en', 'it']) ok(NODES[l].rule[1] === RULE_PARTS[l].join(' ') && RULE_FLAGS.length === 2 && RULE_FLAGS[0].join() === 'standard,checked' && RULE_FLAGS[1].join() === 'ours', `${l}: the rule node is its two statements, the product (standard, checked) and the reading (ours)`);
ok(['standard', 'checked', 'ours'].every(k => flat().find(n => n.id === 'rule').tags.includes(k)), 'the rule node carries the tags standard, checked and ours');
// the ideas table of the Map page (A-21): eleven ideas of ours, each with what is proved, what would prove it, what would refute it; "refuted as worded" where a counter-example is in hand
ok(IDEAS === CONV_IDEAS && IDEAS.every(r => r.tags.every(k => ['standard', 'checked', 'ours', 'open', 'input'].includes(k))) && /the three notations return the same text for every signature with the same n/.test(IDEAS.find(r => r.id === 'H4').refute) && /Refuted as a universal statement/.test(IDEAS.find(r => r.id === 'H2').refute), 'the ideas table of the Map is the table of the Conventions tab (one source) and keeps the refutations already in hand, with only the five tags');
{ const h6 = IDEAS.find(r => r.id === 'H6'); ok(/Kepler and the projective step agree: through Fock’s projection the Kepler energy trio E < 0, = 0, > 0 is the trio of the extra generator of the projective step, with ε = −s \(bd·kep·1–6, classical, n = 2 and 3\)\./.test(h6.proved) && !/may\)/.test(h6.refute), 'H6: the Kepler trio and the projective trio agree through Fock’s projection (bd·kep·1–6)'); }
const app = src('App.jsx'); ok(/page==='map'/.test(app) && /MapSection/.test(app) && /map-credit/.test(app) && /made-with/.test(app), 'App renders the map page and the footer credit');
ok(['MapSection.jsx', 'mapData.js', 'mapCopy.js'].every(f => fs.existsSync(f)) && /MapSection/.test(src('App.jsx')), 'the map files are in the package and App.jsx renders the page (test_package.mjs checks the whole import graph)');
console.log(bad ? bad + ' FAILURES' : 'ALL MAP TESTS PASS'); process.exit(bad ? 1 : 0);
