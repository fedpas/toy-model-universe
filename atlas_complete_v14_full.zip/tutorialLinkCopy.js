// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Text and settings of the link to the tutorial on the first page (TutorialLink.jsx), English and Italian with the same keys (test_tutorial_ui.mjs checks it).
// The tutorial is a page of its own, reports/html/bit_rule_tutorial.html (served beside the reports; it is not one of the six), and opens in a new tab.
// It is written in English for a reader of a college course, so the Italian line says so, and the audiences listed in HIDE_FOR do not see the link.
export const TUTORIAL_PAGE = 'reports/html/bit_rule_tutorial.html';
export const HIDE_FOR = ['Young Learner'];
export const TUTORIAL_LINK = {
  en: { lead: 'Coming to the rule from a college course? A tutorial reads it beside geometry, algebra, category theory and topology, one concept at a time.', open: 'Open the tutorial (new tab)' },
  it: { lead: 'Arrivi alla regola da un corso universitario? Un tutorial la legge accanto a geometria, algebra, teoria delle categorie e topologia, un concetto alla volta.', open: 'Apri il tutorial (nuova scheda, in inglese)' },
};
