// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The chat persona (lib/chatPersona.js) against the product's own data: every count it quotes is recomputed here from the data files and steps.js,
// the step list is rebuilt from steps.js, the two house rules and the honesty rules are asserted, the audience layers are checked for conflicts,
// and the statements the v8 audit retired must be absent. No assertion here can pass by construction.
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import { buildSystemPrompt, buildSystemParts, buildSystemCore, PROFILES, LANGUAGES, METRICS, LENS_BLOCK } from './lib/chatPersona.js';
import { LENS_ROWS, LENSES, LENS_MATRIX, lensDictionaryCompact, lensDictionaryForm, compactRowsShown, compactLine, shortName } from './lensDictionaryData.js';
import os from 'os'; import path from 'path'; import { pathToFileURL } from 'url';
import { STEP_GROUPS, NAV_NAMES, stepCount, stepNo, stepTotal, numWord } from './steps.js';
import { PAGES } from './storyCopy.js';
import M from './maxwellData.js';
import Tg from './threegenData.js';
import SH from './shapesData.js';
import GS from './gossetData.js';
import EQ from './equationsData.js';
import EQC from './equationsCopy.js';
import MR from './mirrorsData.js';
import PJ from './projectiveData.js';
import FQD from './forqueData.js';
import BENCH from './benchData.js';
import MRX from './matrixrepData.js';
import SPD from './spinData.js';
import SRD from './springData.js';
import PGD from './pgadynData.js';
import K from './nullData.js';
import NC from './nullCopy.js';
import DICT from './dictionaryData.js';
import CP from './couplingData.js';
import MT from './matterData.js';
import GV from './gravityData.js';
import { RESEARCH } from './mapData.js';
import { RESEARCH_TEXT } from './mapCopy.js';
import { KINDS, NEEDS } from './inputsData.js';
const J = JSON.parse(fs.readFileSync('./furey_results.json', 'utf8'));
const BJ = JSON.parse(fs.readFileSync('./selfcheck/bench_labels.json', 'utf8'));
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const has = (s, sub, m) => ok(s.includes(sub), m + ' (expected: ' + sub.slice(0, 90) + ')');
const lacks = (s, re, m) => ok(!(typeof re === 'string' ? s.includes(re) : re.test(s)), m + ' (retired: ' + String(re).slice(0, 90) + ')');

// ---- every variant: 2 languages x 3 audiences x 2 metrics x 2 modes
const P = buildSystemPrompt({ spokenLang: 'it', userProfile: 'Physicist', metricMode: 'Temporal', isMatchMode: true });
const Q = buildSystemPrompt({ spokenLang: 'en', userProfile: 'Young Learner', metricMode: 'Spatial' });
const C = buildSystemCore();
const ALL = []; for (const l of LANGUAGES) for (const u of PROFILES) for (const mm of METRICS) for (const x of [false, true]) ALL.push({ spokenLang: l, userProfile: u, metricMode: mm, isMatchMode: x });
ok(ALL.length === 24 && ALL.every(c => { const p = buildSystemParts(c); return p.core === C && buildSystemPrompt(c) === C + '\n\n' + p.tail; }), 'the core is identical for every reader (so it can be cached) and the prompt is core + tail');
ok(ALL.every(c => { const s = buildSystemPrompt(c); return !/\$\{|undefined|NaN|\[object/.test(s); }), 'no leftover template, undefined or NaN in any variant');
ok(P.length - LENS_BLOCK.length < 50500, 'lean: ' + (P.length - LENS_BLOCK.length) + ' chars besides the generated lens dictionary (the limit is 50500: the story, every layer, the lens chapters, the starting ideas and the strip kinds)');
ok(C.includes(LENS_BLOCK) && LENS_BLOCK.length <= 9216, 'the lens dictionary block is in the fixed core and holds at most 9 KB (9216 characters): ' + LENS_BLOCK.length);
ok(P.length < 50500 + 9216, 'lean as a whole: ' + P.length + ' chars (at most 50500 plus the 9 KB of the lens dictionary)');
has(P, 'Reply in Italian.', 'language named in full (it)'); has(Q, 'Reply in English.', 'language named in full (en)'); lacks(P + Q, /Reply in "/, 'bare language code');
has(P, 'Metric mode: "Temporal" (the mirror reading', 'metric interpolated (Temporal)'); has(Q, 'Metric mode: "Spatial" (the base reading', 'metric interpolated (Spatial)'); has(P, 'Audience: "Physicist"', 'audience interpolated');

// ---- audience layers: one rule per audience, compare mode never overrides it (G27)
const tail = c => buildSystemParts(c).tail;
for (const l of LANGUAGES) for (const mm of METRICS) for (const x of [false, true]) {
  const yl = tail({ spokenLang: l, userProfile: 'Young Learner', metricMode: mm, isMatchMode: x });
  ok(!/\[R, C\] address and algebra|begin with its \[R, C\]/.test(yl) && !/Write every formula in LaTeX/.test(yl) && !/PEER-REVIEW MODE \(on/.test(yl), `Young Learner (${l}, ${mm}, compare ${x}): no [R, C] opening, no LaTeX, no peer-review block`);
  ok(/No formulas, no LaTeX or other formula markup/.test(yl) && /no \[R, C\] addresses/.test(yl) && /5 XOR 3 = 6/.test(yl) && !/- Physicist:|- Mathematician:/.test(yl), `Young Learner (${l}, ${mm}, compare ${x}): plain words, the simplest sums, only its own audience line`);
  ok(x ? /COMPARE MODE \(on\)/.test(yl) && /The Young Learner rule above still holds/.test(yl) : /Peer-review mode is off\./.test(yl), `Young Learner compare mode keeps the audience rule (${l}, ${mm}, ${x})`);
  for (const u of ['Physicist', 'Mathematician']) {
    const t = tail({ spokenLang: l, userProfile: u, metricMode: mm, isMatchMode: x });
    ok(/begin with its \[R, C\] address and algebra/.test(t) && /Write every formula in LaTeX/.test(t) && t.includes(`- ${u}:`) && !/- Young Learner:/.test(t), `${u} (${l}, ${mm}): address and LaTeX, only its own audience line`);
    ok(x ? /PEER-REVIEW MODE \(on; the reader is comparing two models side by side\): within the audience rule above/.test(t) : /Peer-review mode is off\./.test(t), `${u} peer-review mode follows compare mode (${x})`);
  }
}
ok(!/begin with its \[R, C\] address|Write every formula in LaTeX|PEER-REVIEW MODE/.test(C), 'the core carries no response-shape or peer-review instruction (they are per audience)');
// re-test T1-6: the Physicist line asks for Standard Model language only where SHAPE_COMMON allows it (the question is about Standard Model content)
for (const l of LANGUAGES) for (const mm of METRICS) for (const x of [false, true]) { const t = tail({ spokenLang: l, userProfile: 'Physicist', metricMode: mm, isMatchMode: x }), line = t.split('\n').find(s => s.startsWith('- Physicist:')) || '';
  ok(line.includes('gauge and representation language (generations, hypercharge, chirality) where the question is about Standard Model content') && !/language: generations, hypercharge/.test(line) && t.includes('Mention generations, hypercharge or other Standard Model content only when the question is about Standard Model particles'), `Physicist line and the response shape agree (${l}, ${mm}, ${x}): ${line}`); }
has(C, 'Quote a result only with its tag (checked / standard / ours / open / input) and say when it comes from the page\'s data rather than from a calculation you did', 'ledger rule: quote with tag (five tags)');
has(C, 'from three starting ideas of ours (the Genesis story, tag ours)', 'the starting ideas are named as ours'); has(C, 'STARTING IDEAS (ours, the Genesis story; no result below depends on them; the shapes page uses the node names 2n and 16 only as names for Cl(n,n) and Cl(8,8))', 'the block of the starting ideas says no result depends on them, and what the shapes page does use'); lacks(C, /three axioms|\nAXIOMS\n/, 'no axioms');
// v11 fix round (V6-03, V6-23, V1-16, V6-17): the step numbers inside the equations layer are those of steps.js, the heading says what the section does, the atlas has cards, and the eleven primordial ideas are named
has(C, `the step-${stepNo('eq', 'coupling')} current is the same formula`, 'the current of the coupling step is named by its step number'); has(C, `weight-2 corners are the step-${stepNo('eq', 'comm')} planes`, 'the planes of the commutator step are named by its step number'); has(C, `the bivectors B of step ${stepNo('eq', 'ym')} act by LEFT multiplication`, 'the Yang–Mills step is named by its step number');
lacks(C, /step-3 current|step-1 planes/, 'the numbers of the step-3 current and the step-1 planes are the old ones');
has(C, '\nHOW TO READ THE TYPES AND THE TWO MODES\n', 'the section heading says what the section does'); lacks(C + P, /HOW TO DERIVE/, 'no section is headed with the word derive'); has(P, 'see HOW TO READ THE TYPES AND THE TWO MODES', 'the tail points to the section by its heading');
has(C, `- Step ${stepNo('core', 'clock')}, the clock. checked:`, 'the first step of the story is the clock'); lacks(C, /Step 1, labels/, 'step 1 is not called labels');
has(C, '2 The atlas: 25 cards Cl(p,q), each with an audit status', 'the atlas has 25 cards'); lacks(C, /25 cells/, 'no 25 cells');
has(C, 'The Conventions page lists eleven primordial ideas and readings, H1 to H11, all ours', 'the eleven primordial ideas are named'); has(C, 'H10, physics from the bit rule alone, is refuted as worded', 'H10 is refuted as worded');
has(C, 'The pairing is an extra datum, not a consequence of the null seed', 'idea B: the pairing is an extra datum'); has(C, 'is a convention for this pair', 'the sign of a pair is a convention'); lacks(C, /gauge choice/, 'no gauge choice for a sign');
has(C, 'A and B reach only these neutral and radical cells; Cl(0,10), Cl(5,5), Cl(1,9) and Cl(16,0) also occur in the atlas', 'idea C is a scope, with the cells beyond it'); has(C, 'The type table is a theorem about the bit rule (T4 on the For researchers page), not a consequence of the starting ideas', 'T4 gives the type table');
lacks(C, /never recall a result you cannot recompute/i, 'the ledger rule no model can follow'); lacks(C, /compute them, never recall them/, 'recall rule in HOW TO DERIVE'); lacks(C, /recompute counts \(/, 'recompute-everything rule in the Furey layer');
lacks(P, /256 test/, 'undefined "256 test"'); has(C, 'The Furey tabs are the Dictionary (every Standard Model particle and gauge generator of one generation', 'the Dictionary is defined');
has(C, 'Three generations (the test of the 256 real dimensions of End(V)=M₁₆(ℝ) for three generations)', 'the 256 test is defined as the Three generations tab');
ok(Tg.dimensions.real_total === 256, 'the 256 real dimensions are the data\'s');

// ---- the page map and the step list come from steps.js (G23)
const nEq = stepCount('eq'), nSh = stepCount('shapes');
const wantEq = STEP_GROUPS.eq.map(id => `${stepNo('eq', id)} ${NAV_NAMES.en[id]}`).join(' · '), wantSh = STEP_GROUPS.shapes.map((id, i) => `${i + 1} ${NAV_NAMES.en[id]}`).join(' · ');
has(C, `6 More equations, ${numWord('en', nEq)} steps, labelled "STEP k OF ${stepTotal('eq')}" (steps ${stepNo('eq', STEP_GROUPS.eq[0])} to ${stepNo('eq', STEP_GROUPS.eq.at(-1))}): ${wantEq}.`, 'equations step list and count from steps.js');
has(C, `5 More shapes, ${numWord('en', nSh)} steps: ${wantSh}`, 'shapes step list and count from steps.js');
ok(nEq === 15 && STEP_GROUPS.eq.at(-1) === 'rigid' && C.includes(`${stepNo('eq', 'nullsurf')} Null surfaces`) && C.includes(`${stepNo('eq', 'rigid')} A rigid body`) && C.includes(`step ${stepNo('core', 'clock')}, ${NAV_NAMES.en.clock}`), 'the clock (step 1), null surfaces (step 13) and the rigid body (step 16) are in the story list');
lacks(C, new RegExp(`STEP k OF (?!${stepTotal('core')}\\b|${stepTotal('eq')}\\b|${stepTotal('lens')}\\b)\\d+|\\bk OF 13\\b`), 'a step total other than steps.js (every step of the story, the clock, the equations page and the lenses page, counts to 20)');
has(C, `the portal has ${numWord('en', PAGES.length)} pages, labelled "PAGE k OF ${PAGES.length}"`, 'page count from storyCopy.js');
ok(EQC.en.t.rows.length === nEq + 1 && C.includes(`and the ${nEq} steps of page 6 are ${numWord('en', nEq + 1)} things drawn and checked`), 'Maxwell + the steps = the tally rows of the equations page');
// every "(step k" of a layer names the step steps.js gives it
const SEQ = [[/Coupling \(step (\d+)/, 'coupling'], [/Yang–Mills \(step (\d+)/, 'ym'], [/Charged matter \(step (\d+)/, 'matter'], [/Gravity \(steps (\d+), \d+/, 'grav1'], [/Gravity \(steps \d+, (\d+)/, 'grav2'], [/Mirrors \(step (\d+)/, 'mirrors'], [/Projective \/ conformal \(step (\d+)/, 'projective'], [/Forque dynamics \(step (\d+)/, 'forque'], [/Spinors \(step (\d+)/, 'spin'], [/Springs \(step (\d+)/, 'spring'], [/tesseract \(step (\d+)/, 'rigid'], [/Labels, benchmarked \(step (\d+)/, 'rigid'], [/matrix route \(step (\d+)/, 'rigid'], [/Step (\d+) does not do/, 'rigid'], [/Null surfaces \(step (\d+)/, 'nullsurf'], [/spring network \(step (\d+)\)/, 'spring'], [/rigid bodies \(step (\d+)\)/, 'rigid'], [/Steps (\d+), \d+ and \d+ take/, 'spin'], [/Steps \d+, (\d+) and \d+ take/, 'nullsurf'], [/Steps \d+, \d+ and (\d+) take/, 'forque'], [/kinds of i of step (\d+)/, 'spin'], [/the dynamics are step (\d+)/, 'forque'], [/null mirrors \(a·a=0: step (\d+)\)/, 'projective'], [/the spinor paper of step (\d+)/, 'spin'], [/null-surface paper of step (\d+)/, 'nullsurf'], [/only as Cl\(N\+8\)=M₁₆\(Cl\(N\)\) for N=0\.\.3 \(step (\d+)\)/, 'rigid']];
for (const [re, id] of SEQ) { const m = C.match(re); ok(m && Number(m[1]) === stepNo('eq', id), `step number of ${id} (${re}) = ${stepNo('eq', id)}: ${m && m[1]}`); }
ok(/Gosset series \(step (\d+)/.exec(C)?.[1] === String(stepNo('shapes', 'gosset')), 'Gosset step number from steps.js');
ok([...C.matchAll(/\bsteps? (\d+)/gi)].every(m => Number(m[1]) <= stepTotal('lens')), 'no step number beyond the last step (20, the last step of the lenses page)');

// ---- step 13, null surfaces: source, numbers and limits as the page states them (L8-010)
const NS = K.portal.summary, en = NC.en, minus = s => s.replace('-', '−');
has(C, `Null surfaces (step ${stepNo('eq', 'nullsurf')}; null_selfcheck.py, exact fractions, standard library: ${NS.computed} computed checks, ${NS.passed} pass; ${NS.readings} readings are ours and are not computed)`, 'step 13 counts are null.json\'s');
ok(NS.computed === NS.passed, 'every computed null check passes');
has(C, 'Source: Hsu, Barker, Hobson and Lasenby (arXiv:2504.13255); four of its claims', 'step 13 source'); ok(en.lede.includes('Hsu, Barker, Hobson and Lasenby (arXiv:2504.13255)') && /four claims/.test(en.lede), 'the page names the same source and four claims');
has(C, `κ for five horizons: ${K.portal.kappa.map(k => minus(k.kappa)).join(', ')}`, 'κ of the five horizons are null.json\'s'); ok(K.portal.kappa.length === 5, 'five horizons in the data');
ok(en.cards[0].text[1].includes('= 1/30 at five polar angles') && C.includes('dφ/dt=a/(r₊²+a²)=1/30 at five polar angles'), 'Kerr photon rate as the page states it');
ok(K.portal.kerr.at(-1).r === '9' && K.portal.kerr.at(-1).n2 === '0' && en.kerrText.includes('M = 5, a = 3, r₊ = 9') && C.includes('M=5, a=3, r₊=9'), 'Kerr parameters are the data\'s and the page\'s');
ok(K.portal.ladder.map(r => r.n).join() === '2,3,4,5,6' && K.portal.ladder.every(r => r.dim === 2 ** (r.n - 1) && r.J === 2 ** (r.n - 2)) && C.includes('for n=2..6 the tangent algebra of a null hypersurface is Cl(0,n−2,1)') && C.includes('dimension 2^{n−2}'), 'horizon algebra range and ideal dimension are the data\'s');
for (const [tag, line] of en.limits) ok(tag === 'open', 'the page tags each limit open: ' + line.slice(0, 40));
ok(en.limits[0][1].includes('Eq. (12)') && C.includes('Eq. (12) of the paper is not rebuilt'), 'limit: Eq. (12) not rebuilt');
ok(en.limits[1][1].includes('Vishveshwara’s Appendix B and the abstract of Vollick') && C.includes("only Vishveshwara's Appendix B and the abstract of Vollick were read"), 'limit: two references read');
ok(/One author wrote both the claims and the checks/.test(en.limits[2][1]) && C.includes('one author wrote both the claims and the checks, and no second reader has gone through them'), 'limit: one author, no second reader');
has(C, '"by contrast with the induced-metric approach" is a difference of presentation (ours, not computed)', 'step 13 reading tagged ours');
has(C, 'reading J as a facet of the cube and as the star of a vertex is ours', 'step 13 second reading tagged ours');

// ---- G24: the force terms are the contraction terms (true in any dimension), not "half the incidences"
const FC = M.charges.rows.find(r => r.id === 'force_is_contraction').terms;
has(C, `Its terms are the contraction terms of ∇F=J: same edges, same targets, with ∂ replaced by the velocity and a fixed sign rule (${FC[2]}, ${FC[3]} and ${FC[4]} terms in 2, 3 and 4 space dimensions: two per edge)`, 'force terms as ChargesWidget words them');
ok(fs.readFileSync('./ChargesWidget.jsx', 'utf8').includes('Its terms are the contraction terms of ∇F = J'), 'the page words them the same way');
for (const [d, k] of [[2, '1,2'], [3, '1,3'], [4, '1,4']]) { const nn = d + 1, contract = M.cells[k].incidences.filter(i => i.op === 'contract').length; ok(FC[d] === contract && FC[d] === nn * (nn - 1), `d=${d}: ${FC[d]} force terms = ${contract} contraction incidences = two per edge`); }
lacks(C, /half the ∇F incidences/, 'half the ∇F incidences');

// ---- G25: the Prime lens speaks of dimensions only; where odd primes come from stays in the OPEN list
has(C, 'Prime (in the cell view only the prime 2 appears, since the dimension 2ⁿ of a cell is a power of 2; grade counts such as C(3,1)=3 are not cell dimensions and can be odd;', 'Prime lens restricted to dimensions'); has(C, 'each switch has its own prime and a box is the product of its switches\' primes, the names being notation only, ours', 'the Dictionary names boxes by primes, as notation');
lacks(C, /factors of every count/, 'every count is a power of 2'); lacks(C, /can only enter through extra input/, 'odd primes enter only through extra input');
ok(JSON.stringify(DICT.ladder.find(r => r.n === 3).odd_primes_in_grade_counts) === '[3]', 'the dictionary data: the first odd prime in the grade counts is 3, at n=3');
const OPEN = C.slice(C.indexOf('OPEN (say'), C.indexOf('STATUS DISCIPLINE'));
ok(OPEN.includes('odd primes and continuous parameters'), 'odd primes stay open');

// ---- G26: linearity as the equations page says it, not compressed
const NOTE = EQC.en.t.note, lin = NOTE.slice(NOTE.indexOf('Maxwell, bivector commutators'), NOTE.indexOf(' We drew'));
ok(lin.length > 200 && C.includes(lin), 'linearity sentences copied from equationsCopy.js word for word');
lacks(C, /the rest are not/, 'the first three are linear, the rest are not'); has(C, 'x″=−Lx', 'the spring network is still written as the linear x″=−Lx');

// ---- G45: the not-read list says which works, on which subject; read sources are not listed as unread
lacks(C, /(Roelfs|Eelbode)[^.;]*were not read/, 'Roelfs/Eelbode "were not read"'); lacks(C, /the Lasenbys and Doran were not read/, 'the bare not-read list');
has(C, 'Not read, on dynamics: Doran and Lasenby, Geometric Algebra for Physicists', 'not-read list names works and subject');
// re-test T1-6: the list names Dechant, who is not a row of the Map's researchers table (mapData RESEARCH), so it is not introduced as that table
ok(!/researchers table/.test(C) || !/Dechant/.test(C) || /dechant/i.test(JSON.stringify(RESEARCH)), 'the not-read list is not called the Map\'s researchers table while it names someone the table lacks');
ok(RESEARCH.find(r => r.id === 'roelfs').read === 'read' && C.includes('"From Invariant Decomposition to Spinors" v1.1 (arXiv 2401.01142), read in full'), 'the spinor paper is read (mapData) and said to be read');
for (const id of ['doran', 'exp', 'visual']) { ok(RESEARCH.find(r => r.id === id).read === 'not', `${id} is "not read" in mapData`); const who = RESEARCH_TEXT.en.rows[id][0].split(/[;,]/)[0].replace(/^Roelfs and De Keninck.*/, 'graded symmetry groups').replace(/^Joan Lasenby.*/, 'Joan Lasenby, Hamish Todd, Freya Holmer and Stephen Mann'); has(C, who, `not-read work of the ${id} row named`); }
has(C, 'Eelbode, Roelfs and De Keninck on outer exponentials', 'outer exponentials named as not read');

// ---- G06 / L6-019 and G05: period 8 is a repeat of types from the standard table; closure is not shown
lacks(C, /More of the same, nothing new/, 'nothing new (unqualified)'); has(C, 'Same type, 16 times the matrix size: nothing new in type; what the repeat means is open.', 'nothing new in type');
ok(OPEN.includes('what the period-8 repeat means'), 'what the repeat means is open');
has(C, 'tag standard, not derived from A, B, C', 'types and period 8 tagged standard'); lacks(C, /checked to k=11/, 'period 8 checked to k=11');
ok(C.includes('Cl(N+8)=M₁₆(Cl(N)) for N=0..3') && MRX.period8.map(x => x.N).join() === '0,1,2,3', 'the explicit period-8 construction covers N=0..3');
ok(C.includes('Cl(k,k)=M_{2^k}(ℝ) to n=10') && Math.max(...MRX.counts.rep_sizes) === 10, 'the explicit representation goes to n=10');
// re-test V1-9: the matrix route's "checked to n=10", and the Clifford spring network's D²=nI and two levels n±√n, each 2^{n−1} times (springData.clifford, and the bit rule)
ok(C.includes(`(standard fact, our representation, checked to n=${Math.max(...MRX.counts.rep_sizes)})`), 'matrix route: checked to the largest representation the data holds');
{ const cl = SRD.clifford, ns = Object.keys(cl).map(Number);
  ok(ns.length >= 3 && ns.every(n => cl[n].frequencies_squared === `${n} +- sqrt(${n})` && cl[n].multiplicity_each === 2 ** (n - 1)), 'springData: levels n ± √n, each 2^{n−1} times, for n=' + ns.join(','));
  const pop = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; }, sg = (a, b) => { let s2 = 0, x = a >> 1; while (x) { s2 += pop(x & b); x >>= 1; } return s2 & 1 ? -1 : 1; };   // Cl(n,0): every generator squares to +1
  const dsq = n => { const N = 1 << n, D = Array.from({ length: N }, () => Array(N).fill(0)); for (let x = 0; x < N; x++) for (let i = 0; i < n; i++) D[(1 << i) ^ x][x] += sg(1 << i, x); return D.every((row, a) => row.every((_, b) => D[a].reduce((t, v, k) => t + v * D[k][b], 0) === (a === b ? n : 0))); };
  ok([2, 3, 4, 5].every(dsq), 'the bit rule: D = Σ e_i (left multiplication) has D² = nI for n=2..5');
  has(C, 'D=Σe_i (left multiplication) has D²=nI', 'D² = nI'); has(C, 'has only two levels n±√n, each 2^{n−1} times', 'two levels n ± √n, each 2^{n−1} times'); }

// ---- G08: the E8 stop and period 8: open, never "unrelated"
lacks(C, /mechanisms are unrelated|unrelated mechanisms/, 'E8 stop and period 8 unrelated'); // v10.2 complete: the persona says what T10 (7) and the category chapter say. The stop is det = 9 - n reaching 0, the shared 8 is the Gauss-sum period, Clifford periodicity does not cause the stop; whether the two are related stays open (pin moved with the wording, now stricter).
has(C, 'The stop at E8 resembles our budget of 8, and may only be said together with this', 'E8 stop vs period 8: the clause travels with "resembles"'); has(C, 'the stop itself is det = 9 − n reaching 0', 'E8 stop is det = 9 - n'); has(C, 'Clifford periodicity does not cause the stop; whether the two are related is open', 'E8 stop vs period 8 open'); has(C, 'never call them unrelated', 'E8 rule');
ok(OPEN.includes('whether the E8 stop is related to our budget of 8 (idea C)'), 'E8 stop vs the budget of 8 in the OPEN list');
has(C, 'The 8 of E8 and that of the clock are one fact, a lattice signature mod 8 (van der Blij; standard, checked).', 'the two 8s are one fact (QD2)'); lacks(C, /the 8 the two share is the period of a Gauss-sum phase/, 'the shared 8 as a Gauss-sum period only');

// ---- G34 / L6-017 / L4-001: timings only from selfcheck/bench_labels.json; the frame's gain is standard; the fair rival is the matrix route
ok(JSON.stringify(BENCH) === JSON.stringify(BJ), 'benchData.js is bench_labels.json');
{ const r = (n, a, b) => BJ.rows.find(x => x.n === n).ns[a].med / BJ.rows.find(x => x.n === n).ns[b].med, f = v => (v >= 10 ? v.toFixed(0) : v >= 1 ? v.toFixed(1) : v.toFixed(2));
  const sp = (ns, a, b, g) => { const v = ns.map(n => r(n, a, b)); return `${g(Math.min(...v))}–${g(Math.max(...v))}×`; }, t2 = v => v.toFixed(2), all = [1, 2, 3, 4, 5, 6];
  has(C, `Timed against one sandwich per corner, n=1,2,3,4,5,6: ${all.map(n => f(r(n, 'direct', 'frame')) + '×').join(', ')}; that gain is the standard one`, 'frame vs one sandwich per corner, tagged standard');
  has(C, `The standard rival from the same frame is the matrix route (the usual column-matrix method): against it the frame is about even (matrix route time / frame time ${sp(all, 'matrix', 'frame', t2)})`, 'matrix route from the same frame is the rival');
  has(C, `Mirroring the odd half: no gain (${sp([2, 3, 4, 5, 6], 'frame', 'mirror', t2)})`, 'mirror ratios'); has(C, `beat scanning a built table ${sp(all, 'scan', 'bits', f)}, but ${sp(all, 'scanBuilt', 'bitsBuilt', t2)} once building`, 'scan ratios');
  has(C, `beats the hull ${sp([2, 3, 4, 5, 6], 'hull', 'zono', f)} on given data, ${sp([2, 3, 4, 5, 6], 'hullBuilt', 'zonoBuilt', f)} with building`, 'hull ratios');
  has(C, `n=${BJ.product.map(x => x.n).join(',')}: ${BJ.product.map(x => f(x.ns.signTable.med / x.ns.matrixRoute.med) + '×').join(', ')} (the route as written, which allocates fresh typed arrays on every call): slower at small n`, 'product ratios');
  has(C, `node ${BJ.machine.node}, one noisy ${BJ.machine.cores}-core virtual machine, batches ≥${BJ.machine.minMs} ms, median of ${BJ.machine.reps}`, 'machine line');
  ok(!/µs|microsecond/.test(C), 'no microsecond figure typed in the prompt');
  // the allocation figures are quoted from the stored run (E: bench_labels.json now holds the route with its arrays allocated once, and the allocations alone)
  has(C, `on both sides: ${BJ.product.map(x => f(x.ns.signTableReuse.med / x.ns.matrixRouteReuse.med) + '×').join(', ')}; the route's seven allocations alone took ${BJ.product.map(x => Math.round(100 * x.ns.routeAllocs.med / x.ns.matrixRoute.med) + ' %').join(', ')} of its time as written`, 'allocation figures are those of the stored run');
  ok(!/no timing of that cost is stored/.test(C) && !/quote no number for it/.test(C), 'the old "no allocation timing is stored" sentence is gone'); ok(BJ.product.every(x => x.ns.signTableReuse && x.ns.matrixRouteReuse && x.ns.routeAllocs) && Array.isArray(BJ.alloc), 'and the stored run does hold them');
  has(C, 'That a frame (n+1 sandwiches, then 2ⁿ−1 additions) replaces 2ⁿ sandwiches follows from linearity: standard; the bit label is only the addressing.', 'the frame\'s gain is tagged standard, as the page says');
  ok(/This is a standard fact; the bit label is only the address/.test(fs.readFileSync('./rigidCopy.js', 'utf8')) && !/Labels, benchmarked[^\n]*\bours\b/.test(C), 'the page calls it standard too, and the benchmark paragraph credits nothing to ours');
  has(C, 'allocation is a large part of the small-n loss and the list shows how much is left', 'small-n loss: allocation is part, the list says how much'); ok(!/allocation, not algebra/.test(C), 'and it no longer says the loss is all allocation'); }

// ---- L6-016: the parts of the 48 add up to 48
{ const gen = Object.values(Tg.sm_rows).reduce((a, x) => a + x.dim_C, 0), rep = Object.entries(Tg.linear_beyond_one_generation).reduce((a, [k, v]) => a + v * Tg.sm_rows[k].dim_C, 0);
  ok(gen === 16 && rep === 8 && gen + gen + rep + rep === Tg.dimensions.linear_off_diagonal_complex, `one generation ${gen} + conjugate ${gen} + replica ${rep} + its conjugate ${rep} = ${Tg.dimensions.linear_off_diagonal_complex}`);
  has(C, `The ${Tg.dimensions.linear_off_diagonal_complex} are all Standard-Model type: one generation (${gen}), its conjugate (${gen}), a partial replica (d_R, two L, e_R: ${rep}) and the replica's conjugate (${rep})`, '48 = 16 + 16 + 8 + 8');
  ok(Tg.linear_beyond_one_generation.L === 2 && Tg.linear_beyond_one_generation.d_R === 1 && Tg.linear_beyond_one_generation.e_R === 1, 'the replica is d_R, two L, e_R'); }

// ---- L8-004: Theorem 3 scoped to what the exact check covers
{ const S22 = SPD.spm.rows.find(r => r.id === 'S22');
  ok(/6 samples in each of d = 4 \(two signatures\) and d = 6/.test(S22.how) && S22.worked.lhs.includes('(α+βv)R: 6/6, unrelated P: 0/6'), 'S22 covers d=4 (two signatures) and d=6, six samples');
  has(C, 'd=4 (Euclid and Lorentz) and d=6, six random samples each, where (α+βv)R was a pointor every time and αR+βP with an unrelated odd versor P never', 'Theorem 3 scoped to the check');
  has(C, 'do not say that P=vR is the only form that gives a pointor', 'no "never" beyond the check');
  lacks(C, /an unrelated P is never a pointor/, 'unrelated P is never a pointor'); lacks(C, /Theorem 3 needs the odd part/, 'Theorem 3 needs P=vR');
  // L8-004 in the persona: Theorem 3 worded as a converse check, not as a line our check found to read differently (the page texts mapCopy.js and spinData.js S22 are not changed here)
  has(C, 'Theorem 3 is a remark on wording, not a failure found by the check', 'Theorem 3 is a wording remark'); has(C, 'What the check covers is the converse direction: d=4', 'the check is the converse');
  has(C, 'do not say that the check proves or refutes Theorem 3', 'no verdict on Theorem 3'); lacks(C, /Two printed lines read differently in our exact check/, 'Theorem 3 counted among lines that read differently in the check');
  ok(SPD.spm.counts.note === 2 && C.includes('Two printed lines carry a note (the two small adjustments above)'), 'the two noted lines are the data\'s two small adjustments'); }

// ---- counts quoted in the ledger, each against its data
for (const m of J.sm_matches) has(C, `${m.name.replace('nu_R', 'ν_R')} ${m.dim_C}`, 'SM content ' + m.name);
ok(J.sm_matches.reduce((a, m) => a + m.dim_C, 0) === J.sm_generation_dim && C.includes(`(${J.sm_generation_dim}ℂ: Q_L`), 'one generation is 16ℂ');
ok(C.includes('(' + J.real_blocks.join(',') + ')') && C.includes('(' + J.complex_blocks.join(',') + ')'), 'Peirce blocks');
ok(C.includes('diagonal ' + J.real_diag) && C.includes('off-diagonal ' + J.real_off) && C.includes('diagonal ' + J.complex_diag) && C.includes('off-diagonal ' + J.complex_off + 'ℂ'), 'Peirce numbers');
ok(C.includes('ten edges, largest ' + J.maxEdge.capacity_C + 'ℂ') && J.edges.length === 10, 'edges');
ok(C.includes(J.witt.diagonalising_all_block_projectors + ' of ' + J.witt.independent_commuting_grade4_quadruples), 'Witt counts');
ok(C.includes('8ℂ') && J.extras_dim === 8, 'replica edges 8ℂ'); ok(J.omega_prime_over_omega_minus_axes.length === 4 && /four axes/.test(C), 'Z2 parallel');
ok(/Three generations \(checked/.test(C) && C.includes(`Over all ${Tg.search_all.admissible_W} admissible`) && C.includes('at most one complete set fits') && C.includes('three first fit at dimension 14') && Tg.search_all.max_generations === 2 && C.includes(`hold ${Tg.exotic.antilinear} of Standard-Model type and ${Tg.exotic.antilinear} with exotic charges`) && Tg.generations.furey_frame === 1, 'three-generation layer');
{ const c = FQD.fq.counts; has(C, `A ${c.rows}-row translation matrix`, 'forque rows'); has(C, `${c.ok} agree exactly, ${c.note} agree after a small adjustment`, 'forque agreement'); has(C, `${c.not_checked} not checked`, 'forque not checked'); ok(c.ok + c.note + c.not_checked === c.rows, 'forque counts add up'); }
{ const c = SPD.spm.counts; has(C, `${c.rows} rows: ${c.ok} agree exactly, ${c.note} agree after a small adjustment, ${c.not_checked} not checked`, 'spinor counts'); ok(c.ok + c.note + c.not_checked === c.rows, 'spinor counts add up'); }
has(C, `${SRD.summary.ok} claims in ${SRD.rows.length} rows, spring_selfcheck.py`, 'spring counts'); ok(SRD.summary.ok === SRD.summary.rows, 'every spring claim passes');
has(C, `${PGD.summary.checks} claims in ${PGD.summary.rows} rows`, 'rigid-body counts'); ok(PGD.summary.ok === PGD.summary.checks && PGD.rows.length === PGD.summary.rows, 'every rigid-body claim passes');
has(C, `worst semi-major-axis error ${PGD.planets.worst_a_error.replace('%', ' %')}`, 'planets error');
ok(SRD.cube['3'].modes['1'] === 3 && C.includes('multiplicity C(n,j) at ω²=2j'), 'spring modes are binomial');
ok(/14 rows, 9 exact, 5 numeric/.test(C) && M.charges.counts.exact === 9 && M.charges.counts.numeric === 5 && M.charges.rows.length === 14, 'charges counts');
ok(/61\.35°/.test(C) && Math.abs(M.charges.numeric.relativistic_orbit.advance_degrees_formula - 61.348) < 0.01, 'Kepler advance');
ok(C.includes('4096 products in Cl(N)') && MRX.period8.every(x => x.cl_n_products_per_product === 4096 && x.operation_ratio === 16), 'period-8 product counts');
ok(/three Euclidean products/.test(C) && MRX.pga.every(x => x.products_in_euclidean_cl_n === 3), 'motor split');
// Maxwell
ok(/first ultrahyperbolic cell is \(2,2\)/.test(C) && M.cells['2,2'].symbol.class === 'ultrahyperbolic' && M.cells['2,1'].symbol.class === 'hyperbolic', 'wave-operator class');
ok(C.includes('M₂(ℝ), M₂(ℝ)², M₄(ℝ), M₄(ℂ), M₄(ℍ), M₄(ℍ)², M₈(ℍ), M₁₆(ℂ), M₃₂(ℝ)') && M.time_ladder.map(l => l.type + l.matrix_size).join() === 'R2,R22,R4,C4,H4,H24,H8,C16,R32', 'time ladder');
ok(C.includes('2, 9, 24, 50, 90, 147') && [2, 3, 4, 5, 6, 7].map(k => M.cells[Object.keys(M.cells).find(c => M.cells[c].n === k)].incidences.length).join() === '2,9,24,50,90,147', 'incidence counts');
ok(/Cl\(4,3\)=M₈\(ℝ\)²/.test(C) && M.cells['4,3'].algebra.splits_in_two && !M.cells['3,4'].algebra.splits_in_two, 'n=7 mirror pair');
ok(/J→−J/.test(C) && M.cells['2,2'].mirror.vector_equations_factor === -1, 'mirror factor');
ok(/No link between this sector and Furey/.test(C), 'no link claim');
// shapes, Gosset, equations, mirrors, projective
ok(SH.orthoplex.n8_E8.roots === 240 && /112 edges plus 128 even facets are the 240 roots of E8/.test(C), 'E8 count');
ok(JSON.stringify(SH.demicube.rows[5].even_blades_by_grade) === JSON.stringify({ 0: 1, 2: 10, 4: 5 }) && /graded 1\+10\+5/.test(C) && /grades 0,2,4/.test(C), 'n=5 grades');
ok(SH.demicube.even_subalgebra['4,4'].even === 'M8(R) + M8(R)' && SH.demicube.even_subalgebra['4,3'].full === 'M8(R) + M8(R)' && /Cl⁰\(4,4\)=M₈\(ℝ\)²=Cl\(4,3\)/.test(C), 'even half of Cl(4,4)');
ok(SH.orthoplex.n4_triality.Q8_index === 3 && /three 16-cells \(Q₈ has index 3\)/.test(C), 'triality');
ok(SH.demicube.maxwell[5].vector_equation_terms === 4 && SH.demicube.maxwell[5].trivector_equation_terms === 3 && /n−1 field components, a trivector equation 3/.test(C), 'equation supports');
ok(SH.demicube.rows[4].f_vector.join() === '8,24,32,16' && /n=3 tetrahedron, n=4 16-cell, n=5 demipenteract/.test(C), 'named demicubes');
ok(/not an identification/.test(C) && /is ours and open/.test(C), 'shapes status discipline');
ok([3, 4, 5, 6, 7, 8].map(k => GS.rank[k].det).join() === '6,5,4,3,2,1' && /\(6,5,4,3,2,1\)/.test(C) && /det\(E_n\)=9−n/.test(C), 'Gosset determinants');
ok(GS.rank[9].null_vector.join(' ') === '2 3 4 6 5 4 3 2 1' && /null vector 2 3 4 6 5 4 3 2 1/.test(C) && GS.rank[10].inertia.join() === '9,1,0' && /E10 is indefinite \(signs 9\+1\)/.test(C), 'E9 and E10');
ok([5, 6, 7, 8].map(k => GS.polytopes[k].vertices).join() === '16,27,56,240' && /Gosset polytopes 16 \(the 5-demicube\), 27, 56, 240 vertices/.test(C), 'polytope counts');
ok(GS.coordinates['8'].orthoplex_edges === 112 && GS.coordinates['8'].demicube_vertices === 128 && /E7 = 60\+2\+64, E6 = 40\+32/.test(C) && GS.coordinates['7'].orthoplex_edges_inside_first_6_axes === 60 && GS.coordinates['6'].orthoplex_edges_inside_first_5_axes === 40, 'E8, E7, E6 splits');
ok(GS.branching.total === 240 && /72\+6\+3×27\+3×27̄/.test(C) && /whether it is the model's generations is open/.test(C), 'E6 x A2');
ok(EQ.eq.commutators.by_n['4'].edges === 12 && /\(12 at n=4\)/.test(C), 'commutator count');
ok(EQ.eq.dirac.counts.incidences === 40 && EQ.eq.dirac.counts.components === 8 && /8 components, 8 equations, 40 incidences/.test(C), 'Dirac counts');
ok(SH.demicube.maxwell[4].incidences === 24 && /24 incidences in 4D/.test(C), 'Maxwell 4D incidences');
ok(EQ.matrix.worst_error < 1e-12 && /two wrong versions fail/.test(C), 'Dirac matrix check');
ok(MR.mr.e8.roots === 240 && MR.mr.e8.d8_roots === 112 && MR.mr.e8.demicube_vertices === 128 && /240 roots = 112 \+ 128 demicube vertices/.test(C) && MR.mr.ladder[4].rotors === 8, 'mirrors layer');
ok(PJ.pj.counts[4].conformal_generators === 15 && PJ.pj.doubling['4,4'].matrix_size === 16 && /four pairs give M₁₆\(ℝ\) \(the repeat of types, not a wall\)/.test(C), 'projective layer');

// ---- OPEN items are defined where the page defines them
ok(OPEN.includes('the cell of the top quark (three candidates, [7,±1], [4,+4] and [3,+1]; none derived)') && fs.readFileSync('./fureyCopy.js', 'utf8').includes('[7,±1], [4,+4] and [3,+1]'), 'top-quark item as the Findings page states it');
ok(OPEN.includes('the origin of the number 210 (=2·3·5·7') && fs.readFileSync('./genesis_audit_v3.js', 'utf8').includes('210=2·3·5·7'), '210 as the atlas states it');

// ---- re-test T1-2: the numbers and tags the earlier version of this test let through, each pinned to its data module, to the page's own words,
// or (where no data module holds it) recomputed here with the bit rule e_a e_b = s(a,b) e_{a xor b}
{ const pop = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; }, Cb = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); };
  const sgn = (a, b, sq) => { let s = 0, x = a >> 1; while (x) { s += pop(x & b); x >>= 1; } let r = s & 1 ? -1 : 1; for (let i = 0; (a & b) >> i; i++) if (((a & b) >> i) & 1) r *= sq[i]; return r; };
  const mul = (A, B, sq) => { const o = {}; for (const [a, x] of Object.entries(A)) for (const [b, y] of Object.entries(B)) { const k = Number(a) ^ Number(b); o[k] = (o[k] || 0) + sgn(Number(a), Number(b), sq) * x * y; } return o; };
  const rev = A => Object.fromEntries(Object.entries(A).map(([a, x]) => { const g = pop(Number(a)); return [a, (g * (g - 1) / 2) % 2 ? -x : x]; }));
  const SUP = { 2: '²', 3: '³', 4: '⁴', 6: '⁶', 8: '⁸' };
  const page = f => fs.readFileSync(f, 'utf8');
  // Lorentz split of the 12 non-commuting bivector pairs at n=4 (bit 0 = time): boost·boost, rotation·rotation, rotation·boost
  { const bv = []; for (let i = 0; i < 4; i++) for (let j = i + 1; j < 4; j++) bv.push((1 << i) | (1 << j)); let bb = 0, rr = 0, rb = 0;
    for (let i = 0; i < bv.length; i++) for (let j = i + 1; j < bv.length; j++) if (pop(bv[i] & bv[j]) === 1) { const t = (bv[i] & 1) + (bv[j] & 1); if (t === 2) bb++; else if (t === 0) rr++; else rb++; }
    ok(bb + rr + rb === EQ.eq.commutators.by_n['4'].edges, `the Lorentz split adds up to the data's ${EQ.eq.commutators.by_n['4'].edges} non-commuting pairs`);
    has(C, `boost·boost→rotation (${bb}), rotation·rotation→rotation (${rr}), rotation·boost→boost (${rb}) is the Lorentz algebra`, 'Lorentz split recomputed with the bit rule'); }
  // coupling: (2n+1)·2^{n−1} terms in total, 72 at n=4 (couplingData)
  { const t = CP.coupling.ladder[4].incidences_total; ok(t === 9 * 2 ** 3, `couplingData: ${t} coupling incidences at n=4 = (2n+1)·2^{n−1}`); has(C, `total (2n+1)·2^{n−1} (${t} at n=4)`, 'coupling total from couplingData'); }
  // charged matter: n(G+1)+1 terms per component, 17 at m=3, n=4 (matterData: ladder by gauge dimension m at n=4)
  { const r = MT.mt.ladder[3]; ok(r.terms_per_equation === 4 * (Cb(3, 2) + 1) + 1 && r.gauge_terms_per_equation === 4 * Cb(3, 2), `matterData: ${r.terms_per_equation} terms at m=3, n=4 = n(G+1)+1`); has(C, `n(G+1)+1 terms per component (${r.terms_per_equation} at m=3, n=4)`, 'matter terms from matterData'); }
  // gravity: independent curvature components and the Ricci + Weyl split (gravityData)
  { const cs = GV.gv.curvature_space; ok([4, 5].every(n => cs[n].dimension === n * n * (n * n - 1) / 12 && cs[n].ricci_rank + cs[n].weyl_dimension === cs[n].dimension), 'gravityData: n²(n²−1)/12 = Ricci + Weyl at n=4, 5');
    has(C, `independent components n²(n²−1)/12 (${cs[4].dimension} at n=4, ${cs[5].dimension} at 5), Ricci+Weyl ${cs[4].ricci_rank}+${cs[4].weyl_dimension}, ${cs[5].ricci_rank}+${cs[5].weyl_dimension} (linear algebra n≤7; the plane-pair reading is ours)`, 'curvature counts from gravityData, and the plane-pair reading tagged ours');
    has(C, 'at e=dx E_a is the Einstein tensor Ric−½Sδ (numpy contraction agrees; Ricci alone fails)', 'Ricci alone fails'); ok(/Ricci alone, or a trace coefficient of 1, would give a ratio that varies/.test(page('./gravityCopy.js')), 'the gravity page says the same of Ricci alone'); }
  // the 28 Peirce edges: 4 gauge, 16 matter, 8 replica (dictionaryData)
  { const d = DICT.counts; ok(d.gauge_root_edges + d.matter_edges + d.replica_edges === d.edges && d.edges === Cb(8, 2), `dictionaryData: ${d.edges} = ${d.gauge_root_edges} + ${d.matter_edges} + ${d.replica_edges} = C(8,2)`); has(C, `The ${d.edges} Peirce edges are ${d.gauge_root_edges} gauge, ${d.matter_edges} matter and ${d.replica_edges} replica`, 'Peirce edge split from dictionaryData'); }
  // Dirac: the determinant's exponent and the 32 cube edges (equationsData)
  { const e = Number(/\(p\^2 - m\^2\)\^(\d)/.exec(EQ.eq.status.checked.join(' '))?.[1]); ok(e === 4, `equationsData: the dispersion determinant is (p²−m²)^${e}`); has(C, `Determinant (p²−m²)${SUP[e]} exact`, 'Dirac determinant exponent from equationsData');
    const ce = EQ.eq.dirac.counts.cube_edges_used_by_derivative; ok(ce === 4 * 2 ** 3, `equationsData: ${ce} = the edges of the 4-cube`); has(C, `the derivative terms are the ${ce} edges of the 4-cube shifted by J's bits`, 'Dirac cube edges from equationsData'); }
  // RK4 on a rotor: |R(iθ)|² with R(z)=1+z+z²/2+z³/6+z⁴/24, exact integer polynomial arithmetic over 576
  { const re = [576, 0, -288, 0, 24], im = [0, 576, 0, -96], sq = Array(9).fill(0); for (const p of [re, im]) p.forEach((a, i) => p.forEach((b, j) => { sq[i + j] += a * b; }));
    const D = 576 * 576, g = (a, b) => (b ? g(b, a % b) : Math.abs(a)), fr = c => [c / g(c, D), D / g(c, D)];
    ok(sq[0] === D && sq[2] === 0 && sq[4] === 0 && fr(sq[6])[0] === -1 && fr(sq[8])[0] === 1, 'RK4: |R(iθ)|² = 1 − θ⁶/a + θ⁸/b exactly');
    const [a72, b576] = [fr(sq[6])[1], fr(sq[8])[1]]; has(C, `(energy factor 1−h⁶/${a72}+h⁸/${b576})`, 'RK4 energy factor recomputed'); ok(page('./rigidRows.js').includes(`h⁶/${a72} + h⁸/${b576}`), 'the rigid-body page prints the same factor'); }
  // one Euler step of M′=−½MB from M=1 with B=b·e12 (Cl(2,0)): M M̃ by the bit rule
  { const h = 0.2, b = 1.7, M1 = { 0: 1, 3: -h * b / 2 }, s = mul(M1, rev(M1), [1, 1])[0];
    const pick = Object.entries({ '1+(hb/2)²': 1 + (h * b / 2) ** 2, '1+(hb)²': 1 + (h * b) ** 2, '1−(hb/2)²': 1 - (h * b / 2) ** 2 }).find(([, v]) => Math.abs(v - s) < 1e-12)?.[0];
    ok(pick === '1+(hb/2)²', `one Euler step: M M̃ = ${s} by the bit rule (${pick})`); has(C, `one Euler step leaves the motor group (M M̃=${pick})`, 'Euler motor norm recomputed'); ok(page('./rigidCopy.js').includes('hb/2)²'), 'the rigid-body page says (hb/2)² too'); }
  // orthoplex faces C(n,m)·2^m, demicube 2^{n−1} vertices and 2^{n−2}C(n,2) edges, the 24 unit quaternions (shapesData)
  { const L = SH.orthoplex.ladder; ok([1, 2, 3, 4, 5, 6, 7, 8].every(n => L[n].faces_by_vertices.every((f, i) => f === Cb(n, i + 1) * 2 ** (i + 1))), 'shapesData: orthoplex faces with m vertices = C(n,m)·2^m for n=1..8'); has(C, 'C(n,m)·2^m faces with m vertices', 'orthoplex face count');
    const R = SH.demicube.rows; ok([3, 4, 5, 6].every(n => R[n].f_vector[0] === 2 ** (n - 1) && R[n].f_vector[1] === 2 ** (n - 2) * Cb(n, 2)), 'shapesData: demicube vertices 2^{n−1}, edges 2^{n−2}C(n,2) for n=3..6'); has(C, '2^{n−1} vertices, 2^{n−2}C(n,2) edges', 'demicube counts');
    const t = SH.orthoplex.n4_triality; ok(t.union_is_group_of_order === 3 * t.vertices_8v && t.Q8_index === 3, `shapesData: the union of the three 16-cells is a group of order ${t.union_is_group_of_order}`); has(C, `the ${t.union_is_group_of_order} unit quaternions are three 16-cells (Q₈ has index ${t.Q8_index})`, 'unit quaternions from shapesData'); }
  // the space ladder Cl(1,d): pseudoscalar central with I²=+1 (maxwellData.ladder, d=0..8)
  { const ds = M.ladder.filter(r => r.pseudoscalar_central && r.pseudoscalar_square === 1).map(r => r.d); ok(ds.join() === '0,4,8' && M.ladder.filter(r => r.splits_in_two).map(r => r.d).join() === ds.join(), `maxwellData: I central with I²=+1 at d=${ds.join(',')}, exactly where the algebra splits`); has(C, `I²=+1 (algebra splits in two) at d=${ds.join(', ')}`, 'space-ladder I² from maxwellData'); }
  // chirality ψ↦IψJ with I=γ0γ1γ2γ3 (mask 15) and J=γ2γ1 (mask 6): XOR on the labels
  { const x = 15 ^ 6; has(C, 'J=γ₂γ₁', 'J is γ₂γ₁'); has(C, `the chirality ψ↦IψJ is XOR ${x}`, 'chirality XOR recomputed'); ok(page('./spinCopy.js').includes(`XOR ${x} chirality`), 'the spinor page says the same'); }
  // tags: the page's own status words, quoted exactly
  has(C, 'Wave-operator type: the classification by min(k,d)', 'wave-operator type: the classification is computed'); has(C, 'check_T18.py part F', 'hyperbolicity for Lorentzian signatures is checked (T18(f))'); has(C, 'is standard PDE theory, not proved by the script', 'well-posedness stays standard, not proved');
  has(C, 'Conformal invariance of Maxwell, Yang–Mills, massless Dirac is standard and NOT rebuilt.', 'conformal invariance not rebuilt'); ok(/conformally invariant: standard, not rebuilt here/.test(page('./projectiveCopy.js')), 'the projective page says not rebuilt too');
  has(C, `JPL was unreachable, so it is plausibility (worst semi-major-axis error ${PGD.planets.worst_a_error.replace('%', ' %')}), not verification.`, 'planets: plausibility, not verification'); ok(/plausibility only/.test(page('./rigidCopy.js')), 'the rigid-body page tags the planets plausibility only');
  has(C, 'It relabels signature; it is not time reversal and adds no new dynamics.', 'Temporal mode adds no dynamics');
  has(C, 'one scalar displacement each: x″=−Lx, L=∂₁∂₁ᵀ=n·I−adjacency (standard).', 'the spring equation exactly as the page has it (linear)'); lacks(C, /x″=−Lx[−+]/, 'no extra term after x″=−Lx');
}

// ---- house rules and honesty rules
has(C, 'Never describe period 8 as a wall, reset or end: it is a repeat of types with larger matrices, nothing new in type; and do not say that nothing new can come after it, because closure is not shown.', 'house rule 1: period 8 is never a wall, closure not shown');
has(C, 'Types repeat and the construction continues; nothing saturates.', 'house rule 1 in HOW TO DERIVE');
has(C, 'OPEN (say "open" and stop; do not fill the gap)', 'house rule 2: open items stay open'); has(C, 'An open item stays open: do not fill it with a guess, even when asked.', 'house rule 2 in STATUS DISCIPLINE');
has(C, 'Never call a reading derived.', 'readings are not derived'); has(C, 'open: not established.', 'definition of open');
has(C, 'checked: computed from the bit rule or by the portal\'s scripts.', 'definition of checked'); has(C, 'standard: textbook mathematics or physics', 'definition of standard'); has(C, 'ours: a reading we propose', 'definition of ours');
// v11 (WP2/WP3 items A-27, A-36, A-45, A-48, A-50, B-022, B-058): the wording of the lens and equation layers
has(C, 'checked: the horizon null ℓ=e_r+e_t is one element in two algebras, a paired null of Cl(1,3) (dagger partner e_t−e_r) and the generator of the radical of the tangent algebra Cl(0,2,1) (bd·str·21, bd·xph·3). ours: reading r=2M as the 0 class (a paired null of the (t,r) plane).', 'step 12: the horizon null in two algebras is checked, the 0-class reading is ours (LAB-007)'); lacks(C, /its normal as the unpaired null \(the radical\)/, 'the radical reading tagged ours'); lacks(C, /the horizon as the 0 label/, 'no horizon as the 0 label');
has(C, 'Three nulls must be named apart: an unpaired null generator (label 0, the radical), a paired null vector', 'the three kinds of null are named apart');
has(C, 'so positive cells suffice for the algebra types (as algebras with their grading; the reversion is not preserved', 'positive cells suffice for the algebra types only');
has(C, 'The generator of a null surface is a null geodesic lying in the surface (the paper’s “photon that stands still”)', 'step 13: the generator is a null geodesic, the paper\'s photon in quotation marks');
has(C, 'C(n,3) closed triangles (the index triples; from n=4 also n·C(n−1,3) open ones)', 'closed triangles are the index triples');
has(C, 'a doubly-even self-dual code of length n is a Lagrangian of w=|a| mod 4 of Cl(n,0) and exists iff 8 | n (T14, check_T14.py; standard in the ℤ₄-form language, Wood 1993 §5; the phrasing through Q and 1…1 is ours)', 'Type II codes: standard (Wood 1993 §5) and checked, the phrasing ours'); lacks(C, /proved here and unreviewed, not standard/, 'the label-form route as unreviewed');
has(C, 'A tab that checks an equation opens with a strip under the tabs: Needs names the tabs to read first, Inputs lists what the tab takes from outside the bit rule, each marked input', 'the persona knows the needs and inputs strip'); has(C, 'involution such as the reversion used for norms and currents', 'the strip kinds include the involution'); has(C, 'never say that physics follows from the bit rule alone', 'no physics from the bit rule alone');
has(C, 'Temporal mode is the mirror reading Cl(q,p): the +1 generators are named time and the −1 generators are named space', 'temporal mode names the signs');
has(C, 'Never cite empirical values to support the model.', 'no empirical support'); has(C, 'say plainly that an earlier claim (including your own) was wrong', 'correction rule');
ok(!/period 8 (is|as) (a )?(wall|reset|end)\b(?! or)/i.test(C.replace('Never describe period 8 as a wall, reset or end', '')), 'period 8 is never called a wall elsewhere');
for (const re of [/saturat(ed|ion) (fusion|threshold)/i, /time-lock/i, /Hopf Fibration Axiom/, /Mass Scaling Defect/, /4\/17/, /two generations/i, /numerolog/i, /\[Row, Column\] truncation/, /No shape on this page selects/, /selects a number of generations/]) lacks(P, re, 'stale content');

// ---- the lens dictionary (lensDictionaryData.js, generated from reports/lens_dictionary.json): the prompt carries its compact form, the rule for answering from a lens and two examples
// the block holds at most 9 KB: the rows in their order of priority (the order of the json), as many as fit with the rule and the examples, and not one row fewer
{ const rest = LENS_BLOCK.slice(LENS_BLOCK.indexOf('\nHOW TO ANSWER FROM A LENS.')), fit = 9216 - rest.length, k = compactRowsShown(LENS_ROWS, LENSES, LENS_MATRIX, fit);
  const D = lensDictionaryCompact(LENS_ROWS, LENSES, LENS_MATRIX, fit), lines = D.split('\n'), shown = LENS_ROWS.slice(0, k), left = LENS_ROWS.slice(k);
  ok(LENS_BLOCK === D + rest && C.includes(D) && D === lensDictionaryForm(LENS_ROWS, k), 'the fixed core carries the generated lens dictionary, as lensDictionaryCompact() prints it within the cap of the block');
  ok(['clock p − q mod 8', 'doubling'].every(a => shown.some(r => r.atlas === a)) && (k === LENS_ROWS.length || lensDictionaryForm(LENS_ROWS, k + 1).length + rest.length > 9216), `the block prints ${k} of the ${LENS_ROWS.length} rows, the two rows of the examples among them: the next row in the order of priority does not fit in 9 KB`);
  ok(shown.every(r => C.includes('\n' + compactLine(r) + '\n')) && shown.every(r => lines.filter(l => l.startsWith(r.id + ' ')).length === 1), `the block lists each printed row once (D01 to ${shown.at(-1).id}, in their order)`);
  ok(left.every(r => !C.includes(compactLine(r)) && !lines.some(l => l.startsWith(r.id + ' '))), `the rows after them (${left.length ? left[0].id + ' to ' + left.at(-1).id : 'none'}) are not in the prompt; the json keeps them`);
  ok(k === LENS_ROWS.length ? lines[0].startsWith(`LENS DICTIONARY (${k} rows)`) : lines[0].startsWith(`LENS DICTIONARY (${LENS_ROWS.length} rows; the first ${k}, by priority, are printed here)`), 'the first line gives the row count of the dictionary and the number printed, from the data');
  for (const t of ['HOW TO ANSWER FROM A LENS.', 'give that field\'s name first, then the atlas name and the row\'s tags', 'say partial, none or new where marked', 'say what the atlas has and that this name is not recorded', 'Never join two rows into a new equivalence.',
    'Schuller, Baez, category lens: through x', 'Furey, Hestenes/LDG, Pumplün: by the rows naming them']) has(LENS_BLOCK, t, 'the rule for answering from a lens');
  // the two examples are built from the rows: an algebra question and a string-theory question, each answered with the row's own short name, atlas name, id and tags
  const ex = (atlas, key) => { const r = LENS_ROWS.find(x => x.atlas === atlas); return r && `${shortName(r.terms[key])}, the atlas's ${r.atlas} (${r.id}; ${[r.flags.join(', '), r.scope].filter(Boolean).join('; ')}).`; };
  has(LENS_BLOCK, 'Algebra, "what is the clock?": ' + ex('clock p − q mod 8', 'alg'), 'example: an algebra question answered from its row'); has(LENS_BLOCK, 'String theory, "what is the doubling?": ' + ex('doubling', 'str'), 'example: a string-theory question answered from its row');
  ok(ex('clock p − q mod 8', 'alg').startsWith('Brown invariant') && ex('doubling', 'str').startsWith('Cl(T ⊕ T*) = End ΛT*'), 'the examples say the Brown invariant and Cl(T ⊕ T*) = End ΛT*');
  ok(C.indexOf(LENS_BLOCK) > C.indexOf('SCHULLER (step') && C.indexOf(LENS_BLOCK) < C.indexOf('OPEN (say'), 'the block sits after the lens chapters and before the OPEN list');
  ok(ALL.every(c => !buildSystemParts(c).tail.includes('LENS DICTIONARY')), 'the tail (language, audience, modes) carries no part of the dictionary');
  has(C, 'The core statements of the bit rule are the rows core·B1 to B20 of core_check.py; their names in other fields are in the LENS DICTIONARY.', 'the core rows point to the dictionary for their names');
  lacks(C, /core·B1 to B17\b/, 'the core rows are named to B20, the last row of core_check.py');
  lacks(C, /the frame-free triple \(V,Q,π\)/, 'the core rows are not described as a frame-free triple');
  // the block is a function of the data only: the persona built on a copy of the data module with one term changed carries the changed term, and nothing else of the prompt moves
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-persona-lens-')), row = LENS_ROWS.find(r => r.atlas === 'clock p − q mod 8'), old = row.terms.alg, planted = 'Planted test term; ' + old;
  const data = fs.readFileSync('lensDictionaryData.js', 'utf8'), at = data.indexOf(JSON.stringify(old));
  ok(at > 0 && data.indexOf(JSON.stringify(old), at + 1) < 0, 'the term to change occurs once in the data module');
  fs.writeFileSync(path.join(tmp, 'lensDictionaryData.js'), data.replace(JSON.stringify(old), JSON.stringify(planted)).replace(/from '\.\/([\w.]+)'/g, (m, f) => `from '${pathToFileURL(path.join(PKG, f)).href}'`));
  fs.mkdirSync(path.join(tmp, 'lib'));
  fs.writeFileSync(path.join(tmp, 'lib', 'chatPersona.js'), fs.readFileSync('lib/chatPersona.js', 'utf8').replace(/from '\.\.\/([\w.]+)'/g, (m, f) => f === 'lensDictionaryData.js' ? m : `from '${pathToFileURL(path.join(PKG, f)).href}'`));
  const P2 = await import(pathToFileURL(path.join(tmp, 'lib', 'chatPersona.js')).href), C2 = P2.buildSystemCore();
  ok(C2 !== C && C2.includes(row.id + ' ' + row.atlas + ': alg Planted test term|') && !C.includes('Planted test term'), 'a term changed in a copy of the data changes the prompt: the dictionary block is built from the data');
  ok(C2.replace(P2.LENS_BLOCK, '') === C.replace(LENS_BLOCK, ''), 'and only the dictionary block changes');
  fs.rmSync(tmp, { recursive: true, force: true }); }

// ---- scope, clock, inputs, gauges and the discovery results, as the pages and the bridge checks state them
has(C, 'The cell is the triple (V,Q,π) for r=0 (standard, Wood 1993: fixed by n and p−q mod 8), the quadruple (V,Q,π,N) for r≥1 (fixed by n, r and p−q mod 8; weight 0 on null bits forced)', 'cell scope: the triple for r = 0, the quadruple for r ≥ 1');
has(C, 'the triple does not fix the signature and forgets the reversion by one datum, definite or indefinite (checked)', 'the triple against the signature and the reversion datum (REV)');
has(C, 'the clock c=p−q mod 8 is the phase of the Gauss sum Σ_a i^{pos−neg}, for r=0 the Brown invariant of (V,w) (standard: Kirby–Taylor, Debray–Gunningham), with null bits that of the quotient Cl(p,q)', 'the clock is the Brown invariant for r = 0 (LAB-018)');
has(C, '{n,n†}=1 is the canonical anticommutation relation', 'idea B: the pairing datum is a positive inner product');
has(C, 'they differ by an overall sign, q→−q; a positive field energy fixes the relative sign of source and force (bd·sol·17)', 'Maxwell: the overall sign is q → −q');
has(C, 'with null generators a hyperbolic direction exists exactly when one sign occurs once, never strictly', 'T18(f) is the case r = 0');
has(C, 'from min(p,q)≥2 also a totally null plane, first in Cl(2,2) (T17(b), bd·geo·10, bd·xck·4)', 'T17(b): the s = 0 kinds in a non-degenerate cell');
has(C, 'One action fixes the sign of the source (input: the action; bd·phy·18–19); e is free.', 'coupling: the sign of the source comes with the action'); lacks(C, /\(no action( principle rebuilt)?\)/, 'the source sign as open for want of an action'); lacks(C, /Open: g, the action,/, 'the action listed as open');
has(C, 'the action is an input', 'Yang–Mills: the action is an input'); has(C, 'a chiral coupling needs a scalar doublet for the mass term', 'matter: chirality needs a scalar doublet');
{ const strips = Object.values(NEEDS), lines = strips.reduce((s, x) => s + x.inputs.length, 0), kinds = Object.entries(KINDS).map(([k, w]) => (k === 'involution' ? w + ' such as the reversion used for norms and currents' : w));
  has(C, `each marked input and of one kind (${kinds.join(', ')}): ${lines} input lines in ${strips.length} strips.`, 'the strip kinds and counts, read from inputsData.js');
  ok(kinds.includes('the action'), 'the action is a kind of input'); lacks(C, /\(a chart and derivative, the grade a field lives in/, 'the kinds list without the action'); }
has(C, 'A choice is a gauge when a group the algebra supplies has one orbit on the choices, a datum otherwise; a time direction carries only a time orientation, γ₀ and J on the right being a fixed reference (Conventions row 15; bd·tor·1–7).', 'gauge or datum, and the Dirac time orientation (TOR)');
has(C, 'are the bases of one Lagrangian, a gauge like ω; given them, the partition is input, a datum with 11 orbits (bd·tor·5)', 'Furey: the torus is a gauge, the partition a datum');
has(C, 'the signs are the Kogut–Susskind phases and D is a Majorana hopping, the symmetric partner of the staggered Dirac operator (bd·phy·16–17); a Dirac reading needs the translations (input)', 'springs: the signs are the Kogut–Susskind phases'); lacks(C, /the flux reading is ours/, 'the flux reading as ours');
has(C, 'vector displacements are counted, not drawn (bd·sol·19)', 'springs: vector displacements counted'); has(C, 'the C(n+1,2) rigid motions and 1, 6, 22, 65 mechanisms for n=2..5, not simulated', 'rigid body: the zero modes counted'); lacks(C, /zero modes should be the rigid motions/, 'the zero modes as open');
has(C, 'the surface gravity (retarded chart: its T=0 surface is the past horizon; no thermodynamics claimed)', 'null surfaces: the chart and κ'); has(C, "at T=0 Wigner's little group, bd·phy·5–7", 'null surfaces: iso(2) is the little group');
has(C, 'over 𝔽₂ itself every cell is one commutative algebra', 'step 17: the finite lens is the blade group and Q');
has(C, 'and onto all of O(q) for n=3…20 (bd·en·2; QT6 answered; every n: Dieudonné, a pointer)', 'step 17: QT6 answered (EN)');
has(C, 'The commutant of her 12-dimensional gauge Lie algebra is 22-dimensional and no order-3 element of it keeping the Peirce blocks moves a cell: H9 is refuted inside her model (bd·fur·2–3).', 'Furey: the commutant and H9 (FUR)');
has(C, '(the commutant of the associative Δ_SM acts by complex scalars on Q_L, u_R, L)', 'the two commutants are named apart');

// ---- the routes use this persona
for (const f of ['api/chat.js', 'api/chat-openai.js']) { const s = fs.readFileSync(f, 'utf8');
  ok(s.includes('../lib/chatPersona.js') && /buildSystem(Parts|Prompt)\b/.test(s) && !s.includes('un-fudged'), f + ' imports the persona'); ok(/export const config = \{ runtime: 'edge' \}/.test(s), f + ' edge config'); ok(!/const (profiles|languages|metrics) = new Set/.test(s), f + ' no duplicate sets'); }
console.log(bad ? `${bad} FAILURES of ${n}` : `ALL ${n} PERSONA CHECKS PASS`); process.exit(bad ? 1 : 0);
