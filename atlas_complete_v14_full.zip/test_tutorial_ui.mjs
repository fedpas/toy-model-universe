// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { PKG_DIST } from './paths.mjs';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { setLang } from './ui_helpers.mjs';
import { TUTORIAL_PAGE, TUTORIAL_LINK, HIDE_FOR } from './tutorialLinkCopy.js';
// The link to the tutorial at the end of the first page (TutorialLink.jsx), v14:
//  1. it comes right after the genesis adventure, in English and in Italian (the Italian line says the tutorial is in English); the link opens in a new tab (target _blank, rel noopener)
//     and points to the page beside the reports; a click opens that page, with its six tabs, in a new tab and leaves the first page where it was
//  2. the audiences of HIDE_FOR (Young Learner: also the audience of a first visit) do not see it; the other two do
//  3. no script error; on a phone (375 px) the page has no horizontal scroll with the link in it
// Run: node test_tutorial_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`)); };
const newCtx = async (aud, w = 1100) => { const ctx = await b.newContext({ viewport: { width: w, height: 800 } }); await ctx.addInitScript(a => { try { localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, aud); return ctx; };

ok(HIDE_FOR.length === 1 && HIDE_FOR[0] === 'Young Learner' && Object.keys(TUTORIAL_LINK.en).join() === Object.keys(TUTORIAL_LINK.it).join() && /inglese/.test(TUTORIAL_LINK.it.open) && TUTORIAL_PAGE === 'reports/html/bit_rule_tutorial.html', 'the copy: same keys in both languages, the Italian link says "in inglese", the page is beside the reports, Young Learner does not see it');

// ---- 1. the link, after the genesis adventure, in both languages
{ const ctx = await newCtx('Physicist'), pg = await ctx.newPage(); onErr(pg, 'link');
  await pg.goto('about:blank'); await pg.goto(APP + '#rule'); await pg.waitForTimeout(400);
  const L = pg.locator('[data-tutorial-link]'), A = pg.locator('[data-tutorial-open]');
  ok(await L.count() === 1 && await A.count() === 1, 'one tutorial block with one link on the first page');
  ok(await A.getAttribute('href') === TUTORIAL_PAGE && await A.getAttribute('target') === '_blank' && /noopener/.test(await A.getAttribute('rel') || ''), 'the link goes to the tutorial page, target _blank, rel noopener: ' + await A.getAttribute('href'));
  ok((await L.textContent()).includes(TUTORIAL_LINK.en.lead) && (await A.textContent()).trim() === TUTORIAL_LINK.en.open, 'English text: ' + (await A.textContent()).trim());
  const order = await pg.evaluate(() => { const g = document.querySelector('.genesis-adventure'), t = document.querySelector('[data-tutorial-link]'); return !!g && !!t && !!(g.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING) && g.nextElementSibling === t; });
  ok(order, 'the block follows the genesis adventure directly');
  await setLang(pg, 'it'); await pg.waitForTimeout(200);
  ok((await pg.locator('[data-tutorial-link]').textContent()).includes(TUTORIAL_LINK.it.lead) && (await pg.locator('[data-tutorial-open]').textContent()).trim() === TUTORIAL_LINK.it.open, 'Italian text: ' + (await pg.locator('[data-tutorial-open]').textContent()).trim());
  await setLang(pg, 'en'); await pg.waitForTimeout(200);
  await A.scrollIntoViewIfNeeded(); await pg.waitForTimeout(250);
  const y0 = await pg.evaluate(() => scrollY), hash0 = await pg.evaluate(() => location.hash);
  const [pop] = await Promise.all([ctx.waitForEvent('page'), pg.locator('[data-tutorial-open]').click()]);
  await pop.waitForLoadState('load');
  ok(pop.url().endsWith('/' + TUTORIAL_PAGE) && (await pop.title()).includes('bit rule'), 'the click opens the tutorial in a new tab: ' + pop.url().split('/').slice(-3).join('/') + ' · ' + await pop.title());
  ok(await pop.locator('[role=tab]').count() === 6 && await pop.locator('section.tp:not([hidden])').count() === 1, 'the tutorial has its six tabs, one section shown');
  ok(await pg.evaluate(() => location.hash) === hash0 && Math.abs(await pg.evaluate(() => scrollY) - y0) < 5, 'the first page stays where it was (' + hash0 + ')');
  await pop.close(); await ctx.close(); }

// ---- 2. the audiences
for (const [aud, want] of [['Young Learner', 0], ['Physicist', 1], ['Mathematician', 1]]) {
  const ctx = await newCtx(aud), pg = await ctx.newPage(); onErr(pg, aud);
  await pg.goto('about:blank'); await pg.goto(APP + '#rule'); await pg.waitForTimeout(400);
  ok(await pg.locator('[data-tutorial-link]').count() === want, `${aud}: the tutorial block is ${want ? 'shown' : 'not shown'}`);
  await ctx.close(); }

// ---- 3. a phone
{ const ctx = await newCtx('Mathematician', 375), pg = await ctx.newPage(); onErr(pg, 'phone');
  await pg.goto('about:blank'); await pg.goto(APP + '#rule'); await pg.waitForTimeout(400);
  const w = await pg.evaluate(() => [document.documentElement.scrollWidth, innerWidth]);
  ok(w[0] <= w[1] + 1 && await pg.locator('[data-tutorial-open]').isVisible(), `375 px: no horizontal scroll (${w[0]} <= ${w[1]}) and the link is visible`);
  await ctx.close(); }

await b.close();
console.log(`test_tutorial_ui: ${n - bad} ok, ${bad} failed`); process.exit(bad ? 1 : 0);
