// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The two lines of an atlas card: for the Physicist and the Mathematician every cell states a THEOREM line (what is
// standard and/or checked) and, where the cell carries a reading, a READING line (what is ours and/or open), each with its own tags.
// A cell with one kind of flag only has one line ('line'). AtlasLines.jsx draws them in place of the card prose; the Young Learner keeps the
// plain card of ylAtlas.js and never sees these lines. The theorem panel (proofs.js) keeps its own statement, sketch and caveat.
// kind: 'theorem' | 'reading' | 'line'; flags: in the order standard, checked, ours, open. A reading line never calls itself derived.
// test_proofs.mjs checks every algebra label of these lines against the bit rule and the shape of the table.
export const LINE_FLAGS = ['standard', 'checked', 'ours', 'open'];
const T = (flags, en, it) => ({ kind: 'theorem', flags, en, it });
const R = (flags, en, it) => ({ kind: 'reading', flags, en, it });
const ONE = (flags, en, it) => ({ kind: 'line', flags, en, it });

export const ATLAS_LINES = {
 Sector_Vacuum_Origin: { lines: [
  T(['checked'], 'With zero generators the algebra is spanned by the identity alone: Cl(0,0)=ℝ, dimension 2⁰=1, at cell [0,0]. It is its own mirror.',
   "Con zero generatori l'algebra è generata dalla sola identità: Cl(0,0)=ℝ, dimensione 2⁰=1, nella cella [0,0]. È il proprio specchio."),
  R(['ours'], 'Our reading: this is the baseline of every cell, since ℝ·1 sits in each of them, with no generator and no metric; “vacuum origin” is our name for it.',
   'Nostra lettura: è la base di ogni cella, perché ℝ·1 sta in ciascuna di esse, senza generatori e senza metrica; «origine del vuoto» è il nostro nome per questa cella.')] },
 Sector_Inject_Base_Real: { lines: [
  T(['checked'], 'One generator with e²=+1 gives Cl(1,0)≅ℝ⊕ℝ (cell [1,+1]). It has zero divisors, so it is not a division algebra.',
   "Un generatore con e²=+1 dà Cl(1,0)≅ℝ⊕ℝ (cella [1,+1]). Ha divisori dello zero, quindi non è un'algebra di divisione."),
  R(['ours'], 'Genesis reading (ours): this cell is a signed face of a fused pair, not something a lone null generator can turn into.',
   'Lettura della Genesi (nostra): questa cella è una faccia con segno di una coppia fusa, non qualcosa in cui un generatore nullo solitario possa trasformarsi.')] },
 Sector_Inject_Fiber_Clock: { lines: [
  T(['checked'], 'One generator with f²=−1 gives Cl(0,1)≅ℂ (cell [1,−1]). Its elements of norm 1 form U(1), the group of phases.',
   'Un generatore con f²=−1 dà Cl(0,1)≅ℂ (cella [1,−1]). Its elements of norm 1 form U(1), the group of phases.'),
  R(['ours', 'open'], 'Reading that phase as the electromagnetic phase (the “clock” of the fiber) is ours and open; nothing here yields electromagnetism.',
   "Leggere quella fase come la fase elettromagnetica (l'«orologio» della fibra) è nostro e aperto; qui nulla produce l'elettromagnetismo.")] },
 Sector_Quaternionic_Base: { lines: [
  ONE(['standard', 'checked'], 'Two generators with e²=+1 give Cl(2,0)≅M₂(ℝ) (cell [2,+2]).',
   'Due generatori con e²=+1 danno Cl(2,0)≅M₂(ℝ) (cella [2,+2]).')] },
 Sector_Quaternionic_Fiber: { lines: [
  T(['checked'], 'Two generators with f²=−1 give Cl(0,2)≅ℍ (cell [2,−2]). Its elements of norm 1 form Sp(1)≅SU(2).',
   'Due generatori con f²=−1 danno Cl(0,2)≅ℍ (cella [2,−2]). Its elements of norm 1 form Sp(1)≅SU(2).'),
  R(['ours', 'open'], 'In Furey’s construction su(2)_L comes from the quaternion multiplication algebra; reading this cell as weak isospin is that model’s choice, not a result of this cell.',
   "Nella costruzione di Furey su(2)_L viene dall'algebra di moltiplicazione dei quaternioni; leggere questa cella come isospin debole è una scelta di quel modello, non un risultato di questa cella.")] },
 Sector_Trivector_Base: { lines: [
  T(['standard', 'checked'], 'Three generators with e²=+1 give Cl(3,0)≅M₂(ℂ) (cell [3,+3]), the Pauli algebra of non-relativistic spin: σ_k = e_k. The volume element I=e₁e₂e₃ squares to −1, is central and plays the role of i.',
   "Tre generatori con e²=+1 danno Cl(3,0)≅M₂(ℂ) (cella [3,+3]), l'algebra di Pauli dello spin non relativistico: σ_k = e_k. L'elemento di volume I=e₁e₂e₃ ha quadrato −1, è centrale e fa la parte di i."),
  R(['ours'], 'Reading these three generators as the directions of space on the base is the atlas’s Spatial reading (ours).',
   "Leggere questi tre generatori come le direzioni dello spazio sulla base è la lettura Spaziale dell'atlante (nostra).")] },
 Sector_Trivector_Quark: { lines: [
  T(['standard', 'checked'], 'Two +1 generators and one −1 generator give Cl(2,1)≅M₂(ℝ)⊕M₂(ℝ) (cell [3,+1]). The volume element I=e₁e₂f₁ squares to +1 and is central, so it splits the algebra in two.',
   "Due generatori +1 e uno −1 danno Cl(2,1)≅M₂(ℝ)⊕M₂(ℝ) (cella [3,+1]). L'elemento di volume I=e₁e₂f₁ ha quadrato +1 ed è centrale, quindi divide l'algebra in due."),
  R(['ours', 'open'], 'The name “quark” for this cell is ours and open: B=2, F=1 ↦ 2/3 is only the ratio B/(B+F), not a charge computed from the algebra, and quark colour does not follow from this cell.',
   'The name “quark” for this cell is ours and open: B=2, F=1 ↦ 2/3 is only the ratio B/(B+F), not a charge computed from the algebra, and quark colour does not follow from this cell.')] },
 Sector_Trivector_Lepton: { lines: [
  T(['standard', 'checked'], 'One +1 generator and two −1 generators give Cl(1,2)≅M₂(ℂ) (cell [3,−1]), isomorphic to Cl(3,0). The volume element squares to −1 and is central. Cl(1,2) is also the even subalgebra of the spacetime algebra Cl(1,3): its elements x with x x̄ = 1 are the even versors of Cl(1,3) and form SL(2,ℂ), the spin group of special relativity; the even versors of Cl(1,2) itself form Spin(1,2) = SL(2,ℝ).',
   "Un generatore +1 e due −1 danno Cl(1,2)≅M₂(ℂ) (cella [3,−1]), isomorfa a Cl(3,0). L'elemento di volume ha quadrato −1 ed è centrale. Cl(1,2) is also the even subalgebra of the spacetime algebra Cl(1,3): its elements x with x x̄ = 1 are the even versors of Cl(1,3) and form SL(2,ℂ), the spin group of special relativity; the even versors of Cl(1,2) itself form Spin(1,2) = SL(2,ℝ)."),
  R(['ours', 'open'], 'Reading this cell as the home of charged-lepton spinors (its name “lepton”) is ours and open, not a result.',
   'Leggere questa cella come la sede degli spinori dei leptoni carichi (il suo nome «leptone») è nostro e aperto, non un risultato.')] },
 Sector_STA_Euclidean_Base: { lines: [
  ONE(['standard', 'checked'], 'Four generators with e²=+1 give Cl(4,0)≅M₂(ℍ) (cell [4,+4]). With no −1 generator this is not a spacetime algebra.',
   "Quattro generatori con e²=+1 danno Cl(4,0)≅M₂(ℍ) (cella [4,+4]). Senza generatori −1 non è un'algebra spazio-temporale.")] },
 Sector_STA_Minkowski: { lines: [
  T(['standard', 'checked'], 'Three +1 generators and one −1 generator give Cl(3,1)≅M₄(ℝ) (cell [4,+2]) with metric signature (+,+,+,−): Lorentzian (mostly plus), hence hyperbolic in Schuller’s sense, with real 4×4 gamma matrices; the real operator γ·∂ − m has the physical mass shell. Its mirror Cl(1,3)≅M₂(ℍ), where time squares +1 (Hestenes), is the cell the Dirac step uses.',
   "Tre generatori +1 e uno −1 danno Cl(3,1)≅M₄(ℝ) (cella [4,+2]) con segnatura (+,+,+,−): lorentziana (prevalentemente positiva), quindi iperbolica nel senso di Schuller, con matrici gamma reali 4×4; l'operatore reale γ·∂ − m ha il guscio di massa fisico. Il suo specchio Cl(1,3)≅M₂(ℍ), dove il tempo ha quadrato +1 (Hestenes), è la cella che usa il passo di Dirac."),
  R(['ours'], 'Which of Cl(3,1) and Cl(1,3) is called spacetime is a convention; naming this cell “Minkowski” and reading +1 as space is the atlas’s Spatial reading (ours).',
   "Quale tra Cl(3,1) e Cl(1,3) si chiami spaziotempo è una convenzione; chiamare questa cella «Minkowski» e leggere +1 come spazio è la lettura Spaziale dell'atlante (nostra).")] },
 Sector_STA_Symmetric_Core: { lines: [
  T(['standard', 'checked'], 'Two +1 and two −1 generators give Cl(2,2)≅M₄(ℝ) (cell [4,0]). Its grade-2 part is so(2,2)≅sl₂(ℝ)⊕sl₂(ℝ): 2 compact bivectors (square −1) and 4 boosts (square +1).',
   'Due generatori +1 e due −1 danno Cl(2,2)≅M₄(ℝ) (cella [4,0]). La sua parte di grado 2 è so(2,2)≅sl₂(ℝ)⊕sl₂(ℝ): 2 bivettori compatti (quadrato −1) e 4 boost (quadrato +1).'),
  R(['ours', 'open'], 'Calling it an electroweak core is an interpretation, and open: Furey’s su(2)_L comes from the quaternion multiplication algebra Cl(0,2) at [2,−2].',
   "Chiamarlo nucleo elettrodebole è un'interpretazione, aperta: l'su(2)_L di Furey viene dall'algebra di moltiplicazione dei quaternioni Cl(0,2) in [2,−2].")] },
 Sector_STA_Fiber_Frame: { lines: [
  ONE(['standard', 'checked'], 'One +1 and three −1 generators give Cl(1,3)≅M₂(ℍ) (cell [4,−2]), not the biquaternions M₂(ℂ). The volume element squares to −1. Cl(1,3) is Hestenes’ spacetime algebra (γ₀² = +1), the cell the Dirac step uses: there ∇ψJ = mψγ₀ has the physical mass shell. In the mirror Cl(3,1) the real operator γ·∂ − m has it too; the (iγ·∂ − m) printed in the notes of Schuller’s quantum lectures with η = diag(−1,1,1,1) does not, since that form belongs to the opposite convention, in which time squares to +1: a mismatch of conventions, not a problem of the cell.',
   "Un generatore +1 e tre −1 danno Cl(1,3)≅M₂(ℍ) (cella [4,−2]), non i biquaternioni M₂(ℂ). L'elemento di volume ha quadrato −1. Cl(1,3) è l'algebra dello spaziotempo di Hestenes (γ₀² = +1), la cella che usa il passo di Dirac: lì ∇ψJ = mψγ₀ ha il guscio di massa fisico. Nello specchio Cl(3,1) ce l'ha anche l'operatore reale γ·∂ − m; l'(iγ·∂ − m) stampato negli appunti delle lezioni di meccanica quantistica di Schuller con η = diag(−1,1,1,1) no, perché quella forma appartiene alla convenzione opposta, in cui il tempo ha quadrato +1: un disaccordo di convenzioni, non un problema della cella.")] },
 Sector_Row5_Base: { lines: [
  T(['standard', 'checked'], 'Four +1 and one −1 generator give Cl(4,1)≅M₄(ℂ) (cell [5,+3]) ≅ Cl(4,0)⊗ℂ ≅ Cl(2,3). The volume element squares to −1 and is central. With its null pair this is the conformal model of 3D Euclidean space used in step 11.',
   "Quattro generatori +1 e uno −1 danno Cl(4,1)≅M₄(ℂ) (cella [5,+3]) ≅ Cl(4,0)⊗ℂ ≅ Cl(2,3). L'elemento di volume ha quadrato −1 ed è centrale. Con la sua coppia nulla è il modello conforme dello spazio euclideo 3D usato nel passo 11."),
  R(['ours', 'open'], 'Reading this cell as the frame behind maximal parity violation is ours and open: parity violation is a weak-interaction fact that does not follow from this cell.',
   "Leggere questa cella come il frame dietro la violazione massima di parità è nostro e aperto: la violazione di parità è un fatto dell'interazione debole che non segue da questa cella.")] },
 Sector_Row6_Confinement: { lines: [
  T(['standard', 'checked'], 'Four +1 and two −1 generators give Cl(4,2)≅M₈(ℝ) (cell [6,+2]); Cl(5,1)≅M₄(ℍ) lives at [6,+4], a different cell. Its 15 bivectors form so(4,2), the conformal algebra of Minkowski space and the dynamical algebra of hydrogen (Baez).',
   "Quattro generatori +1 e due −1 danno Cl(4,2)≅M₈(ℝ) (cella [6,+2]); Cl(5,1)≅M₄(ℍ) sta in [6,+4], una cella diversa. I suoi 15 bivettori formano so(4,2), l'algebra conforme dello spazio di Minkowski e l'algebra dinamica dell'atomo di idrogeno (Baez)."),
  R(['ours', 'open'], 'The name “confinement” is ours and open: colour confinement is a physical statement that does not follow from this cell.',
   "Il nome «confinamento» è nostro e aperto: il confinamento del colore è un'affermazione fisica che non segue da questa cella.")] },
 Sector_Row7_Mirror: { lines: [
  T(['standard', 'checked'], 'Four +1 and three −1 generators give Cl(4,3)≅M₈(ℝ)⊕M₈(ℝ) (cell [7,+1]), dimension 128: the central ω (ω²=+1) splits it into two ideals, as at every Cl(k+1,k). The two ideals carry the same representation of Spin(4,3) and differ by the sign of every odd generator: they are the two pinor classes; the reversion exchanges them, Clifford conjugation does not. Its mirror Cl(3,4) is M₈(ℂ) at [7,−1].',
   "Quattro generatori +1 e tre −1 danno Cl(4,3)≅M₈(ℝ)⊕M₈(ℝ) (cella [7,+1]), dimensione 128: l'ω centrale (ω²=+1) la divide in due ideali, come in ogni Cl(k+1,k). The two ideals carry the same representation of Spin(4,3) and differ by the sign of every odd generator: they are the two pinor classes; the reversion exchanges them, Clifford conjugation does not. Il suo specchio Cl(3,4) è M₈(ℂ) in [7,−1]."),
  R(['ours', 'open'], 'A central split of this kind has a standard reading elsewhere: the two ideals carry the two signs of a pseudoscalar mass (Schuller, for Cl(1,4)). In the five-bit label picture of one generation (Baez–Bokor–Boyle) antiparticles are instead the complement labels (particle-hole, XOR with 1…1). Reading the two ideals as matter and antimatter is ours, and it needs a choice of anti-involution as an input.',
   "Una scissione centrale di questo tipo ha altrove una lettura standard: i due ideali portano i due segni di una massa pseudoscalare (Schuller, per Cl(1,4)). Nell'immagine a etichette di cinque bit di una generazione (Baez–Bokor–Boyle) le antiparticelle sono invece le etichette complementari (particella-lacuna, XOR con 1…1). Reading the two ideals as matter and antimatter is ours, and it needs a choice of anti-involution as an input.")] },
 Sector_Chiral_Parity: { lines: [
  T(['standard', 'checked'], 'Two +1 and three −1 generators give Cl(2,3)≅M₄(ℂ) (cell [5,−1]), isomorphic to Cl(4,1); the central volume element has ω²=−1, a complex structure.',
   "Due generatori +1 e tre −1 danno Cl(2,3)≅M₄(ℂ) (cella [5,−1]), isomorfa a Cl(4,1); l'elemento di volume centrale ha ω²=−1, una struttura complessa."),
  R(['ours', 'open'], 'The name “chiral parity” is ours and open: parity is a reflection (the grade involution of the spatial algebra), a different operation from the signature flip, and parity violation does not follow from this cell.',
   "Il nome «parità chirale» è nostro e aperto: la parità è una riflessione (l'involuzione di grado dell'algebra spaziale), un'operazione diversa dallo scambio di segnatura, e la violazione di parità non segue da questa cella.")] },
 Sector_EM_Maxwell: { lines: [
  T(['standard', 'checked'], 'The electromagnetic field is a grade-2 element F of a 4D spacetime algebra, with 6 components: in Hestenes’ form Cl(1,3)≅M₂(ℍ) (cell [4,−2]) or in its mirror Cl(3,1)≅M₄(ℝ) (cell [4,+2], the cell of this card). The Maxwell equations combine into one, ∇F = J: dF = 0 and d⋆F = J are its grade-3 and grade-1 parts. Calibration 1 checks every term exactly.',
   "The electromagnetic field is a grade-2 element F of a 4D spacetime algebra, with 6 components: in Hestenes’ form Cl(1,3)≅M₂(ℍ) (cell [4,−2]) or in its mirror Cl(3,1)≅M₄(ℝ) (cell [4,+2], the cell of this card). The Maxwell equations combine into one, ∇F = J: dF = 0 and d⋆F = J are its grade-3 and grade-1 parts. Calibration 1 checks every term exactly."),
  R(['ours'], 'Placing electromagnetism at this cell of the atlas (the card name “EM Maxwell”) is ours; no link to Furey’s model is claimed.',
   "Collocare l'elettromagnetismo in questa cella dell'atlante (il nome della scheda «EM Maxwell») è nostro; non si afferma alcun legame con il modello di Furey.")] },
 Sector_Gravity_Strain: { lines: [
  T(['standard'], 'For a frame map h, the strain is S = hᵀηh − η. It vanishes exactly when h preserves the metric η (a Lorentz map), and for h = 1 + ε its trace to first order is tr(η⁻¹S) = 2 tr ε, twice the first-order volume change.',
   'For a frame map h, the strain is S = hᵀηh − η. It vanishes exactly when h preserves the metric η (a Lorentz map), and for h = 1 + ε its trace to first order is tr(η⁻¹S) = 2 tr ε, twice the first-order volume change.'),
  R(['ours', 'open'], 'Reading S as a gravitational strain (the card name “Gravity Strain”) is only a reading of ours, and open: no field equation is built from it.',
   'Reading S as a gravitational strain (the card name “Gravity Strain”) is only a reading of ours, and open: no field equation is built from it.')] },
 Sector_Baryon_Conservation: { lines: [
  T(['standard', 'checked'], 'The cell is Cl(5,3)≅M₁₆(ℝ) at [8,+2].',
   'La cella è Cl(5,3)≅M₁₆(ℝ) in [8,+2].'),
  R(['ours', 'open'], 'A conserved baryon number is a conjecture: no grading or symmetry carrying it has been found.',
   'Un numero barionico conservato è una congettura: non è stata trovata alcuna graduazione o simmetria che lo porti.')] },
 Sector_Electroweak_Unified: { lines: [
  T(['standard', 'checked'], 'Four +1 and four −1 generators give Cl(4,4)≅M₁₆(ℝ) (cell [8,0]), self-mirror and isomorphic to Cl(0,8) and Cl(8,0).',
   'Quattro generatori +1 e quattro −1 danno Cl(4,4)≅M₁₆(ℝ) (cella [8,0]), auto-speculare e isomorfa a Cl(0,8) e Cl(8,0).'),
  R(['ours', 'open'], 'The ratio 4/17 is an internal count of neutral paths, not a weak mixing angle. Furey’s 3/8 = Tr Y / dim 𝕍 is the shift that makes Y traceless (her eq. 44); it equals numerically, but is not, the unification value sin²θ_W = Tr T₃²/Tr Q² = 3/8.',
   'Il rapporto 4/17 è un conteggio interno di percorsi neutri, non un angolo di mescolamento debole. Il 3/8 di Furey, Tr Y / dim 𝕍, è lo spostamento che rende Y a traccia nulla (sua eq. 44); coincide numericamente con il valore di unificazione sin²θ_W = Tr T₃²/Tr Q² = 3/8, ma non è quel valore.')] },
 Sector_Vacuum_Mass_Generation: { lines: [
  T(['standard', 'checked'], 'In every Clifford algebra the grade-0 part is ℝ·1 and is central. A scalar can only rescale; it cannot by itself pick out a direction or a generator.',
   'In ogni algebra di Clifford la parte di grado 0 è ℝ·1 ed è centrale. Uno scalare può solo riscalare; da solo non può scegliere una direzione o un generatore.'),
  R(['ours', 'open'], 'Reading its passive role as a sterile-neutrino state and its active role as the Higgs VEV operator is our interpretation: neither follows from the algebra, and no mass scale comes out of it.',
   "Leggere il suo ruolo passivo come stato di neutrino sterile e quello attivo come operatore del VEV di Higgs è una nostra interpretazione: nessuno dei due segue dall'algebra e non ne esce nessuna scala di massa.")] },
 Sector_GUT_Junction: { lines: [
  T(['checked'], 'Two +1 and six −1 generators give Cl(2,6)≅M₈(ℍ) (cell [8,−4]). Two counting facts hold: an 8-vertex simplex has 70 four-vertex faces, and the 8-cube has 1120 four-dimensional faces.',
   "Due generatori +1 e sei −1 danno Cl(2,6)≅M₈(ℍ) (cella [8,−4]). Valgono due fatti di conteggio: un simplesso a 8 vertici ha 70 facce da quattro vertici, e l'8-cubo ha 1120 facce di dimensione 4."),
  R(['open'], 'The value 210 = 2·3·5·7 is not derived: the lattice budget 2⁸ = 256 has no odd prime factor, and odd primes appear only outside the cell sizes, for example in the orders of the finite groups of step 17 (for GL(n,2) a prime p enters when n is the order of 2 modulo p). Whether 210 means anything is open.',
   "Il valore 210 = 2·3·5·7 non è derivato: il budget del reticolo 2⁸ = 256 non ha fattori primi dispari, e i primi dispari compaiono solo fuori dalle dimensioni delle celle, per esempio negli ordini dei gruppi finiti del passo 17 (per GL(n,2) un primo p entra quando n è l'ordine di 2 modulo p). Se 210 abbia un significato è aperto.")] },
 Sector_Cosmic_Horizon: { lines: [
  T(['standard', 'checked'], 'In the three row-8 cells with clock 0, Cl(0,8), Cl(4,4), Cl(8,0)≅M₁₆(ℝ), the volume element squares to +1, as in every row-8 cell with q even. Cl(5,3) and Cl(1,7) are M₁₆(ℝ) too, with clock 2 and a volume element of square −1. Period 8 means the types repeat: Cl(n+8)=Cl(n)⊗M₁₆(ℝ).',
   'In the three row-8 cells with clock 0, Cl(0,8), Cl(4,4), Cl(8,0)≅M₁₆(ℝ), the volume element squares to +1, as in every row-8 cell with q even. Cl(5,3) and Cl(1,7) are M₁₆(ℝ) too, with clock 2 and a volume element of square −1. Period 8 means the types repeat: Cl(n+8)=Cl(n)⊗M₁₆(ℝ).'),
  R(['ours'], 'The name “cosmic horizon” is ours: no horizon, Hubble constant or cosmological boundary follows from this cell; period 8 is a repeat of types, not a wall.',
   'Il nome «orizzonte cosmico» è nostro: da questa cella non segue alcun orizzonte, costante di Hubble o confine cosmologico; il periodo 8 è una ripetizione di tipi, non un muro.')] },
 Sector_Open_Questions: { lines: [
  T(['standard', 'checked'], 'The lattice gives the cell addresses. The algebra types are the standard mod-8 classification and are also recomputed from the squares of the labels for every cell shown (step 1). A cell is a real form Cl(p,q), finer than its triple: Cl(1,4) and Cl(5,0) have one triple, and only the first is hyperbolic.',
   'Il reticolo dà gli indirizzi delle celle. I tipi di algebra sono la classificazione standard mod 8 e sono anche ricalcolati dai quadrati delle etichette per ogni cella mostrata (passo 1). A cell is a real form Cl(p,q), finer than its triple: Cl(1,4) and Cl(5,0) have one triple, and only the first is hyperbolic.'),
  R(['ours', 'open'], 'The odd primes outside the group orders of step 17, the continuous parameters, a map from irreps to cells (it has to target the real forms, not the triples) and the number 210 are open.',
   'The odd primes outside the group orders of step 17, the continuous parameters, a map from irreps to cells (it has to target the real forms, not the triples) and the number 210 are open.')] },
 Sector_Furey_Ledger: { lines: [
  ONE(['checked'], 'End_ℝ(𝕍)≅Cl(0,8)≅M₁₆(ℝ) splits into Peirce blocks of sizes (2,6,4,2,1,1). A complex structure gives M₈(ℂ) with blocks (1,3,2,1,1). The off-diagonal parts have dimensions 194 (real) and 48ℂ (complex).',
   'End_ℝ(𝕍)≅Cl(0,8)≅M₁₆(ℝ) si divide in blocchi di Peirce di dimensioni (2,6,4,2,1,1). Una struttura complessa dà M₈(ℂ) con blocchi (1,3,2,1,1). Le parti fuori diagonale hanno dimensione 194 (reale) e 48ℂ (complessa).')] },
};
