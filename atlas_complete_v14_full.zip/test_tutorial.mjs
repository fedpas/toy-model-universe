// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The tutorial "The bit rule and four college courses" (the page reports/html/bit_rule_tutorial.html, v14) is a page beside the reports, not one of them, and it is clean:
//  - it is a page in html/, is not in index.json, in a zip or in reportsData.js; build.sh copies it to dist/reports/html/; make_package.py knows it
//  - it opens as a file: no address, no mail link, no machine path, no external request (a script, style sheet, image or frame); its links go to its own headings, to the Atlas
//    (https://toy-model-v0.vercel.app/#<page>/<tab>, a page and a tab that exist) and to the licence page; the only script is the inline one of the tabs
//  - six tabs (Part 0, A, B, C, D, closing table), each a real tab of a tab list with its own section, one shown; a print rule that shows all sections
//  - no history wording (reports/no_history.py), no first person singular, no draft or review label in the visible text
// The page is built outside the package (its builder and its 305 checks are not shipped); this test reads the page. Needs python3 for the history scan (exit 77 without).
// Run: node test_tutorial.mjs
import fs from 'node:fs'; import path from 'node:path'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(f, 'utf8');
const py = (args, opts = {}) => spawnSync('python3', args, { encoding: 'utf8', maxBuffer: 64 << 20, ...opts });
const pv = py(['-c', 'import sys']);
if (pv.error || pv.status !== 0) { console.log('SKIP: test_tutorial needs python3: ' + (pv.error ? pv.error.message : (pv.stderr || '').trim().split('\n').pop())); process.exit(77); }
const R = 'reports', PAGE = path.join(R, 'html', 'bit_rule_tutorial.html');
ok(fs.existsSync(PAGE), 'the page is in reports/html/');
const H = rd(PAGE);

// ---- beside the reports, not one of them
const idx = JSON.parse(rd(path.join(R, 'html', 'index.json')));
ok(!JSON.stringify(idx).includes('bit_rule_tutorial') && idx.reports.length === 6, 'html/index.json lists the six reports and not the tutorial');
ok(fs.readdirSync(path.join(R, 'zips')).length === 6 && !fs.readdirSync(path.join(R, 'zips')).some(z => /tutorial/i.test(z)), 'the six zips are the six reports; the tutorial has no zip');
ok(!/bit_rule_tutorial/.test(rd('reportsData.js')), 'reportsData.js (the For researchers list) does not list the tutorial');
ok(/reports\/html/.test(rd('build.sh')), 'build.sh copies reports/html/ to dist/reports/html/, where the tutorial is served');
const MP = rd(path.join(R, 'make_package.py'));
ok(MP.includes("bit_rule_tutorial.html") && Object.keys(JSON.parse(rd(path.join(R, 'MANIFEST.json'))).files).includes('html/bit_rule_tutorial.html'), 'make_package.py knows the page and MANIFEST.json lists it');
const link = rd('tutorialLinkCopy.js'); ok(link.includes("'reports/html/bit_rule_tutorial.html'"), 'the link of the first page (tutorialLinkCopy.js) points to this page');

// ---- the page opens as a file and is clean
ok(!/@/.test(H.replace(/@media|@font-face|@import|@keyframes|@supports|@page/g, '')) && !/mailto:/i.test(H), 'no "@" (no address) and no mail link in the page');
ok(!/[A-Za-z]:\\|\/tmp\/|\/home\/|\/root\/|scratchpad|claude-0/.test(H), 'no path of a machine in the page');
ok(!/<script[^>]*\ssrc=|<link[^>]*rel=["']?stylesheet|<img[^>]*src=["']?https?:|url\(\s*["']?https?:|@import|<iframe|<object|<embed/i.test(H), 'the page makes no request: no external script, style sheet, image, font or frame');
const scripts = [...H.matchAll(/<script\b[^>]*>/g)].map(m => m[0]); ok(scripts.length === 1 && scripts[0] === '<script>', 'one script, inline (the tabs): ' + scripts.join(' '));
const hrefs = [...H.matchAll(/href="([^"]*)"/g)].map(m => m[1]);
const PAGES = ['rule', 'atlas', 'conventions', 'maxwell', 'shapes', 'equations', 'furey', 'lenses', 'map', 'researchers', 'ask'];
const atlas = hrefs.filter(h => h.startsWith('https://toy-model-v0.vercel.app/#'));
ok(atlas.length > 10 && atlas.every(h => { const m = /^https:\/\/toy-model-v0\.vercel\.app\/#([a-z]+)(?:\/([a-z0-9]+))?$/.exec(h); return m && PAGES.includes(m[1]); }), `the ${atlas.length} Atlas links name a page of the app: ` + atlas.filter(h => !/^https:\/\/toy-model-v0\.vercel\.app\/#(rule|atlas|conventions|maxwell|shapes|equations|furey|lenses|map|researchers|ask)(\/[a-z0-9]+)?$/.test(h)).join(' '));
ok(hrefs.every(h => h.startsWith('#') || h.startsWith('https://toy-model-v0.vercel.app/#') || h.startsWith('https://polyformproject.org/')), 'the links go to its own headings, to the Atlas and to the licence page: ' + hrefs.filter(h => !(h.startsWith('#') || h.startsWith('https://toy-model-v0.vercel.app/#') || h.startsWith('https://polyformproject.org/'))).join(' '));
ok(/<title>The bit rule and four college courses<\/title>/.test(H) && /name="viewport"/.test(H) && /<h1[\s>]/.test(H) && H.includes('prefers-color-scheme') && H.includes('@media print'), 'title, viewport, heading, dark scheme and print rule');

// ---- six tabs
const tabs = [...H.matchAll(/role="tab"[^>]*\bid="tab-([A-Za-z0-9]+)"|\bid="tab-([A-Za-z0-9]+)"[^>]*role="tab"/g)].map(m => m[1] || m[2]);
ok(JSON.stringify(tabs) === JSON.stringify(['part0', 'partA', 'partB', 'partC', 'partD', 'closing']), 'six tabs in order: ' + tabs.join(', '));
const secs = [...H.matchAll(/<section class="tp"[^>]*\bid="([A-Za-z0-9]+)"[^>]*>/g)].map(m => m[1]);
ok(JSON.stringify(secs) === JSON.stringify(tabs) && /role="tablist"/.test(H) && !/<section class="tp"[^>]*\bhidden\b/.test(H), 'six sections with the ids of the tabs and a tab list; without the script all six are shown (the script hides five)');
ok(/section\.tp\[hidden\]\{display:block!important\}/.test(H), 'the print rule shows the hidden sections');

// ---- history wording, first person, labels
const nh = py(['-I', path.join(R, 'no_history.py'), PAGE]);
ok(nh.status === 0 && (nh.stdout || '').includes(PAGE + ' 0 hits'), 'the page holds none of the patterns of history of reports/no_history.py: ' + (nh.stdout || nh.stderr || '').split('\n').filter(l => /^ +P|[1-9]\d* hits/.test(l)).slice(0, 3).join(' | '));
const vis = H.replace(/<style[\s\S]*?<\/style>|<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ');
ok(!/(^|[^A-Za-z0-9ℝℤ𝔽_-])I (?=[a-z])(?!p,q)|\bmy [a-z]|\bme\b/.test(vis), 'no first person singular in the visible text (the symbol I p,q is not one)');
ok(!/\b[Dd]raft\b|not published|for review|\(draft\)/.test(vis), 'no draft or review label in the visible text');
for (const f of [PAGE]) ok(!/PolyForm Noncommercial 1\.0\.0/.test(H) || /Cascade Atlas authors/.test(H), 'the notice of the pictures is on the page');
console.log(`test_tutorial: ${checks - bad} ok, ${bad} failed`); process.exit(bad ? 1 : 0);
