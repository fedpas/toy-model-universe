// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_needs_ui.mjs: the "needs and inputs" strip in the browser (v11, gatherC C-013). For every deep link #page/tab of the pages with tabs, in the three audiences:
//   the strip is there exactly when inputsData.js has an entry for the tab, inside the tab's panel, after the at-a-glance strip and before the content, with the aria-label of its audience;
//   the Physicist and the Mathematician read one line for each input (one `input` badge, no status word on the chip, the kind and the text of the data); the Young Learner reads
//   the read-first row and one plain sentence, no kinds, no symbols, no jargon;
//   every need that names a tab or a page is a link #page/tab to a tab that exists and, when clicked, shows that tab (the label of a link to a tab names its page first: "Equations · 2 · Commutators"); a need that names neither is plain text, no link;
//   with the filter on known+std (both switches) every line of the strip is still visible; the same strips, in English, in the Italian reading.   Run: node test_needs_ui.mjs
import fs from 'node:fs'; import path from 'node:path';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { APP_HTML, PKG } from './paths.mjs';
import { setLang } from './ui_helpers.mjs';
import { STEP_GROUPS } from './steps.js';
import { PAGES } from './storyCopy.js';
import { NEEDS, KINDS, NEEDS_COPY } from './inputsData.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const info = m => console.log('  ' + m);
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8');
const SUBS = new Function('STEP_GROUPS', 'return ' + rd('StoryShell.jsx').match(/export const SUBS = (\{[^\n]*\});/)[1])(STEP_GROUPS);
const TABS = []; for (const p of PAGES) for (const t of SUBS[p] || []) TABS.push({ page: p, id: t, key: p === 'maxwell' ? 'maxwell/' + t : t });
const pageOf = {}; TABS.forEach(t => { pageOf[t.id] = t.page; });
const ylSrc = rd('test_yl_ui.mjs'), lit = n => new Function('return ' + ylSrc.match(new RegExp('^const ' + n + ' = (\\/.*\\/[a-z]*);\\s*$', 'm'))[1])();
const SYMBOLS = lit('SYMBOLS'), JARGON = lit('JARGON');
// where a need goes: a tab id (whatever page holds it), a page word (its first tab), or nowhere (plain text)
const target = w => (pageOf[w] ? '#' + pageOf[w] + '/' + w : PAGES.includes(w) ? '#' + w + ((SUBS[w] || [])[0] ? '/' + SUBS[w][0] : '') : null);

const b = await chromium.launch();
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: page error ${e.message}`)); pg.on('console', m => { if (m.type() === 'error') ok(false, `${tag}: console error ${m.text()}`); }); };
const go = async (pg, t) => { await pg.evaluate(h => { location.hash = h; }, '#' + t.page + '/' + t.id); await pg.waitForSelector(`#panel-${t.page}[data-sub="${t.id}"]`, { timeout: 15000 }); await pg.waitForTimeout(60); };
// what the strip of the open tab shows
const read = (pg, key) => pg.evaluate(k => {
  const all = [...document.querySelectorAll('.needs-strip')], s = all[0] || null, panel = s && s.closest('[role=tabpanel]'), glance = panel && panel.querySelector(':scope > aside.glance');
  const raw = e => { const c = e.cloneNode(true); c.querySelectorAll('.mt[data-raw]').forEach(m => m.replaceWith(document.createTextNode(m.dataset.raw))); return (c.textContent || '').replace(/\s+/g, ' ').trim(); };   // the text as written (a formula is drawn by the page and keeps its source in data-raw)
  const shown = e => { for (let x = e; x && x !== document.body; x = x.parentElement) if (getComputedStyle(x).display === 'none') return false; return e.getClientRects().length > 0; };
  if (!s) return { n: all.length };
  const lis = [...s.querySelectorAll('li')];
  return { n: all.length, inPanel: !!panel, id: s.id, key: s.dataset.needs, aria: s.getAttribute('aria-label'), yl: s.dataset.yl === '1',
    after: !glance || !!(glance.compareDocumentPosition(s) & Node.DOCUMENT_POSITION_FOLLOWING), first: [...panel.children].filter(c => !c.matches('aside.glance'))[0] === s,
    shown: shown(s), rows: [...s.querySelectorAll('.ns-row')].map(r => ({ yl: r.classList.contains('ns-yl'), shown: shown(r), text: raw(r) })),
    lines: lis.map(l => ({ kind: l.dataset.kind, shown: shown(l), badges: l.querySelectorAll('.tag.input').length, others: l.querySelectorAll('.tag:not(.input)').length, chip: [...l.querySelectorAll('.tag')].map(t => (t.textContent || '').trim()).join(''), aria: l.querySelector('.tag')?.getAttribute('aria-label') || '', kindText: (l.querySelector('.ns-kind')?.textContent || '').trim(), text: raw(l) })),
    kinds: s.querySelectorAll('.ns-kind').length, badges: s.querySelectorAll('.tag.input').length, text: raw(s),
    needs: [...s.querySelectorAll('.ns-need')].map(a => ({ need: a.dataset.need, tag: a.tagName, href: a.getAttribute('href'), plain: a.classList.contains('ns-plain'), text: (a.textContent || '').trim() })) };
}, key);

for (const [prof, filter] of [['Physicist', ''], ['Mathematician', ''], ['Young Learner', ''], ['Physicist', 'known+std']]) {
  const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(a => { try { localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, prof);
  const pg = await ctx.newPage(); const tag = prof + (filter ? ' + filter ' + filter : ''); onErr(pg, tag);
  await pg.goto(APP_HTML + (filter ? '?filter=' + filter : '') + '#' + TABS[0].page + '/' + TABS[0].id); await pg.waitForSelector('[role=tabpanel]', { timeout: 20000 }); await pg.waitForTimeout(300);
  ok(!filter || await pg.evaluate(() => document.querySelector('main')?.getAttribute('data-rf')) === 'known+std', `${tag}: the filter is on (known+std)`);
  const yl = prof === 'Young Learner', C = yl ? NEEDS_COPY.yl : NEEDS_COPY; let seen = 0, lines = 0, links = 0, plainNeeds = 0, clicked = 0;
  for (const t of TABS) {
    const E = NEEDS[t.key]; await go(pg, t); const r = await read(pg, t.key), at = `${tag} ${t.page}/${t.id}`;
    ok(r.n === (E ? 1 : 0), `${at}: ${r.n} strip, the data has ${E ? 'an entry' : 'none'}`);
    if (!E) continue; seen++;
    ok(r.inPanel && r.key === t.key && r.id === 'ns-' + t.key.replace(/\//g, '-') && r.aria === C.aria && r.yl === yl, `${at}: the strip is in the tab panel with its key, id ns-…, and the aria-label "${C.aria}" (${r.key}, ${r.id}, ${r.aria})`);
    ok(r.after && r.first, `${at}: the strip comes after the at-a-glance strip and before the content of the tab`);
    ok(r.shown && r.rows.every(x => x.shown) && r.lines.every(x => x.shown), `${at}: every row and line of the strip is visible${filter ? ' with the filter on' : ''}`);
    ok(r.kinds === (yl ? 0 : E.inputs.length) && (yl ? r.lines.length === 0 : r.lines.length === E.inputs.length), `${at}: ${yl ? 'no kinds and no list' : E.inputs.length + ' input lines'} (${r.lines.length} lines, ${r.kinds} kinds)`);
    if (yl) {
      const ylRow = r.rows.find(x => x.yl);
      ok(ylRow && ylRow.text.endsWith(E.yl), `${at}: the plain sentence is the data's: "${ylRow && ylRow.text}"`);
      ok(r.badges === (E.none ? 0 : 1), `${at}: ${E.none ? 'no' : 'one'} input badge for the Young Learner (${r.badges})`);
      ok(!SYMBOLS.test(r.text) && !JARGON.test(r.text), `${at}: the plain strip has no symbol and no jargon: "${r.text}"`);
      ok(r.rows.filter(x => !x.yl).length === (E.needs.length ? 1 : 0), `${at}: the read-first row is there when there is something to read first`);
    } else {
      r.lines.forEach((l, i) => {
        const [kind, text] = E.inputs[i];
        ok(l.kind === kind && l.kindText === KINDS[kind] && l.text.endsWith(text), `${at} line ${i + 1}: kind ${kind}, the text of the data (${l.kind}, "${l.kindText}")`);
        ok(l.badges === 1 && l.others === 0 && l.chip === '' && /input/i.test(l.aria), `${at} line ${i + 1}: one input badge, no word on the chip, "${l.aria}" for a screen reader`);
      });
      lines += r.lines.length;
      if (E.none) ok(r.rows.some(x => x.text.includes(NEEDS_COPY.none)), `${at}: says "${NEEDS_COPY.none}"`);
    }
    ok(r.needs.length === E.needs.length && r.needs.every((x, i) => x.need === E.needs[i]), `${at}: the needs are ${E.needs.join(', ') || '(none)'} in order`);
    for (const x of r.needs) {
      const to = target(x.need);
      if (to) { links++; ok(x.tag === 'A' && x.href === to && !x.plain && x.text, `${at}: the need ${x.need} is a link to ${to} (${x.tag} ${x.href})`);
        // a link to a tab names its page first, the step numbers repeat from page to page ("Shapes · 2 · The demicube", "Equations · 2 · Commutators"); a need that is a page keeps the name of the page
        if (pageOf[x.need]) { const pw = C.pages[pageOf[x.need]]; ok(x.text === pw || x.text.startsWith(pw + ' · '), `${at}: the link to ${x.need} names its page ("${pw} · …"): "${x.text}"`); ok(x.need === 'conventions' || /^[^·]+ · (\d+ · )?\S/.test(x.text), `${at}: the link to ${x.need} reads "page · step · name": "${x.text}"`); }
        const [pp, ss] = to.slice(1).split('/'); ok(PAGES.includes(pp) && (!ss || (SUBS[pp] || []).includes(ss)), `${at}: ${to} names a page and a tab that exist`);
        // clicking shows that tab (Physicist, no filter: once for every link)
        if (prof === 'Physicist' && !filter && ss) { await pg.locator(`#${r.id} a.ns-need[data-need="${x.need}"]`).click(); await pg.waitForTimeout(150); clicked++;
          const now = await pg.evaluate(() => [location.hash, document.querySelector('[role=tabpanel]')?.getAttribute('data-sub'), document.querySelector('[role=tabpanel]')?.id]);
          ok(now[0] === to && now[1] === ss && now[2] === 'panel-' + pp, `${at}: clicking ${x.need} shows ${to} (${now.join(' ')})`); await go(pg, t); }
      } else { plainNeeds++; ok(x.tag === 'SPAN' && x.plain && !x.href && x.text === (C.words[x.need] || NEEDS_COPY.words[x.need]), `${at}: the need ${x.need} names no tab and no page: plain text "${x.text}", no link`); }
    }
  }
  ok(seen === Object.keys(NEEDS).length, `${tag}: ${seen} strips seen, ${Object.keys(NEEDS).length} in the data`);
  if (!yl) ok(lines === 94, `${tag}: ${lines} input lines on the pages, 94 in the data`);
  info(`${tag}: ${seen} strips, ${lines} lines, ${links} links (${clicked} clicked), ${plainNeeds} plain-text needs`);
  await ctx.close();
}
// Italian: the strip is there, with the same lines (the text of the strip is English in the Italian slot, V11 rule 9)
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('atlas.audience', 'Physicist'); } catch { /* ignore */ } });
  const pg = await ctx.newPage(); onErr(pg, 'it'); await pg.goto(APP_HTML + '#equations/coupling'); await pg.waitForSelector('[role=tabpanel]', { timeout: 20000 }); await setLang(pg, 'it');
  let n = 0; for (const t of TABS) { const E = NEEDS[t.key]; await go(pg, t); const r = await read(pg, t.key); ok(r.n === (E ? 1 : 0) && (!E || r.lines.length === E.inputs.length), `it ${t.page}/${t.id}: the strip is there with ${E ? E.inputs.length : 0} lines`); if (E) n += r.lines.length; }
  ok(n === 94, `it: 94 input lines (${n})`); await ctx.close(); }
await b.close();
console.log(bad ? `${bad} FAILURES of ${checks}` : `NEEDS UI OK (${checks} checks)`);
process.exit(bad ? 1 : 0);
