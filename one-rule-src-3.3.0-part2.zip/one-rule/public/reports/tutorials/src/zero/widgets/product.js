// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// widgets/product.js — two labels and their product, with the sign in its steps: the label of the product (XOR), the swaps N(a,b), the
// squares of the shared switches. One function of the container's id (tools/make_tutorial.mjs applies it); no library, no network.
(function (id) {
  const box = document.getElementById(id);
  if (!box) return;
  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  // the self-test: ten products [squares, a, b, sign, label of the product] computed by Alg.blade_mul of checks/selfcheck/steps15_17/bitcliff.py
  // (tools/tutorials/figs_zero.py checks this list against that rule every time it draws the figures)
  const STORED = [[[1, 1], 3, 1, -1, 2], [[1, 1], 2, 1, -1, 3], [[-1, -1], 3, 3, -1, 0], [[-1, -1], 1, 2, 1, 3], [[0, 0], 1, 1, 0, 0], [[0, 0], 2, 1, -1, 3], [[1, 1, 1], 5, 6, -1, 3], [[1, -1, 0], 7, 7, 0, 0], [[-1, 1, 1], 6, 3, -1, 5], [[1, 1, -1, 0], 13, 11, 0, 6]];
  const bad = STORED.filter(([eps, a, b, s, c]) => sign(a, b, eps) !== s || (a ^ b) !== c);
  if (bad.length) { box.textContent = `self-test failed: ${bad.length} of the ${STORED.length} stored products differ from the rule`; return; }

  const SUB = '₀₁₂₃₄₅₆₇₈₉';
  const on = m => { const out = []; for (let i = 0; i < 8; i++) if ((m >> i) & 1) out.push(i + 1); return out; };
  const name = m => (m ? 'e' + on(m).map(i => SUB[i]).join('') : '1');
  const set = m => (m ? '{' + on(m).join(',') + '}' : '∅');
  const sq = e => (e > 0 ? '+1' : e < 0 ? '−1' : '0');
  const st = { n: 2, eps: [1, 1, 1, 1], a: 3, b: 1 };
  box.innerHTML = '<div class="pw" role="group" aria-label="Two labels and their product">'
    + '<p class="pw__row"><span class="pw__k">switches</span> <span data-k="n"></span></p>'
    + '<p class="pw__row"><span class="pw__k">squares</span> <span data-k="eps"></span></p>'
    + '<p class="pw__row"><span class="pw__k">a</span> <span data-k="a"></span></p>'
    + '<p class="pw__row"><span class="pw__k">b</span> <span data-k="b"></span></p>'
    + '<p class="widget__out" aria-live="polite"></p>'
    + '<p class="pw__note">Self-test: the rule of this box gives the ten stored products of the Atlas\'s rule.</p></div>';
  const style = document.createElement('style');
  style.textContent = '#' + id + ' .pw__row{margin:4px 0;display:flex;flex-wrap:wrap;gap:6px;align-items:center}#' + id + ' .pw__k{display:inline-block;min-width:5.5em;font-size:14px;color:var(--ink2)}'
    + '#' + id + ' .pw__note{font-size:13px;color:var(--muted);margin:8px 0 0}#' + id + ' .widget__out{margin-top:10px}';
  box.appendChild(style);
  const slot = k => box.querySelector(`[data-k="${k}"]`), out = box.querySelector('.widget__out');
  const button = (label, pressed, onClick, aria) => {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = label;
    if (pressed != null) b.setAttribute('aria-pressed', pressed ? 'true' : 'false');
    if (aria) b.setAttribute('aria-label', aria);
    b.addEventListener('click', onClick); return b;
  };
  function draw() {
    const { n, eps } = st, mask = (1 << n) - 1, a = st.a & mask, b = st.b & mask, e = eps.slice(0, n);
    const ns = slot('n'); ns.textContent = '';
    for (const k of [2, 3, 4]) ns.appendChild(button(String(k), k === n, () => { st.n = k; draw(); }, `${k} switches`));
    const es = slot('eps'); es.textContent = '';
    e.forEach((v, i) => es.appendChild(button(`${name(1 << i)}² = ${sq(v)}`, null, () => { st.eps[i] = v > 0 ? -1 : v < 0 ? 0 : 1; draw(); }, `the square of ${name(1 << i)} is ${sq(v)}; press to change it`)));
    for (const k of ['a', 'b']) {
      const s = slot(k); s.textContent = '';
      for (let i = 0; i < n; i++) s.appendChild(button(String(i + 1), ((st[k] >> i) & 1) === 1, () => { st[k] ^= 1 << i; draw(); }, `switch ${i + 1} of ${k}`));
      const t = document.createElement('span'); t.textContent = ' = ' + name(st[k] & mask); s.appendChild(t);
    }
    const swaps = [];
    for (const i of on(a)) for (const j of on(b)) if (j < i) swaps.push(`(${i},${j})`);
    const N = nPairs(a, b), r = reorderSign(a, b), sh = on(a & b), s = sign(a, b, e), c = a ^ b;
    const factor = sh.reduce((x, i) => x * e[i - 1], 1);
    out.textContent = [
      `${name(a)} · ${name(b)}   with the squares ${e.map(sq).join(', ')}`,
      `1  the label of the product: ${set(a)} XOR ${set(b)} = ${set(c)}, the blade ${name(c)}`,
      `2  the swaps: the pairs (i in a, j in b) with j < i: ${swaps.join(' ') || 'none'}; N = ${N}, (−1)^${N} = ${r < 0 ? '−1' : '+1'}`,
      `3  the shared switches: ${set(a & b)}${sh.length ? `; their squares ${sh.map(i => `${name(1 << (i - 1))}² = ${sq(e[i - 1])}`).join(', ')}` : ''}; factor ${sq(factor === 0 ? 0 : factor)}`,
      s === 0 ? `=  ${name(a)} ${name(b)} = 0   (a shared switch squares to 0)` : `=  ${name(a)} ${name(b)} = ${s < 0 ? '−' : '+'}${name(c)}`,
    ].join('\n');
  }
  draw();
})
