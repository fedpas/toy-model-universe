# The rule from zero

A first course in linear algebra multiplies a vector by a number and a matrix by a matrix, but it never multiplies two directions of space to get a new object. Clifford algebra does, and the Atlas builds every Clifford algebra it uses from one line, the bit rule. This page is that line from zero: the labels, the product, the three algebras it gives on two switches, and the clock that sorts every cell. It needs a first course and nothing more: vectors, matrices, counting mod 2.

**The rule in one paragraph.** Take $n$ switches. A label $a$ is a setting of the switches, and it names the blade $e_a$, the product of the generators $e_i$ that are on, in increasing order. Two blades multiply as $e_a e_b = s(a,b)\, e_{a \oplus b}$: the label of the product is the XOR of the two labels, and the sign $s(a,b)$ is $-1$ for every swap that sorts the word $ab$, times the square $\varepsilon_i \in \{+1, -1, 0\}$ of every switch that is on in both (MAP-001). The squares are the only input besides $n$. With $p$ squares $+1$, $q$ squares $-1$ and $r$ squares $0$, the rule is the Clifford algebra $\mathrm{Cl}(p,q,r)$ in an orthonormal frame, unique up to a change of sign convention (PAG-002); with every square $0$ it is the exterior algebra $\Lambda(\mathbb{R}^n)$ (LNS-001).

**The worked example, $n = 2$.** Four labels, $1, e_1, e_2, e_{12}$, and one table of labels. Three choices of the squares turn it into three different algebras: the real $2 \times 2$ matrices $M_2(\mathbb{R})$ for the squares $(+,+)$ (ATL-004), the quaternions $\mathbb{H}$ for $(-,-)$ (ATL-005), and the exterior algebra of the plane for $(0,0)$, whose radical has dimension 3 (LNC-024). The figure prints the three tables side by side in the order of that sentence.

![The product tables of the bit rule on two switches, row a and column b, entry e_a e_b, for the squares (+,+), (−,−) and (0,0): the same labels and the same XOR in all three, and three algebras. Beside each table, the counts of the products that are 0 and of the minus signs. Drawn by figs_zero.py with the product of checks/selfcheck/steps15_17/bitcliff.py.](figs/three_algebras.svg)

## Part 0 · The rule from zero

### 0.1 · Labels: n switches, 2ⁿ blades

In the course, an algebra is a vector space with a basis and a table that says how two basis elements multiply. The bit rule chooses the basis first: one element for every subset of the generators. A setting of $n$ switches is a string of $n$ bits, so there are $2^n$ labels, $2^n$ blades, and the algebra has dimension $2^n$ (MAP-001). The grade of a blade is the number of switches that are on; there are $\binom{n}{k}$ blades of grade $k$. Two labels add by XOR, switch by switch, so the labels form the group $\mathbb{Z}_2^n$, in which every label is its own inverse; the classes of signs on that group are the quadratic forms on $\mathbb{F}_2^n$ (LNC-050b).

![The labels at n = 1, 2 and 3, drawn by the number of switches on (the grade, bottom to top). Each box names a blade; the small squares under it are the switches, switch 1 first, filled when on. An edge joins two labels that differ in one switch, so the labels are the vertices of a segment, a square and a cube; the line style says which switch flips. Drawn by figs_zero.py from the labels of the bit rule.](figs/cube_labels.svg)

The labels are the vertices of the $n$-cube, and the cube is more than a picture: its faces are the intervals of the lattice of subsets, ordered by inclusion (CAND-104). A course on polytopes goes on to the face lattice and to the cross-polytope dual to the cube (*recalled*: Ziegler, *Lectures on Polytopes*); the Atlas reads that duality on the labels in the same row.

> **Try it.** List the labels of $n = 3$ with two switches on, and the blade each one names. There are $\binom{3}{2} = 3$ of them: $e_{12}$, $e_{13}$, $e_{23}$. Which label is the XOR of $e_{12}$ and $e_{23}$?

### 0.2 · The product: XOR and a sign

In the course, a product of basis elements is read off a table. The bit rule computes the table in two steps: the label, then the sign. The label of $e_a e_b$ is $a \oplus b$, because a switch that is on in both is used twice and drops out. The sign has two factors:

$$s(a,b) = (-1)^{N(a,b)} \prod_{i \in a \cap b} \varepsilon_i, \qquad N(a,b) = \#\{(i,j) : i \in a,\ j \in b,\ j < i\}.$$

$N(a,b)$ counts the swaps that bring the word $e_a e_b$ into increasing order, and each shared switch $i$ meets itself once and leaves its square $\varepsilon_i$. On disjoint labels only the swaps count, whatever the squares, so the rule restricted to them is the exterior algebra for every choice of squares (THM-001). The Atlas checks it on every pair: on the 1093 disjoint pairs with $n \le 6$ the sign is $(-1)^{N(a,b)}$ for every choice of squares, and all 4368 overlapping pairs change with the squares (bd·mja·1, the log of mja_exterior.py).

![The sign table of Cl(2,0), row a and column b: the sign of e_a e_b, with the swap count N(a,b) and the set of switches on in both. Here every square is +1, so the sign is the swap sign alone; four of the sixteen signs are minus. Drawn by figs_zero.py from the rule of bitcliff.py.](figs/sign_cl20.svg)

The box below runs the rule on two labels you choose. Its sign function is the one of `engines/bitrule.js`, copied; before it draws, it checks ten products against values computed with `bitcliff.py`.

@@widget product

The rule is associative for every $n$ and every choice of squares (MAP-001, theorem T1 on the For researchers page, checked by check_T1.py). The logs show it twice more: for every choice of squares on 2 and 3 switches, 36 tables, the product is associative (scw·P1c, the log of lens_sch_check.py), and on all 331776 blade triples of four switches, for all 81 choices of their squares (cat·S1, the log of cat_check.py). The sign is not the only possible one, but it is unique up to gauge, that is, up to a choice of sign for each blade (LNC-010).

In the course this is the twisted group algebra of $\mathbb{Z}_2^n$: a function $s$ on pairs of group elements gives an associative product exactly when it is a 2-cocycle (*recalled*: Karpilovsky, *Projective Representations of Finite Groups*).

> **Try it.** In the box, choose 3 switches, all squares $+1$, and multiply $e_{13}$ by $e_{23}$. The swap $(3,2)$ gives $-1$ and the shared switch 3 gives its square $+1$: the product is $-e_{12}$. Now press the square of $e_3$ once, to $-1$: the sign flips. Press it again, to $0$: the product is $0$.

### 0.3 · One rule, three algebras

In the course, $M_2(\mathbb{R})$, the quaternions and the exterior algebra are three different objects, met in three different chapters. In the Atlas they are one table of labels with three choices of squares (the first figure). The three tables differ only where two labels share a switch: 0, 0 and 7 of the 16 products are 0, and 4, 6 and 1 carry a minus sign (counted by figs_zero.py; the number of non-zero products, $4^{p+q}\,3^{r}$, is the count of LNC-100: 16, 16 and 9).

- **Squares $(+,+)$.** $\mathrm{Cl}(2,0) \cong M_2(\mathbb{R})$ (ATL-004). The matrices $e_1 = \mathrm{diag}(1,-1)$ and $e_2 = \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix}$ multiply as the table says, and the four blades are independent; the log of cat_check.py builds the matrix units $E_{11} = (1+e_1)/2$ and $E_{12} = E_{11} e_2$ from them (cat·G2).
- **Squares $(-,-)$.** $\mathrm{Cl}(0,2) \cong \mathbb{H}$ (ATL-005). With $i = e_1$, $j = e_2$, $k = e_{12}$ the table gives $i^2 = j^2 = k^2 = ijk = -1$, the defining relations of the quaternions.
- **Squares $(0,0)$.** $\mathrm{Cl}(0,0,2) = \Lambda(\mathbb{R}^2)$ (LNS-001): $e_1^2 = e_2^2 = 0$ and $e_1 e_2 = -e_2 e_1$. Its radical, the largest nilpotent ideal, is spanned by the three blades that hold a null switch: dimension 3 (LNC-024; cat·M2 and cat·R1 in the log of cat_check.py).

The course goes further: every real Clifford algebra with no null generator is a matrix algebra over $\mathbb{R}$, $\mathbb{C}$ or $\mathbb{H}$, or the sum of two such, and which one depends on $p - q$ mod 8 (*recalled*: Lawson and Michelsohn, *Spin Geometry*, chapter I). The Atlas states the type of every cell by that mod-8 table (PAG-004) and checks it: the log of groups_check.py compares the class computed from the squares with the table for all 66 cells with $n \le 10$.

> **Try it.** Read the blade $e_{12}$ in the three tables: it squares to $-1$ in $\mathrm{Cl}(2,0)$ and in $\mathrm{Cl}(0,2)$, and to $0$ in $\mathrm{Cl}(0,0,2)$. Which blades of $\mathrm{Cl}(0,2)$ square to $-1$, and why does that make it a division algebra while $\mathrm{Cl}(2,0)$ is not?

### 0.4 · The clock

In the course, a quadratic form has a signature $(p,q)$. The Atlas keeps one number of it, the clock $c = p - q \bmod 8$, and computes it from the blades alone. Give each blade the number $w(a) = \pi(a) + 2Q(a) \bmod 4$, with $\pi(a)$ the parity of the label and $Q(a) = 1$ exactly when $e_a^2 = -1$. Then the clock is the phase of a Gauss sum (RSN-029, LAB-017):

$$\sum_{a} i^{\,w(a)} = (1+i)^p\,(1-i)^q = 2^{n/2}\, e^{i\pi c/4}.$$

The log of core_check.py checks the identity exactly for every cell with $n \le 8$ (core·B3).

![Every cell Cl(p,q) with p + q at most 4, placed at the phase of its Gauss sum, the sum of i to the power w(a) over its blades, with w(a) read from the squares of the blades. Position c sits at 45° times c; the label at each position is the matrix type of the mod-8 table. Drawn by figs_zero.py, which also checks that each cell lands at p − q mod 8.](figs/clock.svg)

The figure shows the eight positions filled by the fifteen cells with $n \le 4$: $\mathbb{R}$ at 0 and 2, $\mathbb{R} \oplus \mathbb{R}$ at 1, $\mathbb{C}$ at 3 and 7, $\mathbb{H}$ at 4 and 6, $\mathbb{H} \oplus \mathbb{H}$ at 5 (PAG-004). One thing here is chosen, not computed: $p$ counts the generators of square $+1$, and the mirror convention gives $-c$ (INP-017).

The course goes further with Bott periodicity, the period 8 in topology (*recalled*: Atiyah, Bott and Shapiro, *Clifford modules*). The Atlas meets it twice: graded Clifford modules of the bit rule give the K-theory of a point by the clock (ATY-001), and the clock is the Brown invariant of the form $w$, which a topologist reads as a Pin⁻ structure on a connected sum of projective planes (LAB-018).

> **Try it.** Compute the Gauss sum of $\mathrm{Cl}(1,0)$ by hand: the blades $1$ and $e_1$ have $w = 0$ and $w = 1$, so the sum is $1 + i$, at 45°: $c = 1$. Do the same for $\mathrm{Cl}(0,1)$ and find $c = 7$.

### Three questions for a specialist

1. **An algebraist** asks which signs on the labels give an associative product with the given squares. The nearest rows: the classes of such signs are the quadratic forms of $H^2(\mathbb{Z}_2^n; \mathbb{F}_2)$ (LNC-050b), and the bit-rule sign is unique up to gauge (LNC-010). What is open, in the same row: whether the cube category $k B_3$ is tame.
2. **A topologist** asks why the period is 8. The nearest rows: the clock is the Brown invariant of $w$ (LAB-018), and the graded modules give the K-theory of a point (ATY-001). Open: Pin⁺ and Pin⁻ as symmetry classes of neutral fermions are not treated (LAB-016).
3. **A physicist** asks which cell is spacetime. The nearest rows: $\mathrm{Cl}(3,1) \cong M_4(\mathbb{R})$ (ATL-010) and the convention for $p$ (INP-017). Naming that cell Minkowski is our reading (ATL-010b), and reading the phase of $\mathrm{Cl}(0,1)$ as the electromagnetic phase is open (ATL-003b).

### The closing table

| In the course | In the Atlas | Row and status |
|---|---|---|
| a basis of $2^n$ elements | the labels, the settings of $n$ switches | MAP-001 · proved by the Atlas |
| the group $\mathbb{Z}_2^n$ | the labels under XOR | LNC-050b · proved by the Atlas |
| the table of a product of basis elements | XOR with a sign | MAP-001 · proved by the Atlas |
| the exterior algebra $\Lambda(\mathbb{R}^n)$ | every square 0; the rule on disjoint labels | LNS-001, THM-001 · proved by the Atlas |
| a Clifford algebra in an orthonormal frame | the cell $\mathrm{Cl}(p,q,r)$ | PAG-002 · proved by the Atlas |
| $M_2(\mathbb{R})$ and $\mathbb{H}$ | the cells of row 2 | ATL-004, ATL-005 · proved by the Atlas |
| a change of the signs of the basis | the sign up to gauge | LNC-010 · proved by the Atlas |
| the signature mod 8 | the clock | RSN-029 · proved by the Atlas |
| which sign counts as positive | the convention for $p$ | INP-017 · an input |

### Sources, and how far each was read

- **The rows**, each read in full (its research text, its evidence and what it rests on, by `node tools/proofs_todo.mjs --row ID`): MAP-001, PAG-002, LNS-001, THM-001, LNC-050b, LNC-010, LNC-100, LNC-024, ATL-004, ATL-005, ATL-010, ATL-010b, ATL-003b, CAND-104, PAG-004, RSN-029, LAB-017, LAB-018, LAB-016, ATY-001, INP-017.
- **The checks and their logs**, the lines quoted: core·B3 (core_check.py), scw·P1c (lens_sch_check.py), cat·S1, cat·G2 and cat·M2 (cat_check.py), bd·mja·1 (mja_exterior.py), the cell classes of groups_check.py (part A1); check_T1.py is named by MAP-001 and ships without a log. The rule of the figures and of the box: `bitcliff.py` and `engines/bitrule.js`.
- **The pages of the Atlas**: `#/rule`, `#/cells`, `#/clock`.
- **The tutorial "The bit rule and four college courses"**: Part 0 and the closing table, read in full; this page keeps its worked example and its counts at $n = 2$ and adds the sign table, the clock and the box.
- **Recalled, not in the package**: Ziegler, *Lectures on Polytopes*; Karpilovsky, *Projective Representations of Finite Groups*; Lawson and Michelsohn, *Spin Geometry*; Atiyah, Bott and Shapiro, *Clifford modules*.
