# The conformal model on the bit rule: one page, moving

Conformal geometric algebra asks for one algebra in which a point, a point pair, a circle, a sphere, a line and a plane are all elements of one space, in which "the circle where two spheres cross" or "the point where a line pierces a plane" is a product of two elements, and in which every conformal map of space, translation, rotation, dilation and inversion, acts on every object by the same sandwich $X \mapsto V X \tilde V$. A first course meets it as the Clifford algebra of $\mathbb R^{4,1}$, five basis vectors of which four square to $+1$ and one to $-1$, with two null vectors $e_o$ and $e_\infty$ built from the last two.

The bit rule gives this algebra with nothing added. Five switches, squares $(+,+,+,+,-)$: the cell (4,1), 32 labels, and every product is $e_a e_b = s(a,b)\,e_{a\oplus b}$, the XOR of the labels with a sign that counts swaps and squares. The Atlas identifies the cell as $M_4(\mathbb C)$ and names it the conformal model of 3D space (ATL-013, PAG-006). This page builds the model on those 32 labels: the null pair from the switches $e_+$ and $e_-$ (Part A), the objects as blades (Part B), the products (Part C), the moves as versors (Part D) and the neighbour PGA, Cl(3,0,1), which the Atlas uses for rigid bodies (Part E). Every number on the page is printed by `cga_compute.py`, which multiplies with the Atlas's own rule (`checks/researchers_checks/bitrule_A.py`), and quoted with the id of its printed line (A4.4, C2.1 …); the two widgets recompute them in the browser with the rule of `engines/bitrule.js`. The page follows the list of objects of a one-page summary of the conformal model (named in the Sources); the pictures and the widgets are drawn from the Atlas's labels.

**The one rule at n = 2.** Two switches, four labels 1, e₁, e₂, e₁₂. The rule gives three algebras from three choices of squares. With (+,+), $e_1 = \mathrm{diag}(1,-1)$ and $e_2 = \left(\begin{smallmatrix}0&1\\1&0\end{smallmatrix}\right)$ multiply as the table says and the four blades span $M_2(\mathbb R)$ = Cl(2,0). With (−,−), $i = e_1$, $j = e_2$, $k = e_{12}$ satisfy $i^2 = j^2 = k^2 = ijk = -1$: the quaternions ℍ = Cl(0,2). With (0,0), $e_1^2 = e_2^2 = 0$ and $e_1 e_2 = -e_2 e_1$: the exterior algebra Λ(ℝ²) = Cl(0,0,2). The labels, the XOR and the swap sign are the same in the three; only the squares of the shared switches change (LNS-001). The conformal model needs the fourth cell of this row, (1,1), with one square +1 and one −1: there $e_+ + e_-$ squares to 0 although no switch does (A2).

![The three sign tables of the row n = 2: the entry in row a, column b is e_a e_b, coloured by its sign (blue +, red −, grey 0); squares (+,+) give M₂(ℝ), (−,−) the quaternions, (0,0) the exterior algebra. Drawn by figs_cga.py with the bit rule of bitrule_A.py; it counts 0, 0 and 7 zero products and 4, 6 and 1 minus signs, the numbers the shipped tutorial's Part 0 gives.](figs/fig_row2.svg)

## The summary, moving

The widget below is the whole page in one piece. It works in the cell (4,1): every blade it draws is a vector of 32 coefficients on the labels e₁ e₂ e₃ e₊ e₋, built by the outer product from points, and every join, meet and move is computed by the bit rule in the browser (its sign function is the one of `engines/bitrule.js`, checked at load against ten products stored by `cga_compute.py` W.1 and against the numbers of the figures C2.1, C2.2, A4.4 and D1.6; a failure writes "self-test failed" in the box).

The screen is the plane z = 0 of ℝ³. The objects of the palette either lie in it (points, point pairs, flat points, circles and lines) or stand upright on it (a sphere with its centre in the screen, drawn as its outline; a plane perpendicular to the screen, drawn as its trace, a thick line). Results that leave the screen are drawn in projection along z: the circle where two spheres meet stands upright and shows as a segment seen edge on, the line where two upright planes meet shows as a ringed dot. Two objects A (blue) and B (orange) are edited with the sliders; the join A ∧ B (purple, dashed) and the meet A ∨ B (green) are drawn when they are not zero. The preset buttons set A and B to the pairs of Part C. The move buttons apply a translation, a rotation about the z axis, a dilation from the origin or an inversion in a sphere at the origin to the chosen object, by the sandwich, and draw the image in red. The read-out prints the chosen blade: its kind, its centre and radius² or its position and direction, its coefficients on the labels and the same blade on the null pair ($e_o$, $e_\infty$ and $E = e_\infty \wedge e_o$).

@@widget cga

When two objects both lie in the screen (two lines, a line and a circle, two circles), their meet in the full space is 0: in three dimensions two coplanar curves have no intersection of the right dimension. The widget then takes the meet inside the plane z = 0, which is the cell (3,1) of e₁ e₂ e₊ e₋ sitting inside (4,1), and says so (C2).

> **Try it.** Press "sphere ∨ plane", then "edit B", and move the plane's sliders: the green segment is the circle where the plane cuts the sphere, standing upright; when the plane leaves the sphere the read-out turns to "imaginary circle" with a negative radius². Then choose "rotate" with the chosen object A ∨ B: the red image is the rotated circle, and its coefficients are those of $R (A \vee B) \tilde R$.

## Part A · The cell and its null pair

For a reader who knows the Clifford algebra of a quadratic form and meets the conformal model for the first time: which algebra it is, where it sits among the cells of the Atlas, how two null vectors come out of two switches of opposite squares, and why a point of ℝ³ is a null vector.

### A1 · Five switches, thirty-two labels, one cell of row 5

A course writes $\mathbb R^{4,1}$ for ℝ⁵ with the form $x_1^2 + x_2^2 + x_3^2 + x_+^2 - x_-^2$ and its Clifford algebra $\mathcal G_{4,1}$, of dimension $2^5 = 32$. In the Atlas this is the cell (4,1): five switches in the Atlas's order, the four of square +1 first (e₁, e₂, e₃, e₊), then the one of square −1 (e₋). A label is a choice of switches: 1 of grade 0, 5 of grade 1, 10 of grade 2, 10 of grade 3, 5 of grade 4 and 1 of grade 5 (cga_compute.py A1.1–A1.6). The square of a label follows from the rule: e₁₂ squares to −1, e₁₋ to +1, e₊₋ to +1; over all 32 labels, 16 square to +1 and 16 to −1, and none to 0, since no switch is null (A1.7). The top label $I = e_{123+-}$ squares to −1 and commutes with the five generators (A1.8): the volume element is central, as it is in every cell of odd n, and with $I^2 = -1$ it is a complex structure.

![The 32 labels of the cell (4,1) by grade, each coloured by its square (blue +1, red −1); the counts under the columns are 1 +, 4 + and 1 −, 4 + and 6 −, 6 + and 4 −, 1 + and 4 −, 0 + and 1 −. Drawn by figs_cga.py with the bit rule.](figs/fig_labels.svg)

The Atlas's cells page holds the row p + q = 5. ATL-013: "Four +1 and one −1 generator give Cl(4,1)≅M₄(ℂ) (cell [5,+3]) ≅ Cl(4,0)⊗ℂ ≅ Cl(2,3). The volume element squares to −1 and is central. With its null pair this is the conformal model of 3D Euclidean space used in step 11." The address [5,+3] is the row and the signature p − q; the clock of the cell is p − q mod 8 = 3, which LNC-055 reads as the phase of a Gauss sum over the labels. The neighbours of (4,1) in the row differ: ATL-016 gives Cl(2,3) ≅ M₄(ℂ) as well, LNS-017d gives Cl(1,4) = M₂(ℍ) ⊕ M₂(ℍ), and ATL-024 notes that Cl(1,4) and Cl(5,0) share one triple. Recomputed here with the rule (A2.1–A2.6): the six cells of the row have clocks 5, 3, 1, 7, 5, 3; the top label is central in all six and squares to +1 in (5,0), (3,2), (1,4), where the centre span(1, I) is ℝ ⊕ ℝ and the algebra splits into two ideals, and to −1 in (4,1), (2,3), (0,5), where the centre is ℂ.

![The six cells of row 5 on their clocks: each dial points at p − q mod 8; beside it the squares, the square of the top label and the centre it gives; under it the type as the cells rows state it (ATL-013, ATL-016, LNS-017d, ATL-024; the types of (3,2) and (0,5) are the recalled mod-8 table). The cell of this page, (4,1), is framed. Drawn by figs_cga.py with the bit rule.](figs/fig_row5.svg)

One point of care, because the Atlas's own conformal page uses the mirror. Step 11 of the Atlas lets space square −1 (INP-051), and its null pair adds $e_p$ (square −1) and $e_m$ (square +1); for 3D space that is one +1 and four −1, the cell (1,4), not (4,1). The two cells are different algebras (M₂(ℍ) ⊕ M₂(ℍ) against M₄(ℂ)), but flipping every square only flips the sign of every structure constant of the bivectors (ATL-014b), so the two have the same Lie algebra of moves: the Killing form of the ten bivectors has 6 negative and 4 positive directions in the step's stored results (`checks/selfcheck/projective.json`, entry conformal space,3) and in (4,1) (cga_compute.py D3.3). This page works in (4,1), as ATL-013 and the check of part R of `checks/selfcheck/steps15_17/gtg_check.py` do.

Where the course goes further: the classification of real Clifford algebras by p − q mod 8, the isomorphism Cl(4,1) ≅ M₄(ℂ) and the spin group Spin(4,1) as the double cover of the Möbius group of the 3-sphere are *recalled* (Lounesto, *Clifford Algebras and Spinors*; Porteous, *Clifford Algebras and the Classical Groups*); the Atlas recomputes the types from the squares of the labels for every cell it shows (ATL-024) and states the conformal identification as a textbook one (PAG-006).

> **Try it.** In the cell (4,1), which of e₁₂₃, e₁₂₋, e₁₊₋ square to +1? Count the swaps of $e_a e_a$ and multiply by the squares of the switches on. (The figure has the answer: −1, +1, +1.)

### A2 · The null pair: two switches of opposite square

A course defines $e_\infty = e_- + e_+$ and $e_o = \tfrac12(e_- - e_+)$: two vectors of square 0 with $e_o \cdot e_\infty = -1$, the origin and the point at infinity. In the Atlas they are not labels. They are sums of the two labels e₊ and e₋, whose squares are +1 and −1: $e_\infty = e_+ + e_-$, $e_o = -\tfrac12 e_+ + \tfrac12 e_-$, and the rule gives $e_\infty^2 = 0$, $e_o^2 = 0$, $e_o \cdot e_\infty = -1$ (cga_compute.py A3.1–A3.2), the Witt pair that part R of `gtg_check.py` checks in the cell (3,1): "ok R5 n_o is null too and n_o . n_inf = -1 (a Witt pair)" (its log, `checks/selfcheck/steps15_17/logs/gtg_check.log`). Their outer product is a label: $E = e_\infty \wedge e_o = e_{+-}$, with $E^2 = +1$ (A3.3). The geometric products are $e_\infty e_o = -1 + E$ and $e_o e_\infty = -1 - E$, and the null pair are the two eigenvectors of E: $E e_\infty = -e_\infty$, $E e_o = +e_o$ (A3.4). Back again, $e_+ = \tfrac12 e_\infty - e_o$ and $e_- = \tfrac12 e_\infty + e_o$ (A3.5): the two descriptions are one change of basis.

![The plane of e₊ and e₋: the hyperbolas v² = +1 and v² = −1, the two null lines (green, dashed), the labels e₊ and e₋ (black) and the null pair e∞ and eₒ (blue) read from their coefficients; the red dots are the images of e∞ and eₒ under D = 3 + e₊₋, which scales one null line by 1/2 and the other by 2 (cga_compute.py D1.4). Drawn by figs_cga.py with the bit rule.](figs/fig_nullpair.svg)

The Atlas has two kinds of null, and the conformal model uses only one of them. LNC-070: "“Null” has two meanings in the atlas’s own pages … the horizon vector … is a paired null of Cl(1,1), while the tangent algebra Cl(0,n−2,1) of a null hypersurface has an unpaired null, its radical. The projective generator of step 11 is unpaired; its image in the conformal algebra is f⁺ − f⁻." A null generator of Cl(p,q,r) is a switch of square 0: one label, a radical, an ideal on which products vanish (PRJ-001, LNS-001). The null vectors of the conformal model are null vectors of a non-degenerate cell: no switch squares to 0, the algebra has no radical, and $e_\infty$ is a sum of two labels with opposite squares, paired with its partner $e_o$. The same fact is a row of the clock page: a translation inside a non-degenerate cell is a null rotation, T = 1 − a n∞/2 with n∞ null (LAB-004). Reading the two bits of opposite square as two more bits of the cube is the Atlas's own reading; the product it uses is checked: on a base of dimension 1 to 3 whose squares are all +1 or all −1, the bit rule with the null pair equals Chevalley's construction on the exterior algebra on every label pair (PRJ-001b, exact).

Where the course goes further: the conformal model as the projectivised null cone, $\mathbb R^3 \cup \{\infty\}$ = S³, and the Möbius group acting on it, is *recalled* for 3D space (Dorst, Fontijne and Mann, *Geometric Algebra for Computer Science*; Hestenes and Sobczyk, *Clifford Algebra to Geometric Calculus*). The Atlas checks the Lorentzian case: the projectivised null cone of $\mathbb R^{1,3}$ is S² = ℂP¹ with the Lorentz group acting as the Möbius group (CAND-030), and the 96 non-zero integer null vectors with entries up to 4 are multiples of a $P(x)$ or of the generator at infinity (NUL-008).

> **Try it.** Write $e_+ + 2e_-$ on the null pair. (Use A3.5: $e_+ + 2e_- = \tfrac32 e_\infty + e_o$; its square is $2 \cdot \tfrac32 \cdot (-1) = -3$, which the rule gives as $1 \cdot 1 + 4 \cdot (-1)$.)

### A3 · A point is a null vector, and its inner product is a distance

A course embeds a point $x \in \mathbb R^3$ as

$$P(x) = e_o + x + \tfrac12 |x|^2 e_\infty ,$$

a null vector with $P(x) \cdot e_\infty = -1$, and proves $P(x) \cdot P(y) = -\tfrac12 |x - y|^2$: the Euclidean distance is the inner product. On the labels the embedding is $P(x) = x_1 e_1 + x_2 e_2 + x_3 e_3 + \tfrac12(|x|^2 - 1)\,e_+ + \tfrac12(|x|^2 + 1)\,e_-$. The rule gives $P(0) = -\tfrac12 e_+ + \tfrac12 e_-$, $P(1,2,2) = e_1 + 2e_2 + 2e_3 + 4e_+ + 5e_-$, $P(3,4,0) = 3e_1 + 4e_2 + 12e_+ + 13e_-$, each with square 0 and inner product −1 with $e_\infty$ (cga_compute.py A4.1–A4.3): the coefficients on e₊ and e₋ of a point with integer $|x|^2$ are the legs of a Pythagorean-like pair, $13^2 - 12^2 = 25 = |x|^2$. The distance: $P(1,2,0) \cdot P(4,6,0) = -25/2$, $P(0) \cdot P(1,2,2) = -9/2$, $P(1,1,1) \cdot P(-1,-1,-1) = -6$, $P(\tfrac12, 0, 0) \cdot P(0, \tfrac12, 0) = -1/4$, each equal to $-\tfrac12|p - q|^2$ (A4.4–A4.7), and on 40 random pairs with half-integer coordinates the equality holds in 40 of 40, exactly (A4.8). The geometric product of two points is $P(p)P(q) = P \cdot Q + P \wedge Q$: for (1,2,0) and (4,6,0) it is $-25/2 - 2e_{12} + \tfrac{35}{2}e_{1+} + 39e_{2+} + \tfrac{29}{2}e_{1-} + 35e_{2-} - \tfrac{47}{2}e_{+-}$ (A4.9), a scalar and a bivector, the point pair of B2.

![The null cone of the three labels e₁, e₊, e₋ (where v² = 0) and the points P(x e₁) for x from −2.6 to 2.6: they lie on the cone and in the plane P·e∞ = −1 (green), a parabola; the red ray is e∞, the direction the points take as x grows. Drawn by figs_cga.py from the coefficients the rule gives; P(x)² = 0 at the 53 points drawn.](figs/fig_cone.svg)

The Atlas's checks of the step-11 page state the same identity in their convention: "the null pair eps = e_p + e_m, o = (e_m - e_p)/2: eps and o null, eps.o = 1, P(x) null, P(x).P(y) = -(1/2)(x-y)^2" (`checks/selfcheck/projective_selfcheck.py`, its list of what is checked; the log `checks/selfcheck/proofs/logs/projective_selfcheck.plain.log` ends "ALL PROJECTIVE CHECKS PASS"). With space squaring −1 there, $(x - y)^2 = -|x - y|^2$, and the sign of $\varepsilon \cdot o$ flips with every square: the two statements are one statement in two conventions (A1).

![The inner product of two points against their distance: 40 random pairs (red circles) and the curve −½|p − q|² (blue). Drawn by figs_cga.py; each circle is P(p)·P(q) computed by the rule (cga_compute.py A4.8).](figs/fig_distance.svg)

@@widget points

Where the course goes further: the general statement, that the null cone of $\mathbb R^{n+1,1}$ projectivised is the conformal compactification of ℝⁿ and that the inner product of normalised null vectors is $-\tfrac12$ the squared distance in every dimension, is *recalled* (Dorst, Fontijne and Mann, chapter 13). The Atlas checks the null pair and the points for n = 2 to 4 in both conventions of the square of space (PRJ-509, a summary row of the step).

> **Try it.** In the second widget, put p and q at distance 5 in three different ways (along an axis, along (3,4,0), along (0,3,4)). The inner product stays −12.5 and the bivector P∧Q changes: the inner product sees only the distance.

### Three questions for a geometer (Part A)

1. *Which real form?* The conformal model of ℝ³ can be built in (4,1) or in its mirror (1,4); the Atlas's step 11 uses (1,4) and its cells page names (4,1) (ATL-013). Is there a geometric statement that one of them carries and the other does not, beyond the type of the algebra (M₄(ℂ) against M₂(ℍ) ⊕ M₂(ℍ))? The nearest row is ATL-014b (the same bivector algebra for a sign pattern and its negative); nothing is open on it yet.
2. *Why a pair?* The conformal model needs two extra switches of opposite square; PGA needs one switch of square 0 (PRJ-001). Is there a construction that passes from the unpaired null to the paired one by an operation on the cube of labels, a doubling? The nearest is LNC-070 (the image of the projective generator is f⁺ − f⁻) and the Atlas's own reading PRJ-001b, whose product is checked against Chevalley's construction (30 cells, exact); the doubling itself is not a theorem of the Atlas.
3. *The clock.* The cell (4,1) has clock 3 and its points live on a null cone. Do the clocks of the cells that host a conformal model of ℝⁿ, (n+1,1), follow a pattern that a geometer would read? The rows give the clocks (LNC-055); no row reads them as conformal data.

## Part B · The objects

For a reader who knows that a subspace can be stored as a blade: the conformal model stores a round or flat set of ℝ³ as a blade whose outer product with a point is zero exactly on the set. This part takes the objects in the order of the summary the page follows: round point, point pair, circle, sphere; flat point, line, plane.

### B1 · Two ways a blade holds a set: the test "x lies on it"

A course defines the *outer product null space* of a blade X, the points x with $P(x) \wedge X = 0$, and the *inner product null space* of its dual $X^* = X I^{-1}$, the points with $P(x) \rfloor X^* = 0$; for a blade of grade 4 the dual is a vector and the test is one number, $P(x) \cdot X^*$. The two tests are one: $(P \wedge X)I^{-1} = P \rfloor (X I^{-1})$. On the labels, the sphere of centre 0 and radius 2 is the dual vector $\sigma = P(0) - 2e_\infty = -\tfrac52 e_+ - \tfrac32 e_-$, and its blade is $S = \sigma I = \tfrac32 e_{123+} + \tfrac52 e_{123-}$ (cga_compute.py B1.1). The point (0,0,2) lies on it: $P \wedge S = 0$ and $P \cdot \sigma = 0$ (B1.2). The point (1,1,1) does not: $P \wedge S = \tfrac12 e_{123+-}$ and $P \cdot \sigma = \tfrac12 = -\tfrac12(|x - c|^2 - r^2)$, positive because the point is inside (B1.3). The identity of the two tests holds on the four points tried (B1.4).

![The test "x lies on it" as a sign map in the plane z = 0: the sign of P(x)·σ on the grid x, y = −3, −2.5, …, 3 (169 points) for a sphere of centre (½,0,0) and radius 2, for the plane 3x + 4y = 5 and for an imaginary sphere of radius² −1. Blue: positive (inside, or on the side the normal leaves), red: negative, ring: zero, the points that lie on the object. Drawn by figs_cga.py; every sign is P(x)·σ computed by the rule.](figs/fig_tests.svg)

The sign is information the zero set does not have: $P(x) \cdot \sigma = -\tfrac12(|x-c|^2 - r^2)$ is positive inside the sphere and negative outside, and $P(x) \cdot \pi = n \cdot x - \delta$ for a plane $\pi = n + \delta e_\infty$ is the signed distance. The imaginary sphere $P(0) + 2e_\infty$ has $\sigma^2 = -4$: no point lies on it, and $P(x) \cdot \sigma = -\tfrac12(|x|^2 + 4) < 0$ everywhere (B2.7).

The Atlas does not have a row for the inner and outer null spaces; its nearest statements are the Frobenius pairing of a label with its complement (LNC-004) and the step-11 check that "a point on the sphere lies on it: P(x).S = 0" for x on the sphere (`projective_selfcheck.py`, function null_pair_checks). The duality between outer product and contraction, $(A \wedge B)^* = A \rfloor B^*$, is *recalled* (Dorst, Fontijne and Mann, chapter 3).

> **Try it.** In the widget keep A = sphere, press "edit B", set its type to "point", and choose "chosen A ∨ B". The read-out is a scalar: move the point across the outline and watch it change sign; it is 0 exactly when the point lies on the sphere.

### B2 · Rounds and flats: what the outer product of points builds

A course builds the objects by joining points. The outer product of two points is a point pair, of three a circle, of four a sphere; with $e_\infty$ as one of the factors the same products give a flat point, a line and a plane, because a flat is a round through the point at infinity. On the labels:

- the point pair of (2,0,0) and (0,2,0) is $4e_{12} + 3e_{1+} - 3e_{2+} + 5e_{1-} - 5e_{2-}$, of grade 2, with $X^2 = 16$; the two points come back as $(X \pm \sqrt{X^2})(e_\infty \rfloor X)$, here (0,2,0) and (2,0,0) (cga_compute.py B2.1–B2.2);
- the circle through (2,0,0), (0,2,0), (−2,0,0) is $12e_{12+} + 20e_{12-}$, on 2 of the 10 labels of grade 3; its centre is 0 and its radius² is 4 (B2.3–B2.4);
- the sphere through those three and (0,0,2) is $-24e_{123+} - 40e_{123-}$; its dual is $40e_+ + 24e_- = -16\,(P(0) - 2e_\infty)$, a multiple of the dual sphere of B1 (B2.5–B2.6);
- the flat point of (1,2,3) is $P \wedge e_\infty = e_{1+} + 2e_{2+} + 3e_{3+} + e_{1-} + 2e_{2-} + 3e_{3-} - e_{+-}$ (B3.1);
- the line through 0 and (1,1,0) is $e_{1+-} + e_{2+-}$ (B3.2);
- the plane through (0,0,1), (1,0,1), (0,1,1) is $e_{123+} + e_{123-} - e_{12+-}$, whose dual is $-e_3 - e_+ - e_- = -(e_3 + e_\infty)$: the plane $n \cdot x = \delta$ with $n = e_3$, $\delta = 1$ (B3.3).

The flats contain $e_\infty$: $X \wedge e_\infty = 0$ for the three (B3.4), and on the labels this shows as equal coefficients on $e_{S+}$ and $e_{S-}$, since $e_\infty = e_+ + e_-$.

![Which labels carry each object: the coefficients of seven blades built from four points in general position on the 32 labels, ordered by grade (blue positive, red negative, grey zero), with the number of labels used in brackets; a = (1,2,0), b = (−1,1,2), c = (2,−1,1), d = (0,1,−2). The rounds use their whole grade (the point a has no e₃ part); the flats carry equal coefficients on e_S₊ and e_S₋. Drawn by figs_cga.py from blades computed by the rule.](figs/fig_objects.svg)

A line is a circle through the point at infinity, and the rule shows the limit. The circles through (0,0), (2,0) and a third point (1, −k) have radius² 1, 25/16, 289/64, 4225/256, 66049/1024, 1050625/4096 for k = 1, 2, 4, 8, 16, 32, with centres at (1, −(k² − 1)/(2k)) (cga_compute.py B3.5). Divide the third point by its weight $(k^2+1)/2$: it tends to $e_\infty$, and the circle tends to the line $a \wedge b \wedge e_\infty = 2e_{1+-}$; at k = 32 the largest coefficient of the difference is 128/1025, and it shrinks like 4/k (B3.6).

![Circles through a = (0,0), b = (2,0) and (1, −k) for k = 1, 2, 4, 8 (purple), and their limit, the line a∧b∧e∞ (blue). Drawn by figs_cga.py; each circle is read back from its blade (centre and radius² by the formulas of B3), not drawn from a formula for circles.](figs/fig_line_limit.svg)

In the Atlas, the planes and spheres are vectors in the sense that matters for moves: "Planes and spheres are non-null vectors, so they are mirrors; the isometries of R^n are products of at most n + 1 of them. The null vectors ε and o are not mirrors" (PRJ-003). The objects of higher grade, point pairs, circles and lines, have no row of their own; the step-11 check builds planes as $n + \delta\varepsilon$ and spheres as $P(c) - \tfrac12 r^2 \varepsilon$ (`projective_selfcheck.py`, its list of what is checked). Where the course goes further: that every blade of grade k built from k points in general position is a round, and that every round is such a product, is *recalled* (Dorst, Fontijne and Mann, chapter 14); the tangents (rounds of radius 0) and the free and direction blades of that chapter are not drawn here.

> **Try it.** In the widget, preset "pair ∧ point": the purple circle is the join of a point pair and a point. Move B onto the line of the pair: the circle grows without bound and the read-out turns to "line" when B is exactly on it.

### B3 · Weight, orientation, centre, radius: the table of the objects

A blade is defined by its set only up to a scalar factor. The size of the factor is the *weight*, its sign the *orientation*. For a point the weight is $-X \cdot e_\infty$: $-P(1,2,3)$ has the same null space and weight −1 (cga_compute.py B4.8). For a round X the course reads three things from the blade: the carrier $X \wedge e_\infty$, the flat that holds it (the line of a point pair, the plane of a circle, the whole space for a sphere); the centre, from the vector $X e_\infty X$; and the radius, from the square of the blade,

$$\rho^2 = \frac{X \widehat X}{(e_\infty \rfloor X)^2},$$

with $\widehat X$ the grade involution. The formula gives radius² 2 for the point pair of B2 (half the distance $2\sqrt2$, squared), 4 for the circle and 4 for the sphere, and the centres (1,1,0), 0, 0 (B4.2r–B4.4r); for the dual sphere $\sigma$ it reduces to $\sigma^2/(\sigma \cdot e_\infty)^2$, which is 4 for the sphere of B1 (B2.6). For a flat the denominator vanishes: $e_\infty \rfloor X$ is then the direction of the flat times $e_\infty$, which squares to 0 (B3.4); for the line of B2 it is $-e_{1+} - e_{2+} - e_{1-} - e_{2-} = -(e_1 + e_2) \wedge e_\infty$, the direction (1,1,0) (B4.3f). A negative radius² is an imaginary round: the sphere of B2.7 has radius² −4.

The objects in one table: the grade of the blade, an example on the labels (cga_compute.py lines B2–B4), its dual, and the test.

| object | grade | example on the labels | its dual $X I^{-1}$ | x lies on it |
|---|---|---|---|---|
| point P(1,2,2) | 1 | e₁ + 2e₂ + 2e₃ + 4e₊ + 5e₋ | the vector itself, a sphere of radius 0 | $P(x) \cdot P = 0$ |
| point pair (2,0,0), (0,2,0) | 2 | 4e₁₂ + 3e₁₊ − 3e₂₊ + 5e₁₋ − 5e₂₋ | 5e₁₃₊ + 5e₂₃₊ + 3e₁₃₋ + 3e₂₃₋ + 4e₃₊₋ (three spheres' worth) | $P(x) \wedge X = 0$ |
| circle, centre 0, r 2, in z = 0 | 3 | 12e₁₂₊ + 20e₁₂₋ | −20e₃₊ − 12e₃₋ = −8 σ ∧ π (sphere r 2 and the plane z = 0) | $P(x) \wedge X = 0$ |
| sphere, centre 0, r 2 | 4 | −24e₁₂₃₊ − 40e₁₂₃₋ | 40e₊ + 24e₋ = −16 (P(0) − 2e∞) | $P(x) \cdot \sigma = 0$ |
| flat point (1,2,3) | 2 | e₁₊ + 2e₂₊ + 3e₃₊ + e₁₋ + 2e₂₋ + 3e₃₋ − e₊₋ | a trivector through e∞ | $P(x) \wedge X = 0$ only at x |
| line through 0 and (1,1,0) | 3 | e₁₊₋ + e₂₊₋ | e₁₃ − e₂₃ (two planes' worth) | $P(x) \wedge X = 0$ |
| plane z = 1 | 4 | e₁₂₃₊ + e₁₂₃₋ − e₁₂₊₋ | −e₃ − e₊ − e₋ = −(e₃ + e∞) | $P(x) \cdot \pi = n \cdot x - \delta = 0$ |

The duals are printed by cga_compute.py B4.9; the circle's dual is −8 times the outer product of the dual sphere of radius 2 and the dual plane z = 0 (B4.9ch), the dual way of writing a circle as a sphere cut by a plane (C2).

The Atlas has no row on weights and orientations of conformal objects; the orientation it records is the sign of a blade under the reversion, which it uses for motors (INP-065, "the motor is normalised by M M̃ = 1 with the reversion"). The formulas for centre and radius are *recalled* (Dorst, Fontijne and Mann, chapter 14, the table of the parameters of rounds); here they are checked on the examples by the rule, and the widget reads every blade with the same formulas.

> **Try it.** In the widget, edit A as a circle centred at 0, choose "chosen A", and drag its radius: the read-out of A on the labels keeps two labels for a circle centred at 0 (e₁₂₊ and e₁₂₋) and gains e₁₊₋, e₂₊₋ and e₁₂ when the centre moves. Which coefficient carries the radius? (The ratio of the e₁₂₊ and e₁₂₋ coefficients: for centre 0, $(r^2 - 1)/(r^2 + 1)$.)

### Three questions for a geometer (Part B)

1. *Labels for objects.* A sphere centred at 0 uses 2 of the 5 labels of grade 4 and a general one all 5; the flats never use a label without e₊ or e₋ alone. Is there a reading of the support of a blade on the labels (which switches are on) as a geometric property of the object, beyond "contains e∞"? The nearest Atlas statement is the complement pairing LNC-004; no row reads supports of conformal blades.
2. *Imaginary rounds.* The rule gives imaginary spheres and circles (negative radius²) as ordinary blades. Do they have a role in the Atlas's other pages, for instance as the meet of two spheres that do not cross (C2), read as a pair of complex points? Nothing in the Atlas is open on it; the nearest is CAND-030 (the null cone of the Lorentzian case as ℂP¹).
3. *Weight as a field.* The weight of a point, $-P \cdot e_\infty$, is the one number the projective picture forgets. The Atlas's PGA page uses normalised points for masses (PRJ-005, "points normalised in that algebra"). Is the weight of a conformal point a mass in any reading the Atlas would accept? Open, and not asked by any row.

## Part C · The products

For a reader who knows the exterior algebra and the inner product: in the conformal model all of them, and the meet, are the one product of the rule with a filter on the labels.

### C1 · One rule, five products

A course defines the geometric product and then, for blades, the outer product (the part of top grade), the left contraction $A \rfloor B$ (the part of grade $|B| - |A|$), the scalar product (the part of grade 0) and the regressive product $A \vee B$, the dual of the outer product of the duals. On the labels each is the rule $e_a e_b = s(a,b)\,e_{a\oplus b}$ kept on some pairs of labels and set to 0 on the others:

- the geometric product keeps every pair: in (4,1) all 1024 label pairs give a non-zero product, 480 of them with the sign −1 (cga_compute.py C1.1);
- the outer product keeps the pairs of disjoint labels, $a \,\&\, b = 0$: 243 = 3⁵ pairs (each switch is on in a, in b or in neither); on those pairs the rule of (4,1) equals the rule with every square 0, the exterior algebra, and that rule is 0 on every other pair (C1.2–C1.3): the outer product is the cell Cl(0,0,5) on the same labels (LNS-001);
- the left contraction keeps the pairs with a inside b, $a \,\&\, b = a$: 243 pairs again; the scalar product keeps $a = b$: 32 pairs; a pair is kept by both the outer product and the contraction only when $a = 0$ (C1.2);
- for two vectors $uv = u \cdot v + u \wedge v$: for $u = e_1 + 2e_2 + e_+$ and $v = e_2 - e_3 + 2e_-$, $u \cdot v = 2$ and the rest of $uv$ is $u \wedge v$ (C1.4);
- the regressive product is $A \vee B = ((AI^{-1}) \wedge (BI^{-1}))\,I$; on labels, multiplication by the top label I sends $e_a$ to $\pm e_{a \oplus 11111}$, the complement of the label, so the meet is the outer product read on complements.

![The sign table of the rule on the 32 labels of (4,1), rows and columns ordered by grade (blue +1, red −1), and the two filters: the pairs the outer product keeps (a & b = 0) and the pairs the left contraction keeps (a ⊆ b), 243 each. Drawn by figs_cga.py from the bit rule.](figs/fig_signtable.svg)

In the Atlas the same picture is LNS-001 for the outer product (the all-null rule is the exterior algebra, with the same labels, XOR and reorder sign), and LNC-004 for the complement: "λ(e_{a}e_{b}) ≠ 0 iff b = a ⊕ F … So Cl(p,q,r) is a Frobenius algebra for every signature": the coefficient of the top label pairs each label with its complement, which is what makes the dual and the meet work. With no null switch, as in (4,1), multiplication by I is invertible and the dual is the metric Hodge star (the shipped tutorial, Part A on the Hodge star).

Where the course goes further: the Grassmann–Cayley algebra, in which the join and the meet are defined without a metric, and the identity $(A \wedge B)^* = A \rfloor B^*$ for all blades, are *recalled* (Dorst, Fontijne and Mann, chapters 3 and 5; Hestenes and Sobczyk, chapter 1).

> **Try it.** Take the labels e₁₂₊ and e₂₃₋. Which of the five products keep the pair? (They share e₂, so the outer product drops it; neither is inside the other, so both contractions drop it; the geometric product keeps it: $e_{12+} e_{23-} = \pm e_{13+-}$.)

### C2 · Join and meet

A course takes the join of two disjoint objects as their outer product and the meet as the regressive product: the join of points builds rounds and flats (B2), and the meet of two objects is the object of their intersection, of grade $|A| + |B| - 5$. On the labels:

- sphere (0, r 2) ∨ sphere ((2,0,0), r 2) is a circle of grade 3 with radius² 3 and centre (1,0,0); its carrier $(M \wedge e_\infty)I^{-1} = 2e_1 + 2e_+ + 2e_- = 2(e_1 + e_\infty)$ is the plane x = 1 (cga_compute.py C2.1);
- sphere (0, r 2) ∨ plane z = 1 is the circle of centre (0,0,1) and radius² 3 (C2.2); the dual way, the outer product of the dual sphere and the dual plane, $\sigma \wedge \pi = \tfrac52 e_{3+} + \tfrac32 e_{3-} - e_{+-}$, equals $(S \vee \Pi)I^{-1}$ with the factor 1 (C2.3);
- plane x = 1 ∨ plane y = 1 is the line through (1,1,0) along e₃, a flat of grade 3 (C2.4);
- plane z = 1 ∨ the line through 0 and (1,1,1) is the flat point (1,1,1), read from the coefficients of $e_{i+}$ divided by the weight (C2.5);
- sphere (0, r 2) ∨ the line through 0 along (1,2,2) is the point pair ±(2/3, 4/3, 4/3), radius² 4 (C2.6);
- the circle of radius 2 in z = 0 ∨ the sphere ((12/5,0,0), r 2) is the point pair (6/5, ±8/5, 0) (C2.7);
- a point ∨ a sphere is a scalar, the test of B1: 0 for P(0,0,2), ½ for P(1,1,1) (C2.8).

The join list of the summary the page follows is the outer product of B2: point ∧ point a point pair, point pair ∧ point a circle, circle ∧ point a sphere, flat point ∧ point a line, line ∧ point a plane (C2.9).

![A circle as a meet: the sphere of centre 0 and radius 2 cut by the plane z = 1 (left) and by the sphere of centre (2,0,0) and radius 2 (right). The green circles are drawn from the meet blades, centre, radius² and normal read back by the formulas of B3 (cga_compute.py C2.1–C2.2). Drawn by figs_cga.py.](figs/fig_circle.svg)

![Four meets by the regressive product: plane ∨ plane = line, plane ∨ line = flat point, sphere ∨ line = point pair, circle ∨ sphere = point pair (green), each read back from its blade (cga_compute.py C2.4–C2.7). Drawn by figs_cga.py.](figs/fig_meets.svg)

The meet can vanish, touch or turn imaginary, and the rule shows the three. Two lines in the plane z = 0 have full meet 0 and outer product 0 (C3.1). The regressive product in the whole space is the intersection only when the two blades together span the whole space; two lines of one plane span only that plane, so the product is 0 although they cross, and their outer product is 0 because both contain $e_\infty$. Inside the plane z = 0 the meet is taken against the blade of that plane, $J = e_{12+-}$, with $J^2 = -1$: $L_1 \vee_J L_2 = -e_{1+} - e_{1-} - e_{+-}$, the flat point (−1, 0) (C3.2). The blade J is the plane z = 0, the dual of $e_3$ (C3.3), and the labels e₁ e₂ e₊ e₋ span the cell (3,1) inside (4,1), the conformal model of the plane (ATL-010 for the cell, Cl(3,1) ≅ M₄(ℝ)). Two circles of radius 2 in z = 0 with centres 0 and (12/5, 0) have full meet 0, and inside J the point pair (6/5, ±8/5) (C3.4). Two spheres of radius 2 whose centres are 4 apart touch: their meet has radius² 0 at (2,0,0) (C3.5); at distance 5 the meet is an imaginary circle with radius² −9/4, centre (5/2, 0, 0) (C3.6): $r^2 = 4 - (5/2)^2$, the formula for the circle of two crossing spheres read past the point where they part.

The Atlas has no row on meets of spheres and circles; its joins and meets are those of PGA (the join of two points, FRQ-009; the meet of planes in the motors of the rigid pages). The meet relative to a join smaller than the whole space, and the "plunge" for objects that do not meet, are *recalled* (Dorst, Fontijne and Mann, chapters 5 and 14).

> **Try it.** In the widget press "circle ∨ line": the read-out says the full meet is 0 and shows the meet inside z = 0. Now press "edit A", set its type to "sphere" and its centre and radius to 0, 0 and 2: the meet with the line is now a full meet of grade 2, the same two points.

### Three questions for a geometer (Part C)

1. *Products as filters.* Every product of the course is the rule restricted to a set of label pairs (disjoint, nested, equal). Which other filters give associative products on the labels, and do any of them have a geometric name? The nearest rows are LNS-001 (the all-null rule) and LNC-004 (the complement pairing); none lists the filters.
2. *The meet inside a join.* The widget computes the meet of coplanar objects inside the cell (3,1) of the screen. Is "the meet inside the smallest cell containing both" a functor on the lattice of sub-cells of a cell, in the Atlas's sense of LNC-035 (concatenating generator lists)? Not asked by any row.
3. *Imaginary meets.* The meet of two spheres apart is a circle with negative radius²: in the complexification it is a real circle of complex points. The Atlas's cell (4,1) is M₄(ℂ) with a central complex structure I (ATL-013). Does multiplication by I relate the imaginary meets to real ones? Open; the nearest row is ATL-013 itself.

## Part D · The moves

For a reader who knows the orthogonal group and its double cover: in the conformal model every conformal map of ℝ³ ∪ {∞} is a product of reflections in spheres and planes, and acts on every object, of every grade, by one sandwich.

### D1 · Mirrors, and the inversion

A course reflects in a non-null vector m by $X \mapsto -mXm^{-1}$ (for a vector X). In the conformal model the non-null vectors are the dual planes and the dual spheres, so the reflections are the reflections in planes and the inversions in spheres. The Atlas states the first half: "Planes and spheres are non-null vectors, so they are mirrors; the isometries of R^n are products of at most n + 1 of them. The null vectors ε and o are not mirrors, which is why the degenerate case needed its own page" (PRJ-003). On the labels, the unit sphere at the origin is $\sigma = e_o - \tfrac12 e_\infty$ with $\sigma^2 = 1$, and $-\sigma P(x) \sigma = |x|^2\, P(x/|x|^2)$: the factor is 9, 25 and 1/4 for x = (1,2,2), (3,0,4), (1/2,0,0) (cga_compute.py D1.6). The image of a point under the inversion is a point, with a new weight.

Two mirrors make a move. Two parallel planes x = 0 and x = 3/2 multiply to $\pi_2\pi_1 = 1 - \tfrac32 e_{1+} - \tfrac32 e_{1-}$, which is the translator by (3,0,0), twice the distance of the planes (D2.1). Two planes through the z axis at the angle φ with cos φ = 4/5 multiply to $\tfrac45 - \tfrac35 e_{12}$, which turns by 2φ, with cos 2φ = 7/25 and sin 2φ = 24/25 (D2.2). Two spheres at the origin with radii 1 and 2 multiply to $\tfrac52 - \tfrac32 e_{+-}$, which dilates by 4, the square of the ratio of the radii (D2.3). The Atlas checks the same three, in its convention: "A null pair e_p (−1), e_m (+1) gives the conformal points, with translation as two parallel planes, rotation as two planes through a point, dilation as two concentric spheres" (RSN-022), and `projective_selfcheck.py` lists "two parallel planes are a translation, two planes through the origin a rotation, two concentric spheres a dilation, one sphere an inversion; both bases, n = 2 to 4".

![Two mirrors make a move: two parallel planes (a translation by twice their distance), two planes through the z axis (a rotation by twice their angle), two concentric spheres (a dilation by the square of the ratio of the radii). x is the point (1/4, 1/2), the grey dot its image in the first mirror, x″ its image in the second. Here the mirrors are x = 0 and x = 3/4, two planes at the angle φ with cos φ = 4/5, and spheres of radii 1/2 and 1; by the rule σ₂σ₁ = 1 − ¾(e₁₊ + e₁₋), ⅘ − ⅗e₁₂ and ⅝ − ⅜e₊₋. Drawn by figs_cga.py with the sandwich of cga_compute.py (the same three kinds with other numbers are its lines D2.1–D2.3).](figs/fig_mirrors.svg)

![A grid of lines x = k and y = k (k = ±1, ±2, ±3, dotted) and their images under the inversion in the circle of radius 3/2 (dashed): every line goes to a circle through the centre. Each image is the sandwich −σLσ of the line's blade, read back as a circle by the formulas of B3; x = 1 goes to the circle of centre (9/8, 0) and radius² 81/64. Drawn by figs_cga.py.](figs/fig_inversion.svg)

Where the course goes further: that every conformal map of ℝⁿ ∪ {∞} with n ≥ 3 is a Möbius transformation, a product of inversions (Liouville's theorem), and that the reflections generate the group O(n+1,1) acting on the null cone, are *recalled* (Dorst, Fontijne and Mann, chapter 16; Hestenes and Sobczyk, chapter 8 on conformal transformations). The Atlas checks the bound for isometries, at most n + 1 plane mirrors (PRJ-003), and the Möbius action in the Lorentzian case (CAND-030).

> **Try it.** In the widget, choose B = line, chosen B, and the move "invert": the red image is a circle through the origin. Move the line through the origin: the image becomes a line again (a line through the centre of inversion is its own image).

### D2 · Versors: translation, rotation, dilation, and the ten bivectors

A course writes the moves as exponentials of bivectors, $V = e^{-B/2}$, acting by $X \mapsto V X \tilde V$. The three kinds of bivector of the conformal model are the three squares of the rule. A translation bivector $t\,e_\infty$ squares to 0, so its exponential stops after one term: $T = 1 - \tfrac12 t e_\infty$ with $T\tilde T = 1$, and for t = (1,2,0), $T = 1 - \tfrac12 e_{1+} - e_{2+} - \tfrac12 e_{1-} - e_{2-}$ (cga_compute.py D1.1); $T P(x) \tilde T = P(x + t)$ on the three points tried (D1.2). A rotation bivector $e_{12}$ squares to −1: $R = 2 - e_{12}$, not normalised ($R\tilde R = 5$), turns by cos θ = 3/5, sin θ = 4/5 about the z axis (D1.3). A dilation bivector $e_{+-}$ squares to +1: $D = 3 + e_{+-}$ ($D\tilde D = 8$) sends $e_\infty$ to $\tfrac12 e_\infty$ and $e_o$ to $2e_o$, and every point to $2\,P(x/2)$: a dilation by 1/2 from the origin (D1.4–D1.5). The three squares 0, −1, +1 are the three kinds of move (D1.7), as in the Atlas's check of the plane model, "so the conformal group of the plane Cl(3,1) holds all three classes: rotation (-1), dilation (+1), translation (null bivector a n_inf)" (`gtg_check.log`, part R5), and as the geometry lens reads the squares −1, 0, +1 (its dictionary entry D34: elliptic, parabolic, hyperbolic).

![The four moves of the widget applied by the sandwich to one point, one circle and the line y = −1 (grey): translation by (½, ½), rotation by the angle with cos 3/5, dilation by 2 from the origin, inversion in the circle of radius 3/2. Red: the images V X Ṽ computed by the rule and read back from their blades; under each, the square of the generator. Drawn by figs_cga.py.](figs/fig_versors.svg)

The Atlas records the translation of the conformal model as a null rotation inside a non-degenerate cell, T = 1 − a n∞/2 with n∞ null (LAB-004), and "the translation rotor T = 1 − a n∞/2 moves conformal points exactly with n∞ a null vector of a non-degenerate cell" (RSN-014). The log of part R5 has the line "ok R5 T P(x) T~ = P(x + a): the translation rotor T = 1 - a n_inf/2 moves conformal points exactly (rational arithmetic) -- translation lives inside Cl(3,1); no degenerate generator needed". The inversion is not of this kind: σ is a vector, an odd versor, and it reverses the orientation of what it moves.

The ten bivector labels of (4,1) square as e₁₂, e₁₃, e₂₃, e₁₊, e₂₊, e₃₊ to −1 and e₁₋, e₂₋, e₃₋, e₊₋ to +1 (D3.1). On the null pair they are three rotations $e_{ij}$, three translations $e_i e_\infty$, three special conformal maps $e_i e_o$ and one dilation E, ten in all, and the dilation grades them: $[E, e_i e_\infty] = -2\,e_i e_\infty$ and $[E, e_i e_o] = 2\,e_i e_o$ (D3.2). The Killing form of the ten has 6 negative and 4 positive directions (D3.3), so(4,1), with the six of so(4) negative. The Atlas stores the same counts for its convention: 10 generators, 3 rotations, 3 translations, 3 special conformal, 1 dilation, Killing form 6 negative and 4 positive, and the dilation eigenvalues 2 on the translations and −2 on the special conformal maps: the same size with the opposite sign, which the orientation chosen for the dilation generator decides (`checks/selfcheck/projective.json`, entry conformal space,3; the log `projective_matrix_check.plain.log` checks the moves again with matrices and ends "ALL PROJECTIVE MATRIX CHECKS PASS"). One dimension up, the same split is 15 = J 6 + P 4 + K 4 + D 1 (EQN-015, GRV-004c), graded 4 + 7 + 4 by the dilation (LNB-023i).

Where the course goes further: the exponential and logarithm of a general bivector of (4,1), and the decomposition of a bivector into commuting simple parts, are *recalled* for the conformal model (Dorst, Fontijne and Mann, chapter 16); the Atlas checks the invariant decomposition of Roelfs and De Keninck in Cl(2,2), Cl(3,0,1) and Cl(1,3) (`gtg_check.log`, part R1–R3), not in (4,1). Conformal dynamics, a top or a particle moving by conformal versors, is not built: "The paper has no conformal dynamics" (FRQ-005, open).

> **Try it.** In the widget choose the move "dilate" with the chosen object A (a sphere centred at 0): the radius² in the read-out multiplies by λ², and the coefficients of the blade change only on e₁₂₃₊ and e₁₂₃₋. Then move the sphere off the origin: the dilation moves its centre too.

### Three questions for a geometer (Part D)

1. *Three squares, three moves.* Translations, rotations and dilations are the bivectors of square 0, −1 and +1, the same three squares that choose Euclid, elliptic and hyperbolic geometry for one extra switch (RSN-008). Is the conformal model the place where the three geometries of step 11 meet, each the stabiliser of one vector of the null-pair plane? The nearest rows are PRJ-002 and RSN-008; the statement is not in the Atlas.
2. *The special conformal maps.* The three bivectors $e_i e_o$ are translations conjugated by the inversion. The Atlas checks Maxwell's equations invariant under a special conformal generator of so(2,4) (CAND-139). Which statement of that kind holds for the 3D Laplace equation in (4,1), with the Kelvin transform as the inversion? Not asked by any row.
3. *Dynamics.* The rigid pages run a free top in three plane-based algebras with one engine (PRJ-005). What is the conformal top, and does the inversion act on its phase space? Open (FRQ-005, MAP-035).

## Part E · The PGA neighbour

For a reader who has met plane-based geometric algebra: PGA keeps the flats and the rigid motions and pays one null switch for them; the conformal model keeps the rounds and the dilations and inversions too, and pays two switches of opposite square.

### E1 · One null bit against a null pair: PGA inside the conformal model

PGA of ℝ³ is the cell Cl(3,0,1): three switches of square +1 and one of square 0, which the Atlas calls e₀ (INP-051: "PGA is Cl(n,0,1) when space squares +1 (Dorst and De Keninck) and Cl(0,n,1) when space squares −1 (the convention used here)"). It has 16 labels, and 64 of its 256 label products are 0, the pairs that share e₀ (cga_compute.py E1.1). The null switch is a label: "e₀ of the projective algebra Cl(3,0,1) is a null generator (step 11)" (LNC-021), an unpaired null whose labels span the radical (LNC-070). The map

$$\varphi: \quad e_S \mapsto e_S, \qquad e_S e_0 \mapsto e_S e_\infty \qquad (S \subseteq \{1,2,3\})$$

sends it into the cell (4,1). It is an algebra homomorphism, $\varphi(e_a)\varphi(e_b) = s(a,b)\,\varphi(e_{a \oplus b})$ on 256 of 256 pairs, the 64 zero products of PGA go to zero products, and the 16 images have rank 16, so φ is injective (E1.2). One PGA label goes to two labels of (4,1): $\varphi(e_0) = e_\infty = e_+ + e_-$, $\varphi(e_{12}e_0) = e_{12+} + e_{12-}$ (E1.3). The Atlas checks the same embedding in its convention: "the generators of the base and eps span the degenerate algebra Cl(0,n,1) … as a subalgebra: an injective algebra homomorphism, all pairs of basis elements, n = 2, 3" (`projective_selfcheck.py`; its stored entry pga space,3: 16 and 32 dimensions, 256 products tested, homomorphism and injective), recorded as RSN-008 and MAP-023.

![The sign table of Cl(3,0,1) on its 16 labels (left: e_a e_b = s e_{a⊕b}; blue +1, red −1, grey 0) and the table read from the images in (4,1) (right: the c with φ(e_a)φ(e_b) = c φ(e_{a⊕b})). The two agree entry by entry: 112 plus, 80 minus, 64 zero. Drawn by figs_cga.py with the bit rule of both cells.](figs/fig_pga.svg)

The embedding carries the moves. In PGA the translator by t = (1,2,0) is $1 - \tfrac12 t e_0 = 1 - \tfrac12 e_{10} - e_{20}$, and it sends the plane $\tfrac35 e_1 + \tfrac45 e_2 + 2e_0$ (the plane $\tfrac35 x + \tfrac45 y = 2$) to $\tfrac35 e_1 + \tfrac45 e_2 + \tfrac{21}5 e_0$, the plane moved by $n \cdot t = 11/5$ (E2.1). Its image under φ is the conformal translator of D2, and it sends the image of the plane to the image of the moved plane (E2.2): PGA's planes are the conformal model's dual planes $n + \delta e_\infty$, and PGA's motors go to the conformal versors that fix $e_\infty$ (that these are all the rigid motions is *recalled*, Dorst, Fontijne and Mann, chapter 13).

What this does not say, honestly: inside (4,1) the image of PGA is a degenerate subalgebra of a non-degenerate algebra. Its $e_\infty$ is null but not a radical element of (4,1), because (4,1) also holds the partner $e_o$ with $e_o \cdot e_\infty = -1$; in Cl(3,0,1) nothing pairs with e₀. The Atlas keeps the two kinds apart (LNC-070, PRJ-001) and finds the unpaired kind elsewhere too, as the normal of a null hypersurface (NUL-004). Two algebraic differences follow from the null switch: Cl(3,0,1) is a Frobenius algebra but not a symmetric one, since its Nakayama automorphism is the grade involution and no unit implements it (LNC-030, LNC-112), and whether that twist matters for the complement-based dual that PGA uses is open (LNC-097, LNC-123).

> **Try it.** Check one product of the right table by hand: $\varphi(e_1 e_0)\varphi(e_2) = e_1 e_\infty e_2 = -e_1 e_2 e_\infty = -\varphi(e_{12}e_0)$, and in PGA $e_{10}e_2 = -e_{120}$. Both carry the sign −1 because e₀ and $e_\infty$ each anticommute with e₂.

### E2 · What each has: the table of correspondences

The Atlas's rigid pages use PGA. RIG-007: "The plane-based algebra R(2,0,1) carries the motions of the plane: its motors act on the points e₁₂ − x e₀₂ + y e₀₁ as rigid motions, and its bivectors e₁₂, e₀₁, e₀₂ close as iso(2)". RIG-502 puts the 2ⁿ coefficients of a motor on the vertices of the n-cube, and the rigid motions are the C(n+1, 2) bivectors, 6 at n = 3 (RIG-006, MAP-033). In PGA the distance of two points is the size of their join: a point is the complement of $e_0 + x$, and "the bit rule gives the join of two points at distance d the size d, sin d, sinh d" in the flat, spherical and hyperbolic cases (FRQ-009). Recomputed: the points (1,2,2) and (4,6,2) as complements of $e_0 + x$ have the join $4e_{13} - 3e_{23} - 8e_{10} + 6e_{20} - 2e_{30}$, whose scalar part of $L\tilde L$ is 25, size 5 (cga_compute.py E3.1–E3.2); in (4,1) the same two points have $P \cdot Q = -25/2$ (E3.3). PGA of ℝ³ has 16 labels and 6 bivectors of motion; (4,1) has 32 labels and 10 (E3.4). The three plane-based algebras of the rigid pages and their extension to spheres are taken from Dorst and De Keninck's tables (INP-052, PRJ-004).

| the course says | PGA, Cl(3,0,1) | the conformal model, Cl(4,1) | rows |
|---|---|---|---|
| null element | the switch e₀, a label of square 0 (unpaired, a radical) | $e_\infty = e_+ + e_-$, a sum of two labels (paired with $e_o$) | LNC-021, LNC-070, PRJ-001 |
| algebra | 16 labels, Frobenius, not symmetric | 32 labels, M₄(ℂ), I central | LNC-030, ATL-013 |
| plane | the vector $n + \delta e_0$ | the vector $n + \delta e_\infty$ (φ sends one to the other) | RSN-008, MAP-023 |
| point | a trivector, the complement of $e_0 + x$ | the null vector $P(x)$ | FRQ-009, NUL-008 |
| distance | the size of the join $p \vee q$: d | $P(p) \cdot P(q) = -\tfrac12 d^2$ | FRQ-009 |
| rigid motions | motors, 6 bivectors | the versors that fix $e_\infty$ | RIG-007, RIG-006, LAB-004 |
| translation | $1 - \tfrac12 t e_0$ | $1 - \tfrac12 t e_\infty$, a null rotation | LAB-004, RSN-014 |
| rounds: point pairs, circles, spheres | none (a sphere is not a blade) | blades of grade 2, 3, 4 | PRJ-003 |
| dilation, inversion | none | $e^{\beta E/2}$; reflection in a dual sphere | RSN-022 |
| curved geometries | the square of e₄: 0, +1, −1 gives Euclid, sphere, hyperbolic space | one model holds all three as stabilisers (recalled) | PRJ-004, RSN-008 |
| dynamics | the free top, forced tops, with one engine | not built | PRJ-005, FRQ-005 |

In the lens list of the Atlas the researchers' lens `pga` (Dorst, De Keninck, Gunn) has no dictionary rows yet; its terms sit in the geometry lens, whose entries name "the degenerate co-metric of PGA" for the radical of Cl(p,q,r), the Cayley–Klein pairs for the extra switch of step 11, the conformal compactification for the null pair $P(x) = o + x - \tfrac12 x^2 \varepsilon$ (with NUL-008), and the null rotations for the translation $T = 1 - a n_\infty/2$ (with LAB-004).

Where the course goes further: Gunn's duality of PGA (points as trivectors, the "ideal" plane), and the claim that PGA's equations of motion are the same in the three plane-based geometries, are *cited, not derived*, by the Atlas (PRJ-004); the conformal model's reading of the three geometries as stabilisers is *recalled* (Dorst, Fontijne and Mann, chapter 16).

> **Try it.** In the widget, preset "plane ∨ line": the meet is a flat point, the object PGA also has. Press "edit B" and set its type to "sphere": the meet becomes a circle, which PGA does not have. Count the labels of each in the read-out.

### Three questions for a geometer (Part E)

1. *Which subalgebra?* φ sends PGA into (4,1) by $e_0 \mapsto e_\infty$; sending $e_0 \mapsto e_o$ gives a second copy. Is the pair of copies, meeting in the Euclidean even algebra, the whole of what the conformal model adds to PGA, and does a statement of that form hold in the Atlas's other cells (n = 2 and 3 are checked for one copy, RSN-008)? Open.
2. *The distance.* PGA measures distance by the size of a join (FRQ-009), the conformal model by an inner product. In the elliptic and hyperbolic PGA the size is sin d and sinh d. Which inner product in a cell of the Atlas gives cos d and cosh d for the same points, and is it the conformal model of the sphere and of hyperbolic space? The nearest rows are FRQ-009 and LNB-023e (Fock's projection onto S³, ℝ³, H³); not asked.
3. *The Nakayama twist.* Cl(3,0,1) is Frobenius but not symmetric (LNC-112) while (4,1) is symmetric Frobenius (n odd). Does the embedding φ explain the twist, the conformal model "untwisting" PGA's complement by the partner $e_o$? Open (LNC-097, LNC-123).

## Closing table

The objects of the page, in the course's words and the Atlas's, with the row nearest to each and its status (the link of each id shows the status).

| the course's name | the Atlas's name | row |
|---|---|---|
| $\mathbb R^{4,1}$, the algebra $\mathcal G_{4,1}$ | the cell (4,1), clock 3, M₄(ℂ) | ATL-013 (proved by the Atlas), PAG-006 (standard) |
| the mirror convention, space squaring −1 | the cell (1,4) of step 11, M₂(ℍ) ⊕ M₂(ℍ) | INP-051 (input), LNS-017d (proved by the Atlas) |
| the null vectors $e_o$, $e_\infty$ | the null pair, a sum of two labels of opposite square | PRJ-001 (standard), LNC-070 (proved by the Atlas) |
| the null generator of PGA | the switch e₀ of square 0, unpaired | LNC-021 (proved by the Atlas) |
| the conformal embedding $P(x)$ | the null vectors with $P \cdot e_\infty = -1$ | NUL-008, CAND-030 (proved by the Atlas) |
| the outer product | the all-null rule on disjoint labels | LNS-001 (proved by the Atlas) |
| the dual, the regressive product | multiplication by the top label, the complement pairing | LNC-004 (proved by the Atlas) |
| planes and spheres as reflections | non-null vectors are mirrors | PRJ-003 (proved by the Atlas) |
| translator, rotor, dilator | null, elliptic, hyperbolic bivectors | LAB-004, RSN-014, RSN-022 (proved by the Atlas) |
| the conformal Lie algebra so(4,1) | the ten bivector labels, graded by E | EQN-015, LNB-023i (proved by the Atlas) |
| PGA inside the conformal model | an injective homomorphism, n = 2, 3 | RSN-008, MAP-023 (proved by the Atlas) |
| distance in PGA | the size of the join of two points | FRQ-009 (proved by the Atlas) |
| the three plane-based geometries | one extra switch of square 0, −1, +1 | PRJ-004 (proved by the Atlas), INP-052 (input) |
| conformal dynamics | not built | FRQ-005 (open) |

## Sources, and how far each was read

- **The summary the page follows.** Eric Lengyel, the one-page poster *Conformal Geometric Algebra* (conformalgeometricalgebra.org): read in full in its extracted text, for its list of objects (flat point, line, plane; round point, point pair, circle, sphere) and of operations (join, meet, the dual, carrier, centre, radius, weight). The page takes its mathematics, which is the standard conformal model; it uses its own basis (the Atlas's labels e₁ e₂ e₃ e₊ e₋ and the null pair of `gtg_check.py`), its own notation and its own figures. The poster's further operations (expansion, attitude, the bulk and weight norms) are not drawn here.
- **The rows of the Atlas**, read in their research text (`content/texts.json`, by `tools/proofs_todo.mjs --row`): ATL-010, ATL-013, ATL-013b, ATL-014, ATL-014b, ATL-016, ATL-024, PAG-006, LNC-004, LNC-021, LNC-030, LNC-055, LNC-070, LNC-097, LNC-112, LNC-123, LNS-001, LNS-017d, PRJ-001, PRJ-001b, PRJ-002, PRJ-003, PRJ-004, PRJ-005, PRJ-509, INP-051, INP-052, INP-065, EQN-015, GRV-004c, LNB-023e, LNB-023i, CAND-030, CAND-139, NUL-004, NUL-008, LAB-004, RSN-008, RSN-014, RSN-022, MAP-023, MAP-033, MAP-035, FRQ-005, FRQ-009, RIG-006, RIG-007, RIG-502, LNC-035. Their status is the one of `content/derived/status.json`, shown on each link.
- **The checks and logs**: `checks/selfcheck/projective_selfcheck.py` (the step-11 check: its list of what is checked, the functions null_pair_checks, pga_inside_cga and conformal_algebra read; its log `checks/selfcheck/proofs/logs/projective_selfcheck.plain.log` and the stored results `checks/selfcheck/projective.json`, entries null_pair, pga, conformal and counts); `checks/selfcheck/projective_matrix_check.py` (only its log's last line); `checks/selfcheck/steps15_17/gtg_check.py` part R (the lines R1–R5 of `checks/selfcheck/steps15_17/logs/gtg_check.log`); the records `selfcheck/projective_selfcheck.py` and `selfcheck/steps15_17/gtg_check.py` of `content/checks.json`.
- **The code**: `checks/researchers_checks/bitrule_A.py` (the rule, imported by `cga_compute.py` and `figs_cga.py`); `engines/bitrule.js` (its sign function copied into both widgets).
- **The pages and lenses**: the cells page (`#/cells`), the clock page (`#/clock`), step 11 (`#/steps/projective`), the rigid and forque steps (`#/steps/rigid`, `#/steps/forque`); `content/lenses.json`, the lenses `pga` (no dictionary rows) and `geo` (the entries quoted in E2); the geometer's reading `reports/analyses/reading_geometry.html` (searched for the conformal model, its lines on step 11 read).
- **The shipped tutorial** "The bit rule and four college courses": Part 0 (the rule and the worked example at n = 2, kept and redrawn here) and Part A on the Hodge star, read; the rest searched for the conformal model, which it does not treat.
- **This page's own computations**: `cga_compute.py` (every number, with the id of its printed line), `figs_cga.py` (every figure), `widgets/cga.js` and `widgets/points.js`.
- **Recalled, not in the package**: Leo Dorst, Daniel Fontijne and Stephen Mann, *Geometric Algebra for Computer Science: An Object-Oriented Approach to Geometry* (chapters 3, 5, 13, 14, 16 for the contraction, the meet, the conformal model, its objects and its versors); David Hestenes and Garret Sobczyk, *Clifford Algebra to Geometric Calculus* (chapters 1 and 8); David Hestenes, *New Foundations for Classical Mechanics* (for the rotor picture of rotations); Pertti Lounesto, *Clifford Algebras and Spinors*, and Ian Porteous, *Clifford Algebras and the Classical Groups* (for the classification by p − q mod 8). None of them is in `$SP/second_source/txt_clean/`; the statements taken from them are marked *recalled* where they are used.
