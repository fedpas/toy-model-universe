(function (id) {
  // points.js: two points of R^3 embedded as null vectors of the cell (4,1); their inner product, by the bit rule, against -|p - q|^2 / 2.
  const root = document.getElementById(id); if (!root) return;

  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }

  const EPS = [1, 1, 1, 1, -1], N = 32;
  const gp = (x, y) => { const o = new Float64Array(N); for (let a = 0; a < N; a++) if (x[a]) for (let b = 0; b < N; b++) if (y[b]) o[a ^ b] += sign(a, b, EPS) * x[a] * y[b]; return o; };
  const op = (x, y) => { const o = new Float64Array(N); for (let a = 0; a < N; a++) if (x[a]) for (let b = 0; b < N; b++) if (y[b] && !(a & b)) o[a ^ b] += sign(a, b, EPS) * x[a] * y[b]; return o; };
  const P = (x, y, z) => { const o = new Float64Array(N), h = (x * x + y * y + z * z) / 2; o[1] = x; o[2] = y; o[4] = z; o[8] = h - 0.5; o[16] = h + 0.5; return o; };  // e_o + x + h e_inf

  // self-test: ten stored products (cga_compute.py W.1), P(1,2,2) on the labels (A4.2), P(1,2,0).P(4,6,0) = -25/2 (A4.4)
  const STORED = [[1, 2, 1, 3], [2, 1, -1, 3], [16, 16, -1, 0], [8, 16, 1, 24], [24, 24, 1, 0], [31, 31, -1, 0], [7, 7, -1, 0], [13, 22, -1, 27], [11, 28, -1, 23], [30, 17, -1, 15]];
  const p122 = P(1, 2, 2);
  const ok = STORED.every(([a, b, s, k]) => sign(a, b, EPS) === s && (a ^ b) === k)
    && [1, 2, 2, 4, 5].every((v, i) => p122[[1, 2, 4, 8, 16][i]] === v) && gp(P(1, 2, 0), P(4, 6, 0))[0] === -12.5;
  if (!ok) { root.textContent = 'self-test failed'; return; }

  const num = v => { const r = Math.round(v * 1000) / 1000; return (Object.is(r, -0) ? 0 : r).toString(); };
  const SUBN = ['e₁', 'e₂', 'e₃', 'e₊', 'e₋'];
  const onLabels = X => { const t = []; [1, 2, 4, 8, 16].forEach((m, i) => { if (X[m]) t.push((X[m] < 0 ? (t.length ? '− ' : '−') : (t.length ? '+ ' : '')) + (Math.abs(X[m]) === 1 ? '' : num(Math.abs(X[m])) + ' ') + SUBN[i]); }); return t.join(' ') || '0'; };
  const st = { p: [-1, -1, 0], q: [2, 3, 0] };
  root.innerHTML = `<div style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-start">
   <div style="flex:1 1 250px;min-width:0" class="pt-sl"></div>
   <div style="flex:1 1 260px;max-width:360px;min-width:0"><svg viewBox="0 0 320 224" width="320" height="224" role="img" aria-label="the curve minus half the squared distance, with the current pair" style="width:100%;height:auto;display:block;border:1px solid var(--line);border-radius:8px;background:var(--bg)"></svg></div></div>
   <div class="widget__out" aria-live="polite"></div>`;
  const box = root.querySelector('.pt-sl'), svg = root.querySelector('svg'), out = root.querySelector('.widget__out');
  ['p', 'q'].forEach(w => ['x', 'y', 'z'].forEach((c, i) => {
    const l = document.createElement('label'); l.style.display = 'block'; l.style.margin = '2px 0';
    l.innerHTML = `<span style="display:inline-block;min-width:34px">${w}${c}</span> <input type="range" min="-3.5" max="3.5" step="0.25" value="${st[w][i]}" aria-label="${w} ${c}"> <output style="font-family:ui-monospace,monospace;font-size:13px">${num(st[w][i])}</output>`;
    const r = l.querySelector('input'), o = l.querySelector('output');
    r.addEventListener('input', () => { st[w][i] = +r.value; o.textContent = num(+r.value); draw(); });
    box.appendChild(l);
  }));
  function draw() {
    const A = P(...st.p), B = P(...st.q), AB = gp(A, B), d2 = st.p.reduce((s, v, i) => s + (v - st.q[i]) ** 2, 0);
    const pr = op(A, B), pr2 = gp(pr, pr)[0];
    const sx = 26, sy = 4.2, ox = 30, oy = 16;
    let g = '';
    for (let k = 0; k <= 10; k += 2) g += `<line x1="${ox + k * sx}" y1="${oy}" x2="${ox + k * sx}" y2="${oy + 44 * sy}" stroke="var(--line)" stroke-width=".6"/><text x="${ox + k * sx}" y="${oy + 44 * sy + 14}" font-size="11" text-anchor="middle" fill="var(--muted)">${k}</text>`;
    for (let v = 0; v >= -40; v -= 10) g += `<line x1="${ox}" y1="${oy - v * sy}" x2="${ox + 10 * sx}" y2="${oy - v * sy}" stroke="var(--line)" stroke-width=".6"/><text x="${ox - 4}" y="${oy - v * sy + 4}" font-size="11" text-anchor="end" fill="var(--muted)">${v}</text>`;
    let d = ''; for (let t = 0; t <= 100; t++) { const dd = t / 10; if (0.5 * dd * dd > 44) break; d +=(t ? 'L' : 'M') + (ox + dd * sx).toFixed(1) + ' ' + (oy + 0.5 * dd * dd * sy).toFixed(1); }
    g += `<path d="${d}" fill="none" stroke="var(--acc)" stroke-width="2"/>`;
    const dist = Math.sqrt(d2), cy = Math.min(oy + 44 * sy, oy - AB[0] * sy);
    g += `<circle cx="${(ox + Math.min(dist, 10) * sx).toFixed(1)}" cy="${cy.toFixed(1)}" r="6" fill="#d0543c"/><text x="${ox + 8}" y="${oy + 44 * sy - 8}" font-size="12" fill="var(--ink2)">|p − q| = ${num(dist)}, P·Q = ${num(AB[0])}</text>`;
    svg.innerHTML = g;
    out.textContent = [
      'P(p) = ' + onLabels(A) + '   (= eₒ + p + ' + num(st.p.reduce((s, v) => s + v * v, 0) / 2) + ' e∞)',
      'P(q) = ' + onLabels(B),
      'P(p)² = ' + num(gp(A, A)[0]) + ', P(q)² = ' + num(gp(B, B)[0]) + '   (null vectors: a point is a ray of the null cone)',
      'P(p)·P(q) = ' + num(AB[0]) + ' by the rule;  −½|p − q|² = ' + num(-d2 / 2),
      'P(p)P(q) = P·Q + P∧Q; (P∧Q)² = ' + num(pr2) + ' = (P·Q)², the point pair of radius² ' + num(d2 / 4),
    ].join('\n');
  }
  draw();
})
