(function (id) {
  // cga.js: the conformal model of R^3 on the cell (4,1), in one widget. Every product is the bit rule on the 32 labels
  // (bits e1 e2 e3 e+ e-), computed here in the browser; the screen is the plane z = 0. No library, no network.
  const root = document.getElementById(id); if (!root) return;

  // the bit rule, as engines/bitrule.js
  const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
  function nPairs(a, b) { let c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
  function sign(a, b, eps) { let v = reorderSign(a, b); let m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }

  // ---- the cell (4,1) and its products
  const EPS = [1, 1, 1, 1, -1], N = 32;
  const SG = new Int8Array(N * N), PC = new Int8Array(N);
  for (let a = 0; a < N; a++) { PC[a] = popcount(a); for (let b = 0; b < N; b++) SG[a * N + b] = sign(a, b, EPS); }
  const Z = () => new Float64Array(N);
  function prod(x, y, keep) { const o = Z(); for (let a = 0; a < N; a++) { const xa = x[a]; if (!xa) continue; for (let b = 0; b < N; b++) { const yb = y[b]; if (!yb || !keep(a, b)) continue; o[a ^ b] += SG[a * N + b] * xa * yb; } } return o; }
  const gp = (x, y) => prod(x, y, () => true);                    // geometric product: every label pair
  const op = (x, y) => prod(x, y, (a, b) => (a & b) === 0);       // outer product: disjoint labels
  const lc = (x, y) => prod(x, y, (a, b) => (a & b) === a);       // left contraction: a inside b
  const add = (x, y, c = 1) => { const o = Z(); for (let i = 0; i < N; i++) o[i] = x[i] + c * y[i]; return o; };
  const scal = (x, c) => { const o = Z(); for (let i = 0; i < N; i++) o[i] = c * x[i]; return o; };
  const rev = x => { const o = Z(); for (let a = 0; a < N; a++) o[a] = ((PC[a] * (PC[a] - 1) / 2) % 2 ? -1 : 1) * x[a]; return o; };
  const inv = x => { const o = Z(); for (let a = 0; a < N; a++) o[a] = (PC[a] % 2 ? -1 : 1) * x[a]; return o; };
  const one = c => { const o = Z(); o[0] = c; return o; };
  const blade = (m, c = 1) => { const o = Z(); o[m] = c; return o; };
  const I = blade(31), IINV = blade(31, -1);                      // I^2 = -1
  const J = blade(27), JINV = blade(27, -1);                      // the plane z = 0: e1 e2 e+ e-, J^2 = -1
  const dual = x => gp(x, IINV), undual = x => gp(x, I);
  const meet = (x, y) => undual(op(dual(x), dual(y)));
  const meetJ = (x, y) => gp(op(gp(x, JINV), gp(y, JINV)), J);
  const EINF = (() => { const o = Z(); o[8] = 1; o[16] = 1; return o; })();
  const EO = (() => { const o = Z(); o[8] = -0.5; o[16] = 0.5; return o; })();
  const vec = (x, y, z) => { const o = Z(); o[1] = x; o[2] = y; o[4] = z; return o; };
  const P = (x, y, z = 0) => add(add(EO, vec(x, y, z)), EINF, (x * x + y * y + z * z) / 2);
  const dot = (u, v) => gp(u, v)[0];
  const nrm = x => { let m = 0; for (let i = 0; i < N; i++) m = Math.max(m, Math.abs(x[i])); return m; };
  const clean = x => { const m = nrm(x), o = Z(); for (let i = 0; i < N; i++) o[i] = Math.abs(x[i]) > 1e-9 * m ? x[i] : 0; return o; };
  const grades = x => { const s = new Set(); for (let i = 0; i < N; i++) if (x[i]) s.add(PC[i]); return [...s].sort(); };
  const loc = v => { const w = -dot(v, EINF); return [v[1] / w, v[2] / w, v[4] / w]; };
  const isFlat = X => nrm(op(X, EINF)) <= 1e-9 * nrm(X);
  const center = X => loc(gp(gp(X, EINF), X));
  const radius2 = X => { const d = lc(EINF, X); return gp(X, inv(X))[0] / gp(d, d)[0]; };
  const inScreen = X => { for (let i = 0; i < N; i++) if (X[i] && (i & 4)) return false; return true; };
  function sandwich(V, X) {
    const n = gp(V, rev(V))[0]; let Y = gp(gp(V, X), rev(V));
    let odd = true; for (let i = 0; i < N; i++) if (V[i] && PC[i] % 2 === 0) odd = false;
    if (odd) Y = inv(Y);
    return clean(scal(Y, 1 / n));
  }
  const dualSphere = (cx, cy, r) => add(P(cx, cy, 0), EINF, -r * r / 2);

  // ---- self-test: ten stored products of (4,1) (cga_compute.py W.1) and the numbers of the figures
  const STORED = [[1, 2, 1, 3], [2, 1, -1, 3], [16, 16, -1, 0], [8, 16, 1, 24], [24, 24, 1, 0], [31, 31, -1, 0], [7, 7, -1, 0], [13, 22, -1, 27], [11, 28, -1, 23], [30, 17, -1, 15]];
  const near = (a, b) => Math.abs(a - b) < 1e-9;
  const S1 = undual(dualSphere(0, 0, 2)), Mz = clean(meet(S1, undual(add(vec(0, 0, 1), EINF, 1)))), Mx = clean(meet(S1, undual(dualSphere(2, 0, 2))));
  const cz = center(Mz), cx_ = center(Mx), inv9 = loc(sandwich(dualSphere(0, 0, 1), P(1, 2, 2)));
  const tests = [
    STORED.every(([a, b, s, k]) => sign(a, b, EPS) === s && (a ^ b) === k),
    near(radius2(Mz), 3) && near(cz[0], 0) && near(cz[1], 0) && near(cz[2], 1),       // C2.2
    near(radius2(Mx), 3) && near(cx_[0], 1) && near(cx_[1], 0) && near(cx_[2], 0),    // C2.1
    near(dot(P(1, 2, 0), P(4, 6, 0)), -12.5),                                          // A4.4
    near(inv9[0], 1 / 9) && near(inv9[1], 2 / 9) && near(inv9[2], 2 / 9),             // D1.6
  ];
  if (!tests.every(Boolean)) { root.textContent = 'self-test failed: ' + tests.map((t, i) => t ? '' : '#' + (i + 1)).join(' '); return; }

  // ---- names and numbers
  const SUB = ['₁', '₂', '₃', '₊', '₋'];
  const lab = m => m ? 'e' + [0, 1, 2, 3, 4].filter(i => (m >> i) & 1).map(i => SUB[i]).join('') : '1';
  const num = v => { const r = Math.round(v * 1000) / 1000; return (Object.is(r, -0) ? 0 : r).toString(); };
  function terms(list) {
    if (!list.length) return '0';
    return list.map(([c, name], k) => { const s = c < 0 ? '−' : (k ? '+' : ''); const a = Math.abs(c); const cs = (near(a, 1) && name !== '1') ? '' : num(a) + (name === '1' ? '' : ' '); return (k ? ' ' + s + ' ' : s) + cs + (name === '1' ? '' : name); }).join('').trim();
  }
  function onLabels(X) { const order = [...Array(N).keys()].sort((a, b) => PC[a] - PC[b] || a - b); return terms(order.filter(m => X[m]).map(m => [X[m], lab(m)])); }
  function onNull(X) {
    const out = [], S3 = ['', '₁', '₂', '₁₂', '₃', '₁₃', '₂₃', '₁₂₃'];
    const nm = (s, t) => (s ? 'e' + S3[s] + (t ? '∧' + t : '') : (t || '1'));
    for (const s of [0, 1, 2, 4, 3, 5, 6, 7]) {
      const al = X[s], be = X[s | 8], ga = X[s | 16], de = X[s | 24];
      if (Math.abs(al) > 1e-12) out.push([al, nm(s, '')]);
      if (Math.abs(ga - be) > 1e-12) out.push([ga - be, nm(s, 'eₒ')]);
      if (Math.abs((be + ga) / 2) > 1e-12) out.push([(be + ga) / 2, nm(s, 'e∞')]);
      if (Math.abs(de) > 1e-12) out.push([de, nm(s, 'E')]);
    }
    return terms(out);
  }
  const v3 = p => '(' + p.map(num).join(', ') + ')';

  // ---- reading a blade: its kind and its geometry (as figs_cga.py reads it)
  function read(X) {
    X = clean(X); const m = nrm(X); if (m < 1e-12) return { kind: 'zero', X };
    const g = grades(X); if (g.length > 1) return { kind: 'mixed grades ' + g.join(', '), X };
    const k = g[0], r = { X, k };
    if (k === 0) return Object.assign(r, { kind: 'scalar ' + num(X[0]) });
    if (k === 5) return Object.assign(r, { kind: 'pseudoscalar ' + num(X[31]) + ' I' });
    if (k === 1) {
      const sq = dot(X, X), w = -dot(X, EINF);
      if (Math.abs(sq) <= 1e-9 * m * m) return Object.assign(r, { kind: 'point', p: loc(X), w });
      if (Math.abs(w) <= 1e-9 * m) { const n = [X[1], X[2], X[4]], nn = Math.hypot(...n); return Object.assign(r, { kind: 'dual plane (a vector, not null)', plane: { n: n.map(t => t / nn), d: X[8] / nn } }); }
      return Object.assign(r, { kind: 'dual sphere (a vector, not null)', c: loc(X), r2: sq / (w * w) });
    }
    const flat = isFlat(X);
    if (k === 2 && flat) { const w = -X[24]; if (Math.abs(w) < 1e-9 * m) return Object.assign(r, { kind: 'flat point at infinity' }); return Object.assign(r, { kind: 'flat point', p: [X[9] / w, X[10] / w, X[12] / w] }); }
    if (k === 2) {
      const x2 = gp(X, X)[0], d = lc(EINF, X), r2 = radius2(X);
      if (Math.abs(x2) <= 1e-9 * m * m) return Object.assign(r, { kind: 'tangent point pair (one point)', c: center(X), r2: 0 });
      if (x2 < 0) return Object.assign(r, { kind: 'imaginary point pair', c: center(X), r2 });
      const pts = [1, -1].map(s => loc(gp(add(X, one(s * Math.sqrt(x2))), d)));
      return Object.assign(r, { kind: 'point pair', pts, c: center(X), r2 });
    }
    if (k === 3 && flat) {
      const d = [X[25], X[26], X[28]], Mv = [X[14], -X[13], X[11]], dd = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
      if (dd < 1e-18 * m * m) return Object.assign(r, { kind: 'line at infinity' });
      const p = [(d[1] * Mv[2] - d[2] * Mv[1]) / dd, (d[2] * Mv[0] - d[0] * Mv[2]) / dd, (d[0] * Mv[1] - d[1] * Mv[0]) / dd];
      return Object.assign(r, { kind: 'line', p, d: d.map(t => t / Math.sqrt(dd)) });
    }
    if (k === 3) {
      const pi = dual(op(X, EINF)), n = [pi[1], pi[2], pi[4]], nn = Math.hypot(...n) || 1;
      return Object.assign(r, { kind: radius2(X) < -1e-9 ? 'imaginary circle' : 'circle', c: center(X), r2: radius2(X), n: n.map(t => t / nn) });
    }
    if (k === 4 && flat) {
      const pi = dual(X), n = [pi[1], pi[2], pi[4]], nn = Math.hypot(...n);
      if (nn < 1e-12 * m) return Object.assign(r, { kind: 'plane at infinity' });
      return Object.assign(r, { kind: 'plane', plane: { n: n.map(t => t / nn), d: pi[8] / nn } });
    }
    return Object.assign(r, { kind: radius2(X) < -1e-9 ? 'imaginary sphere' : 'sphere', c: center(X), r2: radius2(X) });
  }
  function describe(R) {
    if (R.kind === 'zero') return '0';
    const lines = [R.kind + (R.k !== undefined && !/^scalar|^pseudo/.test(R.kind) ? ' (grade ' + R.k + ')' : '')];
    if (R.p) lines.push((R.kind === 'line' ? 'through ' : 'at ') + v3(R.p) + (R.d ? ' along ' + v3(R.d) : ''));
    if (R.pts) lines.push('points ' + v3(R.pts[0]) + ' and ' + v3(R.pts[1]));
    if (R.c && !R.p) lines.push('centre ' + v3(R.c) + ', radius² ' + num(R.r2) + (R.n ? ', normal ' + v3(R.n) : ''));
    if (R.plane) lines.push('the plane ' + v3(R.plane.n) + '·x = ' + num(R.plane.d) + (Math.hypot(R.plane.n[0], R.plane.n[1]) < 1e-9 ? ' (parallel to the screen: no trace)' : ''));
    if (R.X) { lines.push('on the labels: ' + onLabels(R.X)); lines.push('on the null pair: ' + onNull(R.X)); }
    return lines.join('\n');
  }

  // ---- the objects of the palette, built by the outer product from points (the plane and the sphere by their duals too)
  const TYPES = {
    point: { p: ['x', 'y'], make: ([x, y]) => P(x, y) },
    pair: { p: ['x₁', 'y₁', 'x₂', 'y₂'], make: ([a, b, c, d]) => op(P(a, b), P(c, d)) },
    circle: { p: ['centre x', 'centre y', 'radius'], make: ([x, y, r]) => op(op(P(x + r, y), P(x, y + r)), P(x - r, y)) },
    line: { p: ['x₁', 'y₁', 'x₂', 'y₂'], make: ([a, b, c, d]) => op(op(P(a, b), P(c, d)), EINF) },
    sphere: { p: ['centre x', 'centre y', 'radius'], make: ([x, y, r]) => undual(dualSphere(x, y, r)) },
    plane: { p: ['x₁', 'y₁', 'x₂', 'y₂'], make: ([a, b, c, d]) => op(op(op(P(a, b), P(c, d)), P(a, b, 1)), EINF) },
    flat: { p: ['x', 'y'], make: ([x, y]) => op(P(x, y), EINF) },
  };
  const TNAME = { point: 'point', pair: 'point pair', circle: 'circle (in z = 0)', line: 'line (in z = 0)', sphere: 'sphere (centre in z = 0)', plane: 'plane (upright)', flat: 'flat point' };
  const PRESETS = [
    ['sphere ∨ line', ['sphere', [0, 0, 2]], ['line', [-3, -1.5, 3, 1]], 'meet'],
    ['sphere ∨ sphere', ['sphere', [-0.75, 0, 2]], ['sphere', [1.25, 0.5, 1.5]], 'meet'],
    ['sphere ∨ plane', ['sphere', [0, 0, 2]], ['plane', [1, -3, 1.5, 3]], 'meet'],
    ['plane ∨ line', ['plane', [-2, -3, 1, 3]], ['line', [-3, 1, 3, 0]], 'meet'],
    ['plane ∨ plane', ['plane', [-2, -3, 1, 3]], ['plane', [-3, 1, 3, -0.5]], 'meet'],
    ['circle ∨ line', ['circle', [0, 0, 2]], ['line', [-3, -1, 3, 1.5]], 'meet'],
    ['point ∧ point', ['point', [-2, -1]], ['point', [2, 1.5]], 'join'],
    ['pair ∧ point', ['pair', [-2, 0, 2, 0]], ['point', [0.5, 2]], 'join'],
    ['flat point ∧ point', ['flat', [-2, -1]], ['point', [2, 1.5]], 'join'],
  ];
  const st = { A: { t: 'sphere', v: [0, 0, 2] }, B: { t: 'line', v: [-3, -1.5, 3, 1] }, edit: 'A', chosen: 'meet', move: 'none', m1: 1, m2: 0.5, showJ: true, showM: true };
  const MOVES = {
    none: { p: [] },
    translate: { p: [['tₓ', -3, 3, 0.25], ['tᵧ', -3, 3, 0.25]], make: (a, b) => add(one(1), gp(vec(a, b, 0), EINF), -0.5), say: (a, b) => 'T = 1 − ½ t e∞, t = (' + num(a) + ', ' + num(b) + ', 0); (t e∞)² = 0' },
    rotate: { p: [['θ (degrees)', -180, 180, 5]], make: a => { const h = a * Math.PI / 360, o = Z(); o[0] = Math.cos(h); o[3] = -Math.sin(h); return o; }, say: a => 'R = cos(θ/2) − sin(θ/2) e₁₂, θ = ' + num(a) + '° about the z axis; e₁₂² = −1' },
    dilate: { p: [['log₂ λ', -2, 2, 0.1]], make: a => { const h = a * Math.LN2 / 2, o = Z(); o[0] = Math.cosh(h); o[24] = -Math.sinh(h); return o; }, say: a => 'D = cosh(½ ln λ) − sinh(½ ln λ) e₊₋, λ = ' + num(Math.pow(2, a)) + ' from 0; e₊₋² = +1' },
    invert: { p: [['radius ρ', 0.5, 3, 0.25]], make: a => dualSphere(0, 0, a), say: a => 'σ = eₒ − ½ρ² e∞, ρ = ' + num(a) + ' (a mirror: −σXσ, σ² = ρ²)' },
  };

  // ---- the page of the widget
  const css = 'display:flex;flex-wrap:wrap;gap:12px;align-items:flex-start';
  root.innerHTML = `<div style="${css}">
  <div style="flex:1 1 300px;max-width:420px;min-width:0"><svg viewBox="0 0 400 400" width="400" height="400" role="img" style="width:100%;height:auto;display:block;border:1px solid var(--line);border-radius:8px;background:var(--bg)"></svg>
  <p class="cg-legend" style="font-size:13px;margin:6px 0 0;color:var(--ink2)"></p></div>
  <div style="flex:1 1 260px;min-width:0">
   <div class="cg-presets" style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px"></div>
   <div style="margin-bottom:6px"><button type="button" data-edit="A">edit A</button> <button type="button" data-edit="B">edit B</button>
    <label style="margin-left:6px">type <select class="cg-type"></select></label></div>
   <div class="cg-sl"></div>
   <div style="margin:8px 0 4px"><button type="button" class="cg-j" aria-pressed="true">A ∧ B (join)</button> <button type="button" class="cg-m" aria-pressed="true">A ∨ B (meet)</button></div>
   <div style="margin:4px 0"><label>chosen <select class="cg-ch"><option value="A">A</option><option value="B">B</option><option value="join">A ∧ B</option><option value="meet">A ∨ B</option></select></label></div>
   <div class="cg-mv" style="display:flex;flex-wrap:wrap;gap:4px;margin:6px 0"></div>
   <div class="cg-msl"></div>
  </div></div>
  <div class="widget__out" aria-live="polite"></div>`;
  const $ = s => root.querySelector(s);
  const svg = $('svg'), out = $('.widget__out'), legend = $('.cg-legend');
  const typeSel = $('.cg-type'); for (const t of Object.keys(TYPES)) typeSel.insertAdjacentHTML('beforeend', `<option value="${t}">${TNAME[t]}</option>`);
  PRESETS.forEach((p, i) => $('.cg-presets').insertAdjacentHTML('beforeend', `<button type="button" data-preset="${i}">${p[0]}</button>`));
  Object.keys(MOVES).forEach(m => $('.cg-mv').insertAdjacentHTML('beforeend', `<button type="button" data-move="${m}" aria-pressed="false">${m}</button>`));

  function slider(label, min, max, step, value, onInput) {
    const w = document.createElement('label'); w.style.display = 'block'; w.style.margin = '2px 0';
    w.innerHTML = `<span style="display:inline-block;min-width:76px">${label}</span> <input type="range" min="${min}" max="${max}" step="${step}" value="${value}" aria-label="${label}"> <output style="font-family:ui-monospace,monospace;font-size:13px"></output>`;
    const r = w.querySelector('input'), o = w.querySelector('output'); o.textContent = num(+value);
    r.addEventListener('input', () => { o.textContent = num(+r.value); onInput(+r.value); });
    return w;
  }
  function buildSliders() {
    const box = $('.cg-sl'); box.innerHTML = ''; const ob = st[st.edit], T = TYPES[ob.t];
    T.p.forEach((nm, i) => {
      const isR = /radius/.test(nm), min = isR ? 0.25 : -3.5, max = 3.5;
      if (ob.v[i] === undefined) ob.v[i] = isR ? 1.5 : (i % 2 ? 1 : -1) * (1 + i * 0.5);
      box.appendChild(slider(st.edit + ': ' + nm, min, max, 0.25, ob.v[i], v => { ob.v[i] = v; draw(); }));
    });
    typeSel.value = ob.t;
    root.querySelectorAll('[data-edit]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.edit === st.edit)));
  }
  function buildMoveSliders() {
    const box = $('.cg-msl'); box.innerHTML = ''; const M = MOVES[st.move];
    M.p.forEach(([nm, min, max, step], i) => {
      const key = i ? 'm2' : 'm1'; if (st[key] < min || st[key] > max) st[key] = (min + max) / 2 || min;
      box.appendChild(slider(nm, min, max, step, st[key], v => { st[key] = v; draw(); }));
    });
    root.querySelectorAll('[data-move]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.move === st.move)));
  }

  // ---- drawing on the plane z = 0
  const S = 46, O = 200, BOX = [-4.3, 4.3, -4.3, 4.3];
  const X_ = x => (O + S * x).toFixed(1), Y_ = y => (O - S * y).toFixed(1);
  function clipLine(p, d) {
    let t0 = -1e9, t1 = 1e9;
    for (const [pi, di, lo, hi] of [[p[0], d[0], BOX[0], BOX[1]], [p[1], d[1], BOX[2], BOX[3]]]) {
      if (Math.abs(di) < 1e-12) { if (pi < lo || pi > hi) return null; continue; }
      const a = (lo - pi) / di, b = (hi - pi) / di; t0 = Math.max(t0, Math.min(a, b)); t1 = Math.min(t1, Math.max(a, b));
    }
    return t0 > t1 ? null : [[p[0] + t0 * d[0], p[1] + t0 * d[1]], [p[0] + t1 * d[0], p[1] + t1 * d[1]]];
  }
  const seg = (q, col, w, extra = '') => q ? `<line x1="${X_(q[0][0])}" y1="${Y_(q[0][1])}" x2="${X_(q[1][0])}" y2="${Y_(q[1][1])}" stroke="${col}" stroke-width="${w}" ${extra}/>` : '';
  const dotS = (p, col, r = 4.5, extra = '') => `<circle cx="${X_(p[0])}" cy="${Y_(p[1])}" r="${r}" fill="${col}" ${extra}/>`;
  function perp(n) { const a = Math.abs(n[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0]; let u = [a[1] * n[2] - a[2] * n[1], a[2] * n[0] - a[0] * n[2], a[0] * n[1] - a[1] * n[0]]; const l = Math.hypot(...u); u = u.map(t => t / l); return [u, [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]]]; }
  function drawRead(R, col, w, dash) {
    const da = dash ? ` stroke-dasharray="${dash}"` : '';
    switch (R.kind) {
      case 'point': return dotS(R.p, col, 5);
      case 'flat point': return dotS(R.p, 'none', 6.5, `stroke="${col}" stroke-width="2.2"`) + dotS(R.p, col, 2.6);
      case 'point pair': return seg([R.pts[0], R.pts[1]], col, 1.2, 'stroke-dasharray="3 3"') + dotS(R.pts[0], col, 5) + dotS(R.pts[1], col, 5);
      case 'tangent point pair (one point)': return dotS(R.c, col, 5);
      case 'imaginary point pair': case 'imaginary circle': case 'imaginary sphere': {
        const r = Math.sqrt(-R.r2); return `<circle cx="${X_(R.c[0])}" cy="${Y_(R.c[1])}" r="${(S * r).toFixed(1)}" fill="none" stroke="${col}" stroke-width="1" stroke-dasharray="1 4" opacity=".8"/>` + dotS(R.c, col, 2.5);
      }
      case 'line': {
        const dxy = Math.hypot(R.d[0], R.d[1]);
        if (dxy < 1e-9) return dotS(R.p, 'none', 7, `stroke="${col}" stroke-width="2"`) + dotS(R.p, col, 2.2);
        return seg(clipLine(R.p, [R.d[0] / dxy, R.d[1] / dxy]), col, w, da);
      }
      case 'circle': {
        const r = Math.sqrt(Math.max(R.r2, 0)), [u, v] = perp(R.n); let d = '';
        for (let t = 0; t <= 96; t++) { const a = 2 * Math.PI * t / 96; const x = R.c[0] + r * (Math.cos(a) * u[0] + Math.sin(a) * v[0]), y = R.c[1] + r * (Math.cos(a) * u[1] + Math.sin(a) * v[1]); d += (t ? 'L' : 'M') + X_(x) + ' ' + Y_(y); }
        return `<path d="${d}" fill="none" stroke="${col}" stroke-width="${w}"${da}/>`;
      }
      case 'sphere': {
        const r = Math.sqrt(R.r2); return `<circle cx="${X_(R.c[0])}" cy="${Y_(R.c[1])}" r="${(S * r).toFixed(1)}" fill="${col}" fill-opacity=".09" stroke="${col}" stroke-width="${w}"${da}/>`;
      }
      case 'plane': case 'dual plane (a vector, not null)': {
        const n = R.plane.n, nxy = Math.hypot(n[0], n[1]); if (nxy < 1e-9) return '';
        const p = [R.plane.d * n[0] / (nxy * nxy), R.plane.d * n[1] / (nxy * nxy)], q = clipLine(p, [-n[1] / nxy, n[0] / nxy]);
        return seg(q, col, 9, 'stroke-opacity=".16"') + seg(q, col, w, da);
      }
      case 'dual sphere (a vector, not null)': {
        if (R.r2 <= 0) return dotS(R.c, col, 2.5);
        return `<circle cx="${X_(R.c[0])}" cy="${Y_(R.c[1])}" r="${(S * Math.sqrt(R.r2)).toFixed(1)}" fill="none" stroke="${col}" stroke-width="${w}" stroke-dasharray="6 3"/>`;
      }
      default: return '';
    }
  }

  const COL = { A: 'var(--acc)', B: '#d9822b', join: '#8e5bb5', meet: '#2f9154', img: '#d0543c' };
  function draw() {
    const A = clean(TYPES[st.A.t].make(st.A.v)), B = clean(TYPES[st.B.t].make(st.B.v));
    let Jn = clean(op(A, B)), Mt = clean(meet(A, B)), mnote = '';
    if (nrm(Mt) < 1e-12 && inScreen(A) && inScreen(B)) { Mt = clean(meetJ(A, B)); mnote = 'the full meet is 0 (both lie in the plane z = 0); shown: the meet inside z = 0, the cell (3,1) inside (4,1)'; }
    const objs = { A, B, join: Jn, meet: Mt }, R = { A: read(A), B: read(B), join: read(Jn), meet: read(Mt) };
    let g = '';
    for (let k = -4; k <= 4; k++) g += `<line x1="${X_(k)}" y1="${Y_(-4.3)}" x2="${X_(k)}" y2="${Y_(4.3)}" stroke="var(--line)" stroke-width="${k ? 0.6 : 1.2}"/><line x1="${X_(-4.3)}" y1="${Y_(k)}" x2="${X_(4.3)}" y2="${Y_(k)}" stroke="var(--line)" stroke-width="${k ? 0.6 : 1.2}"/>`;
    g += drawRead(R.A, COL.A, 2.2) + drawRead(R.B, COL.B, 2.2);
    if (st.showJ) g += drawRead(R.join, COL.join, 2.6, '7 4');
    if (st.showM) g += drawRead(R.meet, COL.meet, 3);
    let V = null, img = null;
    if (st.move !== 'none') { const M = MOVES[st.move]; V = clean(M.make(st.m1, st.m2)); img = read(sandwich(V, objs[st.chosen])); g += drawRead(img, COL.img, 2.6, '2 3'); }
    svg.innerHTML = g;
    svg.setAttribute('aria-label', `A: ${R.A.kind}; B: ${R.B.kind}; A join B: ${R.join.kind}; A meet B: ${R.meet.kind}` + (img ? `; moved ${st.chosen}: ${img.kind}` : ''));
    legend.innerHTML = `<span style="color:var(--acc)">● A ${R.A.kind}</span> · <span style="color:#d9822b">● B ${R.B.kind}</span> · <span style="color:#8e5bb5">┄ A∧B ${R.join.kind}</span> · <span style="color:#2f9154">━ A∨B ${R.meet.kind}</span>` + (img ? ` · <span style="color:#d0543c">┈ moved ${st.chosen === 'join' ? 'A∧B' : st.chosen === 'meet' ? 'A∨B' : st.chosen}</span>` : '');
    const nm = { A: 'A', B: 'B', join: 'A ∧ B (join, the outer product)', meet: 'A ∨ B (meet, ((A I⁻¹) ∧ (B I⁻¹)) I)' }[st.chosen];
    let txt = nm + ': ' + describe(R[st.chosen]);
    if (st.chosen === 'meet' && mnote) txt += '\n' + mnote;
    if (st.chosen === 'join' && R.join.kind === 'zero') txt += '\nthe outer product is 0: grade ' + (grades(A)[0] + grades(B)[0]) + ' > 5, or A and B are not independent (they share a point)';
    if (V) txt += '\n\nmove: ' + MOVES[st.move].say(st.m1, st.m2) + '\nV on the labels: ' + onLabels(V) + '\nV X Ṽ / (V Ṽ): ' + describe(img);
    out.textContent = txt;
  }

  // ---- events
  root.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.edit) { st.edit = b.dataset.edit; buildSliders(); }
    else if (b.dataset.preset !== undefined) { const p = PRESETS[+b.dataset.preset]; st.A = { t: p[1][0], v: p[1][1].slice() }; st.B = { t: p[2][0], v: p[2][1].slice() }; st.chosen = p[3]; $('.cg-ch').value = st.chosen; buildSliders(); }
    else if (b.dataset.move) { st.move = b.dataset.move; st.m1 = st.move === 'rotate' ? 30 : st.move === 'dilate' ? 0.5 : st.move === 'invert' ? 1.5 : 1; st.m2 = 0.5; buildMoveSliders(); }
    else if (b.classList.contains('cg-j')) { st.showJ = !st.showJ; b.setAttribute('aria-pressed', String(st.showJ)); }
    else if (b.classList.contains('cg-m')) { st.showM = !st.showM; b.setAttribute('aria-pressed', String(st.showM)); }
    draw();
  });
  typeSel.addEventListener('change', () => { st[st.edit] = { t: typeSel.value, v: [] }; buildSliders(); draw(); });
  $('.cg-ch').addEventListener('change', e => { st.chosen = e.target.value; draw(); });
  $('.cg-ch').value = st.chosen;
  buildSliders(); buildMoveSliders(); draw();
})
