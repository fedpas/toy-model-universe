(function (id) {
  // brown.js: the Gauss sum of a cell Cl(p,q,r) over its 2^n labels, its phase on the clock and the Brown invariant (LAB-017, LAB-018, CAND-091).
  var el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  function popcount(x) { var c = 0; while (x) { x &= x - 1; c++; } return c; }
  function nPairs(a, b) { var c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  function sign(a, b, eps) { var v = (nPairs(a, b) & 1) ? -1 : 1; var m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  function cell(p, q, r) { var e = [], i; for (i = 0; i < p; i++) e.push(1); for (i = 0; i < q; i++) e.push(-1); for (i = 0; i < r; i++) e.push(0); return e; }
  // w = pi + 2Q on the non-null part of a label (core·B1, core·B3: weight 0 on the null bits); the sum of i^w as an exact Gaussian integer
  function gauss(p, q, r) {
    var eps = cell(p, q, r), n = p + q + r, D = (1 << (p + q)) - 1, cnt = [0, 0, 0, 0];
    for (var a = 0; a < (1 << n); a++) { var d = a & D; var w = (popcount(d) % 2 + (sign(d, d, eps) === -1 ? 2 : 0)) % 4; cnt[w]++; }
    return [cnt[0] - cnt[2], cnt[1] - cnt[3]];
  }
  // self-test: ten products of the rule and eight Gauss sums, computed by figs_top.py with bitcliff.py
  var STORED = [[[-1, 0, 0], 6, 7, 0], [[1, 0, 0], 5, 4, 0], [[0, -1, 1, 1, 0, 1], 8, 19, 1], [[-1, 1, -1], 6, 3, -1], [[-1, -1, -1, -1], 13, 7, -1],
                [[-1, 1, 0], 5, 3, -1], [[-1, 1, 0, -1, 1], 28, 23, 0], [[-1, -1, -1, 1, -1], 29, 19, 1], [[1, -1, 0, 0, -1, -1], 59, 34, -1], [[-1, 0, -1, 0, 0], 26, 1, -1]];
  var GAUSS = [[1, 0, 0, 1, 1], [0, 1, 0, 1, -1], [2, 0, 0, 0, 2], [1, 3, 0, 0, -4], [3, 1, 0, 0, 4], [4, 4, 0, 16, 0], [2, 1, 1, 4, 4], [0, 3, 2, -8, -8]];
  var ok = STORED.every(function (t) { return sign(t[1], t[2], t[0]) === t[3]; }) &&
           GAUSS.every(function (t) { var g = gauss(t[0], t[1], t[2]); return g[0] === t[3] && g[1] === t[4]; });
  if (!ok) { el.textContent = 'self-test failed'; return; }
  // the graded cokernels by the clock c = p - q mod 8, a generator of square -1 added (aty.A3): KO^(p-q)(point)
  var KO = ['ℤ', '0', '0', '0', 'ℤ', '0', 'ℤ₂', 'ℤ₂'];
  el.innerHTML = '<div class="b-ctl"></div><div class="b-pre"></div><div style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-start;margin-top:6px">' +
    '<svg class="b-dial" viewBox="0 0 180 180" width="180" height="180" role="img" aria-label="the clock hand at the phase of the Gauss sum"></svg>' +
    '<p class="widget__out b-out" style="flex:1 1 220px;margin:0"></p></div>';
  var ctl = el.querySelector('.b-ctl'), out = el.querySelector('.b-out'), dial = el.querySelector('.b-dial'), pre = el.querySelector('.b-pre');
  var st = { p: 1, q: 3, r: 0 };
  function slider(key, max) {
    var lab = document.createElement('label'); lab.innerHTML = key + ' <input type="range" min="0" max="' + max + '" step="1"> <b></b>';
    var inp = lab.querySelector('input'), b = lab.querySelector('b'); inp.value = st[key]; b.textContent = st[key];
    inp.addEventListener('input', function () { st[key] = +inp.value; if (st.p + st.q + st.r > 12) { st[key] -= st.p + st.q + st.r - 12; inp.value = st[key]; } b.textContent = st[key]; show(); });
    ctl.appendChild(lab); return function () { inp.value = st[key]; b.textContent = st[key]; };
  }
  var sync = [slider('p', 8), slider('q', 8), slider('r', 3)];
  [[1, 0, 0, 'Cl(1,0)'], [0, 1, 0, 'Cl(0,1)'], [1, 3, 0, 'Cl(1,3)'], [3, 1, 0, 'Cl(3,1)'], [4, 4, 0, 'Cl(4,4)'], [2, 1, 1, 'Cl(2,1,1)']].forEach(function (t) {
    var bt = document.createElement('button'); bt.type = 'button'; bt.textContent = t[3]; bt.style.margin = '4px 6px 0 0';
    bt.addEventListener('click', function () { st.p = t[0]; st.q = t[1]; st.r = t[2]; sync.forEach(function (f) { f(); }); show(); });
    pre.appendChild(bt);
  });
  function gi(z) { var a = z[0], b = z[1]; if (b === 0) return String(a).replace('-', '−'); var s = Math.abs(b) === 1 ? 'i' : Math.abs(b) + 'i'; if (a === 0) return (b < 0 ? '−' : '') + s; return String(a).replace('-', '−') + (b < 0 ? ' − ' : ' + ') + s; }
  function show() {
    var p = st.p, q = st.q, r = st.r, n = p + q + r, z = gauss(p, q, r);
    var beta = ((Math.round(Math.atan2(z[1], z[0]) / (Math.PI / 4)) % 8) + 8) % 8, c = ((p - q) % 8 + 8) % 8;
    var lines = ['Cl(' + p + ',' + q + (r ? ',' + r : '') + '): n = ' + n + ', ' + (1 << n) + ' labels',
      'Σ i^w(a) = ' + gi(z) + '   (|Σ|² = 2^' + (p + q + 2 * r) + ')',
      'phase = 45° × ' + beta + ', and p − q mod 8 = ' + c + (beta === c ? ': the same' : ': DIFFERENT'),
      'Brown invariant β = ' + beta + ' in ℤ₈' + (r ? ' (the null bits only double the sum: the quotient Cl(' + p + ',' + q + '))' : ''),
      p + q ? 'as a Pin⁻ surface: #' + (p + q) + 'ℝP² with ' + p + (p === 1 ? ' crosscap' : ' crosscaps') + ' of w = 1 and ' + q + ' of w = 3' : 'the empty surface: β = 0'];
    if (!r && p + q <= 7) lines.push('same clock position, graded modules: KO^(p−q)(point) = ' + KO[c] + ' (ATY-001)');
    out.textContent = lines.join('\n');
    var s = '<circle cx="90" cy="90" r="64" fill="none" style="stroke:var(--line2,#c9c8c0)"/>';
    for (var k = 0; k < 8; k++) {
      var a = -Math.PI / 2 + k * Math.PI / 4, x = 90 + 78 * Math.cos(a), y = 90 + 78 * Math.sin(a) + 4;
      s += '<text x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" text-anchor="middle" font-size="12" style="fill:' + (k === beta ? 'var(--acc,#184f95)' : 'var(--muted,#6b6b64)') + ';font-weight:' + (k === beta ? 700 : 400) + '">' + k + '</text>';
    }
    if (z[0] || z[1]) { var ang = -Math.PI / 2 + beta * Math.PI / 4; s += '<line x1="90" y1="90" x2="' + (90 + 58 * Math.cos(ang)).toFixed(1) + '" y2="' + (90 + 58 * Math.sin(ang)).toFixed(1) + '" stroke-width="4" stroke-linecap="round" style="stroke:var(--acc,#184f95)"/>'; }
    s += '<circle cx="90" cy="90" r="4" style="fill:var(--ink,#1a1a19)"/>';
    dial.innerHTML = s;
  }
  show();
})
