(function (id) {
  // cone.js: the Euler and signature integrals of a 4-metric with an edge cone of angle 2 pi beta along a surface (ATY-020, ATY-021),
  // the two formulas of Atiyah and LeBrun (Theorems 2.1 and 2.2, recalled) on the three families the Atlas integrated exactly.
  var el = document.getElementById(id); if (!el) return;
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = a % b; a = b; b = t; } return a || 1; }
  function F(n, d) { if (d < 0) { n = -n; d = -d; } var g = gcd(n, d); return [n / g, d / g]; }
  function add(x, y) { return F(x[0] * y[1] + y[0] * x[1], x[1] * y[1]); }
  function mul(x, y) { return F(x[0] * y[0], x[1] * y[1]); }
  function sub(x, y) { return add(x, [-y[0], y[1]]); }
  function eq(x, y) { return x[0] === y[0] && x[1] === y[1]; }
  function fs(x) { return (x[1] === 1 ? String(x[0]) : x[0] + '/' + x[1]).replace('-', '−'); }
  var ONE = [1, 1], THIRD = [1, 3];
  // chi(M) - (1 - beta) chi(Sigma); tau(M) - (1/3)(1 - beta^2) [Sigma]^2
  function euler(chiM, chiS, b) { return sub(chiM, mul(sub(ONE, b), chiS)); }
  function sigdef(tau, self, b) { return sub(tau, mul(mul(THIRD, sub(ONE, mul(b, b))), self)); }
  var FAM = [
    { name: 'S⁴ ⊃ S²', chi: [2, 1], chiS: [2, 1], tau: [0, 1], self: [0, 1] },
    { name: 'S² × football ⊃ two spheres', chi: [4, 1], chiS: [4, 1], tau: [0, 1], self: [0, 1] },
    { name: 'ℂP² ⊃ ℂP¹ (chart orientation, τ = −1)', chi: [3, 1], chiS: [2, 1], tau: [-1, 1], self: [-1, 1] }];
  // self-test: the exact integrals of logs/aty_cone_defects.log (parts 3 and 4) against the two formulas
  var LOGGED = [[0, '1/3', '2/3'], [0, '1/2', '1'], [0, '2/3', '4/3'], [0, '2', '4'], [0, '3', '6'], [1, '1/3', '4/3'], [1, '1/2', '2'], [1, '2/3', '8/3'], [1, '2', '8'], [1, '3', '12'],
                [2, '1/3', '5/3'], [2, '1/2', '2'], [2, '1', '3'], [2, '2', '5']];
  var LOGSIG = [['1/3', '-19/27'], ['1/2', '-3/4'], ['1', '-1'], ['2', '-2']];
  function pf(s) { var t = s.split('/'); return F(+t[0], t.length > 1 ? +t[1] : 1); }
  var ok = LOGGED.every(function (t) { var f = FAM[t[0]]; return eq(euler(f.chi, f.chiS, pf(t[1])), pf(t[2])); }) &&
           LOGSIG.every(function (t) { var f = FAM[2]; return eq(sigdef(f.tau, f.self, pf(t[0])), pf(t[1])); });
  if (!ok) { el.textContent = 'self-test failed'; return; }
  el.innerHTML = '<label>β <input type="range" min="5" max="300" step="1" value="50"> <b class="c-b"></b></label><span class="c-pre"></span>' +
    '<svg class="c-plot" viewBox="0 0 320 170" width="320" height="170" role="img" aria-label="the three Euler integrals against beta"></svg><p class="widget__out c-out"></p>';
  var inp = el.querySelector('input'), bl = el.querySelector('.c-b'), out = el.querySelector('.c-out'), plot = el.querySelector('.c-plot'), pre = el.querySelector('.c-pre');
  var beta = F(1, 2);
  ['1/3', '1/2', '2/3', '1', '2', '3'].forEach(function (s) {
    var bt = document.createElement('button'); bt.type = 'button'; bt.textContent = 'β = ' + s; bt.style.margin = '4px 6px 0 0';
    bt.addEventListener('click', function () { beta = pf(s); inp.value = Math.round(100 * beta[0] / beta[1]); show(); });
    pre.appendChild(bt);
  });
  inp.addEventListener('input', function () { beta = F(+inp.value, 100); show(); });
  var COL = ['var(--acc,#184f95)', '#eb6834', '#1baf7a'];
  function X(b) { return 34 + 276 * b / 3; } function Y(v) { return 150 - 140 * v / 13; }
  function show() {
    var bs = fs(beta), logged = function (k) { return LOGGED.some(function (t) { return t[0] === k && eq(pf(t[1]), beta); }); };
    var lines = ['β = ' + bs + ' (cone angle 2πβ; β = 1 is smooth)'];
    FAM.forEach(function (f, k) {
      var e = euler(f.chi, f.chiS, beta), s = sigdef(f.tau, f.self, beta);
      lines.push(f.name + ':  Euler ' + fs(e) + ',  signature ' + fs(s) + (logged(k) ? '   (integrated exactly on the engine)' : ''));
    });
    lines.push('Euler: χ(M) − (1 − β)χ(Σ);  signature: τ(M) − (1/3)(1 − β²)[Σ]²');
    out.textContent = lines.join('\n');
    var s = '';
    [0, 4, 8, 12].forEach(function (v) { s += '<line x1="34" x2="310" y1="' + Y(v) + '" y2="' + Y(v) + '" style="stroke:var(--line,#e3e2dc)"/><text x="28" y="' + (Y(v) + 4) + '" text-anchor="end" font-size="11" style="fill:var(--muted,#6b6b64)">' + v + '</text>'; });
    [0, 1, 2, 3].forEach(function (b) { s += '<text x="' + X(b) + '" y="166" text-anchor="middle" font-size="11" style="fill:var(--muted,#6b6b64)">' + b + '</text>'; });
    FAM.forEach(function (f, k) {
      var a = euler(f.chi, f.chiS, [0, 1]), c = euler(f.chi, f.chiS, [3, 1]);
      s += '<line x1="' + X(0) + '" y1="' + Y(a[0] / a[1]) + '" x2="' + X(3) + '" y2="' + Y(c[0] / c[1]) + '" stroke-width="2" style="stroke:' + COL[k] + '"/>';
      var v = euler(f.chi, f.chiS, beta), bv = beta[0] / beta[1];
      s += '<circle cx="' + X(bv).toFixed(1) + '" cy="' + Y(v[0] / v[1]).toFixed(1) + '" r="5" style="fill:' + COL[k] + ';stroke:var(--ink,#1a1a19)"/>';
      s += '<text x="' + (X(3) - 4) + '" y="' + (Y(c[0] / c[1]) + (k === 0 ? 14 : -6)) + '" text-anchor="end" font-size="11" style="fill:var(--ink,#1a1a19)">' + ['S⁴', 'S² × football', 'ℂP²'][k] + '</text>';
    });
    var bx = X(beta[0] / beta[1]); s += '<line x1="' + bx.toFixed(1) + '" x2="' + bx.toFixed(1) + '" y1="8" y2="150" stroke-dasharray="3 3" style="stroke:var(--muted,#6b6b64)"/>';
    plot.innerHTML = s; bl.textContent = bs;
  }
  show();
})
