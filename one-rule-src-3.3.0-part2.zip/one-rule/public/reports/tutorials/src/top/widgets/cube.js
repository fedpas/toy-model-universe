(function (id) {
  // cube.js: the cube complex of B_n (cells = arrows S -> T, dimension |T \ S|), its boundary with the bit-rule sign (LNC-140, bd·mjg·24),
  // the chain ranks and the Betti numbers; the top cell can be dropped (the boundary sphere) and the sign can be dropped (a control).
  var el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  function popcount(x) { var c = 0; while (x) { x &= x - 1; c++; } return c; }
  function nPairs(a, b) { var c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  function sign(a, b, eps) { var v = (nPairs(a, b) & 1) ? -1 : 1; var m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  var PR = 32749;                                                   // ranks over the field Z/32749 (and over Z/2); bd·mjg·24 logs the ranks over Q
  function rank(cols, nrows, mod) {
    var M = cols.map(function (c) { var v = new Array(nrows).fill(0); for (var r in c) v[r] = ((c[r] % mod) + mod) % mod; return v; });
    var rk = 0, used = new Array(M.length).fill(false);
    for (var row = 0; row < nrows; row++) {
      var piv = -1; for (var j = 0; j < M.length; j++) if (!used[j] && M[j][row]) { piv = j; break; }
      if (piv < 0) continue; used[piv] = true; rk++;
      var inv = 1, a = M[piv][row], e = mod - 2, b = a; while (e > 0) { if (e & 1) inv = inv * b % mod; b = b * b % mod; e >>= 1; }
      if (mod === 2) inv = 1;
      for (var k = 0; k < M.length; k++) if (k !== piv && M[k][row]) { var f = M[k][row] * inv % mod; for (var t = row; t < nrows; t++) M[k][t] = ((M[k][t] - f * M[piv][t]) % mod + mod) % mod; }
    }
    return rk;
  }
  function complex(n, dropTop, signed) {
    var eps = []; for (var i = 0; i < n; i++) eps.push(1);
    var cells = [], idx = [];
    for (var k = 0; k <= n; k++) { cells.push([]); idx.push({}); }
    for (var T = 0; T < (1 << n); T++) for (var S = 0; S < (1 << n); S++) if ((S & ~T) === 0) { var d = popcount(T & ~S); if (dropTop && d === n && S === 0) continue; idx[d][S + ',' + T] = cells[d].length; cells[d].push([S, T]); }
    var bd = [[]];
    for (var k2 = 1; k2 <= n; k2++) {
      bd.push(cells[k2].map(function (c) {
        var S = c[0], T = c[1], A = T & ~S, col = {};
        for (var i = 0; i < n; i++) if ((A >> i) & 1) {
          var s = signed ? sign(1 << i, A & ~(1 << i), eps) : 1;
          var up = idx[k2 - 1][(S | (1 << i)) + ',' + T], dn = idx[k2 - 1][S + ',' + (T & ~(1 << i))];
          col[up] = (col[up] || 0) + s; col[dn] = (col[dn] || 0) - s;
        }
        return col;
      }));
    }
    var d2 = true;
    for (var k3 = 2; k3 <= n; k3++) bd[k3].forEach(function (col) { var acc = {}; for (var r in col) { var c2 = bd[k3 - 1][r]; for (var rr in c2) acc[rr] = (acc[rr] || 0) + col[r] * c2[rr]; } for (var x in acc) if (acc[x]) d2 = false; });
    var sizes = cells.map(function (L) { return L.length; });
    function betti(mod) { var r = [0]; for (var k = 1; k <= n; k++) r.push(rank(bd[k], sizes[k - 1], mod)); r.push(0); return sizes.map(function (f, k) { return f - r[k] - r[k + 1]; }); }
    return { sizes: sizes, bq: betti(PR), b2: betti(2), d2: d2 };
  }
  // self-test: ten products of the rule (figs_top.py with bitcliff.py), and the Betti numbers that bd·mjg·24 logs for n = 1 ... 5
  var STORED = [[[-1, 0, 0], 6, 7, 0], [[1, 0, 0], 5, 4, 0], [[0, -1, 1, 1, 0, 1], 8, 19, 1], [[-1, 1, -1], 6, 3, -1], [[-1, -1, -1, -1], 13, 7, -1],
                [[-1, 1, 0], 5, 3, -1], [[-1, 1, 0, -1, 1], 28, 23, 0], [[-1, -1, -1, 1, -1], 29, 19, 1], [[1, -1, 0, 0, -1, -1], 59, 34, -1], [[-1, 0, -1, 0, 0], 26, 1, -1]];
  var LOGB = { 1: [[1, 0], [2, 0]], 2: [[1, 0, 0], [1, 1, 0]], 3: [[1, 0, 0, 0], [1, 0, 1, 0]], 4: [[1, 0, 0, 0, 0], [1, 0, 0, 1, 0]], 5: [[1, 0, 0, 0, 0, 0], [1, 0, 0, 0, 1, 0]] };
  var ok = STORED.every(function (t) { return sign(t[1], t[2], t[0]) === t[3]; });
  for (var n0 = 1; ok && n0 <= 5; n0++) { var a = complex(n0, false, true), b = complex(n0, true, true); ok = a.d2 && a.bq.join() === LOGB[n0][0].join() && b.bq.join() === LOGB[n0][1].join(); }
  if (!ok) { el.textContent = 'self-test failed'; return; }
  el.innerHTML = '<label>n <input type="range" min="1" max="6" step="1" value="3"> <b class="q-n"></b></label>' +
    '<button type="button" class="q-top" aria-pressed="false">drop the top cell</button> <button type="button" class="q-sg" aria-pressed="false">drop the sign</button>' +
    '<div class="tw" style="margin-top:8px"><table class="q-tab"></table></div><p class="widget__out q-out"></p>';
  var inp = el.querySelector('input'), nb = el.querySelector('.q-n'), tab = el.querySelector('.q-tab'), out = el.querySelector('.q-out');
  var bTop = el.querySelector('.q-top'), bSg = el.querySelector('.q-sg'), st = { top: false, sg: false };
  bTop.addEventListener('click', function () { st.top = !st.top; bTop.setAttribute('aria-pressed', st.top); show(); });
  bSg.addEventListener('click', function () { st.sg = !st.sg; bSg.setAttribute('aria-pressed', st.sg); show(); });
  inp.addEventListener('input', show);
  function show() {
    var n = +inp.value, c = complex(n, st.top, !st.sg); nb.textContent = n;
    var TD = '<td style="min-width:2.2em;text-align:right">', TH = '<th style="min-width:2.2em;text-align:right">';
    var h = '<tr><th style="min-width:7em">k</th>', f = '<tr><td>cells f_k</td>', q = '<tr><td>Betti (ℚ)</td>', t = '<tr><td>Betti (mod 2)</td>';
    for (var k = 0; k <= n; k++) { h += TH + k + '</th>'; f += TD + c.sizes[k] + '</td>'; q += TD + (c.d2 ? c.bq[k] : '–') + '</td>'; t += TD + c.b2[k] + '</td>'; }
    tab.innerHTML = h + '</tr>' + f + '</tr>' + q + '</tr>' + t + '</tr>';
    var chi = c.sizes.reduce(function (s, x, k) { return s + (k % 2 ? -x : x); }, 0);
    out.textContent = [(st.top ? 'the boundary of the ' + n + '-cube' : 'the ' + n + '-cube') + ': ' + c.sizes.reduce(function (s, x) { return s + x; }, 0) + ' cells, χ = ' + chi,
      'd∘d = 0: ' + (c.d2 ? 'yes' : 'NO — without the sign the boundary is not a differential, so there is no homology over ℚ'),
      c.d2 ? (st.top ? 'Betti 1, 0, …, 0, 1: the sphere S^' + (n - 1) : 'Betti 1, 0, …, 0: the homology of a point') : 'mod 2 the sign is invisible: the row is the homology of the unsigned complex over ℤ/2'].join('\n');
  }
  show();
})
