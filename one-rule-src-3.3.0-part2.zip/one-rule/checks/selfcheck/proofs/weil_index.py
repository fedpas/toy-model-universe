#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""weil_index.py: the clock's phase as Weil's index, on the labels and on the real quadratic form of the cell (round 17, proofs pass 13b;
docs/round17/PROOFS_ROUND13B.md).      python3 weil_index.py [--fault CHI|NOPARITY|COUNTING|CONJ]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators of
square +1 first (core_check.sig). The Z4 form of the labels is w(a) = (|a| mod 2) + 2 [e_a^2 = -1] (core.B1, LAB-017), the square read from the
kernel's s(a, a); f(a) = i^w(a) is its phase and the clock sum is sum_a f(a) = (1+i)^p (1-i)^q (LAB-017). A Gaussian integer on a [bit] line is a
pair of Python integers (a vector of them, two lists), never a complex number; the real index is computed in floating point (cmath).
Source (docs/round17/PROOFS_ROUND13B.md, section 3): A. Weil, Sur certains groupes d'operateurs unitaires, Acta Math. 111 (1964) 143-211, read
in full. Used: n. 1 (a character of the second degree f of a locally compact abelian group G: f(x+y) f(x)^-1 f(y)^-1 = <x, y rho>, relation (1),
rho the symmetric morphism of G into its dual G* associated with f; f non-degenerate when rho is an isomorphism); n. 2 (the Fourier transform
Phi*(x*) = int Phi(x) <x, x*> dx, the dual measure, for which Phi(x) = int Phi*(x*) <x, -x*> dx*, and the module |alpha| of an isomorphism);
n. 7 (relation (9), d'0(-rho^-1) t0(f) d'0(rho^-1) t0(f^-) = t0(f^-1) d'0(-rho^-1), in the simpler form (t0(f) d'0(-rho^-1))^3 = e, which Weil notes is
well known in the classical theory of the modular group); n. 13 (the lifts to unitary operators: t0(f) Phi(x) = Phi(x) f(x), d'0(gamma) Phi(x) =
|gamma|^-1/2 Phi*(-x gamma*^-1)); n. 14 (relation (9) lifted holds up to a scalar of absolute value 1, gamma(f); Theorem 2: the Fourier
transform of f is gamma(f) |rho|^-1/2 f(x* rho^-1)^-1; Corollary 2: int (int Phi(x - y) f(y) dy) dx = gamma(f) |rho|^-1/2 int Phi(x) dx);
n. 20 (Theorem 5: if f = 1 on a closed subgroup Gamma of G and rho is an isomorphism of (G, Gamma) onto (G*, Gamma_*), Gamma_* the subgroup
of G* that corresponds to Gamma, then gamma(f) = 1; its corollary: f(x, x*) = <x, x*> on G x G* is non-degenerate with gamma = 1); n. 22
(products); n. 24-26 (gamma(f) = gamma(chi o f) for a quadratic form f on a vector space over a local field, chi a non-trivial character;
gamma(-f) = gamma(f)^-1; Proposition 3: f -> gamma(f) is a character of the Witt group; over R, chi(x) = exp(2 pi i lam x), a form of inertia
type (a, b) has gamma(f) = gamma(q1)^(a-b), and Corollary 2 with Phi(x) = exp(-pi x^2) gives gamma(q1) = exp(pi i/4) if lam > 0 and
exp(-pi i/4) if lam < 0); n. 27 (for a field with a discrete valuation gamma(f) is a normalised Gauss sum); n. 28, formula (28):
gamma(f)^2 = (D/-1) gamma(q1)^(2m), D the discriminant. Milgram's formula for the Gauss sum of an even lattice: recalled, not read.
wi.DEF   Weil's definition on the labels.  [bit] for the 45 cells (p,q,0) with n <= 8, on all 4^n pairs, f = i^w is a character of the second
         degree of the group of labels with rho the identity (the labels identified with their dual by (-1)^(a.b)), so non-degenerate; with the
         counting measure on the labels and its dual measure 2^-n on the dual (the inversion formula holds with it), Weil's lifted operators of
         n. 13 satisfy relation (9) up to one scalar gamma for each cell, |gamma| = 1 and gamma = (1+i)^p (1-i)^q / 2^(n/2) = exp(i pi (p-q)/4),
         and (t0(f) d'0(-rho^-1))^3 = gamma (n <= 6); Corollary 2 with Phi the indicator of 0 gives the clock sum, 2^(n/2) gamma.
wi.FT    Theorem 2 on the labels.  [bit] for the 66 cells with n <= 10 the transform sum_a f(a) (-1)^(a.b) is gamma |rho|^-1/2 f(b rho^-1)^-1 at
         every label b: the finite theta law of ATY-033, read with Weil's constants.
wi.REAL  the real index.  [std] Corollary 2 on R with Phi(x) = exp(-pi x^2), f(y) = chi(y^2), by the trapezoid rule (inner integral first):
         gamma(q1) = exp(i pi/4) for lam = 1/2, 3/4, 1 and exp(-i pi/4) for lam = -1/2, -3/4, -1, the modulus |rho|^-1/2 = (2 |lam|)^-1/2; the
         closed form of the Gaussian integrals agrees (Weil prints the result only).  [bit==std] the form v -> v^2 of the cell read from the kernel has inertia type (p, q);
         its index for chi(t) = exp(2 pi i t), by Proposition 3, equals the labels' gamma for the 66 cells with n <= 10, and for exp(-2 pi i t)
         that of the mirror cell (q, p).
wi.WITT  the labels' index with the properties Proposition 3 and formula (28) give for real forms.  [bit] orthogonal sums (pairs of cells with n1 + n2 <= 8): w adds over the two
         blocks and gamma multiplies; the mirror cell: gamma(q,p) = conj gamma(p,q); the cell (1,1) has gamma = 1, so (p+1, q+1) has the index
         of (p, q); Weil's corollary of Theorem 5 on the labels ((-1)^(x.x*) on m + m generators, m <= 4: gamma = 1); formula (28) with
         D = prod e_j^2; gamma depends on p - q mod 8 alone and takes the eight eighth roots of unity.
wi.T5    Theorem 5 on R^n x labels.  [std] the lattice Z^n with the Gram matrix 2E, E = diag(eps): even, dual lattice (1/2 Z)^n, discriminant
         form Q(x) mod 1 on the 2^n classes x = a/2, its Gauss sum (1+i)^p (1-i)^q (the left side of Milgram's formula for A1^p + A1(-1)^q),
         no label used.  [bit==std] exp(2 pi i Q(a/2)) = i^w(a) label by label; on G' = R^n x labels, f' = exp(2 pi i Q) (x) conj(i^w) is 1
         on Gamma' = {(x, 2x mod 2) : x in (1/2 Z)^n} and its rho' is an isomorphism of (G', Gamma') onto (G'*, Gamma'_*), so Theorem 5 gives
         gamma(exp(2 pi i Q)) = gamma(i^w), against the quadrature's real index for the 66 cells.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   CHI the character chi(t) = exp(-2 pi i t) in place of exp(2 pi i t); NOPARITY w without its parity term (w = 2 [e_a^2 = -1], a real f, whose
   bicharacter is the commutation form); COUNTING the counting measure on the dual in place of the dual measure; CONJ f' = exp(2 pi i Q) (x) i^w
   without the conjugate in Theorem 5.
Not computed here (stated, not checked): Weil's theorems themselves (read: Theorems 2 and 5 and Proposition 3 are applied, their hypotheses
computed); the metaplectic group and its double cover (Chapters III and IV, read); Milgram's formula in general (recalled); cells with null
generators (r > 0), where the form is degenerate and Weil's index is not defined.
Command: python3 -I -B selfcheck/proofs/weil_index.py from checks/ (or from this folder); standard library only."""
import os, sys, time, cmath, math
from fractions import Fraction as Fr

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import sig as _core_sig, signature_of                     # the cell's eps; exact congruence diagonalisation

# ------------------------------------------------------------------------------------------------ check lines (from clock_walk.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def lap(t): return '(%.1f s)' % (time.time() - t)
def finish():
    print('\n  tags: %s; %.0f s' % (', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), time.time() - T0))
    print('weil_index: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('CHI', 'NOPARITY', 'COUNTING', 'CONJ')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
LAM_MAIN = -1 if FAULT == 'CHI' else 1                                    # chi(t) = exp(2 pi i LAM_MAIN t) in the main lines

# ------------------------------------------------------------------------------------------------ the labels: the kernel's form, Gaussian integers
def pc(a): return bin(a).count('1')
def dot(a, b): return pc(a & b) & 1
def sig(p, q): return list(_core_sig(p, q, 0))
def cells(nmax, nmin=0): return [(p, n - p) for n in range(nmin, nmax + 1) for p in range(n + 1)]
I_POW = ((1, 0), (0, 1), (-1, 0), (0, -1))                                # i^0 .. i^3 as Gaussian integers (pairs)
def gmul(u, v): return (u[0] * v[0] - u[1] * v[1], u[0] * v[1] + u[1] * v[0])
def gconj(u): return (u[0], -u[1])
def gnorm(u): return u[0] * u[0] + u[1] * u[1]
def gpow(u, k):
    z = (1, 0)
    for _ in range(k): z = gmul(z, u)
    return z
def clock_sum_closed(p, q): return gmul(gpow((1, 1), p), gpow((1, -1), q))   # (1+i)^p (1-i)^q
def wform(eps, parity=True):
    """w(a) = (|a| mod 2) + 2 [e_a^2 = -1] for every label, the square from the kernel's s(a, a); parity=False drops the first term"""
    br = BR(eps)
    return [((pc(a) & 1) if parity else 0) + 2 * (1 if br.sq(a) == -1 else 0) for a in range(1 << len(eps))]
def W(eps): return wform(eps, parity=(FAULT != 'NOPARITY'))
def gauss(w):
    """sum_a i^w(a) as a Gaussian integer"""
    re = im = 0
    for e in w:
        u = I_POW[e & 3]; re += u[0]; im += u[1]
    return (re, im)

# ------------------------------------------------------------------------------------------------ Weil's frame for the group of labels (n. 1, 2, 13)
def bichar_matrix(w, n):
    """Weil's relation (1) for f = i^w: f(a+b) f(a)^-1 f(b)^-1 = (-1)^beta(a,b) needs w(a xor b) - w(a) - w(b) even (mod 4) on every pair;
    beta read on the generators gives the matrix R (rows as bitmasks) of rho: <a, b rho> = (-1)^(a . R b). Returns (R, ok) where ok says that
    the differences are even and beta(a, b) = a . R b on every pair (a bicharacter)"""
    N = 1 << n; R = [0] * n
    for i in range(n):
        for j in range(n):
            d = (w[(1 << i) ^ (1 << j)] - w[1 << i] - w[1 << j]) % 4
            if d == 2: R[i] |= 1 << j
            elif d != 0: return R, False
    Rb = [matvec(R, b) for b in range(N)]
    for a in range(N):
        wa = w[a]
        for b in range(N):
            d = (w[a ^ b] - wa - w[b]) % 4
            if d not in (0, 2) or (d // 2) != dot(a, Rb[b]): return R, False
    return R, True
def matvec(R, x):
    y = 0
    for i, r in enumerate(R):
        if pc(r & x) & 1: y |= 1 << i
    return y
def invertible(R, n):
    M = list(R); r = 0
    for col in range(n):
        piv = next((i for i in range(r, n) if (M[i] >> col) & 1), None)
        if piv is None: continue
        M[r], M[piv] = M[piv], M[r]
        for i in range(n):
            if i != r and (M[i] >> col) & 1: M[i] ^= M[r]
        r += 1
    return r == n
def neg(x): return x                                                      # the inverse in the group of labels: -x = x
def fwht(v):
    """Weil's Phi*(y) = sum_x Phi(x) <x, y> = sum_x Phi(x) (-1)^(x.y) (counting measure on the labels), on a pair of integer lists"""
    re, im = list(v[0]), list(v[1]); N = len(re); h = 1
    while h < N:
        for i in range(0, N, 2 * h):
            for j in range(i, i + h):
                a, b = re[j], re[j + h]; re[j], re[j + h] = a + b, a - b
                a, b = im[j], im[j + h]; im[j], im[j + h] = a + b, a - b
        h *= 2
    return re, im
def t0(ex, v):
    """Weil's t0(f): Phi -> Phi f, f = i^ex"""
    re, im = v; N = len(re); o_re = [0] * N; o_im = [0] * N
    for x in range(N):
        k = ex[x] & 3; r, s = re[x], im[x]
        if k == 0: o_re[x], o_im[x] = r, s
        elif k == 1: o_re[x], o_im[x] = -s, r
        elif k == 2: o_re[x], o_im[x] = -r, -s
        else: o_re[x], o_im[x] = s, -r
    return o_re, o_im
def d0p_scaled(R, sign, v):
    """|gamma|^(1/2) d'0(gamma) for gamma = sign * rho^-1 (an isomorphism of the dual onto the labels): Phi -> Phi*(-x gamma*^-1); rho is
    symmetric, so gamma* = gamma and gamma*^-1 = sign * rho: the argument is -(x rho) for sign +1 and x rho for sign -1 (one point on the
    labels, where -1 = 1)"""
    ft = fwht(v); N = len(ft[0])
    arg = [neg(matvec(R, x)) if sign > 0 else matvec(R, x) for x in range(N)]
    return [ft[0][y] for y in arg], [ft[1][y] for y in arg]
def f2_inverse(R, n):
    """the inverse of an invertible matrix over F2 (rows as bitmasks), by Gauss-Jordan on [R | 1]"""
    M = [(R[i], 1 << i) for i in range(n)]
    for col in range(n):
        piv = next(i for i in range(col, n) if (M[i][0] >> col) & 1)
        M[col], M[piv] = M[piv], M[col]
        for i in range(n):
            if i != col and (M[i][0] >> col) & 1: M[i] = (M[i][0] ^ M[col][0], M[i][1] ^ M[col][1])
    return [M[i][1] for i in range(n)]
def gen_matrix(w, n):
    """the matrix R of beta on the generators only (n^2 pairs), for the cells where the 4^n pairs are not all read"""
    R = [0] * n
    for i in range(n):
        for j in range(n):
            if (w[(1 << i) ^ (1 << j)] - w[1 << i] - w[1 << j]) % 4 == 2: R[i] |= 1 << j
    return R
def dual_weight(n):
    """the weight m of the measure on the dual (n. 2): with the counting measure on the labels, Phi(x) = m sum_y Phi*(y) <x, -y> on every
    indicator Phi = 1_c (Phi*(y) = (-1)^(c.y)) forces m = 2^-n; COUNTING takes the counting measure (m = 1)"""
    return Fr(1) if FAULT == 'COUNTING' else Fr(1, 1 << n)
def inversion_ok(n, m):
    N = 1 << n
    for c in range(N):
        for x in range(N):
            if m * sum((-1) ** (dot(c, y) + dot(x, y)) for y in range(N)) != (1 if x == c else 0): return False
    return True
def gdiv(a, b):
    """a / b in Q(i) as a pair of Fractions"""
    d = gnorm(b)
    return (Fr(a[0] * b[0] + a[1] * b[1], d), Fr(a[1] * b[0] - a[0] * b[1], d))
def relation9(ex, R, n):
    """relation (9) lifted, column by column on the 2^n indicators: |rho^-1| d'0(-rho^-1) t0(f) d'0(rho^-1) t0(f^-) against
    |rho^-1|^(1/2) t0(f^-1) d'0(-rho^-1); returns the Gaussian scalar c with LHS = c RHS on every entry (so gamma = c |rho^-1|^(-1/2)), or None"""
    N = 1 << n; ex_m = [ex[neg(x)] for x in range(N)]; ex_inv = [(-e) % 4 for e in ex]; c = None
    for col in range(N):
        v = ([1 if x == col else 0 for x in range(N)], [0] * N)
        L = d0p_scaled(R, -1, t0(ex, d0p_scaled(R, +1, t0(ex_m, v))))
        Rt = t0(ex_inv, d0p_scaled(R, -1, v))
        for x in range(N):
            a = (L[0][x], L[1][x]); b = (Rt[0][x], Rt[1][x])
            if c is None and b != (0, 0): c = gdiv(a, b)
            if c is not None and (c[0] * b[0] - c[1] * b[1], c[0] * b[1] + c[1] * b[0]) != a: return None
            if c is None and a != (0, 0): return None
    if c is None or c[0].denominator != 1 or c[1].denominator != 1: return None
    return (int(c[0]), int(c[1]))
def relation9_kernel(ex, n, c):
    """relation (9) for rho = 1 through the kernel of d'0 t0 d'0: sum_y (-1)^(x.y) f(y) (-1)^(y.z) = F(x xor z), F the transform of f, so
    the left side has the entry F(x xor z) f(z) and the right side c f(x)^-1 (-1)^(x.z): all 4^n entries"""
    N = 1 << n; F = fwht(([I_POW[e & 3][0] for e in ex], [I_POW[e & 3][1] for e in ex]))
    for x in range(N):
        fxi = I_POW[(-ex[x]) & 3]; rx = gmul(c, fxi)
        for z in range(N):
            lhs = gmul((F[0][x ^ z], F[1][x ^ z]), I_POW[ex[z] & 3])
            rhs = rx if not dot(x, z) else (-rx[0], -rx[1])
            if lhs != rhs: return False
    return True
def cube_scalar(ex, R, n):
    """(t0(f) |rho^-1|^(1/2) d'0(-rho^-1))^3 on the 2^n indicators: the Gaussian scalar d with (t0 D)^3 = d, or None"""
    N = 1 << n; d = None
    for col in range(N):
        v = ([1 if x == col else 0 for x in range(N)], [0] * N)
        for _ in range(3): v = t0(ex, d0p_scaled(R, -1, v))
        for x in range(N):
            a = (v[0][x], v[1][x])
            if x != col and a != (0, 0): return None
            if x == col:
                if d is None: d = a
                elif a != d: return None
    return d

# ------------------------------------------------------------------------------------------------ the real index (n. 26)
TWO_PI_I = 2j * math.pi
def cor2_real(lam, hx=0.04, X=6.5, hy=0.01, Y=6.5):
    """Weil's Corollary 2 on G = R, Phi(x) = exp(-pi x^2), f(y) = chi(y^2) with chi(t) = exp(2 pi i lam t): int over x of (int over y of
    Phi(x - y) f(y)), the inner integral first, each by the trapezoid rule (y = x + t, |t| <= Y; |x| <= X)"""
    nt = int(round(Y / hy)); ts = [j * hy for j in range(-nt, nt + 1)]; gw = [math.exp(-math.pi * t * t) for t in ts]
    nx = int(round(X / hx)); tot = 0j
    for k in range(-nx, nx + 1):
        x = k * hx; s = 0j
        for t, g in zip(ts, gw):
            y = x + t; s += g * cmath.exp(TWO_PI_I * lam * y * y)
        tot += s * hy
    return tot * hx
def cor2_closed(lam):
    """the two Gaussian integrals of Corollary 2 in closed form (Weil prints only the result): the inner one is (1 - 2i lam)^-1/2 exp(pi x^2 2i lam/(1 - 2i lam)), the outer one
    (-2i lam/(1 - 2i lam))^-1/2, principal roots (both arguments in the right half-plane)"""
    return 1 / cmath.sqrt(1 - 2j * lam) / cmath.sqrt((-2j * lam) / (1 - 2j * lam))
def rho_module_real(lam):
    """|rho| for f = chi(x^2) on R: f(x+y) f(x)^-1 f(y)^-1 = chi(2xy) = <x, 2y>, so rho = 2; the measure on the dual of dx for <x, y> =
    chi(xy) is |lam| dy (Fourier inversion), and int F(y) |lam| dy = |rho| int F(2x) dx gives |rho| = 2 |lam|"""
    return 2 * abs(lam)

# ================================================================================================ wi.DEF
head('wi.DEF: Weil\'s definition of gamma(f) on the labels (n. 1, 2, 7, 13, 14)')
t = time.time()
ok1 = True; ok_nd = True; npairs = 0
ok2 = True; ok_mod = True; ok_phase = True; ok_inv = True; ok_cube = True; ok3 = True
GAMMA = {}                                                                  # (p, q) -> the Gaussian scalar c of relation (9)
for p, q in cells(8):
    n = p + q; N = 1 << n; w = W(sig(p, q))
    R, isbichar = bichar_matrix(w, n); npairs += N * N
    if not (isbichar and R == [1 << i for i in range(n)]): ok1 = False
    if not invertible(R, n): ok_nd = False
    m = dual_weight(n)
    if n <= 6: ok_inv &= inversion_ok(n, m)
    if not isbichar or not invertible(R, n): ok2 = False; continue
    if n <= 6: c = relation9(w, R, n)
    else:
        c = gauss(w) if R == [1 << i for i in range(n)] else None         # the candidate scalar, then all 4^n entries of (9) through the kernel
        if c is not None and not relation9_kernel(w, n, c): c = None
    if c is None: ok2 = False; continue
    GAMMA[(p, q)] = c
    if gnorm(c) * m != 1: ok_mod = False                                    # |gamma|^2 = |c|^2 |rho^-1|^-1 = |c|^2 m
    if c != clock_sum_closed(p, q): ok_phase = False                        # gamma = (1+i)^p (1-i)^q / 2^(n/2) = exp(i pi (p-q)/4)
    if n <= 6:
        d = cube_scalar(w, R, n)                                            # (t0 D)^3 = d with D = |rho^-1|^(1/2) d'0 = m^(-1/2) d'0, so
        if d is None or (Fr(d[0]) * m, Fr(d[1]) * m) != (Fr(c[0]), Fr(c[1])): ok_cube = False   # (t0 d'0)^3 = d m^(3/2) = gamma = c m^(1/2): d m = c
    if c != gauss(w): ok3 = False                                           # Corollary 2 with Phi the indicator of 0
chk('bit', ok1 and ok_nd, 'wi.DEF: for the 45 cells (p,q,0) with n <= 8, on all %d pairs of labels, the phase f(a) = i^w(a), w read from the kernel\'s squares, satisfies Weil\'s relation (1): f(a+b) f(a)^-1 f(b)^-1 = (-1)^(a.b), a bicharacter; f is a character of the second degree of the group of labels, and the symmetric morphism rho associated with it is the identity when the labels are identified with their dual by (-1)^(a.b) (the dot product, non-degenerate): f is non-degenerate; on the labels -a = a, so f^- = f and -rho^-1 = rho^-1' % npairs)
chk('bit', ok2 and ok_inv and ok_mod and ok_phase and ok_cube, 'wi.DEF: with the counting measure on the labels and the measure 2^-n (counting) on the dual, the one for which Weil\'s inversion formula of n. 2 holds (checked on all the indicators, n <= 6), the module of rho^-1 is |rho^-1| = 2^n, and Weil\'s lifted operators of n. 13, t0(f) Phi = Phi f and d\'0(rho^-1) Phi(x) = |rho^-1|^(-1/2) Phi*(-x rho), Phi*(y) = sum_x Phi(x) (-1)^(x.y), satisfy relation (9) (n. 7) lifted, d\'0(-rho^-1) t0(f) d\'0(rho^-1) t0(f^-) = gamma t0(f^-1) d\'0(-rho^-1), with one scalar gamma for each of the 45 cells (column by column on the 2^n indicators for n <= 6; through the kernel F(x xor z) f(z) of the left side, F the transform of f, on all 4^n entries for n = 7, 8; exact over Z[i] after the factor 2^(n/2)): |gamma| = 1 and gamma = (1+i)^p (1-i)^q / 2^(n/2) = exp(i pi (p-q)/4), the clock\'s phase (LAB-017); and the lifted cube carries the same scalar, (t0(f) d\'0(-rho^-1))^3 = gamma, the form of (9) that Weil relates to the modular group in n. 7 (n <= 6)')
chk('bit', ok3 and len(GAMMA) == 45, 'wi.DEF: Weil\'s Corollary 2 (n. 14) with Phi the indicator of 0: sum_x sum_y Phi(x - y) f(y) = sum_a i^w(a) = gamma |rho|^(-1/2), |rho| = 2^-n: for the 45 cells the scalar of relation (9) times 2^(n/2) is the clock sum (LAB-017), so Weil\'s gamma(f) is the clock sum divided by its modulus, a normalised Gauss sum as in his n. 27')
note(lap(t))

# ================================================================================================ wi.FT
head('wi.FT: Theorem 2 (n. 14) on the labels')
t = time.time(); ok4 = True; nb = 0
for p, q in cells(10):
    n = p + q; N = 1 << n; w = W(sig(p, q)); m = dual_weight(n)
    R = bichar_matrix(w, n)[0] if n <= 8 else gen_matrix(w, n)             # n = 9, 10: rho read on the generators (n^2 pairs)
    if not invertible(R, n): ok4 = False; continue
    c = GAMMA.get((p, q)) if n <= 8 else gauss(w)                           # gamma |rho|^(-1/2) = c: from relation (9) (n <= 8), Corollary 2 (9, 10)
    if c is None: ok4 = False; continue
    Ri = f2_inverse(R, n)
    F = fwht(([I_POW[e & 3][0] for e in w], [I_POW[e & 3][1] for e in w]))
    for b in range(N):
        if (F[0][b], F[1][b]) != gmul(c, I_POW[(-w[matvec(Ri, b)]) & 3]): ok4 = False
        nb += 1
    if R != [1 << i for i in range(n)]: ok4 = False                         # rho the identity: the law reads f(b)^-1 at b itself
chk('bit', ok4, 'wi.FT: Theorem 2 on the labels of the 66 cells with n <= 10: Weil\'s transform of f, sum_a f(a) (-1)^(a.b) with the counting measure, equals gamma(f) |rho|^(-1/2) f(b rho^-1)^-1 = gamma 2^(n/2) i^(-w(b)) at every label b (%d values of b; rho the identity, read on all pairs for n <= 8 and on the generators for n = 9, 10; gamma 2^(n/2) from relation (9) for n <= 8, from Corollary 2 for n = 9, 10): the finite theta law of ATY-033 is Weil\'s Theorem 2 for the group of labels, with his constants' % nb)
note(lap(t))

# ================================================================================================ wi.REAL
head('wi.REAL: the real index (n. 26), Weil\'s recipe by quadrature, and the form of the cell')
t = time.time()
LAMS = (Fr(1, 2), Fr(3, 4), Fr(1), Fr(-1, 2), Fr(-3, 4), Fr(-1))
GQ1 = {}; ok5 = True; worst = 0.0
for lam in LAMS:
    lam_used = float(lam) * (-1 if FAULT == 'CHI' else 1)                  # CHI: chi(t) = exp(-2 pi i lam t) in place of exp(2 pi i lam t)
    I = cor2_real(lam_used); Ic = cor2_closed(float(lam))
    g = I * math.sqrt(rho_module_real(float(lam)))                          # gamma(q1) = I / (|rho|^-1/2 int Phi), int Phi = 1
    want = cmath.exp(1j * math.pi / 4 * (1 if lam > 0 else -1))
    err = max(abs(g - want), abs(I - Ic), abs(abs(I) ** 2 * rho_module_real(float(lam)) - 1))
    worst = max(worst, err); ok5 &= err < 1e-12
    GQ1[lam] = g
chk('std', ok5, 'wi.REAL: Weil\'s n. 26 by his own recipe: Corollary 2 on G = R with Phi(x) = exp(-pi x^2) and f(y) = chi(y^2), chi(t) = exp(2 pi i lam t), the inner integral over y first and then the outer one over x, each by the trapezoid rule (steps 0.01 and 0.04, |x - y| <= 6.5, |x| <= 6.5): for lam = 1/2, 3/4, 1 the double integral is |rho|^(-1/2) exp(i pi/4), for lam = -1/2, -3/4, -1 it is |rho|^(-1/2) exp(-i pi/4), with |rho| = 2 |lam| (rho = 2, and |lam| dy the measure dual to dx for chi(xy)), and the closed form of the two Gaussian integrals, (1 - 2i lam)^(-1/2) (-2i lam/(1 - 2i lam))^(-1/2) with principal roots, agrees: gamma(q1) = exp(pi i/4) if lam > 0 and exp(-pi i/4) if lam < 0, the values Weil prints (largest deviation %.1e)' % worst)
ok6 = True; ok6m = True; ok_sig = True; worst6 = 0.0
g_plus, g_minus = GQ1[Fr(1)], GQ1[Fr(-1)]                                  # with chi(t) = exp(2 pi i t): the index of chi(x^2) and of chi(-x^2)
for p, q in cells(10):
    n = p + q; br = BR(sig(p, q)); kappa = math.sqrt(dual_weight(n))
    anti = all(br.s(1 << i, 1 << j) + br.s(1 << j, 1 << i) == 0 for i in range(n) for j in range(n) if i != j)
    gram = [[br.sq(1 << i) if i == j else 0 for j in range(n)] for i in range(n)]
    if not anti or tuple(signature_of(gram))[:2] != (p, q): ok_sig = False
    gR = g_plus ** p * g_minus ** q                                         # Proposition 3: gamma(q_p - q_q) = gamma(q1)^p gamma(-q1)^q
    gRm = g_minus ** p * g_plus ** q                                        # the same form with chi(t) = exp(-2 pi i t)
    c = gauss(W(sig(p, q))); gD = complex(c[0], c[1]) * kappa             # the labels' gamma = c |rho^-1|^(-1/2)
    cm = gauss(W(sig(q, p))); gDm = complex(cm[0], cm[1]) * kappa
    worst6 = max(worst6, abs(gR - gD)); ok6 &= abs(gR - gD) < 1e-9; ok6m &= abs(gRm - gDm) < 1e-9
chk('bit==std', ok_sig and ok6 and ok6m, 'wi.REAL: for the 66 cells with n <= 10 the quadratic form v -> v^2 of the cell, read from the kernel (the generators anticommute in pairs, e_j^2 = eps_j), has inertia type (p, q) (exact congruence diagonalisation); by Weil\'s Proposition 3 its index for chi(t) = exp(2 pi i t) is gamma(q1)^p gamma(-q1)^q with the two values of the quadrature, and it equals the labels\' gamma = clock sum / 2^(n/2) (largest deviation %.1e); for chi(t) = exp(-2 pi i t) it is the complex conjugate, the labels\' gamma of the mirror cell (q, p): the clock\'s phase exp(i pi (p-q)/4) is Weil\'s index of the real form of signature (p, q) for lam > 0' % worst6)
note(lap(t))

# ================================================================================================ wi.WITT
head('wi.WITT: the labels\' index with the properties Proposition 3 and formula (28) give for real forms, and the corollary of Theorem 5 (n. 20)')
t = time.time()
ok7a = True; ok7b = True; ok7c = True; npair = 0
CS = {}
for p, q in cells(10):
    w = W(sig(p, q)); CS[(p, q)] = (w, gauss(w))
for (p1, q1) in cells(7, 1):
    for (p2, q2) in cells(8 - (p1 + q1), 1):
        n1 = p1 + q1; eps = sig(p1, q1) + sig(p2, q2); w12 = W(eps)
        w1, c1 = CS[(p1, q1)]; w2, c2 = CS[(p2, q2)]; npair += 1
        if any((w12[a1 | (a2 << n1)] - w1[a1] - w2[a2]) % 4 for a1 in range(1 << n1) for a2 in range(1 << (p2 + q2))): ok7a = False
        if gauss(w12) != gmul(c1, c2): ok7a = False                          # gamma(f1 x f2) = gamma(f1) gamma(f2) (the factors 2^(n/2) multiply)
for p, q in cells(10):
    n = p + q; w, c = CS[(p, q)]; wm, cm = CS[(q, p)]
    def swap(a):                                                            # the label of (q, p) with the blocks of generators exchanged
        return (a >> p) | ((a & ((1 << p) - 1)) << q)
    if any((wm[swap(a)] + w[a]) % 4 for a in range(1 << n)) or cm != gconj(c): ok7b = False
n11 = 0
for p, q in cells(8):
    if p >= 1 and q >= 1:
        m_ = dual_weight(p + q); c = CS[(p, q)][1]; c0 = CS[(p - 1, q - 1)][1]
        # gamma(p,q) = c 2^-(n/2) and gamma(p-1,q-1) = c0 2^-((n-2)/2): equal iff c = 2 c0; gamma(1,1) = 1 iff its c is 2 = 2^(2/2)
        if c != gmul((2, 0), c0): ok7c = False
        n11 += 1
c11 = CS[(1, 1)][1]
if gnorm(c11) * dual_weight(2) != 1 or c11 != (2, 0): ok7c = False
chk('bit', ok7a and ok7b and ok7c, 'wi.WITT: orthogonal sums: for the %d pairs of cells with n1, n2 >= 1 and n1 + n2 <= 8 the cell with the generators of both, read from the kernel, has w(a1 a2) = w(a1) + w(a2) mod 4 on all its labels and gamma = gamma1 gamma2 (exact; the analogue of gamma(f1 + f2) = gamma(f1) gamma(f2), the step of Weil\'s proof of Proposition 3); the mirror cell: for the 66 cells with n <= 10, i^-w of (p, q) is i^w of (q, p) after the exchange of the two blocks of generators, so gamma(q, p) = conj gamma(p, q) (the analogue of Weil\'s gamma(-f) = gamma(f)^-1, n. 25); the cell (1,1) has gamma = 1, and the %d cells (p, q) with p, q >= 1, n <= 8, have the index of (p-1, q-1)' % (npair, n11))
ok8a = True
for m in range(1, 5):
    n = 2 * m; N = 1 << n
    ex = [2 * dot(a & ((1 << m) - 1), a >> m) for a in range(N)]           # f(x, x*) = (-1)^(x.x*) = i^(2 x.x*), x the low m bits
    R, isbichar = bichar_matrix(ex, n)
    swapR = [1 << (i + m) for i in range(m)] + [1 << i for i in range(m)]
    if not (isbichar and R == swapR and invertible(R, n)): ok8a = False; continue
    c = relation9(ex, R, n) if n <= 6 else gauss(ex)
    if c is None or gnorm(c) * dual_weight(n) != 1 or c != (1 << m, 0): ok8a = False
    if n == 8 and (relation9(ex, R, n) != c): ok8a = False
ok8b = True; ok8c = True; vals = {}
for p, q in cells(10):
    n = p + q; c = CS[(p, q)][1]; m_ = dual_weight(n)
    # formula (28): gamma^2 = (D/-1) gamma(q1)^(2n), D = prod e_j^2 = (-1)^q, (D/-1) = sign D over R, gamma(q1)^2 = i: gamma^2 = (-1)^q i^n
    g2 = gmul(c, c); want = gmul(((-1) ** q, 0), I_POW[n % 4])
    if (Fr(g2[0]) * m_, Fr(g2[1]) * m_) != (Fr(want[0]), Fr(want[1])): ok8b = False
    z = complex(c[0], c[1]) / 2 ** (n / 2); k = round(cmath.phase(z) / (math.pi / 4)) % 8
    if abs(z - cmath.exp(1j * math.pi * k / 4)) > 1e-9 or k != (p - q) % 8: ok8c = False
    vals.setdefault(k, set()).add((p - q) % 8)
if sorted(vals) != list(range(8)) or any(len(v) != 1 for v in vals.values()): ok8c = False
chk('bit', ok8a and ok8b and ok8c, 'wi.WITT: Weil\'s corollary of Theorem 5 (n. 20) on the labels: f(x, x*) = (-1)^(x.x*) on the labels of m + m generators (x the first m, x* the last m), m = 1 .. 4, is a non-degenerate character of the second degree (rho exchanges the two halves) and relation (9) holds with gamma = 1 (column by column, 2m <= 8); the analogue of Weil\'s formula (28), gamma(f)^2 = (D/-1) gamma(q1)^(2n), holds on the labels with D = prod e_j^2 = (-1)^q: gamma^2 = (-1)^q i^n for the 66 cells with n <= 10; gamma depends on p - q mod 8 alone and takes the eight values exp(i pi k/4), k = p - q mod 8, each once: a character of Z/8 onto the eighth roots of unity')
note(lap(t))

# ================================================================================================ wi.T5
head('wi.T5: Theorem 5 (n. 20) on R^n x labels: the real index and the labels\' index are one (Milgram\'s formula for A1^p + A1(-1)^q)')
t = time.time()
def chi4(lam, q4):
    """chi(Q) = exp(2 pi i lam Q) for Q with 4Q an integer: i^(lam 4Q) as an exponent mod 4"""
    return (lam * q4) % 4
ok9 = True
for p, q in cells(10):
    n = p + q; eps = sig(p, q)
    gram = [[2 * eps[i] if i == j else 0 for j in range(n)] for i in range(n)]
    det = 1
    for i in range(n): det *= gram[i][i]
    even = all(gram[i][i] % 2 == 0 for i in range(n))
    dual_basis = [[Fr(1, gram[i][i]) if i == j else Fr(0) for j in range(n)] for i in range(n)]   # (2E)^-1 Z^n, E diagonal
    if not even or abs(det) != 1 << n or any(abs(dual_basis[i][i]) != Fr(1, 2) for i in range(n)): ok9 = False; continue
    s = (0, 0)
    for a in range(1 << n):
        x = [Fr((a >> j) & 1, 2) for j in range(n)]
        Q = sum(eps[j] * x[j] * x[j] for j in range(n))
        q4 = 4 * Q; assert q4.denominator == 1
        u = I_POW[chi4(LAM_MAIN, int(q4))]; s = (s[0] + u[0], s[1] + u[1])
    if s != clock_sum_closed(p, q): ok9 = False
chk('std', ok9, 'wi.T5: the lattice route, no label: L = Z^n with the Gram matrix 2E, E = diag(eps), is even (B(x,x) in 2Z) with dual lattice (2E)^-1 Z^n = (1/2 Z)^n and |L#/L| = |det 2E| = 2^n; its discriminant form q(x) = Q(x) mod 1, Q(x) = sum_j eps_j x_j^2, summed over the 2^n classes x = a/2 with chi(t) = exp(2 pi i t): sum exp(2 pi i q(x)) = (1+i)^p (1-i)^q for the 66 cells with n <= 10, exact: the left side of Milgram\'s formula for the even lattice A1^p + A1(-1)^q, sqrt|L#/L| exp(2 pi i (p - q)/8) (recalled)')
ok10 = True
for p, q in cells(10):
    n = p + q; eps = sig(p, q); w = W(eps)
    for a in range(1 << n):
        q4 = sum(eps[j] for j in range(n) if (a >> j) & 1)                 # 4 Q(a/2)
        if chi4(LAM_MAIN, q4) != w[a] % 4: ok10 = False; break
chk('bit==std', ok10, 'wi.T5: label by label, exp(2 pi i Q(a/2)) = i^w(a) for the 66 cells with n <= 10, w from the kernel: the labels with their phase i^w are the discriminant form of that lattice (LAB-018: w(a) = x.x mod 4 for the 0/1 vector x of a in I_{p,q})')
ok11h = True; ok11r = True; ok11c = True; worst11 = 0.0
CONJ_SIGN = 1 if FAULT == 'CONJ' else -1                                  # f' = chi(Q) (x) i^(CONJ_SIGN w): the conjugate is -1
for p, q in cells(10):
    n = p + q; eps = sig(p, q); w = W(eps)
    def f_prime_exp(x, a):
        q4 = sum(eps[j] * 4 * x[j] * x[j] for j in range(n)); assert q4.denominator == 1
        return (chi4(LAM_MAIN, int(q4)) + CONJ_SIGN * w[a]) % 4
    def pi_(x): return sum(((int(2 * x[j]) % 2) << j) for j in range(n))
    for a in range(1 << n):
        x = [Fr((a >> j) & 1, 2) for j in range(n)]
        if f_prime_exp(x, pi_(x)) != 0: ok11h = False; break
    if n <= 4 and ok11h:
        for a in range(1 << n):
            for k in range(3 ** n):
                mm = [((k // 3 ** j) % 3) - 1 for j in range(n)]
                x = [Fr((a >> j) & 1, 2) + mm[j] for j in range(n)]
                if f_prime_exp(x, pi_(x)) != 0: ok11h = False
    # rho'(x, a) = (2 lam E x, a); Gamma'_* = {(z, b) : z_j integers, z_j = b_j mod 2}, the annihilator of Gamma' (tested on its generators)
    def in_gamma_star(z, b):
        return all(z[j].denominator == 1 for j in range(n)) and all((int(z[j]) - ((b >> j) & 1)) % 2 == 0 for j in range(n))
    def annihilates(z, b):                                                 # <(x, pi(x)), (z, b)> = exp(2 pi i x.z) (-1)^(pi(x).b) = 1 on Gamma'
        for j in range(n):
            for x_j, a_j in ((Fr(1, 2), 1), (Fr(1), 0)):
                ph = x_j * z[j] + Fr(a_j * ((b >> j) & 1), 2)
                if ph.denominator != 1: return False
        return True
    def in_gamma(x, a):
        return all((2 * x[j]).denominator == 1 for j in range(n)) and a == pi_(x)
    lam = Fr(LAM_MAIN)
    for j in range(n):
        for x, a in (([Fr(1, 2) if i == j else Fr(0) for i in range(n)], 1 << j), ([Fr(1) if i == j else Fr(0) for i in range(n)], 0)):
            z = [2 * lam * eps[i] * x[i] for i in range(n)]
            if not (in_gamma_star(z, a) and annihilates(z, a)): ok11r = False
        for z, b in (([Fr(1) if i == j else Fr(0) for i in range(n)], 1 << j), ([Fr(2) if i == j else Fr(0) for i in range(n)], 0)):
            if not annihilates(z, b): ok11r = False
            x = [z[i] / (2 * lam * eps[i]) for i in range(n)]
            if not in_gamma(x, b): ok11r = False
    gR = g_plus ** p * g_minus ** q                                         # the quadrature's index of exp(2 pi i Q) (Proposition 3)
    c = gauss(w); m_ = dual_weight(n); gD = complex(c[0], c[1]) * math.sqrt(m_)
    worst11 = max(worst11, abs(gR * gD.conjugate() - 1)); ok11c &= abs(gR * gD.conjugate() - 1) < 1e-9
chk('bit==std', ok11h and ok11r and ok11c, 'wi.T5: Weil\'s Theorem 5 on G\' = R^n x labels, f\' = exp(2 pi i Q) (x) conj(i^w), with the closed subgroup Gamma\' = {(x, 2x mod 2) : x in (1/2 Z)^n}: f\' = 1 on Gamma\' (every class x = a/2 for n <= 10, and every a/2 + m with m in {-1,0,1}^n for n <= 4, exact; on all of Gamma\' since Q(x + m) - Q(x) = sum_j eps_j (2 x_j m_j + m_j^2) is an integer); the morphism rho\'(x, a) = (2Ex, a) associated with f\' is an isomorphism of (G\', Gamma\') onto (G\'*, Gamma\'_*), Gamma\'_* = {(z, z mod 2) : z in Z^n} the annihilator of Gamma\' for <(x, a), (z, b)> = exp(2 pi i x.z) (-1)^(a.b) (the generators of each mapped into the other, exact); so gamma(f\') = 1; since gamma multiplies over products and gamma(conj f) = conj gamma(f) (both from Corollary 2 on a product, with a real Phi), gamma(exp(2 pi i Q)) = gamma(i^w): the quadrature\'s real index times the conjugate of the labels\' exact one is 1 for the 66 cells with n <= 10 (largest deviation %.1e)' % worst11)
note(lap(t))

# ================================================================================================ controls, computed in place
head('controls: the character\'s sign, the parity term, the dual measure, the conjugate in Theorem 5')
t = time.time()
n_diff = n_same = 0; ok_c1 = True
GT = {lam: (GQ1[-lam] if FAULT == 'CHI' else GQ1[lam]) for lam in LAMS}     # the quadrature's values for the right character, whatever the fault
for p, q in cells(10):
    n = p + q; c = gauss(wform(sig(p, q))); gD = complex(c[0], c[1]) / 2 ** (n / 2)
    gRm = GT[Fr(-1)] ** p * GT[Fr(1)] ** q                                  # the index of the form with chi(t) = exp(-2 pi i t)
    differs = abs(gRm - gD) > 1e-6
    if differs != ((p - q) % 4 != 0): ok_c1 = False
    n_diff += differs; n_same += not differs
    if n >= 1:
        w = wform(sig(p, q))
        if all((-sum(sig(p, q)[j] for j in range(n) if (a >> j) & 1) - w[a]) % 4 == 0 for a in range(1 << n)): ok_c1 = False   # f' with chi-bar is 1 on Gamma'
chk('ctl', ok_c1 and n_diff > 0, 'wi.T5: the character\'s sign matters: with chi(t) = exp(-2 pi i t) the real index differs from the labels\' for the %d cells with p - q not 0 or 4 mod 8 and equals it for the %d others (n <= 10), and f\' is not 1 on Gamma\' for any cell with n >= 1 (CHI)' % (n_diff, n_same))
ok_c2 = True; n_odd = 0; n_even = 0; n_diff2 = 0
for p, q in cells(9):
    n = p + q
    if n == 0: continue
    w0 = wform(sig(p, q), parity=False); R, isbichar = bichar_matrix(w0, n)
    J = (1 << n) - 1
    if not isbichar or R != [J ^ (1 << i) for i in range(n)]: ok_c2 = False; continue
    if n % 2:
        n_odd += 1
        if invertible(R, n): ok_c2 = False
    else:
        n_even += 1
        if not invertible(R, n): ok_c2 = False; continue
        if n <= 6:
            c0 = relation9(w0, R, n); br = BR(sig(p, q))
            count = sum(br.sq(a) for a in range(1 << n))                   # sum_a e_a^2 (GEN-032)
            if c0 is None or c0 != (count, 0) or abs(count) != 1 << (n // 2): ok_c2 = False
            elif (count > 0) != ((p - q) % 8 in (0, 2)): ok_c2 = False
            elif ((p - q) % 8 in (2, 6)) != (c0 != clock_sum_closed(p, q)): ok_c2 = False
            else: n_diff2 += c0 != clock_sum_closed(p, q)
chk('ctl', ok_c2, 'wi.DEF: the parity term matters: without it (w = 2 [e_a^2 = -1], a real f) the bicharacter of f is the commutation form, rho = J - I (ones off the diagonal): degenerate for odd n, so no index (the %d cells with n <= 9 odd), and for even n <= 6 relation (9) holds with gamma = +1 or -1, the count sum_a e_a^2 / 2^(n/2) of GEN-032 (+1 for p - q = 0, 2 mod 8, -1 for p - q = 4, 6 mod 8), never +i or -i, so it differs from the clock\'s phase for the %d cells with p - q = 2, 6 mod 8 (NOPARITY; the analogue of Weil\'s n. 25: gamma(conj f) = conj gamma(f), so a real f has gamma = +1 or -1)' % (n_odd, n_diff2))
ok_c3 = True
for p, q in cells(6, 1):
    n = p + q; w = wform(sig(p, q)); R = [1 << i for i in range(n)]
    c = relation9(w, R, n)                                                  # the Gaussian scalar of (9) does not depend on the measure; gamma = c m^(1/2)
    if c is None or gnorm(c) != 1 << n: ok_c3 = False                       # with m = 1 (counting) |gamma|^2 = |c|^2 = 2^n, not 1 (n >= 1)
for p, q in cells(10, 1):
    n = p + q; eps = sig(p, q); w = wform(eps)
    if all((sum(eps[j] for j in range(n) if (a >> j) & 1) + w[a]) % 4 == 0 for a in range(1 << n)): ok_c3 = False   # chi(Q) (x) i^w is 1 on Gamma'?
chk('ctl', ok_c3, 'wi.DEF, wi.T5: the dual measure matters: with the counting measure on the dual (|rho^-1| = 1) the scalar of relation (9) is the clock sum itself, of modulus 2^(n/2), not 1, for every cell with 1 <= n <= 6 (COUNTING); and Theorem 5 needs the conjugate: exp(2 pi i Q) (x) i^w is not 1 on Gamma\' for any cell with 1 <= n <= 10 (CONJ)')
note(lap(t))
finish()
