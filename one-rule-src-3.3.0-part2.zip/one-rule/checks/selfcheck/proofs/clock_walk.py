#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""clock_walk.py: the path of the clock sum, its partial sums in counting order and in Gray-code order, and Duvall and Keesling's count of the
boundary of the Levy dragon on the labels of Cl(0,n) (round 17, proofs pass 13a; docs/round17/PROOFS_ROUND13A.md).
     python3 clock_walk.py [--fault GRAY|F2FIRST|NOPARITY|NOSTAR|MIRROR]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators of
square +1 first (core_check.sig). The Z4 form of the labels is w(a) = (|a| mod 2) + 2 [e_a^2 = -1] (core.B1, LAB-017), the square read from the
kernel's s(a, a); the clock sum is the sum over the labels of i^w(a) (LAB-017). Its partial sums over the labels a = 0, 1, ..., 2^n - 1 (counting
order) are the path the figure gauss-sum draws; a Gaussian integer on a [bit] line is a pair of Python integers, never a complex number.
Sources (docs/round17/PROOFS_ROUND13A.md, section 1): P. Duvall and J. Keesling, The Hausdorff dimension of the boundary of the Levy dragon,
arXiv:math/9907145 (read in full): the maps f1(x,y) = ((x-y)/2, (x+y)/2), f2(x,y) = ((x+y+1)/2, (y-x+1)/2) of sections 1 and 4, the triangle T0 =
(0,0), (1/2,1/2), (1,0) and the triangulation of section 4, the star N(T) of 15 triangles (Fig. 3), covered triangles, Theorem 4.5 (dim of the
boundary = ln(beta)/ln(sqrt 2)), Proposition 5.1 (the two rules of the neighbourhood types) and the numbers of section 5 (752 stable types from
S_19 = S_20; lambda = 1.954776399, dim = 1.934007183); P. C. Allaart and K. Kawamura, On the coordinate functions of Levy's dragon curve
(preprint, 2005; read): L(t) = sum_j 2^-j i^d_j l_(q_j) on the base-4 digits q_j of t, d_j = (number of 0s minus number of 3s among
q_1 .. q_(j-1)) mod 4, l_0 = 0, l_q = q - 1 + i; the L-systems of Levy's C curve (F -> +F--F+, 45 degrees) and of the Heighway dragon
(axiom FX, X -> X+YF+, Y -> -FX-Y, 90 degrees), standard, recalled.
cw.PATH  the path in counting order. [bit] for the 45 cells (p,q,0) with n <= 8, on all 4,097 labels: w equals the charge sum_j eps_j over the
         generators of the label mod 4 (LAB-022), each step i^w(a) squared is (-1)^|a| (the Thue-Morse sign of the label), the labels that
         contain e_k (2^k .. 2^(k+1) - 1) step as the earlier labels times i^w(e_k), and the end is (1+i)^p (1-i)^q.  [std] the paper's two
         maps on pairs of Fractions, F(A) = f1(A) u f2(A) with f1's images first, applied n times to the segment [0,1]; Levy's L-system;
         Allaart and Kawamura's L(t).  [bit==std] the walk of Cl(0,n) divided by (1-i)^n is F^n([0,1]) segment by segment for n <= 12, and
         that of Cl(n,0) divided by (1+i)^n its mirror image; the L-system's segments are the walk's steps turned by n times 45 degrees;
         L(a/4^m) is the walk of Cl(0,2m) at the label a divided by its end, m <= 6.  [ctl] GRAY, F2FIRST, NOPARITY, MIRROR.
cw.GRAY  the same labels in Gray-code order m xor (m >> 1) (each label one generator away from the next).  [bit] for the 91 cells with n <= 12
         the same end, and the labels with the newest generator retrace the first half backwards, turned by a quarter turn; [bit==std] the walk of
         Cl(n,0) is the Heighway dragon's L-system segment by segment for n <= 12, and that of Cl(0,n) its mirror image.
cw.ORD   the path against the end.  [bit] for every order of the signs of the 45 cells with n <= 8 (511 sign words), the end is (1+i)^p (1-i)^q,
         the step of the label of e_k is i^w(e_k) (+i or -i by its sign), so the path determines the word: 511 distinct paths.
cw.DK    the paper's count on the labels.  [bit] each step z -> z + d of the walk of Cl(0,n) is the long side of the triangle with third vertex
         z + d (1+i)/2 (the image of T0); for n <= 16 the 2^n triangles are distinct, and a label is interior when the 15 triangles of the
         star of its triangle all belong to the walk: none for n <= 13, 8 at n = 14, 44 at 15, 172 at 16.  [std] Proposition 5.1 as printed,
         from the types 2^0 .. 2^14 of N_0: the number of boundary labels for each n, the types present (752 from n = 19 on), the shares at
         n = 24 and 64.  [bit==std] the two counts agree for n <= 16.  [ctl] NOSTAR.
cw.LAM   lambda.  [std] the counts of Proposition 5.1 for n <= 419 satisfy an integer linear recurrence of order 95 (Berlekamp-Massey over Q,
         checked on every term); P = x^9 - 3x^8 + 3x^7 - 3x^6 + 2x^5 + 4x^4 - 8x^3 + 8x^2 - 16x + 8 divides its characteristic polynomial
         exactly and is irreducible over Q (Rabin's test modulo 7); its largest real root lambda (bisection on exact rationals, Sturm's theorem
         for no root above it) is the limit of the ratio of successive counts (to 1e-9 at n = 400) and 2 log2(lambda) is the paper's 1.934007183.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   GRAY the Gray-code order in place of the counting order; F2FIRST the union taken with f2's images first; NOPARITY w without its parity term
   (w = 2Q, so every step is +1 or -1); NOSTAR the star replaced by the 4 triangles that share an edge with T (T among them); MIRROR the walk of
   Cl(n,0) taken for the dragon of the paper.
Not computed here (stated, not checked): Theorem 4.5 itself and the open set condition (read, not re-proved; the dimension is 2 log2(lambda) by
it); Levy's tiling of the plane by copies of the dragon (cited); anything about a cell that depends on the order of its labels: the path is a
picture of the counting order, and the cell fixes its end, the clock's phase (LAB-017).
Command: python3 -I -B selfcheck/proofs/clock_walk.py from checks/ (or from this folder); standard library only."""
import os, sys, time
from fractions import Fraction as Fr
from math import log2

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import sig as _core_sig                                   # the cell's eps: p generators of square +1 first

# ------------------------------------------------------------------------------------------------ check lines (from ten_pairings.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish():
    print('\n  tags: %s; %.0f s' % (', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), time.time() - T0))
    print('clock_walk: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('GRAY', 'F2FIRST', 'NOPARITY', 'NOSTAR', 'MIRROR')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))

# ------------------------------------------------------------------------------------------------ the kernel's form and the walk
def pc(a): return bin(a).count('1')
def sig(p, q): return list(_core_sig(p, q, 0))
I_POW = ((1, 0), (0, 1), (-1, 0), (0, -1))                                # i^0 .. i^3 as Gaussian integers (pairs)
def gmul(u, v): return (u[0] * v[0] - u[1] * v[1], u[0] * v[1] + u[1] * v[0])
def gpow(u, k):
    z = (1, 0)
    for _ in range(k): z = gmul(z, u)
    return z
def wform(eps, parity=True):
    """w(a) = (|a| mod 2) + 2 [e_a^2 = -1] for every label, the square from the kernel's s(a, a); parity=False drops the first term (NOPARITY)"""
    br = BR(eps)
    return [((pc(a) & 1) if parity else 0) + 2 * (1 if br.sq(a) == -1 else 0) for a in range(1 << len(eps))]
def W(eps): return wform(eps, parity=(FAULT != 'NOPARITY'))
def counting(n): return list(range(1 << n))                                # the counting order a = 0, 1, ..., 2^n - 1
def gray(n): return [m ^ (m >> 1) for m in range(1 << n)]                 # the Gray-code order
def ORDER(n): return gray(n) if FAULT == 'GRAY' else counting(n)          # the order the main lines read the labels in
def DRAGON(n): return sig(n, 0) if FAULT == 'MIRROR' else sig(0, n)        # the cell whose walk the main lines take for the paper's dragon
def DRAGON_END(n): return gpow((1, 1), n) if FAULT == 'MIRROR' else gpow((1, -1), n)
def walk(w, order):
    """the steps i^w(a) in the given order of the labels and the partial sums (pairs of integers), from 0"""
    steps = [I_POW[w[a] % 4] for a in order]
    pts = [(0, 0)]
    for d in steps: pts.append((pts[-1][0] + d[0], pts[-1][1] + d[1]))
    return steps, pts

# ------------------------------------------------------------------------------------------------ the standard routes
H = Fr(1, 2)
def f1(z): x, y = z; return ((x - y) * H, (x + y) * H)                        # the paper's f1 (sections 1 and 4), as printed
def f2(z): x, y = z; return ((x + y + 1) * H, (y - x + 1) * H)                # the paper's f2, as printed
def stage(n, f2first=False):
    """F^n([0,1]) as the ordered list of its 2^n segments, F(A) = f1(A) u f2(A): f1's images first (or f2's first, F2FIRST)"""
    segs = [((Fr(0), Fr(0)), (Fr(1), Fr(0)))]
    maps = (f2, f1) if f2first else (f1, f2)
    for _ in range(n): segs = [(f(a), f(b)) for f in maps for (a, b) in segs]
    return segs
def gdiv(z, u):
    """z / u for a pair z of Fractions and a Gaussian integer u"""
    d = Fr(u[0] * u[0] + u[1] * u[1]); x, y = z
    return ((x * u[0] + y * u[1]) / d, (y * u[0] - x * u[1]) / d)
def lsystem(axiom, rules, n):
    s = axiom
    for _ in range(n): s = ''.join(rules.get(c, c) for c in s)
    return s
def turns(s):
    """the direction (in units of the L-system's angle) of each F of the string"""
    a, out = 0, []
    for c in s:
        if c == '+': a += 1
        elif c == '-': a -= 1
        elif c == 'F': out.append(a)
    return out
QUARTER = {(1, 0): 0, (0, 1): 1, (-1, 0): 2, (0, -1): 3}
def ak_point(a, m):
    """Allaart and Kawamura's L(t) at t = a / 4^m (base-4 digits q_1 .. q_m of t), as a pair of Fractions"""
    q = [(a // 4 ** (m - 1 - j)) % 4 for j in range(m)]
    x = y = Fr(0); n0 = n3 = 0
    for j, qj in enumerate(q, start=1):
        d = (n0 - n3) % 4
        lq = (0, 0) if qj == 0 else (qj - 1, 1)
        rx, ry = gmul(I_POW[d], lq)
        x += Fr(rx, 2 ** j); y += Fr(ry, 2 ** j)
        n0 += (qj == 0); n3 += (qj == 3)
    return (x, y)

# ================================================================================================ cw.PATH
head('cw.PATH: the path of the clock sum in counting order; the Levy dragon of Duvall and Keesling; Allaart and Kawamura\'s formula')
t = time.time()
labels = 0; charge_ok = tm_ok = block_ok = end_ok = True
for n in range(0, 9):
    for p in range(n + 1):
        q = n - p; eps = sig(p, q); w = W(eps)
        labels += len(w)
        charge = [(pc(a & ((1 << p) - 1)) - pc(a >> p)) % 4 for a in range(1 << n)]
        if w != charge: charge_ok = False
        for a in range(1 << n):
            sq = gmul(I_POW[w[a] % 4], I_POW[w[a] % 4])
            if sq != ((-1) ** pc(a), 0): tm_ok = False
        steps, pts = walk(w, ORDER(n))
        for k in range(n):
            ek = I_POW[w[1 << k] % 4]
            if any(steps[(1 << k) + a] != gmul(steps[a], ek) for a in range(1 << k)): block_ok = False
        if pts[-1] != gmul(gpow((1, 1), p), gpow((1, -1), q)): end_ok = False
chk('bit', charge_ok and tm_ok and block_ok and end_ok and labels == 4097,
    'cw.PATH: for the 45 cells (p,q,0) with n <= 8, on all %d labels, the Z4 form read from the kernel\'s squares, w(a) = (|a| mod 2) + 2 [e_a^2 = -1], '
    'equals the charge sum_j eps_j over the generators of a, mod 4 (LAB-022)%s; each step i^w(a), squared, is (-1)^|a|, the Thue-Morse sign of the '
    'label%s; the labels that contain e_k (2^k .. 2^(k+1) - 1) step as the earlier labels a < 2^k times i^w(e_k) = +i or -i, so each generator adds '
    'a copy of the whole path turned by a quarter turn (the factor 1 + i^w(e_k) of LAB-023, before the sum)%s; and the path ends at (1+i)^p (1-i)^q '
    '(LAB-017)%s (exact, Gaussian integers)' % (labels, '' if charge_ok else ' (NOT on every label)', '' if tm_ok else ' (NOT for every label)',
                                               '' if block_ok else ' (NOT for every k)', '' if end_ok else ' (NOT for every cell)'))
note('(%.1f s)' % (time.time() - t))

t = time.time()
dk_ok = True; mirror_ok = True; nseg = 0
for n in range(0, 13):
    segs = stage(n, f2first=(FAULT == 'F2FIRST'))
    _, pts = walk(W(DRAGON(n)), ORDER(n)); u = DRAGON_END(n)
    norm = [gdiv((Fr(x), Fr(y)), u) for (x, y) in pts]
    if any(segs[a] != (norm[a], norm[a + 1]) for a in range(1 << n)): dk_ok = False
    nseg += len(segs)
    _, ptsp = walk(W(sig(n, 0)), ORDER(n)); up = gpow((1, 1), n)
    normp = [gdiv((Fr(x), Fr(y)), up) for (x, y) in ptsp]
    if n and any(normp[a] != (norm[a][0], -norm[a][1]) for a in range(len(norm))): mirror_ok = False
chk('bit==std', dk_ok and mirror_ok and nseg == 8191,
    'cw.PATH: the paper\'s two maps as printed, f1(x,y) = ((x-y)/2, (x+y)/2) and f2(x,y) = ((x+y+1)/2, (y-x+1)/2), on pairs of Fractions, F(A) = f1(A) u f2(A) '
    'with f1\'s images first, applied n times to the segment [0,1]%s: for n = 0 .. 12 (%d segments in all) the walk of %s divided by its end %s is F^n([0,1]) '
    'segment by segment, in order%s (f1 = the labels without the newest generator, f2 = those with it), and the walk of Cl(n,0) divided by (1+i)^n is '
    'its mirror image (complex conjugate)%s: the path of Cl(0,n) is the n-th stage of the Levy dragon, that of Cl(n,0) its mirror (exact)'
    % (' (F2FIRST: f2\'s images first)' if FAULT == 'F2FIRST' else '', nseg, 'Cl(n,0) (MIRROR)' if FAULT == 'MIRROR' else 'Cl(0,n)',
       '(1+i)^n' if FAULT == 'MIRROR' else '(1-i)^n', ' (GRAY: the labels in Gray-code order)' if FAULT == 'GRAY' else '', '' if mirror_ok else ' (NOT)'))

lev_ok = True; offs = []
for n in range(0, 13):
    L = turns(lsystem('F', {'F': '+F--F+'}, n))
    steps, _ = walk(W(DRAGON(n)), ORDER(n))
    eighths = {(a - 2 * QUARTER[d]) % 8 for a, d in zip(L, steps)}
    offs.append(sorted(eighths))
    if len(L) != (1 << n) or eighths != {n % 8}: lev_ok = False
chk('bit==std', lev_ok,
    'cw.PATH: Levy\'s L-system F -> +F--F+ (45 degrees) after n rounds has 2^n segments, and for n = 0 .. 12 their directions are the steps of the walk of '
    'Cl(0,n) turned by n times 45 degrees (the offsets in eighths of a turn: %s), as the division by (1-i)^n turns them' % ', '.join(str(o[0]) if len(o) == 1 else str(o) for o in offs))

ak_ok = True; ak_d_ok = True; ak_pts = 0
for m in range(1, 7):
    n = 2 * m; w = W(DRAGON(n)); _, pts = walk(w, ORDER(n)); end = pts[-1]
    for a in range(1 << n):
        if ak_point(a, m) != gdiv((Fr(pts[a][0]), Fr(pts[a][1])), end): ak_ok = False
        ak_pts += 1
        n0 = n3 = 0
        for j in range(1, m + 1):                                         # d_j against w of the label of the digits before q_j
            top = (a >> (2 * (m - j + 1))) << (2 * (m - j + 1))
            if (n0 - n3) % 4 != ((j - 1) + w[top]) % 4: ak_d_ok = False
            qj = (a >> (2 * (m - j))) & 3; n0 += (qj == 0); n3 += (qj == 3)
chk('bit==std', ak_ok and ak_d_ok and ak_pts == sum(4 ** m for m in range(1, 7)),
    'cw.PATH: Allaart and Kawamura\'s formula L(t) = sum_j 2^-j i^d_j l_(q_j) (base-4 digits q_j of t, d_j = number of 0s minus number of 3s among the '
    'digits before q_j, mod 4, l_0 = 0, l_q = q - 1 + i) at t = a/4^m is the walk of Cl(0,2m) at the label a divided by its end, for m = 1 .. 6 '
    '(%d points, exact), and their d_j is w of the label made of the digits before q_j (the charge of LAB-022, read two generators at a time) plus j - 1, '
    'the quarter turn of the division by the end at each level%s' % (ak_pts, '' if ak_d_ok else ' (NOT for every digit)'))
note('(%.1f s)' % (time.time() - t))

# the controls: each wrong version differs from F^n([0,1]) (the main lines take it under its --fault)
diff = {'GRAY': [], 'F2FIRST': [], 'NOPARITY': [], 'MIRROR': []}
for n in range(0, 13):
    segs = stage(n); u = gpow((1, -1), n)
    eps = sig(0, n)
    for name in diff:
        if name == 'GRAY': _, pts = walk(wform(eps), gray(n)); uu = u
        elif name == 'NOPARITY': _, pts = walk(wform(eps, parity=False), counting(n)); uu = None
        elif name == 'MIRROR': _, pts = walk(wform(sig(n, 0)), counting(n)); uu = gpow((1, 1), n)
        else: _, pts = walk(wform(eps), counting(n)); uu = u
        if name == 'F2FIRST': cand = stage(n, f2first=True); tgt = [(gdiv((Fr(x), Fr(y)), uu)) for (x, y) in pts]; same = all(cand[a] == (tgt[a], tgt[a + 1]) for a in range(1 << n))
        elif uu is None: same = pts[-1] == (0, 0) and n == 0 or (pts[-1] != (0, 0) and all(segs[a] == (gdiv((Fr(pts[a][0]), Fr(pts[a][1])), (pts[-1][0], pts[-1][1])), gdiv((Fr(pts[a + 1][0]), Fr(pts[a + 1][1])), (pts[-1][0], pts[-1][1]))) for a in range(1 << n)))
        else: tgt = [gdiv((Fr(x), Fr(y)), uu) for (x, y) in pts]; same = all(segs[a] == (tgt[a], tgt[a + 1]) for a in range(1 << n))
        if not same: diff[name].append(n)
chk('ctl', diff['GRAY'] == list(range(2, 13)) and diff['F2FIRST'] == list(range(1, 13)),
    'cw.PATH: the order matters: the labels in Gray-code order differ from F^n([0,1]) for every n from %s to %s (GRAY; for n <= 1 the two orders are one), '
    'and the stage built with f2\'s images first for every n from %s to %s (F2FIRST)'
    % (diff['GRAY'][0] if diff['GRAY'] else '-', diff['GRAY'][-1] if diff['GRAY'] else '-', diff['F2FIRST'][0] if diff['F2FIRST'] else '-', diff['F2FIRST'][-1] if diff['F2FIRST'] else '-'))
chk('ctl', diff['NOPARITY'] == list(range(1, 13)) and diff['MIRROR'] == list(range(1, 13)),
    'cw.PATH: the form matters: w without its parity term (2Q alone, every step +1 or -1, a walk on the real line) is not the dragon for any n from %s to %s '
    '(NOPARITY), and the walk of Cl(n,0), divided by its end, differs from it for every n from %s to %s (MIRROR: the other hand)'
    % (diff['NOPARITY'][0] if diff['NOPARITY'] else '-', diff['NOPARITY'][-1] if diff['NOPARITY'] else '-', diff['MIRROR'][0] if diff['MIRROR'] else '-', diff['MIRROR'][-1] if diff['MIRROR'] else '-'))

# ================================================================================================ cw.GRAY
head('cw.GRAY: the same labels in Gray-code order: the Heighway dragon')
t = time.time()
same_end = True; hey_ok = True; retrace = True; cells_g = 0
for n in range(0, 13):
    for p in range(n + 1):                                                # every cell (p, n - p): Gray order keeps the end and retraces
        q = n - p; w = W(sig(p, q)); cells_g += 1
        _, pc_ = walk(w, ORDER(n)); sg, pg = walk(w, gray(n))
        if pc_[-1] != pg[-1] or pg[-1] != gmul(gpow((1, 1), p), gpow((1, -1), q)): same_end = False
        if n:                                                             # the labels with the newest generator: the first half backwards, turned
            h, r = 1 << (n - 1), I_POW[w[1 << (n - 1)] % 4]
            if any(sg[h + j] != gmul(r, sg[h - 1 - j]) for j in range(h)): retrace = False
    Hs = turns(lsystem('FX', {'X': 'X+YF+', 'Y': '-FX-Y'}, n))
    s1, _ = walk(W(sig(n, 0)), gray(n)); s0, _ = walk(W(sig(0, n)), gray(n))
    if len(Hs) != (1 << n) or any(h % 4 != QUARTER[d] for h, d in zip(Hs, s1)) or any((-h) % 4 != QUARTER[d] for h, d in zip(Hs, s0)): hey_ok = False
chk('bit', same_end and retrace and cells_g == 91,
    'cw.GRAY: in Gray-code order m -> m xor (m >> 1) (each label one generator away from the one before) the labels of the %d cells (p,q,0) with n <= 12 '
    'give the same steps in another order, so the same end (1+i)^p (1-i)^q%s; the labels with the newest generator e_(n-1) (the second half) step as the '
    'first half read backwards times i^w(e_(n-1)): from the end of the first half the path retraces it, turned by a quarter turn about that point%s'
    % (cells_g, '' if same_end else ' (NOT)', '' if retrace else ' (NOT for every cell)'))
chk('bit==std', hey_ok,
    'cw.GRAY: the Heighway dragon\'s L-system (axiom FX, X -> X+YF+, Y -> -FX-Y, 90 degrees) after n rounds has 2^n segments, and for n = 0 .. 12 they are '
    'the steps of the walk of Cl(n,0) in Gray-code order, one by one, and with every turn reversed those of Cl(0,n): the same labels, counted in another '
    'order, draw the Heighway dragon instead of the Levy one')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cw.ORD
head('cw.ORD: the path against the end, over every order of the signs')
t = time.time()
words = 0; paths = set(); ends_ok = True; step_ok = True; at8 = {}
for n in range(0, 9):
    for word in range(1 << n):                                            # bit j of word set: the generator j has square -1
        eps = [(-1 if (word >> j) & 1 else 1) for j in range(n)]
        w = W(eps); steps, pts = walk(w, ORDER(n))
        p = eps.count(1); q = n - p
        if pts[-1] != gmul(gpow((1, 1), p), gpow((1, -1), q)): ends_ok = False
        if any(steps[1 << k] != ((0, 1) if eps[k] == 1 else (0, -1)) for k in range(n)): step_ok = False
        paths.add((n, tuple(steps))); words += 1
        if n == 8: at8.setdefault((p, q), set()).add(tuple(steps))
cells_16 = {k: len(v) for k, v in at8.items() if v and walk(W(sig(*k)), ORDER(8))[1][-1] == (16, 0)}
chk('bit', ends_ok and step_ok and words == 511 and len(paths) == 511 and cells_16 == {(8, 0): 1, (4, 4): 70, (0, 8): 1},
    'cw.ORD: for every order of the signs of the 45 cells with n <= 8 (%d sign words, each a cell with its generators in one order), the path ends at '
    '(1+i)^p (1-i)^q, which depends on p and q alone; the step of the label of e_k is i^w(e_k) = +i for a generator of square +1 and -i for one of square -1, '
    'so the path determines the word: %d distinct paths; at n = 8 the cells ending at 16 (clock 0, M16(R)) are %s, with %s paths: one end, '
    'many paths: the end is an invariant of the cell, the path is not' % (words, len(paths), ', '.join('(%d,%d)' % k for k in sorted(cells_16, reverse=True)),
                                                                        ', '.join(str(cells_16[k]) for k in sorted(cells_16, reverse=True))))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cw.DK
head('cw.DK: Duvall and Keesling\'s count of the boundary on the labels of Cl(0,n)')
t = time.time()
DIRS = ((1, 0), (0, 1), (-1, 0), (0, -1))
def tri_vertices(c2, u):
    """the triangle with doubled centre c2 (the centre of its unit square) and hypotenuse on the side u: doubled coordinates of its three vertices"""
    (cx, cy), (ux, uy) = c2, u
    return {(cx, cy), (cx + ux - uy, cy + uy + ux), (cx + ux + uy, cy + uy - ux)}
STAR15 = [((dx, dy), u) for dx in range(-4, 5, 2) for dy in range(-4, 5, 2) for u in DIRS if tri_vertices((dx, dy), u) & tri_vertices((0, 0), (1, 0))]
EDGE4 = [s for s in STAR15 if len(tri_vertices(*s) & tri_vertices((0, 0), (1, 0))) >= 2]
def triangles(steps, pts):
    """each step z -> z + d as the triangle with third vertex z + d (1+i)/2: doubled centre 2z + d (1+i), hypotenuse side u = -i d"""
    return [(2 * x + dx - dy, 2 * y + dy + dx, dy, -dx) for (x, y), (dx, dy) in zip(pts, steps)]
def interior(T, star):
    S = set(T); out = []
    for idx, (cx, cy, ux, uy) in enumerate(T):
        if all((cx + o[0] * ux - o[1] * uy, cy + o[0] * uy + o[1] * ux, r[0] * ux - r[1] * uy, r[0] * uy + r[1] * ux) in S for o, r in star): out.append(idx)
    return out
star = EDGE4 if FAULT == 'NOSTAR' else STAR15
inside = {}; distinct = True; pairs14 = None; backwards = True
for n in range(0, 17):
    w = W(DRAGON(n)); steps, pts = walk(w, ORDER(n)); T = triangles(steps, pts)
    if len(set(T)) != len(T): distinct = False
    E, N, r = pts[-1], 1 << n, I_POW[w[(1 << n) - 1] % 4]                  # the walk read backwards: E - P_(N-k) = i^w(full) conj(P_k)
    if any((E[0] - pts[N - k][0], E[1] - pts[N - k][1]) != gmul(r, (pts[k][0], -pts[k][1])) for k in range(N + 1)): backwards = False
    ins = interior(T, star); inside[n] = len(ins)
    if n == 14: pairs14 = sorted(a for a in ins); comp14 = all(((1 << 14) - 1 - a) in ins for a in ins)
want = {n: 0 for n in range(14)}; want.update({14: 8, 15: 44, 16: 172})
chk('bit', len(STAR15) == 15 and distinct and inside == want and comp14 and backwards,
    'cw.DK: each step z -> z + d of the walk of Cl(0,n) is the long side of the right isosceles triangle with third vertex z + d (1+i)/2 (the image of the '
    'paper\'s T0 = (0,0), (1/2,1/2), (1,0) by the similarity that takes [0,1] to the step, after the division by (1-i)^n); for n = 0 .. 16 the 2^n triangles '
    'are distinct (the paper\'s Proposition 4.2: F^k(T0) is a union of 2^k triangles)%s; a label is interior (its triangle "covered") when the %d triangles '
    'of its star, the triangles of the triangulation of the unit squares by their diagonals that meet it (the paper\'s N(T), Fig. 3)%s, all belong to the '
    'walk: interior labels by n: '
    'none for n <= 13, %d at n = 14 (the paper: "covered triangles do not exist until the 14th iteration, and only 8 of the 2^14"), %d at n = 15, %d at n = 16; '
    'the 8 of n = 14 are the labels %s, four pairs a, 2^14 - 1 - a of complementary labels%s: the walk read backwards is its own mirror image, '
    'E - P_(2^n - k) = i^w(e_0 ... e_(n-1)) conj(P_k) for its points P_k and end E, every n <= 16%s, w(a) + w(complement of a) being w of the whole label (LAB-022)'
    % ('' if distinct else ' (NOT)', len(star), ' (NOSTAR: the 4 triangles that share an edge with it)' if FAULT == 'NOSTAR' else '', inside[14], inside[15],
       inside[16], ', '.join(str(a) for a in pairs14), '' if comp14 else ' (NOT closed)', '' if backwards else ' (NOT)'))
note('interior labels by n (n = 0 .. 16): %s (%.1f s)' % (', '.join('%d' % inside[n] for n in range(17)), time.time() - t))

# the paper's Proposition 5.1, as printed: the neighbourhood type of each half T1, T2 of a triangle from the type (x1 .. x15) of the triangle
R1 = (8, 1, 9, 8, 10, 9, 1, 10, 15, 3, 2, 5, 4, 7, 6)
R2 = (10, 1, 12, 11, 14, 13, 2, 15, 3, 8, 1, 9, 8, 10, 9)
FULL = (1 << 15) - 1
def child(tp, R): return sum(((tp >> (j - 1)) & 1) << i for i, j in enumerate(R))
def rule_counts(nmax):
    V = {1 << j: 1 for j in range(15)}; B = []; sizes = []; types = []
    for k in range(nmax + 1):
        B.append(sum(c for tp, c in V.items() if (tp & 1) and tp != FULL)); sizes.append(len(V)); types.append(frozenset(V))
        Wn = {}
        for tp, c in V.items():
            for R in (R1, R2):
                ch = child(tp, R); Wn[ch] = Wn.get(ch, 0) + c
        V = Wn
    return B, sizes, types
t = time.time()
Brule, sizes, types = rule_counts(420)
stable = next(k for k in range(1, 420) if types[k] == types[k + 1])
share24, share64 = Brule[24] / 2 ** 24, Brule[64] / 2 ** 64
chk('std', stable == 19 and sizes[19] == 752 and all(types[k] == types[19] for k in range(19, 60)),
    'cw.DK: the paper\'s Proposition 5.1 as printed, rho(T1) = (x8, x1, x9, x8, x10, x9, x1, x10, x15, x3, x2, x5, x4, x7, x6) and rho(T2) = (x10, x1, x12, '
    'x11, x14, x13, x2, x15, x3, x8, x1, x9, x8, x10, x9), run from the 15 types 2^0 .. 2^14 of N_0 with integer counts: the set of types present is the same '
    'from n = %d on (S_19 = S_20, checked to n = 60), with %d types (the paper: 752); the boundary labels |B_n| (odd types other than 32767) are a share '
    '%.6f of the 2^n labels at n = 24 and %.6f at n = 64' % (stable, sizes[stable], share24, share64))
B_bit = [(1 << n) - inside[n] for n in range(17)]
chk('bit==std', Brule[:17] == B_bit,
    'cw.DK: the counts of boundary labels of the rule equal 2^n minus the interior labels of the walk for every n = 0 .. 16 (%s at n = 14, 16)'
    % ('%d, %d' % (Brule[14], Brule[16])))
edge_first = None; edge14 = None
for n in range(0, 15):
    steps, pts = walk(wform(sig(0, n)), counting(n)); c = len(interior(triangles(steps, pts), EDGE4))
    if c and edge_first is None: edge_first = (n, c)
    if n == 14: edge14 = c
chk('ctl', edge_first == (10, 2) and edge14 == 350,
    'cw.DK: with the star replaced by the 4 triangles that share an edge with it (itself among them) labels would be interior from n = %d (%d of them) and %d at '
    'n = 14: the star of 15 of the paper is what keeps every label on the boundary up to n = 13 (NOSTAR)' % (edge_first[0], edge_first[1], edge14))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cw.LAM
head('cw.LAM: lambda, the growth of the boundary labels, as an algebraic number')
t = time.time()
def berlekamp_massey(seq):
    """the shortest linear recurrence sum_(i=0..L) C[i] s[k-i] = 0 (C[0] = 1) of the sequence, over Q"""
    C, Bp, L, m, b = [Fr(1)], [Fr(1)], 0, 1, Fr(1)
    for n in range(len(seq)):
        d = Fr(seq[n])
        for i in range(1, L + 1): d += C[i] * seq[n - i]
        if d == 0: m += 1; continue
        coef = d / b; T = C[:]
        C = C + [Fr(0)] * max(0, len(Bp) + m - len(C))
        for i, x in enumerate(Bp): C[i + m] -= coef * x
        if 2 * L <= n: L, Bp, b, m = n + 1 - L, T, d, 1
        else: m += 1
        if len(C) < L + 1: C = C + [Fr(0)] * (L + 1 - len(C))
    return C[:L + 1], L
C, L = berlekamp_massey(Brule[:400])
rec_ok = all(sum(C[i] * Brule[k - i] for i in range(L + 1)) == 0 for k in range(L, 420)) and all(c.denominator == 1 for c in C)
P = [1, -3, 3, -3, 2, 4, -8, 8, -16, 8]
def divide(a, b):
    a = [Fr(x) for x in a]; qt = []
    while len(a) >= len(b):
        f = a[0] / b[0]; qt.append(f)
        for i in range(len(b)): a[i] -= f * b[i]
        a.pop(0)
    return qt, a
_, rem = divide(C, P)
# Rabin's irreducibility test modulo 7: x^(7^9) = x mod P, and gcd(x^(7^3) - x, P) = 1 (3 the only prime dividing 9)
PR = 7
def pmod(a, m):
    a = [x % PR for x in a]
    while a and a[0] == 0: a.pop(0)
    inv = pow(m[0] % PR, PR - 2, PR)
    while len(a) >= len(m):
        f = a[0] * inv % PR
        for i in range(len(m)): a[i] = (a[i] - f * m[i]) % PR
        a.pop(0)
        while a and a[0] == 0: a.pop(0)
    return a
def pmul(a, b):
    r = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): r[i + j] = (r[i + j] + x * y) % PR
    return r
def xpow(e, m):
    res, base = [1], [1, 0]
    while e:
        if e & 1: res = pmod(pmul(res, base), m)
        base = pmod(pmul(base, base), m); e >>= 1
    return res
def psub(a, b):
    k = max(len(a), len(b)); a = [0] * (k - len(a)) + a; b = [0] * (k - len(b)) + b
    r = [(x - y) % PR for x, y in zip(a, b)]
    while r and r[0] == 0: r.pop(0)
    return r
def pgcd(a, b):
    while b: a, b = b, pmod(a, b)
    return a
Pm = [x % PR for x in P]
irreducible = not psub(xpow(PR ** 9, Pm), [1, 0]) and len(pgcd(Pm, psub(xpow(PR ** 3, Pm), [1, 0]))) == 1
def peval(c, x):
    v = Fr(0)
    for k in c: v = v * x + k
    return v
lo, hi = Fr(195, 100), Fr(196, 100)
sign_change = peval(P, lo) * peval(P, hi) < 0
for _ in range(70):
    mid = (lo + hi) / 2
    if peval(P, lo) * peval(P, mid) <= 0: hi = mid
    else: lo = mid
lam = float(lo)
def digits(x, k): s = str(x.numerator * 10 ** k // x.denominator); return s[0] + '.' + s[1:]
_dl, _dh = digits(lo, 30), digits(hi, 30)
LAM_DIGITS = _dl[:next((i for i in range(len(_dl)) if _dl[i] != _dh[i]), len(_dl))]   # the decimal digits lo and hi share: the digits of lambda
# Sturm's theorem on exact rationals: the number of distinct real roots of P in (a, b] is V(a) - V(b), V the sign changes of the Sturm sequence;
# every root has |z| < 1 + max |a_i| = 17 (Cauchy's bound)
def dP(c): n = len(c) - 1; return [k * (n - i) for i, k in enumerate(c[:-1])]
def qrem(a, b):
    a = [Fr(x) for x in a]
    while len(a) >= len(b):
        f = a[0] / b[0]
        for i in range(len(b)): a[i] -= f * b[i]
        a.pop(0)
    while a and a[0] == 0: a.pop(0)
    return a
STURM = [[Fr(x) for x in P], [Fr(x) for x in dP(P)]]
while True:
    r = qrem(STURM[-2], STURM[-1])
    if not r: break
    STURM.append([-x for x in r])
def V(x):
    vals = [v for v in (peval(s, x) for s in STURM) if v != 0]
    return sum(1 for u, v in zip(vals, vals[1:]) if u * v < 0)
CAUCHY = Fr(17)
real_roots = V(-CAUCHY) - V(CAUCHY)
largest = V(Fr(195, 100)) - V(Fr(196, 100)) == 1 and V(Fr(196, 100)) - V(CAUCHY) == 0
ratio = Brule[400] / Brule[399]
dim = 2 * log2(lam)
chk('std', rec_ok and L == 95 and all(r == 0 for r in rem) and irreducible and sign_change and largest and abs(ratio - lam) < 1e-9
    and int(lam * 1e9) == 1954776399 and round(dim, 9) == 1.934007183 and 1.824190 < lam < 1.974189,
    'cw.LAM: the counts |B_n| of Proposition 5.1 for n = 0 .. 419 satisfy an integer linear recurrence of order %d (Berlekamp-Massey over Q on n <= 399, '
    'checked on every term to 419)%s; P(x) = x^9 - 3x^8 + 3x^7 - 3x^6 + 2x^5 + 4x^4 - 8x^3 + 8x^2 - 16x + 8 divides its characteristic polynomial exactly%s '
    'and is irreducible over Q (Rabin\'s test modulo 7)%s; of its %d real roots (Sturm\'s theorem, exact) the largest is lambda = %s... (bisection on exact '
    'rationals to an interval of width %.0e, the digits its two ends share; no root in (1.96, 17], every root below 17 in size)%s; the ratio |B_400|/|B_399| = %.10f equals it to 1e-9, inside the '
    'paper\'s rigorous bracket 1.824190 < lambda < 1.974189; lambda = %.9f... and 2 log2(lambda) = %.9f, the paper\'s lambda = 1.954776399 and dimension '
    '1.934007183 (its Theorem 4.5, read, not re-proved, says ln(beta)/ln(sqrt 2), beta = lim |B_k|^(1/k), is the Hausdorff dimension of the dragon\'s boundary)'
    % (L, '' if rec_ok else ' (NOT)', '' if all(r == 0 for r in rem) else ' (NOT)', '' if irreducible else ' (NOT)', real_roots, LAM_DIGITS, float(hi - lo),
       '' if largest else ' (NOT)', ratio, lam, dim))
note('(%.1f s)' % (time.time() - t))

finish()
