#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""weil_heisenberg.py: the labels as Weil's Heisenberg group over F2, the finite Stone-von Neumann theorem on them, and Weil's Theorem 1 there
(the Clifford group) (round 17, proofs pass 13c; docs/round17/PROOFS_ROUND13C.md).      python3 weil_heisenberg.py [--fault NOSTRING|NOSQUARE|NONSYMP|REAL]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators of
square +1 first (core_check.sig). Phases in {1, i, -1, -i} are exponents mod 4; a Gaussian integer is a pair of Python integers; the group of
LAB-028's operators is computed exactly in Q(zeta), zeta = exp(i pi/4), as 4-tuples of Fractions (zeta^4 = -1).
Source (docs/round17/PROOFS_ROUND13C.md, section 3): A. Weil, Sur certains groupes d'operateurs unitaires, Acta Math. 111 (1964) 143-211, read in
full (pass 13b). Used here: n. 3 (the bicharacter F(w1, w2) = <x1, x2*> of G x G*, formula (3); Sp(G), the automorphisms keeping F(w1, w2)
F(w2, w1)^-1); n. 4 (U(w) Phi(x) = Phi(x + u) <x, u*> for w = (u, u*), U(w1) U(w2) = F(w1, w2) U(w1 + w2), the group A(G) of the t U(w) with the
law (4)); n. 5 (B0(G): the automorphisms of A(G) that fix its centre, given by pairs (sigma, f), sigma an automorphism of G x G* and f a function
with relation (6), f(w1 + w2) f(w1)^-1 f(w2)^-1 = F(w1 sigma, w2 sigma) F(w1, w2)^-1, a character of the second degree of G x G*; the inner ones,
sigma = 1 and f a character); n. 8-10 (Theorem 1: the centraliser of A(G) among the unitary operators of L2(G) is the scalars T, every element of
B0(G) is induced by a unitary s of the normaliser of A(G), s^-1 U(w) s = f(w) U(w sigma) (relation (15)), and that normaliser modulo T is B0(G);
Weil credits the theorem to I. Segal when x -> 2x is an automorphism of G, which it is not here, 2x = 0); n. 13 (the lifts t0(f), d'0(gamma) of
LAB-028). The Pauli matrices, the Jordan-Wigner representation, the qubit Clifford group and its generation by transvections (CAND-008, GEN-015):
standard, recalled. The Stone-von Neumann theorem for G = R^m: recalled, not read.
Two dictionaries meet here. In LAB-028 the labels of a cell with n generators are G = (Z/2)^n itself, and Weil's operators act on L2(G) = C^(2^n);
in wh.HEIS the labels of a cell with 2m generators are G x G*, G = (Z/2)^m, and his operators act on L2(G) = C^(2^m). So LAB-028's S and H of the
one-generator cell Cl(1,0) act on L2(Z/2) and normalise A(Z/2), whose G x G* is the labels of a two-generator cell: the Clifford group of one qubit.
G = (Z/2)^m, G* = G by <x, x*> = (-1)^(x.x*); w = (x, z) as a 2m-bit integer, x the low m bits; F(w1, w2) = (-1)^(x1.z2); the commutation form
B(w1, w2) = x1.z2 + x2.z1 (F(w1, w2) F(w2, w1)^-1 = (-1)^B). The map phi of the labels of a cell with n = 2m generators: e_(2k) -> (e_k, e_0 + ... +
e_(k-1)), e_(2k+1) -> (e_k, e_0 + ... + e_k) (the Jordan-Wigner string in Weil's coordinates), extended additively; the phase c(e_j) = sqrt(e_j^2)
(1 or i) times 1 for j even and -i for j odd, extended along the product e_a = e_j1 e_j2 ... (j1 < j2 < ...).
wh.HEIS  the labels' Heisenberg group.  [bit] the commutation sign of the labels, e_a e_b = s(a,b) s(b,a) e_b e_a, is (-1)^(|a| |b| + a.b),
         alternating, non-degenerate exactly for n even, with the radical {0, the top label} for n odd (the 45 cells with n <= 8, all pairs); for the
         25 cells with n even <= 8, phi is a linear bijection onto G x G*, carries that sign to (-1)^B, and s(a, b) c(a xor b) = c(a) c(b) F(phi a, phi b)
         on all pairs: the labels' sign rule is Weil's cocycle up to the coboundary of c.  [std] Weil's U(w) as matrices on L2((Z/2)^m), m <= 4:
         U(w1) U(w2) = F(w1, w2) U(w1 + w2) on all pairs; for m = 1, U(1,0) = X, U(0,1) = Z, U(1,1) = ZX = iY (the Pauli matrices, up to the phase
         i^(x.z)).  [bit==std] the matrices M(a) = c(a) U(phi a) multiply as the labels, M(a) M(b) = s(a,b) M(a xor b), and M(e_j)^2 = e_j^2 (the 24
         cells with n = 2, 4, 6, 8).
wh.SVN   Stone-von Neumann on the labels.  [bit] tr M(a) = 2^m for a = 0 and 0 otherwise; summed over the group H of the t e_a (t in {1, i, -1, -i},
         order 4 2^n) |tr|^2 is |H|, so the module L2(G) is irreducible; the 4^m matrices are trace-orthogonal, a basis of M_(2^m)(C).  For n even
         every label a != 0 has a b with e_b e_a = -e_a e_b, so the character of an irreducible module on which i acts as i vanishes off the centre:
         one such module up to equivalence, of dimension 2^(n/2); for n odd every label other than 0 and the top label u has such a b, u is central,
         and the two modules with e_u acting as +sqrt(e_u^2) and -sqrt(e_u^2) are built (from the first n - 1 generators' M and the scalar on e_u),
         checked on all pairs, irreducible and told apart by their characters at e_u (the 20 cells with n = 1, 3, 5, 7).
wh.THM1  Weil's Theorem 1 for G = (Z/2)^m.  [std] Sp(2m, F2) enumerated for m = 1, 2 (6 and 720 elements, generated by the 3 and 15
         transvections); relation (6) has exactly 4^m solutions f for each sigma, so B0(G) has 24 and 11520 elements; for every sigma of Sp(2, 2)
         and Sp(4, 2) and every transvection of Sp(6, 2) and Sp(8, 2) (63, 255), with one f of (6) (the others differ by a character, an inner
         automorphism induced by a U(v)), an intertwiner s with U(w) s = s f(w) U(w sigma), built by averaging U(v) E (f(v) U(v sigma))^-1 over v
         (E a matrix unit), exact over Z[i], with s s* = lambda 1, lambda > 0, so that s / sqrt(lambda) is the unitary of the theorem; the U(w) are
         trace-orthogonal (m <= 4), so they span M_(2^m)(C) and the centraliser is the scalars.  [std] the map (sigma, f) -> sigma of B0 onto
         Sp(2m, F2): for m = 1 two lifts of two generators of Sp(2, 2) generate a group of 6 elements, a complement (B0(Z/2) is a split extension
         of Sp(2, 2) by its 4 inner automorphisms); for m = 2, for two generators of Sp(4, 2), none of the 16 x 16 pairs of lifts generates a group
         of 720 elements, so there is no complement: B0((Z/2)^2) is a non-split extension of Sp(4, F2) by its 16 inner automorphisms.  [bit==std]
         LAB-028's operators of the one-generator cell Cl(1,0), S = t0(i^w) (w read from the kernel) and H = d'0 (Weil's formula, the dual measure)
         on L2(Z/2), normalise the U(w) of G = Z/2 with sigma a transvection, and generate 192 unitaries; its centre is exactly its 8 scalars, the
         eighth roots of unity: (SH)^3 = zeta, the clock's phase of Cl(1,0); for Cl(0,1), (S'H)^3 = zeta^-1; modulo the scalars 24 elements, the
         order of B0(Z/2): the Clifford group of one qubit, up to the scalars.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   NOSTRING phi without the Jordan-Wigner string (e_(2k) -> (e_k, 0), e_(2k+1) -> (e_k, e_k)); NOSQUARE the phases c(e_j) without sqrt(e_j^2);
   NONSYMP invertible maps of G x G* outside Sp(2m, 2) in place of the symplectic ones (m = 2: the 19440 of GL(4, 2); m = 3, 4: each transvection
   followed by the exchange of the first two basis vectors of G, invertible and not symplectic; m = 1 has none, GL(2, 2) = Sp(2, 2));
   REAL t0 of the real character (-1)^x, Z = diag(1, -1) = S^2, in place of S = t0(i^w) (a real character of the second degree in place of i^w).
Not computed here (stated, not checked): Weil's theorems for general G (read); Sp(6, 2) and Sp(8, 2) element by element (their transvections only,
which generate them: CAND-008); the Stone-von Neumann theorem for G = R^m and the metaplectic group (read or recalled); the Clifford group of two
or more qubits as a finite group of unitaries and its phases.
Command: python3 -I -B selfcheck/proofs/weil_heisenberg.py from checks/ (or from this folder); standard library only."""
import os, sys, time, itertools
from fractions import Fraction as Fr

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import sig as _core_sig

# ------------------------------------------------------------------------------------------------ check lines (as in weil_index.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)
def finish():
    print('\n  tags: %s' % ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)))
    print('weil_heisenberg: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NOSTRING', 'NOSQUARE', 'NONSYMP', 'REAL')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
if FAULT: print('FAULT %s: the main lines below use the wrong version and must fail' % FAULT)

def pc(a): return bin(a).count('1')
def dot(a, b): return pc(a & b) & 1
def sig(p, q): return list(_core_sig(p, q, 0))
def cells(nmax, nmin=0, step=1): return [(p, n - p) for n in range(nmin, nmax + 1, step) for p in range(n + 1)]
def sexp(s): return 0 if s == 1 else 2                                    # +1, -1 as exponents of i
GI = ((1, 0), (0, 1), (-1, 0), (0, -1))                                   # i^e as a Gaussian integer

# ------------------------------------------------------------------------------------------------ Weil's frame for G = (Z/2)^m
def xz(w, m): return w & ((1 << m) - 1), w >> m
def Fexp(w1, w2, m): return 2 * dot(xz(w1, m)[0], xz(w2, m)[1])           # F(w1, w2) = <x1, z2> = (-1)^(x1.z2), as an exponent of i
def Bform(w1, w2, m):
    x1, z1 = xz(w1, m); x2, z2 = xz(w2, m); return (dot(x1, z2) + dot(x2, z1)) & 1
FT = {m: [[Fexp(w1, w2, m) for w2 in range(1 << (2 * m))] for w1 in range(1 << (2 * m))] for m in range(0, 5)}
class Mono:
    """a monomial matrix on L2((Z/2)^m): row y has its one entry i^ph[y] in the column col[y]"""
    __slots__ = ('col', 'ph')
    def __init__(self, col, ph): self.col = col; self.ph = ph
    def __mul__(self, o): return Mono([o.col[c] for c in self.col], [(self.ph[y] + o.ph[c]) % 4 for y, c in enumerate(self.col)])
    def scaled(self, k): return Mono(self.col, [(e + k) % 4 for e in self.ph])
    def inv(self):
        col = [0] * len(self.col); ph = [0] * len(self.col)
        for y, c in enumerate(self.col): col[c] = y; ph[c] = (-self.ph[y]) % 4
        return Mono(col, ph)
    def __eq__(self, o): return self.col == o.col and self.ph == o.ph
    def trace(self):
        re = im = 0
        for y, c in enumerate(self.col):
            if c == y: g = GI[self.ph[y]]; re += g[0]; im += g[1]
        return (re, im)
    def dense(self):
        M = len(self.col)
        return [[GI[self.ph[y]] if self.col[y] == c else (0, 0) for c in range(M)] for y in range(M)]
_UC = {}
def U(w, m):
    """Weil's U(w) of n. 4: (U(w) Phi)(y) = Phi(y + x) (-1)^(y.z): the row y holds (-1)^(y.z) in the column y xor x"""
    if (w, m) not in _UC:
        x, z = xz(w, m)
        _UC[(w, m)] = Mono([y ^ x for y in range(1 << m)], [2 * dot(y, z) for y in range(1 << m)])
    return _UC[(w, m)]
def phi_table(n, eps, string=True, square=True):
    """phi on every label of a cell with n = 2m generators, and the phase c (an exponent of i), along e_a = e_j1 ... e_jk, j1 < ... < jk"""
    m = n // 2; N = 1 << n
    def gen(j):
        k = j // 2
        if string: z = ((1 << k) - 1) if j % 2 == 0 else ((1 << (k + 1)) - 1)
        else: z = (1 << k) if j % 2 else 0
        return (1 << k) | (z << m)
    cg = [((0 if (eps[j] == 1 or not square) else 1) + (0 if j % 2 == 0 else 3)) % 4 for j in range(n)]
    phi = [0] * N; c = [0] * N
    for a in range(1, N):
        j = a.bit_length() - 1; a0 = a ^ (1 << j); g = gen(j)
        phi[a] = phi[a0] ^ g
        c[a] = (c[a0] + cg[j] + FT[m][phi[a0]][g]) % 4
    return phi, c
MAIN_STRING = FAULT != 'NOSTRING'; MAIN_SQUARE = FAULT != 'NOSQUARE'

# ================================================================================================ wh.HEIS
head('wh.HEIS: the labels as Weil\'s Heisenberg group over F2 (n. 3, 4)')
ok1 = True; npairs = 0; rad_ok = True; SBR = {}
for p, q in cells(8):
    n = p + q; N = 1 << n; br = BR(sig(p, q)); SBR[(p, q)] = br
    comm = [[br.s(a, b) * br.s(b, a) for b in range(N)] for a in range(N)]
    for a in range(N):
        pa = pc(a)
        for b in range(N):
            if comm[a][b] != (-1) ** ((pa * pc(b) + pc(a & b)) & 1): ok1 = False
        if comm[a][a] != 1: ok1 = False
    npairs += N * N
    radical = [a for a in range(N) if all(comm[a][b] == 1 for b in range(N))]
    if radical != ([0] if n % 2 == 0 else [0, N - 1]): rad_ok = False
chk('bit', ok1 and rad_ok, 'wh.HEIS: for the 45 cells (p,q,0) with n <= 8, on all %d pairs of labels, the commutation sign read from the kernel, e_a e_b = s(a,b) s(b,a) e_b e_a, is (-1)^(|a| |b| + a.b), alternating (+1 on the diagonal); its radical is {0} for n even (non-degenerate) and {0, the top label} for n odd' % npairs)
okb = True; okc = True; npairs2 = 0; TAB = {}
for p, q in cells(8, 0, 2):
    n = p + q; m = n // 2; N = 1 << n; br = SBR[(p, q)]
    phi, c = phi_table(n, sig(p, q), MAIN_STRING, MAIN_SQUARE); TAB[(p, q)] = (phi, c)
    if sorted(phi) != list(range(N)): okb = False                          # a bijection onto G x G* (2m bits)
    if any(phi[a ^ b] != phi[a] ^ phi[b] for a in range(N) for b in range(N)): okb = False
    for a in range(N):
        for b in range(N):
            if br.s(a, b) * br.s(b, a) != (-1) ** Bform(phi[a], phi[b], m): okb = False
            if (sexp(br.s(a, b)) + c[a ^ b]) % 4 != (c[a] + c[b] + FT[m][phi[a]][phi[b]]) % 4: okc = False
    npairs2 += N * N
chk('bit', okb and okc, 'wh.HEIS: for the 25 cells with n even <= 8 the map phi (e_(2k) -> (e_k, e_0 + ... + e_(k-1)), e_(2k+1) -> (e_k, e_0 + ... + e_k), the Jordan-Wigner string in Weil\'s coordinates, extended additively) is a linear bijection of the labels onto G x G*, G = (Z/2)^(n/2), carrying the labels\' commutation sign to Weil\'s F(w1, w2) F(w2, w1)^-1 = (-1)^(x1.z2 + x2.z1); with the phase c(a) (sqrt(e_j^2) on each generator, -i on the odd ones) the labels\' sign rule is Weil\'s cocycle of formula (4) up to the coboundary of c: s(a, b) c(a xor b) = c(a) c(b) F(phi a, phi b) on all %d pairs' % npairs2)
ok3 = True
for m in range(1, 5):
    G2 = 1 << (2 * m)
    for w1 in range(G2):
        for w2 in range(G2):
            if U(w1, m) * U(w2, m) != U(w1 ^ w2, m).scaled(FT[m][w1][w2]): ok3 = False
X = [[(0, 0), (1, 0)], [(1, 0), (0, 0)]]; Zm = [[(1, 0), (0, 0)], [(0, 0), (-1, 0)]]; iY = [[(0, 0), (1, 0)], [(-1, 0), (0, 0)]]   # i [[0, -i], [i, 0]]
pauli = U(0b01, 1).dense() == X and U(0b10, 1).dense() == Zm and U(0b11, 1).dense() == iY
chk('std', ok3 and pauli, 'wh.HEIS: Weil\'s operators of n. 4 on L2((Z/2)^m), (U(w) Phi)(y) = Phi(y + x) (-1)^(y.z), are monomial matrices with U(w1) U(w2) = F(w1, w2) U(w1 + w2), F(w1, w2) = (-1)^(x1.z2), on all pairs for m = 1, 2, 3, 4 (formula (4)); for m = 1 they are the Pauli matrices, U(1,0) = X, U(0,1) = Z, U(1,1) = ZX = iY (the textbook matrices, no label used)')
ok4 = True; oksq = True
for p, q in cells(8, 2, 2):
    n = p + q; m = n // 2; N = 1 << n; br = SBR[(p, q)]; phi, c = TAB[(p, q)]
    Ms = [U(phi[a], m).scaled(c[a]) for a in range(N)]
    for a in range(N):
        for b in range(N):
            if Ms[a] * Ms[b] != Ms[a ^ b].scaled(sexp(br.s(a, b))): ok4 = False; break
        if not ok4: break
    eps = sig(p, q)
    for j in range(n):
        if Ms[1 << j] * Ms[1 << j] != U(0, m).scaled(0 if eps[j] == 1 else 2): oksq = False
chk('bit==std', ok4 and oksq, 'wh.HEIS: the matrices M(a) = c(a) U(phi a) on C^(2^m) multiply as the labels, M(a) M(b) = s(a,b) M(a xor b), on all pairs of the 24 cells with n = 2, 4, 6, 8, and M(e_j)^2 = e_j^2: e_a -> M(a) represents the labels\' Clifford algebra, complexified, on L2((Z/2)^(n/2)) = C^(2^(n/2)), by Weil\'s operators')

# ================================================================================================ wh.SVN
head('wh.SVN: the finite Stone-von Neumann theorem on the labels')
ok5 = True
for p, q in cells(8, 2, 2):
    n = p + q; m = n // 2; N = 1 << n; phi, c = TAB[(p, q)]
    Ms = [U(phi[a], m).scaled(c[a]) for a in range(N)]
    tr = [M.trace() for M in Ms]
    if tr[0] != (1 << m, 0) or any(tr[a] != (0, 0) for a in range(1, N)): ok5 = False
    if 4 * sum(x * x + y * y for x, y in tr) != 4 * N: ok5 = False        # sum over H = {t e_a} of |chi|^2 = |H| = 4 * 2^n
    for a in range(N):                                                     # tr(M(a)* M(b)) = 2^m [a = b]
        ia = Ms[a].inv()
        for b in range(N):
            if (ia * Ms[b]).trace() != ((1 << m, 0) if a == b else (0, 0)): ok5 = False
chk('bit', ok5, 'wh.SVN: on the 24 cells with n = 2, 4, 6, 8, tr M(a) = 2^(n/2) for a = 0 and 0 for every other label; summed over the group H of the t e_a (t in {1, i, -1, -i}, of order 4 2^n) the squares |tr|^2 give |H|, so L2((Z/2)^(n/2)) is an irreducible module of H; the 2^n matrices are trace-orthogonal, tr(M(a)* M(b)) = 2^(n/2) [a = b], a basis of M_(2^(n/2))(C): the complexified Clifford algebra of the cell is M_(2^(n/2))(C)')
ok6 = True; n_even = n_odd = 0
for p, q in cells(8, 1):
    n = p + q; N = 1 << n; br = SBR[(p, q)]
    if n % 2 == 0:
        n_even += 1
        if not all(any(br.s(a, b) != br.s(b, a) for b in range(1, N)) for a in range(1, N)): ok6 = False
for p, q in cells(7, 1, 2):
    n = p + q; m = (n - 1) // 2; N = 1 << n; u = N - 1; br = SBR[(p, q)]; eps = sig(p, q); n_odd += 1
    central = all(br.s(u, b) == br.s(b, u) for b in range(N))
    witnesses = all(any(br.s(a, b) != br.s(b, a) for b in range(1, N)) for a in range(1, N) if a != u)
    phi, c = phi_table(2 * m, eps[:2 * m], MAIN_STRING, MAIN_SQUARE)
    half = 1 << (2 * m); lam_sq = sexp(br.s(u, u))                         # e_u^2 = +1 or -1; lambda^2 = e_u^2
    traces_at_u = []
    for lam in (lam_sq // 2, lam_sq // 2 + 2):                            # the two square roots, as exponents of i
        Ms = [None] * N
        for a in range(half): Ms[a] = U(phi[a], m).scaled(c[a])
        for a in range(half, N):
            a1 = a ^ u; Ms[a] = Ms[a1].scaled((sexp(br.s(a1, u)) + lam) % 4)   # e_a = s(a1, u) e_a1 e_u, e_u acting as i^lam
        rep = all(Ms[a] * Ms[b] == Ms[a ^ b].scaled(sexp(br.s(a, b))) for a in range(N) for b in range(N))
        tr = [M.trace() for M in Ms]
        irred = 4 * sum(x * x + y * y for x, y in tr) == 4 * N               # |H| = 4 2^n
        if not (rep and irred and tr[0] == (1 << m, 0)): ok6 = False
        traces_at_u.append(tr[u])
    if not (central and witnesses and traces_at_u[0] != traces_at_u[1] and traces_at_u[0] == tuple(-t for t in traces_at_u[1])): ok6 = False
chk('bit', ok6, 'wh.SVN: the finite Stone-von Neumann theorem: for the %d cells with n = 2, 4, 6, 8 every label a != 0 has a label b with e_b e_a = -e_a e_b, so the character of an irreducible module on which i acts as i vanishes off the centre {1, i, -1, -i} and is the character of L2((Z/2)^(n/2)): one such module up to equivalence, of dimension 2^(n/2), the spinor module; for the %d cells with n = 1, 3, 5, 7 the top label u is central, every other label a != 0 has such a b, and the two modules on C^(2^((n-1)/2)) with e_u acting as +sqrt(e_u^2) or -sqrt(e_u^2) are representations (all pairs), irreducible (the sum of |tr|^2 over H is |H|) and told apart by tr e_u: there are two' % (n_even, n_odd))

# ================================================================================================ wh.THM1
head('wh.THM1: Weil\'s Theorem 1 for G = (Z/2)^m (n. 5, 8-10): the automorphisms of A(G) fixing its centre, implemented by unitaries')
def apply_lin(S, w, n2):
    r = 0
    for i in range(n2):
        if (w >> i) & 1: r ^= S[i]
    return r
def invertible(S, n2):
    M = list(S); r = 0
    for col in range(n2):
        piv = next((i for i in range(r, n2) if (M[i] >> col) & 1), None)
        if piv is None: continue
        M[r], M[piv] = M[piv], M[r]
        for i in range(n2):
            if i != r and (M[i] >> col) & 1: M[i] ^= M[r]
        r += 1
    return r == n2
def symplectic(S, m):
    n2 = 2 * m
    return all(Bform(S[i], S[j], m) == Bform(1 << i, 1 << j, m) for i in range(n2) for j in range(i + 1, n2))
def lin_maps(m):
    """every invertible linear map of G x G* (the images of the 2m basis vectors), and the symplectic ones"""
    n2 = 2 * m
    allinv = [list(imgs) for imgs in itertools.product(range(1, 1 << n2), repeat=n2) if invertible(imgs, n2)]
    return allinv, [S for S in allinv if symplectic(S, m)]
def transvection(v, m):
    return [(1 << i) ^ (v if Bform(1 << i, v, m) else 0) for i in range(2 * m)]
def swap01(w):
    """the exchange of the first two basis vectors of G (bits 0 and 1 of the x part): invertible, and not symplectic (z_0, z_1 stay)"""
    return (w & ~3) | ((w & 1) << 1) | ((w >> 1) & 1)
def solve6(S, m, count_all=True):
    """the solutions f = i^q of relation (6): q(w1 + w2) - q(w1) - q(w2) = D(w1, w2) mod 4 with D = F(w1 S, w2 S) - F(w1, w2) (exponents);
    D is bilinear; (6) forces D symmetric and q(e_i) = D(e_i, e_i)/2 mod 2, so q is fixed by 0 or 2 added on each basis vector: 4^m candidates,
    each checked on all pairs (m <= 3) or on basis x all (m = 4, enough as D is bilinear); count_all=False tries the first candidate only"""
    n2 = 2 * m; N = 1 << n2; F = FT[m]; img = [apply_lin(S, w, n2) for w in range(N)]
    D = [[(F[img[w1]][img[w2]] - F[w1][w2]) % 4 for w2 in range(N)] for w1 in range(N)]
    if any(D[1 << i][1 << j] != D[1 << j][1 << i] for i in range(n2) for j in range(n2)): return []
    out = []
    for choice in (range(1 << n2) if count_all else [0]):
        base = [(D[1 << i][1 << i] // 2) % 2 + 2 * ((choice >> i) & 1) for i in range(n2)]
        q = [0] * N
        for w in range(1, N):
            j = w.bit_length() - 1; w0 = w ^ (1 << j)
            q[w] = (q[w0] + base[j] + D[w0][1 << j]) % 4
        rng1 = range(N) if m <= 3 else [1 << i for i in range(n2)]
        if all((q[w1 ^ w2] - q[w1] - q[w2] - D[w1][w2]) % 4 == 0 for w1 in rng1 for w2 in range(N)): out.append(q)
    return out
def gm(a, b): return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])
def intertwiner(S, f, m):
    """s = sum over v of U(v) E_(a,b) V(v)^-1 with V(v) = f(v) U(v sigma): U(v) E_(a,b) has its one entry in the row y with U(v).col[y] = a,
    and row b of V(v)^-1 = V(v)* has its one entry in the column k with U(v sigma).col[k] = b, conj(i^(f(v) + ph[k])); the first (a, b) with s != 0"""
    n2 = 2 * m; N = 1 << n2; M = 1 << m
    for a, b in [(0, 0)] + [(a, b) for a in range(M) for b in range(M) if (a, b) != (0, 0)]:
        s = [[[0, 0] for _ in range(M)] for _ in range(M)]
        for v in range(N):
            Uv = U(v, m); Wv = U(apply_lin(S, v, n2), m)
            y = Uv.col.index(a); k = Wv.col.index(b)
            g = GI[(Uv.ph[y] - Wv.ph[k] - f[v]) % 4]
            s[y][k][0] += g[0]; s[y][k][1] += g[1]
        mat = [[tuple(e) for e in row] for row in s]
        if any(e != (0, 0) for row in mat for e in row): return mat
    return None
def mono_left(Mo, A): return [[gm(GI[Mo.ph[y]], A[Mo.col[y]][j]) for j in range(len(A))] for y in range(len(A))]
def mono_right(A, Mo):
    M = len(A); R = [[(0, 0)] * M for _ in range(M)]
    for k in range(M):
        g = GI[Mo.ph[k]]
        for y in range(M): R[y][Mo.col[k]] = gm(A[y][k], g)
    return R
def implements(s, S, f, m, all_w):
    n2 = 2 * m; M = 1 << m
    for w in (range(1 << n2) if all_w else [1 << i for i in range(n2)]):
        if mono_left(U(w, m), s) != mono_right(s, U(apply_lin(S, w, n2), m).scaled(f[w])): return False
    P = [[(sum(s[i][k][0] * s[j][k][0] + s[i][k][1] * s[j][k][1] for k in range(M)),
           sum(s[i][k][1] * s[j][k][0] - s[i][k][0] * s[j][k][1] for k in range(M))) for j in range(M)] for i in range(M)]
    lam = P[0][0]
    return lam[1] == 0 and lam[0] > 0 and all(P[i][j] == (lam if i == j else (0, 0)) for i in range(M) for j in range(M))
ok7 = True; ok8 = True; counts = {}; SP = {}
for m in (1, 2):
    allinv, sp = lin_maps(m); SP[m] = (allinv, sp)
    use = sp if (FAULT != 'NONSYMP' or m == 1) else [S for S in allinv if not symplectic(S, m)]   # m = 1: GL(2, 2) = Sp(2, 2), none outside
    tv = [transvection(v, m) for v in range(1, 1 << (2 * m))]
    gen = {tuple(1 << i for i in range(2 * m))}; frontier = list(gen)
    while frontier:
        nxt = []
        for S in frontier:
            for T in tv:
                C = tuple(apply_lin(T, S[i], 2 * m) for i in range(2 * m))
                if C not in gen: gen.add(C); nxt.append(C)
        frontier = nxt
    nb0 = 0
    for S in use:
        sols = solve6(S, m)
        nb0 += len(sols)
        if len(sols) != 4 ** m: ok8 = False; continue
        s = intertwiner(S, sols[0], m)
        if s is None or not implements(s, S, sols[0], m, all_w=True): ok8 = False
    counts[m] = (len(sp), len(tv), len(gen), nb0)
    if not (all(tuple(T) in gen for T in tv) and len(gen) == len(sp) == (6 if m == 1 else 720) and nb0 == len(sp) * 4 ** m): ok7 = False
for m in (3, 4):
    for v in range(1, 1 << (2 * m)):
        S = transvection(v, m)
        if FAULT == 'NONSYMP': S = [swap01(S[i]) for i in range(2 * m)]   # then exchange e_0 and e_1 of G: invertible, not symplectic
        sols = solve6(S, m, count_all=False)
        if len(sols) != 1: ok8 = False; continue
        s = intertwiner(S, sols[0], m)
        if s is None or not implements(s, S, sols[0], m, all_w=False): ok8 = False
span = True
for m in range(1, 5):
    G2 = 1 << (2 * m)
    for w in range(G2):
        iw = U(w, m).inv()
        for w2 in range(G2):
            if (iw * U(w2, m)).trace() != (((1 << m), 0) if w == w2 else (0, 0)): span = False
chk('std', ok7, 'wh.THM1: Sp(2m, F2), the automorphisms of G x G* that keep the commutation form, enumerated among the invertible maps: %d elements for m = 1 and %d for m = 2, the group generated by the %d and %d transvections w -> w + B(w, v) v (closure from the identity); for each sigma relation (6) has exactly 4^m solutions f, functions with values in {1, i, -1, -i} (two of them differ by a character, an inner automorphism), so Weil\'s B0(G) has %d and %d elements, |Sp(2m, 2)| 4^m' % (counts[1][0], counts[2][0], counts[1][1], counts[2][1], counts[1][3], counts[2][3]))
chk('std', ok8 and span, 'wh.THM1: Weil\'s Theorem 1: for every sigma of Sp(2, 2) and Sp(4, 2) (6, 720) and every transvection of Sp(6, 2) and Sp(8, 2) (63, 255, which generate them, CAND-008), with one f of (6) (the others differ by a character, an inner automorphism induced by a U(v)), an intertwiner s with U(w) s = s f(w) U(w sigma), relation (15), built as the sum over v of U(v) E (f(v) U(v sigma))^-1 for a matrix unit E (exact over Z[i]), checked on every w for m <= 2 and on the 2m generators for m = 3, 4 (then on every w, both sides being projective representations with the cocycle F), with s s* = lambda 1, lambda > 0, so that s / sqrt(lambda) is the unitary of the theorem; the 4^m matrices U(w) are trace-orthogonal (m <= 4, all pairs), a basis of M_(2^m)(C), so the centraliser of A(G) is the scalars and the unitary is unique up to one')
# --- the map (sigma, f) -> sigma of B0 onto Sp(2m, F2): a complement for m = 1, none for m = 2
def b0_elements(S, m, sols):
    n2 = 2 * m; N = 1 << n2; img = tuple(apply_lin(S, w, n2) for w in range(N))
    return [(img, tuple(q)) for q in sols]
def b0_compose(e1, e2):                                                     # e1 then e2: (sigma1 sigma2, w -> f1(w) f2(w sigma1))
    (S1, q1), (S2, q2) = e1, e2
    return (tuple(S2[x] for x in S1), tuple((q1[w] + q2[S1[w]]) % 4 for w in range(len(S1))))
def generated(gens, cap):
    N = len(gens[0][0]); e = (tuple(range(N)), (0,) * N); seen = {e}; frontier = [e]
    while frontier:
        nxt = []
        for a in frontier:
            for g in gens:
                c = b0_compose(a, g)
                if c not in seen:
                    seen.add(c); nxt.append(c)
                    if len(seen) > cap: return len(seen)
        frontier = nxt
    return len(seen)
def sp_generated(A, B, m):
    n2 = 2 * m; e = tuple(1 << i for i in range(n2)); seen = {e}; frontier = [e]
    while frontier:
        nxt = []
        for a in frontier:
            for g in (A, B):
                c = tuple(apply_lin(g, a[i], n2) for i in range(n2))
                if c not in seen: seen.add(c); nxt.append(c)
        frontier = nxt
    return len(seen)
split = {}
for m in (1, 2):
    sp = SP[m][1]; A = transvection(1, m)
    B = next(T for T in sp if sp_generated(A, T, m) == len(sp))           # the first element that generates Sp(2m, 2) with the transvection by e_0
    LA, LB = b0_elements(A, m, solve6(A, m)), b0_elements(B, m, solve6(B, m))
    sizes = [generated([a, b], len(sp)) for a in LA for b in LB]
    split[m] = (len(LA), len(LB), sum(1 for k in sizes if k == len(sp)))
chk('std', split[1][0] * split[1][1] == 16 and split[1][2] > 0 and split[2][0] * split[2][1] == 256 and split[2][2] == 0, 'wh.THM1: the map (sigma, f) -> sigma of B0 onto Sp(2m, F2), kernel the 4^m inner automorphisms: for m = 1, of the 16 pairs of lifts of two elements generating Sp(2, 2), %d generate a group of 6 elements, a complement (B0(Z/2) is a split extension of Sp(2, 2)); for m = 2, of the 256 pairs of lifts of two elements generating Sp(4, 2), %d generate a group of 720 elements, so no subgroup of B0((Z/2)^2) maps isomorphically onto Sp(4, F2): a non-split extension, and Theorem 1 gives a projective representation of B0, not of Sp(4, F2)' % (split[1][2], split[2][2]))
# --- LAB-028's operators of the one-generator cell: S = t0(i^w), H = d'0 on L2(Z/2), exactly in Q(zeta)
def zmul(a, b):
    r = [Fr(0)] * 8
    for i in range(4):
        if a[i]:
            for j in range(4):
                if b[j]: r[i + j] += a[i] * b[j]
    return tuple(r[k] - r[k + 4] for k in range(4))
def zadd(a, b): return tuple(a[k] + b[k] for k in range(4))
ZERO = (Fr(0),) * 4; ONE = (Fr(1), Fr(0), Fr(0), Fr(0))
def zeta_pow(k): k %= 8; return tuple(Fr((1 if k < 4 else -1) if i == k % 4 else 0) for i in range(4))
def zconj(a): return (a[0], -a[3], -a[2], -a[1])                          # zeta^j -> zeta^-j = -zeta^(4-j)
SQRT2_INV = (Fr(0), Fr(1, 2), Fr(0), Fr(-1, 2))                             # 1/sqrt 2 = (zeta - zeta^3)/2
def mmul(A, B): return tuple(tuple(zadd(zmul(A[i][0], B[0][j]), zmul(A[i][1], B[1][j])) for j in range(2)) for i in range(2))
def mstar(A): return ((zconj(A[0][0]), zconj(A[1][0])), (zconj(A[0][1]), zconj(A[1][1])))
def scal(k): return ((zeta_pow(k), ZERO), (ZERO, zeta_pow(k)))
def w_of(p, q):                                                             # LAB-028's w(a) = (|a| mod 2) + 2 [e_a^2 = -1], from the kernel
    br = BR(sig(p, q)); return [((pc(a) & 1) + 2 * (1 if br.sq(a) == -1 else 0)) % 4 for a in range(2)]
w10 = w_of(1, 0); w01 = w_of(0, 1)
if FAULT == 'REAL': w10 = [2 * (a & 1) for a in range(2)]                  # (-1)^x: the real character, Z = S^2
Smat = ((zeta_pow(2 * w10[0]), ZERO), (ZERO, zeta_pow(2 * w10[1])))
S2mat = ((zeta_pow(2 * w01[0]), ZERO), (ZERO, zeta_pow(2 * w01[1])))
# d'0 with the dual measure: |rho^-1|^(-1/2) Phi*(-x rho^-1), the counting measure on Z/2 and its dual 1/2: entries 2^(-1/2) (-1)^(x.y)
Hmat = tuple(tuple(SQRT2_INV if not (x & y) else zmul(zeta_pow(4), SQRT2_INV) for y in range(2)) for x in range(2))
def gen_group(gens):
    I2 = scal(0); seen = {I2}; frontier = [I2]
    while frontier and len(seen) <= 4000:
        nxt = []
        for A in frontier:
            for g in gens:
                C = mmul(A, g)
                if C not in seen: seen.add(C); nxt.append(C)
        frontier = nxt
    return seen
def to_z(Mo): return tuple(tuple((Fr(v[0]), Fr(0), Fr(v[1]), Fr(0)) for v in row) for row in Mo.dense())
TV1 = {tuple(transvection(v, 1)) for v in range(1, 4)}
def normalises(g):
    """g U(w) g^-1 = phase U(w sigma) for w = (1,0), (0,1); returns sigma (images of the basis) or None"""
    img = []
    for w in (0b01, 0b10):
        C = mmul(mmul(g, to_z(U(w, 1))), mstar(g)); hit = [w2 for w2 in range(4) for e in range(4) if C == to_z(U(w2, 1).scaled(e))]
        if len(hit) != 1: return None
        img.append(hit[0])
    return img
grp = gen_group([Smat, Hmat]); scalars = [k for k in range(8) if scal(k) in grp]
centre = [g for g in grp if mmul(g, Smat) == mmul(Smat, g) and mmul(g, Hmat) == mmul(Hmat, g)]
SH = mmul(Smat, Hmat); SH3 = mmul(mmul(SH, SH), SH)
S2H = mmul(S2mat, Hmat); S2H3 = mmul(mmul(S2H, S2H), S2H); grp2 = gen_group([S2mat, Hmat])
sigS = normalises(Smat); sigH = normalises(Hmat)
unitary = all(mmul(g, mstar(g)) == scal(0) for g in (Smat, Hmat, S2mat))
ok9 = (unitary and len(grp) == 192 and scalars == list(range(8)) and set(centre) == {scal(k) for k in range(8)} and SH3 == scal(1) and S2H3 == scal(7)
       and len(grp2) == 192 and sigS is not None and sigH is not None and tuple(sigS) in TV1 and tuple(sigH) in TV1 and len(grp) // len(scalars) == 24)
chk('bit==std', ok9, 'wh.THM1: LAB-028\'s operators of the one-generator cell Cl(1,0) (in LAB-028 the labels of a cell are G itself, here G = Z/2), S = t0(i^w) with w read from the kernel (diag(1, i)) and H = d\'0 by Weil\'s formula with the dual measure ((1/sqrt 2)(-1)^(x.y)), act on L2(Z/2), are unitary and normalise the U(w) of G = Z/2, each with sigma a transvection of Sp(2, 2) (A(Z/2) is, by wh.HEIS, the Heisenberg group of the two-generator cells); they generate %d unitaries, exactly over Q(zeta), zeta = exp(i pi/4), and the centre of that group is exactly its %d scalars, zeta^k for k = %s, the eight eighth roots of unity; (SH)^3 = zeta 1, the clock\'s phase of Cl(1,0); with S\' = t0(i^w) of Cl(0,1) (diag(1, -i)), (S\'H)^3 = zeta^-1 1 and again %d elements; modulo the scalars %d elements, the order of B0(Z/2): the Clifford group of one qubit up to the scalars, every automorphism of A(Z/2) fixing its centre induced by an element of the group of S and H' % (len(grp), len(centre), ', '.join(map(str, scalars)), len(grp2), len(grp) // max(1, len(scalars))))

# ================================================================================================ controls, computed in place
head('controls: the Jordan-Wigner string, the squares, the symplectic condition, a real character in place of i^w')
nostring_bad = 0; nosquare_bad = 0; nosquare_q0_ok = True
for p, q in cells(8, 2, 2):
    n = p + q; m = n // 2; N = 1 << n; br = SBR[(p, q)]; eps = sig(p, q)
    ph0, _ = phi_table(n, eps, string=False)
    if any(br.s(a, b) * br.s(b, a) != (-1) ** Bform(ph0[a], ph0[b], m) for a in range(N) for b in range(N)): nostring_bad += 1
    phi, c0 = phi_table(n, eps, square=False)
    holds = all((sexp(br.s(a, b)) + c0[a ^ b]) % 4 == (c0[a] + c0[b] + FT[m][phi[a]][phi[b]]) % 4 for a in range(N) for b in range(N))
    if q >= 1 and not holds: nosquare_bad += 1
    if q == 0 and not holds: nosquare_q0_ok = False
n_m2 = len(cells(8, 4, 2)); n_q1 = len([1 for p, q in cells(8, 2, 2) if q >= 1])
chk('ctl', nostring_bad == n_m2 and nosquare_bad == n_q1 and nosquare_q0_ok, 'wh.HEIS: the Jordan-Wigner string matters: without it (e_(2k) -> (e_k, 0), e_(2k+1) -> (e_k, e_k)) the map does not carry the commutation sign for any of the %d cells with n = 4, 6, 8 (for n = 2 the string is empty) (NOSTRING); the squares matter: with the phases c(e_j) taken without sqrt(e_j^2) the cocycle identity fails for every one of the %d cells with q >= 1 and holds for those with q = 0 (NOSQUARE)' % (nostring_bad, nosquare_bad))
allinv2, sp2 = SP[2]
nons = [S for S in allinv2 if not symplectic(S, 2)]
unsolved = sum(1 for S in nons if not solve6(S, 2, count_all=False))
chk('ctl', len(allinv2) == 20160 and len(nons) == 19440 and unsolved == len(nons), 'wh.THM1: the symplectic condition matters: of the %d invertible maps of G x G* for m = 2, the %d outside Sp(4, 2) give a D(w1, w2) that is not symmetric, so relation (6) has no solution for any of them (%d): no automorphism of A(G) fixing its centre lies over them (NONSYMP)' % (len(allinv2), len(nons), unsolved))
Zmat = ((ONE, ZERO), (ZERO, zeta_pow(4)))
grpZ = gen_group([Zmat, Hmat]); scalZ = [k for k in range(8) if scal(k) in grpZ]
chk('ctl', len(grpZ) == 16 and scalZ == [0, 4], 'wh.THM1: a real character in place of i^w: with t0 of (-1)^x (Z = diag(1, -1) = S^2) in place of S, the group generated with H has %d elements and its scalars are zeta^k for k = %s, +1 and -1 only: the eighth roots of unity of the group of S and H come from i^w, which takes the values i and -i (REAL)' % (len(grpZ), ', '.join(map(str, scalZ))))
finish()
